import { createContext, useContext, useState, ReactNode } from 'react';
import { db, DBUser } from '../data/db';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'funcionario';
}

interface AppContextType {
  user: AuthUser | null;
  login: (email: string, password: string) => string | null;
  logout: () => void;
}

function toAuthUser(u: DBUser): AuthUser {
  return { id: u.id, name: u.name, email: u.email, role: u.role };
}

function restoreSession(): AuthUser | null {
  try {
    const sessionId = db.session.get();
    if (!sessionId) return null;
    const u = db.users.findById(sessionId);
    if (u && u.status === 'Ativo') return toAuthUser(u);
    db.session.clear();
  } catch {}
  return null;
}

const AppContext = createContext<AppContextType>({
  user: null,
  login: () => 'Erro',
  logout: () => {},
});

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(restoreSession);

  const login = (email: string, password: string): string | null => {
    const u = db.users.findByEmail(email);
    if (!u) return 'Usuário não encontrado. Verifique o e-mail.';
    if (u.status === 'Inativo') return 'Usuário inativo. Contate o administrador.';
    if (u.status === 'Bloqueado') return 'Usuário bloqueado. Contate o administrador.';
    if (u.password !== password) return 'Senha incorreta. Verifique suas credenciais.';
    const authUser = toAuthUser(u);
    setUser(authUser);
    db.session.set(u.id);
    return null;
  };

  const logout = () => {
    setUser(null);
    db.session.clear();
  };

  return (
    <AppContext.Provider value={{ user, login, logout }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
