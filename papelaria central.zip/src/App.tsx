import { RouterProvider } from 'react-router';
import { AppProvider } from './context/AppContext';
import { router } from './routes';
import { runMigrations } from './data/products';

// Executa migrações antes de montar o app (adiciona ~220 produtos ao banco sem apagar os cadastros manuais)
runMigrations();

export default function App() {
  return (
    <AppProvider>
      <RouterProvider router={router} />
    </AppProvider>
  );
}
