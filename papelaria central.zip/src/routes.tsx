import { createBrowserRouter, Navigate } from 'react-router';
import AppLayout from './layouts/AppLayout';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import Dashboard from './pages/Dashboard';
import Usuarios from './pages/Usuarios';
import Categorias from './pages/Categorias';
import Produtos from './pages/Produtos';
import ProdutoForm from './pages/ProdutoForm';
import Clientes from './pages/Clientes';
import Funcionarios from './pages/Funcionarios';
import Estoque from './pages/Estoque';
import Movimentacoes from './pages/Movimentacoes';
import Configuracoes from './pages/Configuracoes';
import FolhaPonto from './pages/FolhaPonto';
import Caixa from './pages/Caixa';
import VendasWhatsApp from './pages/VendasWhatsApp';
import Vendas from './pages/Vendas';
import Fornecedores from './pages/Fornecedores';
import Auditoria from './pages/Auditoria';
import Compras from './pages/Compras';
import FinanceiroLayout from './pages/financeiro/FinanceiroLayout';
import FinanceiroDashboard from './pages/financeiro/FinanceiroDashboard';
import FluxoCaixa from './pages/financeiro/FluxoCaixa';
import ContasReceber from './pages/financeiro/ContasReceber';
import Receitas from './pages/financeiro/Receitas';
import Despesas from './pages/financeiro/Despesas';
import Folha from './pages/financeiro/Folha';
import Pedidos from './pages/financeiro/Pedidos';
import Contas from './pages/financeiro/Contas';
import CustosMargem from './pages/financeiro/CustosMargem';
import Relatorios from './pages/financeiro/Relatorios';
import ConfigFinanceiro from './pages/financeiro/ConfigFinanceiro';
import IdentidadeVisual from './pages/financeiro/IdentidadeVisual';
import CaixaEmergencia from './pages/financeiro/CaixaEmergencia';
import ContasBancarias from './pages/financeiro/ContasBancarias';
import Marketing from './pages/financeiro/Marketing';
import DRE from './pages/financeiro/DRE';
import FechamentoMensal from './pages/financeiro/FechamentoMensal';
import ContasRecorrentes from './pages/financeiro/ContasRecorrentes';
import CurvaABC from './pages/financeiro/CurvaABC';
import ProdutosParados from './pages/financeiro/ProdutosParados';
import SugestaoReposicao from './pages/financeiro/SugestaoReposicao';
import OndeMeuDinheiro from './pages/financeiro/OndeMeuDinheiro';
import CentroCustos from './pages/financeiro/CentroCustos';
import ConciliacaoBancaria from './pages/financeiro/ConciliacaoBancaria';

export const router = createBrowserRouter([
  { path: '/', Component: Login },
  { path: '/cadastro', Component: Register },
  { path: '/recuperar-senha', Component: ForgotPassword },
  {
    Component: AppLayout,
    children: [
      { path: '/dashboard',            Component: Dashboard },
      { path: '/usuarios',             Component: Usuarios },
      { path: '/categorias',           Component: Categorias },
      { path: '/produtos',             Component: Produtos },
      { path: '/produtos/novo',        Component: ProdutoForm },
      { path: '/produtos/:id/editar',  Component: ProdutoForm },
      { path: '/clientes',             Component: Clientes },
      { path: '/funcionarios',         Component: Funcionarios },
      { path: '/estoque',              Component: Estoque },
      { path: '/estoque/movimentacoes', Component: Movimentacoes },
      { path: '/configuracoes',        Component: Configuracoes },
      { path: '/ponto',                Component: FolhaPonto },
      { path: '/caixa',                Component: Caixa },
      { path: '/vendas',                Component: Vendas },
      { path: '/whatsapp-pedidos',     Component: VendasWhatsApp },
      { path: '/fornecedores',         Component: Fornecedores },
      { path: '/auditoria',            Component: Auditoria },
      { path: '/compras',              Component: Compras },
      {
        path: '/financeiro',
        Component: FinanceiroLayout,
        children: [
          { index: true, Component: FinanceiroDashboard },
          { path: 'fluxo',      Component: FluxoCaixa },
          { path: 'receber',    Component: ContasReceber },
          { path: 'receitas',   Component: Receitas },
          { path: 'despesas',   Component: Despesas },
          { path: 'folha',      Component: Folha },
          { path: 'pedidos',    Component: Pedidos },
          { path: 'contas',     Component: Contas },
          { path: 'custos',     Component: CustosMargem },
          { path: 'relatorios',  Component: Relatorios },
          { path: 'config',      Component: ConfigFinanceiro },
          { path: 'identidade',  Component: IdentidadeVisual },
          { path: 'emergencia',    Component: CaixaEmergencia },
          { path: 'bancos',        Component: ContasBancarias },
          { path: 'marketing',     Component: Marketing },
          { path: 'dre',           Component: DRE },
          { path: 'fechamento',    Component: FechamentoMensal },
          { path: 'recorrentes',   Component: ContasRecorrentes },
          { path: 'curva-abc',     Component: CurvaABC },
          { path: 'parados',       Component: ProdutosParados },
          { path: 'reposicao',     Component: SugestaoReposicao },
          { path: 'posicao',       Component: OndeMeuDinheiro },
          { path: 'centrocustos',  Component: CentroCustos },
          { path: 'conciliacao',   Component: ConciliacaoBancaria },
        ],
      },
      { path: '*', element: <Navigate to="/dashboard" replace /> },
    ],
  },
]);
