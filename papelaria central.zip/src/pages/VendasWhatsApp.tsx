import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  wppDb, newWppId, nextPedidoNum,
  type WppPedido, type WppItem, type WppStatus,
  WPP_STATUS_LABELS, WPP_STATUS_NEXT,
} from '../data/wppDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER, formCard, inp, btnPrimary, btnSecondary, btnDanger } from '../theme';

const TODAY = new Date().toISOString().slice(0, 10);

function fmtBRL(v: number): string {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function fmtDate(d: string): string { return d.split('-').reverse().join('/'); }

const STATUS_STYLE: Record<WppStatus, React.CSSProperties> = {
  novo:                  { background: '#EFF6FF', color: '#1D4ED8', border: '1px solid #BFDBFE' },
  separacao:             { background: '#FFFBEB', color: '#B45309', border: '1px solid #FDE68A' },
  aguardando_pagamento:  { background: '#FDF4FF', color: '#7E22CE', border: '1px solid #E9D5FF' },
  pronto:                { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5' },
  retirado:              { background: '#F0F4FA', color: C.textMuted, border: `1px solid ${C.border}` },
  cancelado:             { background: '#FEF3F2', color: '#B42318', border: '1px solid #FECDCA' },
};

const FORMAS_PAG = ['Pix', 'Dinheiro', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência'];

type Tab = 'pedidos' | 'hoje' | 'novo';

function PedidoCard({ p, onUpdate, isAdmin }: { p: WppPedido; onUpdate: () => void; isAdmin: boolean }) {
  const { user } = useApp();
  const next = WPP_STATUS_NEXT[p.status];

  const avançar = () => {
    if (!next) return;
    const patch: Partial<WppPedido> = { status: next };
    if (next === 'retirado') {
      const now = new Date();
      patch.dataRetirada = TODAY;
      patch.horaRetirada = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
      patch.quemConfirmou = user?.name;
    }
    wppDb.pedidos.update(p.id, patch);
    onUpdate();
  };

  const cancelar = () => {
    if (!confirm('Cancelar este pedido?')) return;
    wppDb.pedidos.update(p.id, { status: 'cancelado' });
    onUpdate();
  };

  return (
    <div style={{
      ...formCard,
      marginBottom: 12,
      borderLeft: `3px solid ${p.status === 'pronto' ? '#027A48' : p.status === 'cancelado' ? '#B42318' : p.status === 'retirado' ? C.border : '#93B4D4'}`,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{p.numeroPedido}</span>
            <span style={{ ...STATUS_STYLE[p.status], borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 }}>
              {WPP_STATUS_LABELS[p.status]}
            </span>
          </div>
          <div style={{ fontWeight: 600, fontSize: 14, color: C.text }}>{p.clienteNome}</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>
            {p.clienteWhatsapp} · {fmtDate(p.dataPedido)} às {p.horaPedido} · Retirada prevista: {p.previsaoRetirada}
          </div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 18, fontWeight: 700, color: C.navy }}>{fmtBRL(p.total)}</div>
          <div style={{ fontSize: 12, color: C.textMuted }}>{p.formaPagamento}</div>
          {p.desconto > 0 && <div style={{ fontSize: 11, color: '#B54708' }}>Desconto: {fmtBRL(p.desconto)}</div>}
        </div>
      </div>

      {/* Itens */}
      <div style={{ marginBottom: 10 }}>
        {p.itens.map((item, i) => (
          <div key={i} style={{ fontSize: 12, color: C.textMuted, display: 'flex', gap: 8 }}>
            <span style={{ color: C.text, fontWeight: 500 }}>{item.qty}×</span>
            <span>{item.produtoNome}</span>
            <span style={{ marginLeft: 'auto' }}>{fmtBRL(item.qty * item.precoUnit)}</span>
          </div>
        ))}
      </div>

      {p.observacoes && (
        <div style={{ fontSize: 11, color: C.textMuted, background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 4, padding: '4px 8px', marginBottom: 10 }}>
          Obs.: {p.observacoes}
        </div>
      )}

      {p.dataRetirada && (
        <div style={{ fontSize: 11, color: '#027A48', marginBottom: 8 }}>
          ✓ Retirado em {fmtDate(p.dataRetirada)} às {p.horaRetirada} · Confirmado por: {p.quemConfirmou}
        </div>
      )}

      {/* Actions */}
      <div style={{ display: 'flex', gap: 8 }}>
        {next && p.status !== 'cancelado' && p.status !== 'retirado' && (
          <button onClick={avançar} style={btnPrimary}>
            {next === 'separacao' ? 'Iniciar separação' : next === 'aguardando_pagamento' ? 'Ag. pagamento' : next === 'pronto' ? 'Marcar pronto' : 'Confirmar retirada'}
          </button>
        )}
        {isAdmin && p.status !== 'cancelado' && p.status !== 'retirado' && (
          <button onClick={cancelar} style={btnDanger}>Cancelar pedido</button>
        )}
        <div style={{ marginLeft: 'auto', fontSize: 11, color: C.textMuted, alignSelf: 'center' }}>
          {p.responsavelNome}
        </div>
      </div>
    </div>
  );
}

function NovoPedidoForm({ onSave, onCancel }: { onSave: () => void; onCancel: () => void }) {
  const { user } = useApp();
  const [form, setForm] = useState({
    clienteNome: '', clienteWhatsapp: '',
    previsaoRetirada: '15:00', formaPagamento: 'Pix',
    observacoes: '', desconto: '',
  });
  const [itens, setItens] = useState<WppItem[]>([
    { produtoNome: '', qty: 1, precoUnit: 0 },
  ]);
  const [err, setErr] = useState('');

  const subtotal = itens.reduce((a, it) => a + it.qty * it.precoUnit, 0);
  const desconto = parseFloat(form.desconto.replace(',', '.')) || 0;
  const total = Math.max(0, subtotal - desconto);

  const addItem = () => setItens(x => [...x, { produtoNome: '', qty: 1, precoUnit: 0 }]);
  const removeItem = (i: number) => setItens(x => x.filter((_, j) => j !== i));
  const updateItem = (i: number, patch: Partial<WppItem>) =>
    setItens(x => x.map((it, j) => j === i ? { ...it, ...patch } : it));

  const salvar = () => {
    if (!form.clienteNome || !form.clienteWhatsapp) { setErr('Informe cliente e WhatsApp.'); return; }
    const validItens = itens.filter(it => it.produtoNome && it.qty > 0);
    if (validItens.length === 0) { setErr('Adicione pelo menos um produto.'); return; }
    const now = new Date();
    const hora = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    const p: WppPedido = {
      id: newWppId(), numeroPedido: nextPedidoNum(),
      clienteNome: form.clienteNome, clienteWhatsapp: form.clienteWhatsapp,
      itens: validItens, subtotal, desconto, total,
      formaPagamento: form.formaPagamento, observacoes: form.observacoes,
      dataPedido: TODAY, horaPedido: hora, previsaoRetirada: form.previsaoRetirada,
      responsavelId: user?.id ?? '', responsavelNome: user?.name ?? '',
      status: 'novo', createdAt: new Date().toISOString(),
    };
    wppDb.pedidos.add(p);
    onSave();
  };

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.text,
  };

  return (
    <div style={{ ...formCard, maxWidth: 640 }}>
      <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16 }}>Novo pedido WhatsApp</div>

      {err && <div style={{ background: '#FEF3F2', border: '1px solid #FECDCA', borderRadius: 4, padding: '6px 10px', marginBottom: 12, fontSize: 13, color: '#B42318' }}>{err}</div>}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Nome do cliente *</label>
          <input value={form.clienteNome} onChange={e => setForm(f => ({ ...f, clienteNome: e.target.value }))} style={inp(false)} placeholder="Ex.: Ana Silva" />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>WhatsApp *</label>
          <input value={form.clienteWhatsapp} onChange={e => setForm(f => ({ ...f, clienteWhatsapp: e.target.value }))} style={inp(false)} placeholder="(11) 99999-9999" />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Previsão de retirada</label>
          <input type="time" value={form.previsaoRetirada} onChange={e => setForm(f => ({ ...f, previsaoRetirada: e.target.value }))} style={sinp} />
        </div>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Forma de pagamento</label>
          <select value={form.formaPagamento} onChange={e => setForm(f => ({ ...f, formaPagamento: e.target.value }))} style={sinp}>
            {FORMAS_PAG.map(p => <option key={p}>{p}</option>)}
          </select>
        </div>
      </div>

      {/* Itens */}
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 6 }}>Produtos</div>
        {itens.map((it, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 60px 100px 30px', gap: 8, marginBottom: 6, alignItems: 'center' }}>
            <input value={it.produtoNome} onChange={e => updateItem(i, { produtoNome: e.target.value })} style={inp(false)} placeholder="Nome do produto" />
            <input type="number" min={1} value={it.qty} onChange={e => updateItem(i, { qty: +e.target.value })} style={sinp} placeholder="Qtd" />
            <input type="number" min={0} step={0.01} value={it.precoUnit || ''} onChange={e => updateItem(i, { precoUnit: +e.target.value })} style={sinp} placeholder="Preço unit." />
            <button onClick={() => removeItem(i)} disabled={itens.length === 1} style={{ color: '#B42318', background: 'none', border: 'none', cursor: 'pointer', fontSize: 16 }}>×</button>
          </div>
        ))}
        <button onClick={addItem} style={{ fontSize: 12, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>+ Adicionar produto</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <div>
          <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Desconto (R$)</label>
          <input value={form.desconto} onChange={e => setForm(f => ({ ...f, desconto: e.target.value }))} style={inp(false)} placeholder="0,00" />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-end' }}>
          <div style={{ fontSize: 12, color: C.textMuted }}>Subtotal: {fmtBRL(subtotal)}</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: C.navy }}>Total: {fmtBRL(total)}</div>
        </div>
      </div>

      <div style={{ marginBottom: 16 }}>
        <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Observações</label>
        <input value={form.observacoes} onChange={e => setForm(f => ({ ...f, observacoes: e.target.value }))} style={inp(false)} placeholder="Informações adicionais..." />
      </div>

      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
        <button onClick={onCancel} style={btnSecondary}>Cancelar</button>
        <button onClick={salvar} style={btnPrimary}>Criar pedido</button>
      </div>
    </div>
  );
}

export default function VendasWhatsApp() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';
  const [tab, setTab] = useState<Tab>('hoje');
  const [tick, setTick] = useState(0);
  const refresh = () => setTick(t => t + 1);

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');

  const allPedidos = useMemo(() => wppDb.pedidos.all(), [tick]);
  const pedidosHoje = useMemo(() => allPedidos.filter(p => p.dataPedido === TODAY), [allPedidos]);
  const paraRetirar = useMemo(() => allPedidos.filter(p => p.dataPedido === TODAY && (p.status === 'pronto' || p.status === 'aguardando_pagamento')), [allPedidos]);

  const filtered = useMemo(() => {
    let list = tab === 'hoje' ? pedidosHoje : allPedidos;
    if (statusFilter !== 'Todos') {
      list = list.filter(p => WPP_STATUS_LABELS[p.status] === statusFilter || p.status === statusFilter);
    }
    if (search) {
      const s = search.toLowerCase();
      list = list.filter(p => p.clienteNome.toLowerCase().includes(s) || p.numeroPedido.toLowerCase().includes(s) || p.clienteWhatsapp.includes(s));
    }
    return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }, [allPedidos, pedidosHoje, tab, statusFilter, search]);

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.text,
  };

  const tabs: { k: Tab; label: string }[] = [
    { k: 'hoje', label: `Hoje (${pedidosHoje.length})` },
    { k: 'pedidos', label: 'Todos os pedidos' },
    { k: 'novo', label: '+ Novo pedido' },
  ];

  if (tab === 'novo') {
    return (
      <div>
        <div style={{ marginBottom: 16 }}>
          <button onClick={() => setTab('hoje')} style={{ fontSize: 12, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
            ← Voltar
          </button>
        </div>
        <NovoPedidoForm onSave={() => { refresh(); setTab('hoje'); }} onCancel={() => setTab('hoje')} />
      </div>
    );
  }

  return (
    <div>
      {/* Tab nav */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.k} onClick={() => setTab(t.k)} style={{
            padding: '7px 14px', fontSize: 12, fontFamily: 'Inter, sans-serif',
            fontWeight: tab === t.k ? 600 : 400,
            color: tab === t.k ? C.navy : t.k === 'novo' ? '#027A48' : C.textMuted,
            borderBottom: tab === t.k ? `2px solid ${C.navy}` : '2px solid transparent',
            marginBottom: -1, background: 'none', border: 'none',
            borderLeft: 'none', borderRight: 'none', borderTop: 'none', cursor: 'pointer',
          }}>{t.label}</button>
        ))}
      </div>

      {/* KPIs (Hoje only) */}
      {tab === 'hoje' && (
        <div>
          {/* Para retirar agora */}
          {paraRetirar.length > 0 && (
            <div style={{ background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 6, padding: '10px 16px', marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#027A48', marginBottom: 6 }}>
                🛍 {paraRetirar.length} pedido{paraRetirar.length !== 1 ? 's' : ''} prontos para retirada hoje
              </div>
              {paraRetirar.map(p => (
                <div key={p.id} style={{ fontSize: 12, color: '#027A48', display: 'flex', gap: 12 }}>
                  <span style={{ fontFamily: 'monospace' }}>{p.numeroPedido}</span>
                  <span style={{ fontWeight: 500 }}>{p.clienteNome}</span>
                  <span>{p.clienteWhatsapp}</span>
                  <span>Prev. {p.previsaoRetirada}</span>
                  <span>{fmtBRL(p.total)}</span>
                </div>
              ))}
            </div>
          )}

          {/* Quick stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10, marginBottom: 16 }}>
            {(Object.entries(WPP_STATUS_LABELS) as [WppStatus, string][]).map(([status, label]) => {
              const count = pedidosHoje.filter(p => p.status === status).length;
              return (
                <div key={status} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '10px 12px' }}>
                  <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>{label}</div>
                  <div style={{ fontSize: 20, fontWeight: 700, color: count > 0 ? C.navy : C.textMuted }}>{count}</div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Filters */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar cliente, nº pedido, WhatsApp..." style={{ ...sinp, minWidth: 200 }} />
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={sinp}>
          <option>Todos</option>
          {(Object.entries(WPP_STATUS_LABELS) as [WppStatus, string][]).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
        </select>
        <span style={{ fontSize: 12, color: C.textMuted, marginLeft: 'auto' }}>{filtered.length} pedido{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {/* Pedido cards */}
      <div>
        {filtered.map(p => (
          <PedidoCard key={p.id} p={p} onUpdate={refresh} isAdmin={isAdmin} />
        ))}
        {filtered.length === 0 && (
          <div style={{ textAlign: 'center', padding: '40px 20px', color: C.textMuted, fontSize: 13 }}>
            {tab === 'hoje' ? 'Nenhum pedido hoje.' : 'Nenhum pedido encontrado.'}
          </div>
        )}
      </div>
    </div>
  );
}
