import { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { C, inp, btnPrimary, btnSecondary, formCard, label } from '../theme';
import { db, newId, calcStatus } from '../data/db';

const CATS = ['Cadernos', 'Escrita', 'Material Escolar', 'Acessórios', 'Organização', 'Impressão', 'Papelaria Artística'];

function nextCode(): string {
  const prods = db.products.all();
  const nums = prods.map(p => parseInt(p.code.replace('P-', '')) || 0);
  const max = nums.length ? Math.max(...nums) : 0;
  return `P-${String(max + 1).padStart(3, '0')}`;
}

export default function ProdutoForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEditing = !!id;
 

  const existing = id ? db.products.findById(id) : null;

  const [form, setForm] = useState({
    name: existing?.name ?? '',
    category: existing?.category ?? '',
    description: existing?.description ?? '',
    qty: existing?.qty !== undefined ? String(existing.qty) : '',
    price: existing?.price !== undefined ? String(existing.price) : '',
    minStock: existing?.minStock !== undefined ? String(existing.minStock) : '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState(false);

  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setErrors(x => ({ ...x, [k]: '' })); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Campo obrigatório.';
    if (!form.category) e.category = 'Selecione uma categoria.';
    if (!form.price || isNaN(Number(form.price)) || Number(form.price) <= 0) e.price = 'Informe um preço válido.';
    if (form.qty !== '' && Number(form.qty) < 0) e.qty = 'A quantidade não pode ser negativa.';
    return e;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const qty = Number(form.qty) || 0;
    const minStock = Number(form.minStock) || 0;
    const price = parseFloat(form.price);
    const status = calcStatus(qty, minStock);

    if (isEditing && existing) {
      db.products.update(existing.id, {
        name: form.name.trim(),
        category: form.category,
        description: form.description,
        qty,
        price,
        minStock,
        status,
      });
    } else {
      db.products.add({
        id: newId(),
        code: nextCode(),
        name: form.name.trim(),
        category: form.category,
        description: form.description,
        qty,
        price,
        minStock,
        status,
      });
    }

    setSaved(true);
    setTimeout(() => navigate('/produtos'), 1200);
  };

  return (
    <div style={{ maxWidth: 560 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 16, fontSize: 13, color: C.textMuted }}>
        <button onClick={() => navigate('/produtos')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.navy, fontFamily: 'Inter, sans-serif', fontSize: 13, padding: 0 }}>← Produtos</button>
        <span>/</span>
        <span style={{ color: C.text }}>{isEditing ? 'Editar produto' : 'Novo produto'}</span>
      </div>

      {saved && (
        <div style={{ background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 4, padding: '8px 12px', marginBottom: 14, fontSize: 13, color: '#027A48' }}>
          Produto {isEditing ? 'atualizado' : 'cadastrado'} com sucesso. Redirecionando...
        </div>
      )}

      <div style={formCard}>
        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="Nome do produto *" err={errors.name}>
                <input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Ex: Caderno Universitário Tilibra 10 Matérias" style={inp(!!errors.name)} />
              </F>
            </div>
            <F label="Categoria *" err={errors.category}>
              <select value={form.category} onChange={e => set('category', e.target.value)} style={inp(!!errors.category)}>
                <option value="">Selecione...</option>
                {CATS.map(c => <option key={c}>{c}</option>)}
              </select>
            </F>
            <F label="Preço unitário (R$) *" err={errors.price}>
              <input type="number" min="0.01" step="0.01" value={form.price} onChange={e => set('price', e.target.value)} placeholder="0,00" style={inp(!!errors.price)} />
            </F>
            <F label="Quantidade em estoque" err={errors.qty}>
              <input type="number" min="0" value={form.qty} onChange={e => set('qty', e.target.value)} placeholder="0" style={inp(!!errors.qty)} />
            </F>
            <F label="Estoque mínimo" err="">
              <input type="number" min="0" value={form.minStock} onChange={e => set('minStock', e.target.value)} placeholder="0" style={inp()} />
            </F>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="Descrição" err="">
                <textarea value={form.description} onChange={e => set('description', e.target.value)} placeholder="Descrição opcional..." rows={3} style={{ ...inp(), resize: 'vertical' as const }} />
              </F>
            </div>

          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20, paddingTop: 16, borderTop: `1px solid ${C.borderLight}` }}>
            <button type="button" onClick={() => navigate('/produtos')} style={btnSecondary}>Cancelar</button>
            <button type="submit" style={btnPrimary}>{isEditing ? 'Salvar alterações' : 'Cadastrar produto'}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function F({ label: lbl, err, children }: { label: string; err: string; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ ...label, display: 'block' }}>{lbl}</label>
      {children}
      {err && <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 }}>{err}</span>}
    </div>
  );
}
