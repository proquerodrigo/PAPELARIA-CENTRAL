import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { C, badge, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, inp, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { Modal, Toast } from './Produtos';
import { db, newId, calcStatus, DBProduct } from '../data/db';
import { useApp } from '../context/AppContext';

const statusBadge = (s: DBProduct['status']) =>
  s === 'Sem estoque' ? badge.noStock : s === 'Estoque baixo' ? badge.lowStock : badge.inStock;

const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 };

export default function Estoque() {
  const navigate = useNavigate();
  const { user } = useApp();
  const [items, setItems] = useState<DBProduct[]>(() => db.products.all());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [moveForm, setMoveForm] = useState({ productId: '', type: 'Entrada', qty: '' });
  const [moveError, setMoveError] = useState('');
  const [toast, setToast] = useState('');

  const refresh = () => setItems(db.products.all());

  const total = items.length;
  const inStock = items.filter(i => i.status === 'Em estoque').length;
  const lowStock = items.filter(i => i.status === 'Estoque baixo').length;
  const noStock = items.filter(i => i.status === 'Sem estoque').length;

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return items.filter(i => {
      if (statusFilter && i.status !== statusFilter) return false;
      if (q && !`${i.name} ${i.code} ${i.category}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [items, search, statusFilter]);

  const handleMove = () => {
    const item = items.find(i => i.id === moveForm.productId);
    if (!moveForm.productId) { setMoveError('Selecione um produto.'); return; }
    if (!moveForm.qty || Number(moveForm.qty) <= 0) { setMoveError('Informe uma quantidade válida.'); return; }
    if (moveForm.type === 'Saída' && item && item.qty === 0) {
      setMoveError('Não é possível registrar saída: produto sem estoque.');
      return;
    }
    setMoveError('');
    if (!item) return;

    const qty = Number(moveForm.qty);
    const newQty = moveForm.type === 'Entrada' ? item.qty + qty : Math.max(0, item.qty - qty);
    const newStatus = calcStatus(newQty, item.minStock);
    const now = new Date();
    const dateStr = now.toLocaleDateString('pt-BR');
    const timeStr = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    db.products.update(item.id, { qty: newQty, status: newStatus });
    db.movements.add({
      id: newId(),
      date: dateStr,
      time: timeStr,
      type: moveForm.type as 'Entrada' | 'Saída',
      productId: item.id,
      productName: item.name,
      qty,
      userName: user?.name ? user.name.split(' ').slice(0, 2).join(' ') : 'Sistema',
      createdAt: now.toISOString(),
    });

    refresh();
    setShowModal(false);
    setMoveForm({ productId: '', type: 'Entrada', qty: '' });
    setToast('Movimentação registrada com sucesso.');
    setTimeout(() => setToast(''), 3000);
  };

  return (
    <div>
      {toast && <Toast msg={toast} />}

      {/* Summary bar */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 1, background: C.border, border: `1px solid ${C.border}`, borderRadius: 4, overflow: 'hidden', marginBottom: 16 }}>
        {[
          { label: 'Total cadastrado', value: total, color: C.text },
          { label: 'Em estoque', value: inStock, color: C.success },
          { label: 'Estoque baixo', value: lowStock, color: '#B54708' },
          { label: 'Sem estoque', value: noStock, color: C.error },
        ].map((s, i) => (
          <div key={i} style={{ background: C.white, padding: '12px 16px' }}>
            <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>{s.label}</div>
            <div style={{ fontSize: 20, fontWeight: 600, color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 14, flexWrap: 'wrap' }}>
        {/* Search */}
        <div style={{ position: 'relative', flex: '1 1 220px', minWidth: 180 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={C.textMuted} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
            style={{ position: 'absolute', left: 9, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
            <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
          </svg>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Buscar produto, código, categoria..."
            style={{ ...inp(), paddingLeft: 30 }}
          />
        </div>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ ...inp(), width: 160 }}>
          <option value="">Todos os status</option>
          <option>Em estoque</option>
          <option>Estoque baixo</option>
          <option>Sem estoque</option>
        </select>
        {(search || statusFilter) && (
          <button onClick={() => { setSearch(''); setStatusFilter(''); }} style={{ ...btnSecondary, fontSize: 12 }}>Limpar</button>
        )}
        <div style={{ flex: 1 }} />
        <button onClick={() => navigate('/estoque/movimentacoes')} style={{ padding: '6px 14px', background: C.white, color: C.text, border: `1px solid ${C.border}`, borderRadius: 4, fontSize: 13, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
          Ver movimentações
        </button>
        <button onClick={() => setShowModal(true)} style={btnPrimary}>Registrar movimentação</button>
      </div>
      {(search || statusFilter) && (
        <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 8 }}>
          {filtered.length} de {total} produto{total !== 1 ? 's' : ''}
        </div>
      )}

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Código', 'Produto', 'Qtd. atual', 'Est. mínimo', 'Situação', 'Categoria'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((item, i) => (
              <tr key={item.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{item.code}</td>
                <td style={{ ...TD, fontWeight: 500 }}>{item.name}</td>
                <td style={{ ...TD, fontWeight: 600, color: item.qty === 0 ? C.error : item.qty <= item.minStock ? '#B54708' : C.text }}>{item.qty} un.</td>
                <td style={{ ...TD, color: C.textMuted }}>{item.minStock} un.</td>
                <td style={TD}><Badge style={statusBadge(item.status)}>{item.status}</Badge></td>
                <td style={{ ...TD, color: C.textMuted }}>{item.category}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title="Registrar movimentação" onClose={() => { setShowModal(false); setMoveError(''); }}>
          {moveError && (
            <div style={{ background: '#FEF3F2', border: '1px solid #FECDCA', borderRadius: 4, padding: '7px 12px', marginBottom: 14, fontSize: 13, color: '#B42318' }}>
              {moveError}
            </div>
          )}
          <div style={{ marginBottom: 12 }}>
            <label style={lbl}>Produto</label>
            <select value={moveForm.productId} onChange={e => { setMoveForm(f => ({ ...f, productId: e.target.value })); setMoveError(''); }} style={inp()}>
              <option value="">Selecione o produto...</option>
              {items.map(i => <option key={i.id} value={i.id}>{i.name} (estoque: {i.qty})</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={lbl}>Tipo de movimentação</label>
            <select value={moveForm.type} onChange={e => setMoveForm(f => ({ ...f, type: e.target.value }))} style={inp()}>
              <option>Entrada</option>
              <option>Saída</option>
            </select>
          </div>
          <div style={{ marginBottom: 18 }}>
            <label style={lbl}>Quantidade</label>
            <input type="number" min="1" value={moveForm.qty} onChange={e => setMoveForm(f => ({ ...f, qty: e.target.value }))} placeholder="0" style={inp()} />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => { setShowModal(false); setMoveError(''); }} style={btnSecondary}>Cancelar</button>
            <button onClick={handleMove} style={btnPrimary}>Confirmar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
