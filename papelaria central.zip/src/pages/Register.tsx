import { useState } from 'react';
import { useNavigate } from 'react-router';
import { db, newId, ACCESS_KEY } from '../data/db';

const PHOTO_URL =
  'https://images.unsplash.com/photo-1590019012497-b44f1aaa40d3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800';

/* subtle diamond pattern for the background */
const PATTERN_BG = `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23B8B8B8' fill-opacity='0.18'%3E%3Cpolygon points='30 0 60 30 30 60 0 30'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`;

export default function Register() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '', accessKey: '' });
  const [showPw, setShowPw] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState(false);

  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setErrors(x => ({ ...x, [k]: '' })); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Preencha o nome completo.';
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = 'E-mail inválido.';
    if (form.password.length < 8) e.password = 'Mínimo de 8 caracteres.';
    if (form.confirm !== form.password) e.confirm = 'As senhas não coincidem.';
    if (!form.accessKey.trim()) e.accessKey = 'Informe a chave de acesso.';
    else if (form.accessKey.trim().toUpperCase() !== ACCESS_KEY) e.accessKey = 'Chave de acesso inválida.';
    return e;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const existing = db.users.findByEmail(form.email.trim());
    if (existing) { setErrors({ email: 'E-mail já cadastrado no sistema.' }); return; }
    db.users.add({
      id: newId(),
      name: form.name.trim(),
      email: form.email.trim().toLowerCase(),
      password: form.password,
      role: 'funcionario',
      status: 'Ativo',
      cpf: '',
      phone: '',
      jobTitle: '',
      createdAt: new Date().toISOString(),
    });
    setSuccess(true);
    setTimeout(() => navigate('/'), 2200);
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#E5E5E5',
      backgroundImage: PATTERN_BG,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
    }}>
      {/* Main card */}
      <div style={{
        width: '100%',
        maxWidth: 920,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        borderRadius: 28,
        border: '1.5px solid #111',
        overflow: 'hidden',
        boxShadow: '0 24px 64px rgba(0,0,0,0.14)',
        background: '#fff',
        minHeight: 580,
      }}>

        {/* ── Left: photo ── */}
        <div style={{
          backgroundImage: `url(${PHOTO_URL})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }} />

        {/* ── Right: form panel ── */}
        <div style={{
          background: '#fff',
          padding: '40px 44px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          {/* Logo */}
          <div style={{ marginBottom: 16, textAlign: 'center' }}>
            <img
              src="/logo-papelaria.png"
              alt="Papelaria Central"
              style={{ height: 80, objectFit: 'contain', display: 'block', margin: '0 auto' }}
            />
          </div>

          {/* Heading */}
          <div style={{ width: '100%', marginBottom: 18 }}>
            <h1 style={{ fontSize: 40, fontWeight: 700, color: '#101828', margin: 0, lineHeight: 1.1, letterSpacing: '-0.02em' }}>
              Entrar
            </h1>
          </div>

          {success && (
            <div style={{ width: '100%', background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 12, padding: '10px 16px', marginBottom: 14, fontSize: 13, color: '#027A48' }}>
              Conta criada com sucesso. Redirecionando para o login...
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate style={{ width: '100%' }}>
            {/* Nome completo */}
            <div style={{ marginBottom: 12 }}>
              <label style={lbl}>Nome completo</label>
              <PillField err={!!errors.name}>
                <input
                  className="pill-input"
                  value={form.name}
                  onChange={e => set('name', e.target.value)}
                  placeholder="ex: Lúcio Ramos"
                  style={pillinp}
                />
              </PillField>
              {errors.name && <ErrMsg>{errors.name}</ErrMsg>}
            </div>

            {/* Email */}
            <div style={{ marginBottom: 12 }}>
              <label style={lbl}>Email</label>
              <PillField err={!!errors.email}>
                <input
                  className="pill-input"
                  type="email"
                  value={form.email}
                  onChange={e => set('email', e.target.value)}
                  placeholder="lucioramospalmeiras@gmail.com"
                  style={pillinp}
                />
              </PillField>
              {errors.email && <ErrMsg>{errors.email}</ErrMsg>}
            </div>

            {/* Senha + Confirmar — 2 colunas */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
              <div>
                <label style={lbl}>Senha</label>
                <PillField err={!!errors.password}>
                  <input
                    className="pill-input"
                    type={showPw ? 'text' : 'password'}
                    value={form.password}
                    onChange={e => set('password', e.target.value)}
                    placeholder="••••••••••"
                    style={{ ...pillinp, width: '100%' }}
                  />
                  <EyeToggle show={showPw} onToggle={() => setShowPw(v => !v)} />
                </PillField>
                {errors.password && <ErrMsg>{errors.password}</ErrMsg>}
              </div>
              <div>
                <label style={lbl}>Confirme sua senha</label>
                <PillField err={!!errors.confirm}>
                  <input
                    className="pill-input"
                    type={showConfirm ? 'text' : 'password'}
                    value={form.confirm}
                    onChange={e => set('confirm', e.target.value)}
                    placeholder="••••••••••"
                    style={{ ...pillinp, width: '100%' }}
                  />
                  <EyeToggle show={showConfirm} onToggle={() => setShowConfirm(v => !v)} />
                </PillField>
                {errors.confirm && <ErrMsg>{errors.confirm}</ErrMsg>}
              </div>
            </div>

            {/* Chave de acesso */}
            <div style={{ marginBottom: 20 }}>
              <label style={lbl}>Chave de acesso</label>
              <PillField err={!!errors.accessKey}>
                <input
                  className="pill-input"
                  value={form.accessKey}
                  onChange={e => set('accessKey', e.target.value)}
                  placeholder="Chave fornecida pelo administrador"
                  style={pillinp}
                />
              </PillField>
              {errors.accessKey && <ErrMsg>{errors.accessKey}</ErrMsg>}
            </div>

            {/* Submit */}
            <button type="submit" style={{
              width: '100%',
              padding: '14px',
              background: '#1A2B52',
              color: '#fff',
              border: 'none',
              borderRadius: 999,
              fontSize: 15,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'Inter, sans-serif',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              marginBottom: 16,
              letterSpacing: '0.01em',
            }}>
              Entrar <span style={{ fontSize: 16 }}>→</span>
            </button>
          </form>

          {/* Divider */}
          <div style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ flex: 1, height: 1, background: '#E4E7EC' }} />
            <span style={{ fontSize: 13, color: '#98A2B3' }}>ou</span>
            <div style={{ flex: 1, height: 1, background: '#E4E7EC' }} />
          </div>

          {/* Back to login */}
          <button
            type="button"
            onClick={() => navigate('/')}
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 10,
              padding: '13px 20px',
              background: '#EBEBEB',
              borderRadius: 999,
              fontSize: 14,
              color: '#344054',
              fontFamily: 'Inter, sans-serif',
              border: 'none',
              cursor: 'pointer',
            }}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#667085" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
            </svg>
            Entrar em uma conta existente
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── Sub-components ──────────────────────────────── */

function PillField({ children, err }: { children: React.ReactNode; err: boolean }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      background: err ? '#FEF3F2' : '#EBEBEB',
      borderRadius: 999,
      padding: '11px 18px',
      gap: 8,
      border: err ? '1.5px solid #FECDCA' : '1.5px solid transparent',
    }}>
      {children}
    </div>
  );
}

function ErrMsg({ children }: { children: React.ReactNode }) {
  return <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 5, paddingLeft: 16 }}>{children}</span>;
}

function EyeToggle({ show, onToggle }: { show: boolean; onToggle: () => void }) {
  return (
    <button type="button" onClick={onToggle} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 0, color: '#9EA8B3', display: 'flex', alignItems: 'center', flexShrink: 0 }}>
      {show ? (
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
          <line x1="1" y1="1" x2="23" y2="23" />
        </svg>
      ) : (
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
        </svg>
      )}
    </button>
  );
}

const lbl: React.CSSProperties = { display: 'block', fontSize: 13, fontWeight: 500, color: '#344054', marginBottom: 6 };
const pillinp: React.CSSProperties = { flex: 1, border: 'none', background: 'transparent', fontSize: 14, color: '#101828', outline: 'none', fontFamily: 'Inter, sans-serif' };
