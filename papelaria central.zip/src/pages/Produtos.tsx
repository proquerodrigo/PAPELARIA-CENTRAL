import { useState } from 'react';
import { useNavigate } from 'react-router';
import { C, badge, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, btnDanger, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { db, DBProduct } from '../data/db';

const cats = ['Todas', 'Cadernos', 'Escrita', 'Material Escolar', 'Acessórios', 'Organização', 'Impressão', 'Papelaria Artística'];
const statusBadge = (s: DBProduct['status']) =>
  s === 'Sem estoque' ? badge.noStock : s === 'Estoque baixo' ? badge.lowStock : badge.inStock;

export default function Produtos() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<DBProduct[]>(() => db.products.all());
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('Todas');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState('');

  const filtered = products.filter(p =>
    (p.name.toLowerCase().includes(search.toLowerCase()) || p.code.toLowerCase().includes(search.toLowerCase())) &&
    (cat === 'Todas' || p.category === cat)
  );

  const doDelete = (id: string) => {
    db.products.remove(id);
    setProducts(db.products.all());
    setDeleteId(null);
    setToast('Produto excluído com sucesso.');
    setTimeout(() => setToast(''), 3000);
  };

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center' }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por código ou nome..." style={sinp} />
        <select value={cat} onChange={e => setCat(e.target.value)} style={sinp}>
          {cats.map(c => <option key={c}>{c}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted }}>{filtered.length} registro{filtered.length !== 1 ? 's' : ''}</span>
        <button onClick={() => navigate('/produtos/novo')} style={btnPrimary}>+ Novo produto</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Código', 'Foto', 'Produto', 'Categoria', 'Estoque', 'Est. mínimo', 'Preço unit.', 'Situação', 'Ações'].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((p, i) => (
              <tr key={p.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{p.code}</td>
                <td style={{ ...TD, width: 44, padding: '4px 8px' }}>
                  {p.photo ? (
                    <img
                      src={p.photo}
                      alt={p.name}
                      style={{ width: 32, height: 32, objectFit: 'cover', borderRadius: 3, border: `1px solid ${C.borderLight}`, display: 'block' }}
                    />
                  ) : (
                    <div style={{ width: 32, height: 32, borderRadius: 3, background: '#EEF0F3', border: `1px solid ${C.borderLight}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <span style={{ fontSize: 8, color: C.textMuted }}>—</span>
                    </div>
                  )}
                </td>
                <td style={{ ...TD, fontWeight: 500 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{
                      width: 28, height: 28, flexShrink: 0,
                      border: `1px solid ${C.borderLight}`, borderRadius: 3,
                      background: '#F4F5F6', overflow: 'hidden',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {p.photo
                        ? <img src={p.photo} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                        : <span style={{ fontSize: 8, color: '#C4C9D0' }}>—</span>
                      }
                    </div>
                    <span>
                      {p.name}
                      {p.qty > 0 && p.qty <= p.minStock && <span style={{ marginLeft: 6, fontSize: 10, color: '#B54708' }}>↓ mínimo</span>}
                    </span>
                  </div>
                </td>
                <td style={{ ...TD, color: C.textMuted }}>{p.category}</td>
                <td style={{ ...TD, fontWeight: 600, color: p.qty === 0 ? C.error : p.qty <= p.minStock ? '#B54708' : C.text }}>{p.qty} un.</td>
                <td style={{ ...TD, color: C.textMuted }}>{p.minStock} un.</td>
                <td style={{ ...TD, color: C.textMuted }}>R$ {p.price.toFixed(2)}</td>
                <td style={TD}><Badge style={statusBadge(p.status)}>{p.status}</Badge></td>
                <td style={TD}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button onClick={() => navigate(`/produtos/${p.id}/editar`)} style={actBtn}>Editar</button>
                    <button onClick={() => setDeleteId(p.id)} style={{ ...actBtn, color: C.error }}>Excluir</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={9} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum produto encontrado.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {deleteId !== null && (
        <Modal title="Confirmar exclusão" onClose={() => setDeleteId(null)}>
          <p style={{ fontSize: 13, color: C.text, margin: '0 0 16px' }}>
            Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita.
          </p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setDeleteId(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={() => doDelete(deleteId)} style={btnDanger}>Excluir produto</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

export function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.18)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 100 }}>
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '20px 24px', width: '100%', maxWidth: 440, boxShadow: '0 4px 16px rgba(0,0,0,0.1)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600, color: C.text }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textMuted, fontSize: 16, lineHeight: 1, padding: 2 }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Toast({ msg }: { msg: string }) {
  return (
    <div style={{ position: 'fixed', top: 56, right: 16, background: '#1B3050', color: '#fff', padding: '8px 14px', borderRadius: 4, fontSize: 13, zIndex: 200, boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>
      {msg}
    </div>
  );
}

const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer', fontWeight: 400 };
