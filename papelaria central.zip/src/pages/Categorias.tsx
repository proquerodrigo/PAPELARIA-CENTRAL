import { useState } from 'react';
import { C, badge, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, inp, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { Modal, Toast } from './Produtos';
import { db, newId, DBCategory } from '../data/db';

export default function Categorias() {
  const [cats, setCats] = useState<DBCategory[]>(() => db.categories.all());
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<DBCategory | null>(null);
  const [form, setForm] = useState({ name: '', description: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [toast, setToast] = useState('');

  const refresh = () => setCats(db.categories.all());
  const openNew = () => { setEditing(null); setForm({ name: '', description: '' }); setErrors({}); setShowModal(true); };
  const openEdit = (c: DBCategory) => { setEditing(c); setForm({ name: c.name, description: c.description }); setErrors({}); setShowModal(true); };

  const save = () => {
    if (!form.name.trim()) { setErrors({ name: 'Campo obrigatório.' }); return; }
    if (editing) {
      db.categories.update(editing.id, { name: form.name.trim(), description: form.description });
      setToast('Categoria atualizada com sucesso.');
    } else {
      db.categories.add({ id: newId(), name: form.name.trim(), description: form.description, status: 'Ativa' });
      setToast('Categoria cadastrada com sucesso.');
    }
    setShowModal(false);
    refresh();
    setTimeout(() => setToast(''), 3000);
  };

  const toggle = (c: DBCategory) => {
    db.categories.update(c.id, { status: c.status === 'Ativa' ? 'Inativa' : 'Ativa' });
    refresh();
  };

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <span style={{ fontSize: 12, color: C.textMuted }}>{cats.filter(c => c.status === 'Ativa').length} categorias ativas</span>
        <button onClick={openNew} style={btnPrimary}>+ Nova categoria</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Categoria', 'Descrição', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {cats.map((c, i) => (
              <tr key={c.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{c.name}</td>
                <td style={{ ...TD, color: C.textMuted }}>{c.description || '—'}</td>
                <td style={TD}><Badge style={c.status === 'Ativa' ? badge.active : badge.inactive}>{c.status}</Badge></td>
                <td style={TD}>
                  <button onClick={() => openEdit(c)} style={actBtn}>Editar</button>
                  <button onClick={() => toggle(c)} style={{ ...actBtn, color: C.textMuted }}>{c.status === 'Ativa' ? 'Desativar' : 'Ativar'}</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title={editing ? 'Editar categoria' : 'Nova categoria'} onClose={() => setShowModal(false)}>
          <div style={{ marginBottom: 14 }}>
            <label style={lbl}>Nome *</label>
            <input value={form.name} onChange={e => { setForm(f => ({ ...f, name: e.target.value })); setErrors({}); }} placeholder="Nome da categoria" style={inp(!!errors.name)} />
            {errors.name && <span style={errTxt}>{errors.name}</span>}
          </div>
          <div style={{ marginBottom: 18 }}>
            <label style={lbl}>Descrição</label>
            <textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Descrição opcional..." rows={2} style={{ ...inp(), resize: 'vertical' as const }} />
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setShowModal(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 };
const errTxt: React.CSSProperties = { display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
