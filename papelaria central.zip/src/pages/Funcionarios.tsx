import { useState } from 'react';
import { C, badge, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, inp, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { Modal, Toast } from './Produtos';
import { db, newId, DBUser } from '../data/db';

type FStatus = 'Ativo' | 'Inativo';

const ROLES = ['Gerente', 'Vendedor', 'Caixa', 'Estoquista', 'Atendente', 'Auxiliar Administrativo'];

export default function Funcionarios() {
  const [employees, setEmployees] = useState<DBUser[]>(() => db.users.all().filter(u => u.id !== 'u-admin'));
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<DBUser | null>(null);
  const [form, setForm] = useState({ name: '', email: '', password: '', cpf: '', phone: '', jobTitle: 'Vendedor', role: 'funcionario', status: 'Ativo' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [toast, setToast] = useState('');

  const refresh = () => setEmployees(db.users.all().filter(u => u.id !== 'u-admin'));
  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };

  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setErrors(x => ({ ...x, [k]: '' })); };

  const openNew = () => {
    setEditing(null);
    setForm({ name: '', email: '', password: '', cpf: '', phone: '', jobTitle: 'Vendedor', role: 'funcionario', status: 'Ativo' });
    setErrors({});
    setShowModal(true);
  };

  const openEdit = (u: DBUser) => {
    setEditing(u);
    setForm({ name: u.name, email: u.email, password: '', cpf: u.cpf, phone: u.phone, jobTitle: u.jobTitle, role: u.role, status: u.status });
    setErrors({});
    setShowModal(true);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Campo obrigatório.';
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = 'E-mail inválido.';
    if (!editing && form.password.length < 6) e.password = 'Mínimo de 6 caracteres.';
    if (editing && form.password && form.password.length < 6) e.password = 'Mínimo de 6 caracteres.';
    const emailConflict = db.users.findByEmail(form.email.trim());
    if (emailConflict && emailConflict.id !== editing?.id) e.email = 'E-mail já cadastrado no sistema.';
    if (form.cpf && db.users.all().some(u => u.cpf === form.cpf && u.id !== editing?.id)) e.cpf = 'CPF já cadastrado.';
    return e;
  };

  const save = () => {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;

    if (editing) {
      const patch: Partial<DBUser> = {
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        cpf: form.cpf,
        phone: form.phone,
        jobTitle: form.jobTitle,
        role: form.role as 'admin' | 'funcionario',
        status: form.status as 'Ativo' | 'Inativo' | 'Bloqueado',
      };
      if (form.password) patch.password = form.password;
      db.users.update(editing.id, patch);
      showToast('Funcionário atualizado com sucesso.');
    } else {
      db.users.add({
        id: newId(),
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        password: form.password,
        role: form.role as 'admin' | 'funcionario',
        status: form.status as 'Ativo' | 'Inativo' | 'Bloqueado',
        cpf: form.cpf,
        phone: form.phone,
        jobTitle: form.jobTitle,
        createdAt: new Date().toISOString(),
      });
      showToast('Funcionário cadastrado. Pode acessar o sistema com o e-mail e senha informados.');
    }
    setShowModal(false);
    refresh();
  };

  const toggleStatus = (u: DBUser) => {
    const newStatus: FStatus = u.status === 'Ativo' ? 'Inativo' : 'Ativo';
    db.users.update(u.id, { status: newStatus });
    refresh();
    showToast('Status atualizado com sucesso.');
  };

  const activos = employees.filter(e => e.status === 'Ativo').length;

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
        <span style={{ fontSize: 12, color: C.textMuted }}>{activos} ativo{activos !== 1 ? 's' : ''} · {employees.length} total</span>
        <button onClick={openNew} style={btnPrimary}>+ Novo funcionário</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Nome', 'CPF', 'Cargo', 'E-mail', 'Telefone', 'Perfil', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {employees.map((e, i) => (
              <tr key={e.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{e.name}</td>
                <td style={{ ...TD, color: C.textMuted, fontFamily: 'monospace', fontSize: 12 }}>{e.cpf || '—'}</td>
                <td style={TD}>
                  {e.jobTitle ? (
                    <span style={{ background: '#F0F4FF', color: '#3B4FB5', padding: '1px 7px', borderRadius: 3, fontSize: 11, fontWeight: 500, border: '1px solid #C7D2FE' }}>{e.jobTitle}</span>
                  ) : '—'}
                </td>
                <td style={{ ...TD, color: C.textMuted }}>{e.email}</td>
                <td style={{ ...TD, color: C.textMuted }}>{e.phone || '—'}</td>
                <td style={TD}>
                  <Badge style={e.role === 'admin' ? badge.admin : badge.employee}>
                    {e.role === 'admin' ? 'Administrador' : 'Funcionário'}
                  </Badge>
                </td>
                <td style={TD}><Badge style={e.status === 'Ativo' ? badge.active : e.status === 'Bloqueado' ? badge.blocked : badge.inactive}>{e.status}</Badge></td>
                <td style={TD}>
                  <button onClick={() => openEdit(e)} style={actBtn}>Editar</button>
                  <button onClick={() => toggleStatus(e)} style={{ ...actBtn, color: C.textMuted }}>
                    {e.status === 'Ativo' ? 'Desativar' : 'Ativar'}
                  </button>
                </td>
              </tr>
            ))}
            {employees.length === 0 && (
              <tr><td colSpan={8} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum funcionário cadastrado.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title={editing ? 'Editar funcionário' : 'Novo funcionário'} onClose={() => setShowModal(false)}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="Nome completo *" err={errors.name}>
                <input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Nome completo" style={inp(!!errors.name)} />
              </F>
            </div>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="E-mail * (usado para login)" err={errors.email}>
                <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="email@dominio.com" style={inp(!!errors.email)} />
              </F>
            </div>
            <div style={{ gridColumn: '1/-1' }}>
              <F label={editing ? 'Nova senha (deixe em branco para manter)' : 'Senha * (para acesso ao sistema)'} err={errors.password}>
                <input type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder={editing ? 'Deixe em branco para não alterar' : 'Mín. 6 caracteres'} style={inp(!!errors.password)} />
              </F>
            </div>
            <F label="CPF" err={errors.cpf}>
              <input value={form.cpf} onChange={e => set('cpf', e.target.value)} placeholder="000.000.000-00" style={inp(!!errors.cpf)} />
            </F>
            <F label="Telefone" err="">
              <input value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="(11) 99999-0000" style={inp()} />
            </F>
            <F label="Cargo" err="">
              <select value={form.jobTitle} onChange={e => set('jobTitle', e.target.value)} style={inp()}>
                {ROLES.map(r => <option key={r}>{r}</option>)}
              </select>
            </F>
            <F label="Perfil de acesso" err="">
              <select value={form.role} onChange={e => set('role', e.target.value)} style={inp()}>
                <option value="funcionario">Funcionário</option>
                <option value="admin">Administrador</option>
              </select>
            </F>
            <F label="Status" err="">
              <select value={form.status} onChange={e => set('status', e.target.value)} style={inp()}>
                <option value="Ativo">Ativo</option>
                <option value="Inativo">Inativo</option>
              </select>
            </F>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setShowModal(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Cadastrar funcionário</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function F({ label: lbl, err, children }: { label: string; err: string; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{lbl}</label>
      {children}
      {err && <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 }}>{err}</span>}
    </div>
  );
}

const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
