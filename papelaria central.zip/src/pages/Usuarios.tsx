import { useState } from 'react';
import { C, badge, tbl, TH, TD, tableWrap, ROW_BORDER, inp } from '../theme';
import { Badge } from '../components/Badge';
import { Toast, Modal } from './Produtos';
import { db, DBUser } from '../data/db';

type UStatus = 'Ativo' | 'Inativo' | 'Bloqueado';

const nextStatus: Record<UStatus, UStatus> = { Ativo: 'Inativo', Inativo: 'Ativo', Bloqueado: 'Ativo' };
const statusBadge: Record<UStatus, React.CSSProperties> = {
  Ativo: badge.active,
  Inativo: badge.inactive,
  Bloqueado: badge.blocked,
};

export default function Usuarios() {
  const [users, setUsers] = useState<DBUser[]>(() => db.users.all());
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<DBUser | null>(null);
  const [form, setForm] = useState({ name: '', password: '', role: 'funcionario', status: 'Ativo' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [toast, setToast] = useState('');

  const refresh = () => setUsers(db.users.all());
  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 3000); };
  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setErrors(x => ({ ...x, [k]: '' })); };

  const toggleStatus = (u: DBUser) => {
    if (u.id === 'u-admin') return;
    db.users.update(u.id, { status: nextStatus[u.status as UStatus] });
    refresh();
    showToast('Status atualizado com sucesso.');
  };

  const openEdit = (u: DBUser) => {
    setEditing(u);
    setForm({ name: u.name, password: '', role: u.role, status: u.status });
    setErrors({});
  };

  const saveEdit = () => {
    if (!form.name.trim()) { setErrors({ name: 'Campo obrigatório.' }); return; }
    if (!editing) return;
    const patch: Partial<DBUser> = {
      name: form.name.trim(),
      role: form.role as 'admin' | 'funcionario',
      status: form.status as 'Ativo' | 'Inativo' | 'Bloqueado',
    };
    if (form.password && form.password.length >= 6) patch.password = form.password;
    db.users.update(editing.id, patch);
    setEditing(null);
    refresh();
    showToast('Usuário atualizado com sucesso.');
  };

  const filtered = users.filter(u =>
    u.name.toLowerCase().includes(search.toLowerCase()) ||
    u.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nome ou e-mail..." style={sinp} />
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted, alignSelf: 'center' }}>{filtered.length} usuário{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Nome', 'CPF', 'E-mail', 'Perfil', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((u, i) => (
              <tr key={u.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{u.name}</td>
                <td style={{ ...TD, color: C.textMuted, fontFamily: 'monospace', fontSize: 12 }}>{u.cpf || '—'}</td>
                <td style={{ ...TD, color: C.textMuted }}>{u.email}</td>
                <td style={TD}>
                  <Badge style={u.role === 'admin' ? badge.admin : badge.employee}>
                    {u.role === 'admin' ? 'Administrador' : 'Funcionário'}
                  </Badge>
                </td>
                <td style={TD}><Badge style={statusBadge[u.status as UStatus]}>{u.status}</Badge></td>
                <td style={TD}>
                  <button onClick={() => openEdit(u)} style={actBtn}>Editar</button>
                  {u.id !== 'u-admin' && (
                    <button onClick={() => toggleStatus(u)} style={{ ...actBtn, color: C.textMuted }}>
                      {nextStatus[u.status as UStatus] === 'Ativo' ? 'Ativar' : 'Desativar'}
                    </button>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum usuário encontrado.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {editing && (
        <Modal title="Editar usuário" onClose={() => setEditing(null)}>
          <div style={{ display: 'grid', gap: 12, marginBottom: 18 }}>
            <div>
              <label style={lbl}>Nome completo</label>
              <input value={form.name} onChange={e => set('name', e.target.value)} style={inp(!!errors.name)} />
              {errors.name && <span style={errTxt}>{errors.name}</span>}
            </div>
            <div>
              <label style={lbl}>E-mail</label>
              <input value={editing.email} disabled style={{ ...inp(), background: C.bg, color: C.textMuted }} />
            </div>
            <div>
              <label style={lbl}>Nova senha (deixe em branco para não alterar)</label>
              <input type="password" value={form.password} onChange={e => set('password', e.target.value)} placeholder="Mín. 6 caracteres" style={inp()} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <label style={lbl}>Perfil</label>
                <select value={form.role} onChange={e => set('role', e.target.value)} style={inp()} disabled={editing.id === 'u-admin'}>
                  <option value="funcionario">Funcionário</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>
              <div>
                <label style={lbl}>Status</label>
                <select value={form.status} onChange={e => set('status', e.target.value)} style={inp()} disabled={editing.id === 'u-admin'}>
                  <option value="Ativo">Ativo</option>
                  <option value="Inativo">Inativo</option>
                  <option value="Bloqueado">Bloqueado</option>
                </select>
              </div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setEditing(null)} style={{ padding: '6px 14px', background: C.white, color: C.text, border: `1px solid ${C.border}`, borderRadius: 4, fontSize: 13, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Cancelar</button>
            <button onClick={saveEdit} style={{ padding: '6px 14px', background: C.navy, color: C.white, border: 'none', borderRadius: 4, fontSize: 13, fontWeight: 500, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Salvar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text, width: 300 };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
const lbl: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 };
const errTxt: React.CSSProperties = { display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 };
