import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { caixaDb, newCaixaId, type CaixaSessao, type CaixaLancamento, type LancTipo } from '../data/caixaDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER, formCard, inp, btnPrimary, btnSecondary } from '../theme';

const TODAY = new Date().toISOString().slice(0, 10);

function fmtBRL(v: number): string {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function fmtDate(d: string): string { return d.split('-').reverse().join('/'); }

function KPICard({ label, value, color = C.text }: { label: string; value: string; color?: string }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '12px 16px' }}>
      <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 700, color }}>{value}</div>
    </div>
  );
}

type Tab = 'hoje' | 'historico';

const FORM_PAGS = ['Dinheiro', 'Pix', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência'];

export default function Caixa() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';

  const [tab, setTab] = useState<Tab>('hoje');
  const [sessao, setSessao] = useState<CaixaSessao | undefined>(() => caixaDb.sessoes.byDate(TODAY));

  const [abertura, setAbertura] = useState({ valor: '200,00' });
  const [fech, setFech] = useState({ dinheiro: '', pix: '', debito: '', credito: '', boleto: '', transferencia: '', obs: '' });
  const [lancForm, setLancForm] = useState({ tipo: 'sangria' as LancTipo, descricao: '', valor: '', formaPagamento: 'Dinheiro' });
  const [showLancForm, setShowLancForm] = useState(false);
  const [showFechForm, setShowFechForm] = useState(false);
  const [toast, setToast] = useState('');

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 4000); };
  const refresh = () => setSessao(caixaDb.sessoes.byDate(TODAY));

  const lancamentos = useMemo(() => sessao ? caixaDb.lancamentos.bySessao(sessao.id) : [], [sessao, tab]);

  const historico = useMemo(() => {
    const all = caixaDb.sessoes.all();
    return all.filter(s => s.data !== TODAY).sort((a, b) => b.data.localeCompare(a.data)).slice(0, 30);
  }, [tab]);

  const parseBRL = (s: string): number => parseFloat(s.replace('.', '').replace(',', '.')) || 0;

  const abrirCaixa = () => {
    const vi = parseBRL(abertura.valor);
    if (vi <= 0) { msg('Informe o valor inicial.'); return; }
    const now = new Date();
    const hora = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
    const s: CaixaSessao = {
      id: `cx-${TODAY}-${Date.now()}`, data: TODAY,
      horaAbertura: hora,
      responsavelId: user?.id ?? '', responsavelNome: user?.name ?? '',
      valorInicial: vi,
      totalDinheiro: 0, totalPix: 0, totalDebito: 0, totalCredito: 0, totalBoleto: 0, totalTransferencia: 0,
      totalEntradas: 0, totalSangrias: 0,
      valorEsperado: vi, valorInformado: 0, diferenca: 0,
      observacoesFechamento: '', status: 'aberto',
      createdAt: new Date().toISOString(),
    };
    caixaDb.sessoes.add(s);
    caixaDb.lancamentos.add({
      id: newCaixaId(), sessaoId: s.id, tipo: 'suprimento',
      descricao: 'Abertura de caixa – fundo de troco',
      valor: vi, formaPagamento: 'Dinheiro',
      responsavelId: user?.id ?? '', responsavelNome: user?.name ?? '',
      hora, createdAt: new Date().toISOString(),
    });
    msg('Caixa aberto com sucesso!');
    refresh();
  };

  const adicionarLancamento = () => {
    if (!sessao) return;
    const v = parseBRL(lancForm.valor);
    if (v <= 0 || !lancForm.descricao) { msg('Preencha descrição e valor.'); return; }
    const now = new Date();
    const hora = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

    const l: CaixaLancamento = {
      id: newCaixaId(), sessaoId: sessao.id, tipo: lancForm.tipo,
      descricao: lancForm.descricao, valor: v,
      formaPagamento: lancForm.formaPagamento,
      responsavelId: user?.id ?? '', responsavelNome: user?.name ?? '',
      hora, createdAt: new Date().toISOString(),
    };
    caixaDb.lancamentos.add(l);

    // Update session totals
    const patch: Partial<CaixaSessao> = {};
    if (lancForm.tipo === 'sangria' || lancForm.tipo === 'retirada') {
      patch.totalSangrias = (sessao.totalSangrias ?? 0) + v;
      patch.valorEsperado = (sessao.valorEsperado ?? 0) - v;
    } else if (lancForm.tipo === 'venda' || lancForm.tipo === 'suprimento') {
      const fp = lancForm.formaPagamento;
      const totals: Record<string, number> = {
        'Dinheiro': sessao.totalDinheiro, 'Pix': sessao.totalPix,
        'Cartão de débito': sessao.totalDebito, 'Cartão de crédito': sessao.totalCredito,
        'Boleto': sessao.totalBoleto, 'Transferência': sessao.totalTransferencia,
      };
      const keyMap: Record<string, keyof CaixaSessao> = {
        'Dinheiro': 'totalDinheiro', 'Pix': 'totalPix',
        'Cartão de débito': 'totalDebito', 'Cartão de crédito': 'totalCredito',
        'Boleto': 'totalBoleto', 'Transferência': 'totalTransferencia',
      };
      if (keyMap[fp]) (patch as Record<string, number>)[keyMap[fp] as string] = (totals[fp] ?? 0) + v;
      patch.totalEntradas = (sessao.totalEntradas ?? 0) + v;
      patch.valorEsperado = (sessao.valorEsperado ?? 0) + v;
    }
    caixaDb.sessoes.update(sessao.id, patch);
    setLancForm({ tipo: 'sangria', descricao: '', valor: '', formaPagamento: 'Dinheiro' });
    setShowLancForm(false);
    msg('Lançamento registrado.');
    refresh();
  };

  const fecharCaixa = () => {
    if (!sessao) return;
    const din = parseBRL(fech.dinheiro);
    const pix = parseBRL(fech.pix);
    const deb = parseBRL(fech.debito);
    const cre = parseBRL(fech.credito);
    const bol = parseBRL(fech.boleto);
    const trf = parseBRL(fech.transferencia);
    const informado = din + pix + deb + cre + bol + trf;
    const esperado = sessao.valorEsperado;
    const diff = informado - esperado;
    const now = new Date();
    const hora = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

    caixaDb.sessoes.update(sessao.id, {
      horaFechamento: hora,
      totalDinheiro: din, totalPix: pix, totalDebito: deb,
      totalCredito: cre, totalBoleto: bol, totalTransferencia: trf,
      valorInformado: informado, diferenca: diff,
      observacoesFechamento: fech.obs,
      status: 'fechado',
    });
    setShowFechForm(false);
    msg('Caixa fechado. Conferência registrada.');
    refresh();
  };

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.text,
  };

  const tabs: { k: Tab; label: string }[] = [
    { k: 'hoje', label: 'Caixa de hoje' },
    { k: 'historico', label: 'Histórico' },
  ];

  return (
    <div>
      {toast && (
        <div style={{ background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 4, padding: '8px 12px', marginBottom: 12, fontSize: 13, color: '#027A48' }}>
          {toast}
        </div>
      )}

      {/* Tab nav */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.k} onClick={() => setTab(t.k)} style={{
            padding: '7px 14px', fontSize: 12, fontFamily: 'Inter, sans-serif',
            fontWeight: tab === t.k ? 600 : 400,
            color: tab === t.k ? C.navy : C.textMuted,
            borderBottom: tab === t.k ? `2px solid ${C.navy}` : '2px solid transparent',
            marginBottom: -1, background: 'none', border: 'none',
            borderLeft: 'none', borderRight: 'none', borderTop: 'none',
            cursor: 'pointer',
          }}>{t.label}</button>
        ))}
      </div>

      {/* ── TAB: HOJE ── */}
      {tab === 'hoje' && (
        <div>
          {/* Status banner */}
          <div style={{
            background: sessao?.status === 'aberto' ? '#ECFDF3' : sessao?.status === 'fechado' ? '#F0F4FA' : '#FEF9C3',
            border: `1px solid ${sessao?.status === 'aberto' ? '#A9EFC5' : sessao?.status === 'fechado' ? C.border : '#FEF08A'}`,
            borderRadius: 6, padding: '14px 20px', marginBottom: 20,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 15, color: sessao?.status === 'aberto' ? '#027A48' : C.text }}>
                {!sessao ? '⬜ Caixa não aberto hoje' : sessao.status === 'aberto' ? '🟢 Caixa aberto' : '⬛ Caixa fechado'}
              </div>
              {sessao && (
                <div style={{ fontSize: 12, color: C.textMuted, marginTop: 3 }}>
                  Abertura: {sessao.horaAbertura} por {sessao.responsavelNome}
                  {sessao.horaFechamento && ` · Fechamento: ${sessao.horaFechamento}`}
                </div>
              )}
            </div>
            {isAdmin && !sessao && (
              <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
                <div>
                  <label style={{ fontSize: 12, color: C.textMuted, marginRight: 6 }}>Valor inicial (R$):</label>
                  <input
                    value={abertura.valor}
                    onChange={e => setAbertura({ valor: e.target.value })}
                    style={{ ...sinp, width: 100 }}
                    placeholder="200,00"
                  />
                </div>
                <button onClick={abrirCaixa} style={btnPrimary}>Abrir caixa</button>
              </div>
            )}
            {isAdmin && sessao?.status === 'aberto' && (
              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={() => setShowLancForm(true)} style={btnSecondary}>+ Lançamento</button>
                <button onClick={() => setShowFechForm(true)} style={{ ...btnPrimary, background: '#B42318', border: '1px solid #B42318' }}>
                  Fechar caixa
                </button>
              </div>
            )}
          </div>

          {/* KPIs if session exists */}
          {sessao && (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10, marginBottom: 20 }}>
              <KPICard label="Valor inicial" value={fmtBRL(sessao.valorInicial)} />
              <KPICard label="Dinheiro" value={fmtBRL(sessao.totalDinheiro)} />
              <KPICard label="Pix" value={fmtBRL(sessao.totalPix)} color="#1D4ED8" />
              <KPICard label="Débito" value={fmtBRL(sessao.totalDebito)} />
              <KPICard label="Crédito" value={fmtBRL(sessao.totalCredito)} />
              <KPICard label="Total entradas" value={fmtBRL(sessao.totalEntradas)} color="#027A48" />
              <KPICard label="Sangrias/Retiradas" value={fmtBRL(sessao.totalSangrias)} color="#B42318" />
              <KPICard label="Valor esperado" value={fmtBRL(sessao.valorEsperado)} color={C.navy} />
              {sessao.status === 'fechado' && (
                <>
                  <KPICard label="Informado" value={fmtBRL(sessao.valorInformado)} />
                  <KPICard
                    label="Diferença"
                    value={fmtBRL(sessao.diferenca)}
                    color={sessao.diferenca === 0 ? '#027A48' : sessao.diferenca < 0 ? '#B42318' : '#B54708'}
                  />
                </>
              )}
            </div>
          )}

          {/* Lançamentos do dia */}
          {sessao && (
            <div>
              <div style={{ fontSize: 13, fontWeight: 500, color: C.text, marginBottom: 8 }}>Lançamentos do dia</div>
              <div style={tableWrap}>
                <table style={tbl}>
                  <thead>
                    <tr>
                      {['Hora', 'Tipo', 'Descrição', 'Forma pag.', 'Valor', 'Responsável'].map(h => (
                        <th key={h} style={TH}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[...lancamentos].sort((a, b) => a.hora.localeCompare(b.hora)).map((l, i) => (
                      <tr key={l.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                        <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{l.hora}</td>
                        <td style={TD}>
                          <span style={{
                            background: l.tipo === 'sangria' || l.tipo === 'retirada' ? '#FEF3F2' : '#ECFDF3',
                            color: l.tipo === 'sangria' || l.tipo === 'retirada' ? '#B42318' : '#027A48',
                            border: `1px solid ${l.tipo === 'sangria' || l.tipo === 'retirada' ? '#FECDCA' : '#A9EFC5'}`,
                            borderRadius: 4, padding: '2px 8px', fontSize: 11,
                          }}>
                            {l.tipo === 'suprimento' ? 'Suprimento' : l.tipo === 'venda' ? 'Venda' : l.tipo === 'sangria' ? 'Sangria' : l.tipo === 'retirada' ? 'Retirada' : 'Despesa'}
                          </span>
                        </td>
                        <td style={{ ...TD, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{l.descricao}</td>
                        <td style={{ ...TD, color: C.textMuted }}>{l.formaPagamento}</td>
                        <td style={{ ...TD, fontWeight: 600, color: (l.tipo === 'sangria' || l.tipo === 'retirada') ? '#B42318' : '#027A48' }}>
                          {(l.tipo === 'sangria' || l.tipo === 'retirada') ? '-' : '+'}{fmtBRL(l.valor)}
                        </td>
                        <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{l.responsavelNome}</td>
                      </tr>
                    ))}
                    {lancamentos.length === 0 && (
                      <tr><td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '20px 12px' }}>Nenhum lançamento registrado.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Form: novo lançamento */}
          {showLancForm && (
            <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
              <div style={{ background: C.white, borderRadius: 6, padding: 24, width: 420, boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16 }}>Novo lançamento</div>
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Tipo</label>
                  <select value={lancForm.tipo} onChange={e => setLancForm(f => ({ ...f, tipo: e.target.value as LancTipo }))} style={sinp}>
                    <option value="venda">Venda</option>
                    <option value="suprimento">Suprimento / Entrada</option>
                    <option value="sangria">Sangria</option>
                    <option value="retirada">Retirada</option>
                    <option value="despesa">Despesa</option>
                  </select>
                </div>
                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Descrição</label>
                  <input value={lancForm.descricao} onChange={e => setLancForm(f => ({ ...f, descricao: e.target.value }))} style={inp(false)} placeholder="Ex.: Venda balcão, Sangria para cofre..." />
                </div>
                {(lancForm.tipo === 'venda' || lancForm.tipo === 'suprimento') && (
                  <div style={{ marginBottom: 12 }}>
                    <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Forma de pagamento</label>
                    <select value={lancForm.formaPagamento} onChange={e => setLancForm(f => ({ ...f, formaPagamento: e.target.value }))} style={sinp}>
                      {FORM_PAGS.map(p => <option key={p}>{p}</option>)}
                    </select>
                  </div>
                )}
                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Valor (R$)</label>
                  <input value={lancForm.valor} onChange={e => setLancForm(f => ({ ...f, valor: e.target.value }))} style={inp(false)} placeholder="0,00" />
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => setShowLancForm(false)} style={btnSecondary}>Cancelar</button>
                  <button onClick={adicionarLancamento} style={btnPrimary}>Registrar</button>
                </div>
              </div>
            </div>
          )}

          {/* Form: fechar caixa */}
          {showFechForm && sessao && (
            <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
              <div style={{ background: C.white, borderRadius: 6, padding: 24, width: 480, boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 4 }}>Fechamento de caixa</div>
                <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 16 }}>
                  Valor esperado: <strong style={{ color: C.navy }}>{fmtBRL(sessao.valorEsperado)}</strong>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 12 }}>
                  {[
                    { label: 'Dinheiro (R$)', k: 'dinheiro' },
                    { label: 'Pix (R$)', k: 'pix' },
                    { label: 'Cartão de débito (R$)', k: 'debito' },
                    { label: 'Cartão de crédito (R$)', k: 'credito' },
                    { label: 'Boleto (R$)', k: 'boleto' },
                    { label: 'Transferência (R$)', k: 'transferencia' },
                  ].map(f => (
                    <div key={f.k}>
                      <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>{f.label}</label>
                      <input
                        value={(fech as Record<string, string>)[f.k]}
                        onChange={e => setFech(x => ({ ...x, [f.k]: e.target.value }))}
                        style={sinp} placeholder="0,00"
                      />
                    </div>
                  ))}
                </div>

                {/* Live preview of difference */}
                {(() => {
                  const total = ['dinheiro','pix','debito','credito','boleto','transferencia']
                    .reduce((a, k) => a + (parseFloat((fech as Record<string,string>)[k].replace(',','.')) || 0), 0);
                  const diff = total - sessao.valorEsperado;
                  return total > 0 ? (
                    <div style={{ background: diff === 0 ? '#ECFDF3' : '#FEF3F2', border: `1px solid ${diff === 0 ? '#A9EFC5' : '#FECDCA'}`, borderRadius: 4, padding: '8px 12px', marginBottom: 12, fontSize: 13 }}>
                      Total informado: <strong>{fmtBRL(total)}</strong>
                      {' · '}Diferença: <strong style={{ color: diff === 0 ? '#027A48' : '#B42318' }}>
                        {diff >= 0 ? '+' : ''}{fmtBRL(diff)}
                      </strong>
                    </div>
                  ) : null;
                })()}

                <div style={{ marginBottom: 16 }}>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Observações de fechamento</label>
                  <input value={fech.obs} onChange={e => setFech(x => ({ ...x, obs: e.target.value }))} style={inp(false)} placeholder="Ex.: Diferença de troco, observação..." />
                </div>
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={() => setShowFechForm(false)} style={btnSecondary}>Cancelar</button>
                  <button onClick={fecharCaixa} style={{ ...btnPrimary, background: '#B42318', border: '1px solid #B42318' }}>
                    Confirmar fechamento
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB: HISTÓRICO ── */}
      {tab === 'historico' && (
        <div>
          <div style={tableWrap}>
            <table style={tbl}>
              <thead>
                <tr>
                  {['Data', 'Abertura', 'Fechamento', 'Responsável', 'V. inicial', 'Entradas', 'Sangrias', 'V. esperado', 'V. informado', 'Diferença', 'Status'].map(h => (
                    <th key={h} style={TH}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {historico.map((s, i) => (
                  <tr key={s.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                    <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted, whiteSpace: 'nowrap' }}>{fmtDate(s.data)}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{s.horaAbertura}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{s.horaFechamento ?? '—'}</td>
                    <td style={{ ...TD, color: C.textMuted, fontSize: 12, whiteSpace: 'nowrap' }}>{s.responsavelNome.split(' ').slice(0,2).join(' ')}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{fmtBRL(s.valorInicial)}</td>
                    <td style={{ ...TD, fontWeight: 600, color: '#027A48' }}>{fmtBRL(s.totalEntradas)}</td>
                    <td style={{ ...TD, color: '#B42318' }}>{fmtBRL(s.totalSangrias)}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{fmtBRL(s.valorEsperado)}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{s.valorInformado > 0 ? fmtBRL(s.valorInformado) : '—'}</td>
                    <td style={{ ...TD, color: s.diferenca === 0 ? '#027A48' : s.diferenca < 0 ? '#B42318' : '#B54708', fontWeight: s.diferenca !== 0 ? 600 : 400 }}>
                      {s.valorInformado > 0 ? `${s.diferenca >= 0 ? '+' : ''}${fmtBRL(s.diferenca)}` : '—'}
                    </td>
                    <td style={TD}>
                      <span style={{
                        background: s.status === 'fechado' ? '#F0F4FA' : '#ECFDF3',
                        color: s.status === 'fechado' ? C.text : '#027A48',
                        border: `1px solid ${s.status === 'fechado' ? C.border : '#A9EFC5'}`,
                        borderRadius: 4, padding: '2px 8px', fontSize: 11,
                      }}>
                        {s.status === 'fechado' ? 'Fechado' : 'Aberto'}
                      </span>
                    </td>
                  </tr>
                ))}
                {historico.length === 0 && (
                  <tr><td colSpan={11} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '20px 12px' }}>Nenhum histórico disponível.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
