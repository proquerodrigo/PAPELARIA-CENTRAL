import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { C, badge, tbl, TH, TD, tableWrap, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { db } from '../data/db';
import { horariosDb } from '../data/horariosDb';
import { caixaDb } from '../data/caixaDb';
import { wppDb } from '../data/wppDb';
import { pontoDb } from '../data/pontoDb';
import { auditDb } from '../data/auditDb';

const TODAY = new Date().toISOString().slice(0, 10);

export default function Dashboard() {
  const { user } = useApp();
  const navigate = useNavigate();
  const isAdmin = user?.role === 'admin';

  const products = db.products.all();
  const movements = db.movements.all();

  const total = products.length;
  const lowStockCount = products.filter(p => p.status === 'Estoque baixo' || p.status === 'Sem estoque').length;
  const monthMovs = movements.filter(m => m.date.endsWith('2026'));
  const entradas = monthMovs.filter(m => m.type === 'Entrada').reduce((a, m) => a + m.qty, 0);
  const saidas = monthMovs.filter(m => m.type === 'Saída').reduce((a, m) => a + m.qty, 0);

  const criticalItems = products.filter(p => p.status !== 'Em estoque');
  const recentMovements = movements.slice(0, 6);
  const recentActivity = auditDb.recent(8);

  // Alerts
  const noStockCount = products.filter(p => p.status === 'Sem estoque').length;
  const wppAllPendentes = wppDb.pedidos.all().filter(p => p.status === 'aguardando_pagamento' || p.status === 'pronto');
  const alerts: { msg: string; color: string; bg: string; border: string; to?: string }[] = [];
  if (noStockCount > 0) alerts.push({ msg: `${noStockCount} produto${noStockCount > 1 ? 's' : ''} sem estoque`, color: '#B42318', bg: '#FEF3F2', border: '#FECDCA', to: '/estoque' });
  if (lowStockCount > noStockCount) alerts.push({ msg: `${lowStockCount - noStockCount} produto${(lowStockCount - noStockCount) > 1 ? 's' : ''} com estoque baixo`, color: '#B54708', bg: '#FFFBEB', border: '#FDE68A', to: '/estoque' });
  if (wppAllPendentes.length > 0) alerts.push({ msg: `${wppAllPendentes.length} pedido${wppAllPendentes.length > 1 ? 's' : ''} aguardando atenção`, color: '#1D4ED8', bg: '#EFF6FF', border: '#BFDBFE', to: '/whatsapp-pedidos' });

  const stats = [
    { label: 'Total de produtos', value: String(total) },
    { label: 'Itens em alerta', value: String(lowStockCount), warn: true },
    { label: 'Entradas (mês)', value: String(entradas) },
    { label: 'Saídas (mês)', value: String(saidas) },
  ];

  // Operational data (admin only)
  const lojaStatus = horariosDb.isAberta();
  const caixaAberto = caixaDb.sessoes.aberta();
  const caixaHoje = caixaDb.sessoes.byDate(TODAY);
  const wppHoje = wppDb.pedidos.hoje();
  const wppPendentes = wppHoje.filter(p => p.status !== 'retirado' && p.status !== 'cancelado');
  const todayPonto = pontoDb.todayMap(TODAY);
  const presentes = todayPonto.filter(x => x.registro?.status === 'presente').length;

  return (
    <div>
      {/* Stats row */}
      <div style={{ display: 'grid', gridTemplateColumns: isAdmin ? 'repeat(4, 1fr)' : 'repeat(2, 1fr)', gap: 1, background: C.border, border: `1px solid ${C.border}`, borderRadius: 5, overflow: 'hidden', marginBottom: 20 }}>
        {(isAdmin ? stats : stats.slice(0, 2)).map((s, i) => (
          <div key={i} style={{ background: C.white, padding: '14px 16px' }}>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{s.label}</div>
            <div style={{ fontSize: 22, fontWeight: 600, color: s.warn ? '#B54708' : C.text }}>{s.value}</div>
          </div>
        ))}
      </div>

      {!isAdmin ? (
        <div>
          <div style={{ fontSize: 12, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>Acesso rápido</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {[
              { label: 'Produtos', to: '/produtos' },
              { label: 'Clientes', to: '/clientes' },
              { label: 'Estoque', to: '/estoque' },
              { label: 'Folha de Ponto', to: '/ponto' },
            ].map(q => (
              <button key={q.to} onClick={() => navigate(q.to)} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 4, padding: '12px 16px', cursor: 'pointer', textAlign: 'left', fontSize: 13, fontWeight: 500, color: C.navy, fontFamily: 'Inter, sans-serif' }}>
                {q.label}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div>
          {/* ── Painel operacional ── */}
          <div style={{ fontSize: 12, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>
            Painel operacional
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10, marginBottom: 20 }}>
            {/* Loja */}
            <div
              onClick={() => navigate('/configuracoes')}
              style={{ background: lojaStatus.aberta ? '#ECFDF3' : '#FEF3F2', border: `1px solid ${lojaStatus.aberta ? '#A9EFC5' : '#FECDCA'}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: lojaStatus.aberta ? '#027A48' : '#B42318', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Loja</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: lojaStatus.aberta ? '#027A48' : '#B42318' }}>
                {lojaStatus.aberta ? '🟢 Aberta' : '🔴 Fechada'}
              </div>
              <div style={{ fontSize: 11, color: lojaStatus.aberta ? '#027A48' : '#B42318', marginTop: 2 }}>
                {lojaStatus.aberta ? `até ${lojaStatus.fechamento}` : `abre ${lojaStatus.abertura}`}
              </div>
            </div>

            {/* Caixa */}
            <div
              onClick={() => navigate('/caixa')}
              style={{ background: caixaAberto ? '#ECFDF3' : '#F9FAFB', border: `1px solid ${caixaAberto ? '#A9EFC5' : C.border}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Caixa</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: caixaAberto ? '#027A48' : C.textMuted }}>
                {caixaAberto ? '🟢 Aberto' : caixaHoje ? '⬛ Fechado' : '⬜ Não aberto'}
              </div>
              {caixaHoje && (
                <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>
                  {caixaHoje.status === 'aberto' ? `desde ${caixaHoje.horaAbertura}` : `fechado ${caixaHoje.horaFechamento}`}
                </div>
              )}
            </div>

            {/* Vendas hoje */}
            <div
              onClick={() => navigate('/caixa')}
              style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Vendas hoje</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: C.navy }}>
                {caixaHoje ? (caixaHoje.totalEntradas).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : 'R$ 0,00'}
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>caixa do dia</div>
            </div>

            {/* WhatsApp pedidos */}
            <div
              onClick={() => navigate('/whatsapp-pedidos')}
              style={{ background: wppPendentes.length > 0 ? '#FFFBEB' : C.white, border: `1px solid ${wppPendentes.length > 0 ? '#FDE68A' : C.border}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>WhatsApp</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: wppPendentes.length > 0 ? '#B54708' : C.text }}>
                {wppPendentes.length} pendente{wppPendentes.length !== 1 ? 's' : ''}
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{wppHoje.length} pedidos hoje</div>
            </div>

            {/* Funcionários presentes */}
            <div
              onClick={() => navigate('/ponto')}
              style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Funcionários</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: C.text }}>
                {presentes}/{pontoDb.users.length} presentes
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>hoje</div>
            </div>

            {/* Estoque crítico */}
            <div
              onClick={() => navigate('/estoque')}
              style={{ background: lowStockCount > 0 ? '#FFFBEB' : C.white, border: `1px solid ${lowStockCount > 0 ? '#FDE68A' : C.border}`, borderRadius: 5, padding: '12px 14px', cursor: 'pointer' }}
            >
              <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 4 }}>Estoque</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: lowStockCount > 0 ? '#B54708' : '#027A48' }}>
                {lowStockCount > 0 ? `${lowStockCount} em alerta` : 'Tudo ok'}
              </div>
              <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2 }}>{total} produtos</div>
            </div>
          </div>

          {/* Alertas */}
          {alerts.length > 0 && (
            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>
                Alertas
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {alerts.map((a, i) => (
                  <div
                    key={i}
                    onClick={() => a.to && navigate(a.to)}
                    style={{
                      background: a.bg, border: `1px solid ${a.border}`,
                      borderRadius: 5, padding: '8px 14px',
                      display: 'flex', alignItems: 'center', gap: 10,
                      cursor: a.to ? 'pointer' : 'default',
                    }}
                  >
                    <span style={{ fontSize: 14 }}>⚠️</span>
                    <span style={{ fontSize: 13, color: a.color, fontWeight: 500 }}>{a.msg}</span>
                    {a.to && <span style={{ marginLeft: 'auto', fontSize: 12, color: a.color }}>Ver →</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Funcionários hoje */}
          {todayPonto.some(x => x.registro) && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8 }}>Funcionários hoje</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' as const }}>
                {todayPonto.map(({ user: u, registro: r }) => (
                  <div key={u.id} style={{
                    background: r?.status === 'presente' ? '#ECFDF3' : r?.status === 'folga' ? '#EFF6FF' : '#FEF3F2',
                    border: `1px solid ${r?.status === 'presente' ? '#A9EFC5' : r?.status === 'folga' ? '#BFDBFE' : '#FECDCA'}`,
                    borderRadius: 4, padding: '6px 12px',
                  }}>
                    <div style={{ fontSize: 12, fontWeight: 500, color: C.text }}>{u.name.split(' ')[0]}</div>
                    <div style={{ fontSize: 11, color: r?.status === 'presente' ? '#027A48' : r?.status === 'folga' ? '#1D4ED8' : '#B42318' }}>
                      {r ? (r.status === 'presente' ? `${r.entrada ?? '--'} → ${r.saida ?? 'em serv.'}` : r.status === 'folga' ? 'Folga' : 'Ausente') : 'Sem registro'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            {/* Critical stock */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>Estoque crítico</span>
                <button onClick={() => navigate('/estoque')} style={{ fontSize: 12, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter, sans-serif' }}>Ver estoque</button>
              </div>
              <div style={tableWrap}>
                <table style={tbl}>
                  <thead>
                    <tr>
                      <th style={TH}>Cód.</th>
                      <th style={TH}>Produto</th>
                      <th style={{ ...TH, textAlign: 'right' }}>Qtd.</th>
                      <th style={TH}>Situação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {criticalItems.slice(0, 5).map((r, i) => (
                      <tr key={i} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                        <td style={{ ...TD, color: C.textMuted, fontFamily: 'monospace', fontSize: 12 }}>{r.code}</td>
                        <td style={{ ...TD, fontWeight: 500 }}>{r.name}</td>
                        <td style={{ ...TD, textAlign: 'right', fontWeight: 600, color: r.qty === 0 ? C.error : '#B54708' }}>{r.qty}</td>
                        <td style={TD}>
                          <Badge style={r.status === 'Sem estoque' ? badge.noStock : badge.lowStock}>
                            {r.status === 'Sem estoque' ? 'Sem estoque' : 'Baixo'}
                          </Badge>
                        </td>
                      </tr>
                    ))}
                    {criticalItems.length === 0 && (
                      <tr><td colSpan={4} style={{ ...TD, textAlign: 'center', color: C.success, padding: '16px 12px', fontSize: 12 }}>Todos os produtos estão em estoque.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recent movements */}
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>Movimentações recentes</span>
                <button onClick={() => navigate('/estoque/movimentacoes')} style={{ fontSize: 12, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter, sans-serif' }}>Ver todas</button>
              </div>
              <div style={tableWrap}>
                <table style={tbl}>
                  <thead>
                    <tr>
                      <th style={TH}>Data</th>
                      <th style={TH}>Tipo</th>
                      <th style={TH}>Produto</th>
                      <th style={{ ...TH, textAlign: 'right' }}>Qtd.</th>
                      <th style={TH}>Usuário</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentMovements.map((m, i) => (
                      <tr key={i} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                        <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap', fontSize: 12 }}>{m.date}</td>
                        <td style={TD}>
                          <Badge style={m.type === 'Entrada' ? badge.entrada : badge.saida}>{m.type}</Badge>
                        </td>
                        <td style={{ ...TD, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{m.productName}</td>
                        <td style={{ ...TD, textAlign: 'right', fontWeight: 600, color: m.type === 'Entrada' ? C.success : C.error }}>
                          {m.type === 'Entrada' ? '+' : '-'}{m.qty}
                        </td>
                        <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap' }}>{m.userName}</td>
                      </tr>
                    ))}
                    {recentMovements.length === 0 && (
                      <tr><td colSpan={5} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '16px 12px' }}>Sem movimentações.</td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          {/* Últimas atividades */}
          {recentActivity.length > 0 && (
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>Últimas atividades</span>
                <button onClick={() => navigate('/auditoria')} style={{ fontSize: 12, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter, sans-serif' }}>Ver histórico</button>
              </div>
              <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 6, overflow: 'hidden' }}>
                {recentActivity.map((entry, i) => (
                  <div key={entry.id} style={{
                    padding: '9px 14px',
                    borderTop: i > 0 ? ROW_BORDER : undefined,
                    display: 'flex', gap: 10, alignItems: 'baseline',
                  }}>
                    <span style={{ fontSize: 11, color: C.textMuted, whiteSpace: 'nowrap', flexShrink: 0 }}>{entry.date} {entry.time}</span>
                    <span style={{ fontSize: 13, color: C.text, flex: 1 }}>
                      <span style={{ fontWeight: 500 }}>{entry.userName}</span>
                      {' '}{entry.action.toLowerCase()}{entry.target ? `: ${entry.target}` : ''}
                    </span>
                    <span style={{ fontSize: 11, color: C.textMuted, whiteSpace: 'nowrap', flexShrink: 0 }}>{entry.module}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
