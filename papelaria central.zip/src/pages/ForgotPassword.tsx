import { useState } from 'react';
import { Link } from 'react-router';
import { C, inp } from '../theme';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !/\S+@\S+\.\S+/.test(email)) { setError('Informe um e-mail válido.'); return; }
    setError(''); setSent(true);
  };

  return (
    <div style={{ minHeight: '100vh', background: '#F8F9FA', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
      <div style={{ width: '100%', maxWidth: 360 }}>
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 11, color: C.textMuted, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 4 }}>Papelaria Central</div>
          <h1 style={{ fontSize: 17, fontWeight: 600, color: C.text, margin: '0 0 4px' }}>Recuperar senha</h1>
          <p style={{ fontSize: 13, color: C.textMuted, margin: 0 }}>Informe seu e-mail para receber as instruções.</p>
        </div>

        <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: 24 }}>
          {sent ? (
            <div>
              <div style={{ background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 4, padding: '10px 12px', marginBottom: 16, fontSize: 13, color: '#027A48' }}>
                E-mail enviado para <strong>{email}</strong>. Verifique sua caixa de entrada.
              </div>
              <Link to="/" style={{ fontSize: 13, color: C.navy, fontWeight: 500 }}>← Voltar para o login</Link>
            </div>
          ) : (
            <form onSubmit={handleSubmit} noValidate>
              <div style={{ marginBottom: 16 }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>E-mail</label>
                <input
                  type="email" value={email}
                  onChange={e => { setEmail(e.target.value); setError(''); }}
                  placeholder="seu@email.com.br"
                  style={inp(!!error)}
                />
                {error && <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 }}>{error}</span>}
              </div>
              <button type="submit" style={{ width: '100%', padding: '8px', background: C.navy, color: C.white, border: 'none', borderRadius: 4, fontSize: 13, fontWeight: 500, cursor: 'pointer', marginBottom: 14 }}>
                Enviar link de recuperação
              </button>
              <div style={{ textAlign: 'center' }}>
                <Link to="/" style={{ fontSize: 12, color: C.navy }}>← Voltar para o login</Link>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
