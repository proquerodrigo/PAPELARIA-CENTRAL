import { useNavigate } from 'react-router';
import { C, badge, tbl, TH, TD, tableWrap, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { db } from '../data/db';

export default function Movimentacoes() {
  const navigate = useNavigate();
  const movements = db.movements.all();

  return (
    <div>
      <div style={{ marginBottom: 14 }}>
        <button onClick={() => navigate('/estoque')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.navy, fontFamily: 'Inter, sans-serif', fontSize: 13, padding: 0 }}>
          ← Estoque
        </button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Data', 'Horário', 'Produto', 'Tipo', 'Quantidade', 'Usuário'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {movements.map((m, i) => (
              <tr key={m.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap', fontSize: 12 }}>{m.date}</td>
                <td style={{ ...TD, color: C.textMuted, fontFamily: 'monospace', fontSize: 12 }}>{m.time}</td>
                <td style={{ ...TD, fontWeight: 500 }}>{m.productName}</td>
                <td style={TD}><Badge style={m.type === 'Entrada' ? badge.entrada : badge.saida}>{m.type}</Badge></td>
                <td style={{ ...TD, fontWeight: 600, color: m.type === 'Entrada' ? C.success : C.error }}>
                  {m.type === 'Entrada' ? '+' : '-'}{m.qty} un.
                </td>
                <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap' }}>{m.userName}</td>
              </tr>
            ))}
            {movements.length === 0 && (
              <tr><td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhuma movimentação registrada.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
