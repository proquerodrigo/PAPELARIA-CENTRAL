import { useState, useMemo } from 'react';
import { C, inp, btnPrimary, btnSecondary, formCard, tbl, TH, TD, tableWrap, ROW_BORDER } from '../theme';
import { fornecedoresDb } from '../data/fornecedoresDb';
import { db, newId, calcStatus, DBProduct } from '../data/db';
import { comprasDb, NFItem } from '../data/comprasDb';
import { useApp } from '../context/AppContext';
import { Toast, Modal } from './Produtos';

/* ── helpers ────────────────────────────────────────────────── */
function todayBR(): string {
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

function fmt(n: number): string {
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

/* ── Step indicator ─────────────────────────────────────────── */
const STEPS = ['Fornecedor', 'Produtos', 'Confirmação'];

function StepIndicator({ current }: { current: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 0, marginBottom: 28 }}>
      {STEPS.map((label, i) => {
        const active = i === current;
        const done   = i < current;
        return (
          <div key={i} style={{ display: 'flex', alignItems: 'center' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%',
                background: done ? C.navy : active ? C.navy : C.metalMid,
                color: done || active ? '#fff' : C.textMuted,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 13, fontWeight: 600,
                border: `2px solid ${done || active ? C.navy : C.metalBorder}`,
              }}>
                {done ? '✓' : i + 1}
              </div>
              <span style={{ fontSize: 11, color: active ? C.navy : C.textMuted, fontWeight: active ? 600 : 400, whiteSpace: 'nowrap' }}>
                {label}
              </span>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{ width: 60, height: 2, background: i < current ? C.navy : C.metalMid, margin: '0 4px', marginBottom: 18 }} />
            )}
          </div>
        );
      })}
    </div>
  );
}

/* ── form label helper ──────────────────────────────────────── */
function FLabel({ children }: { children: React.ReactNode }) {
  return (
    <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
      {children}
    </label>
  );
}

/* ── Step 1: Fornecedor + NF info ───────────────────────────── */
interface Step1Data {
  fornecedorId: string;
  numero: string;
  data: string;
  responsavelId: string;
  responsavelNome: string;
  observacoes: string;
}

function Step1({
  data,
  onChange,
  onNext,
}: {
  data: Step1Data;
  onChange: (patch: Partial<Step1Data>) => void;
  onNext: () => void;
}) {
  const fornecedores = useMemo(() => fornecedoresDb.all().filter(f => f.status === 'Ativo'), []);
  const users        = useMemo(() => db.users.all(), []);
  const [err, setErr] = useState<string | null>(null);

  function validate() {
    if (!data.fornecedorId) return 'Selecione um fornecedor.';
    if (!data.numero.trim()) return 'Informe o número da NF.';
    if (!data.data.trim())   return 'Informe a data da NF.';
    return null;
  }

  function handleNext() {
    const e = validate();
    if (e) { setErr(e); return; }
    setErr(null);
    onNext();
  }

  return (
    <div style={formCard}>
      <h3 style={{ margin: '0 0 20px', fontSize: 15, fontWeight: 600, color: C.text }}>
        Dados do Fornecedor e Nota Fiscal
      </h3>

      {err && (
        <div style={{ background: C.errorBg, border: `1px solid ${C.errorBorder}`, color: C.error, padding: '8px 12px', borderRadius: 6, marginBottom: 16, fontSize: 13 }}>
          {err}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px 20px' }}>
        {/* Fornecedor */}
        <div style={{ gridColumn: '1 / -1' }}>
          <FLabel>Fornecedor *</FLabel>
          <select
            value={data.fornecedorId}
            onChange={e => onChange({ fornecedorId: e.target.value })}
            style={{ ...inp(), appearance: 'auto' }}
          >
            <option value="">— Selecione —</option>
            {fornecedores.map(f => (
              <option key={f.id} value={f.id}>{f.nomeFantasia} — {f.razaoSocial}</option>
            ))}
          </select>
        </div>

        {/* NF número */}
        <div>
          <FLabel>Número da NF *</FLabel>
          <input
            type="text"
            value={data.numero}
            onChange={e => onChange({ numero: e.target.value })}
            placeholder="Ex.: 000142"
            style={inp()}
          />
        </div>

        {/* Data */}
        <div>
          <FLabel>Data *</FLabel>
          <input
            type="text"
            value={data.data}
            onChange={e => onChange({ data: e.target.value })}
            placeholder="DD/MM/AAAA"
            maxLength={10}
            style={inp()}
          />
        </div>

        {/* Responsável */}
        <div>
          <FLabel>Responsável</FLabel>
          <select
            value={data.responsavelId}
            onChange={e => {
              const u = users.find(u => u.id === e.target.value);
              onChange({ responsavelId: e.target.value, responsavelNome: u?.name ?? '' });
            }}
            style={{ ...inp(), appearance: 'auto' }}
          >
            {users.map(u => (
              <option key={u.id} value={u.id}>{u.name}</option>
            ))}
          </select>
        </div>

        {/* Observações */}
        <div style={{ gridColumn: '1 / -1' }}>
          <FLabel>Observações</FLabel>
          <textarea
            value={data.observacoes}
            onChange={e => onChange({ observacoes: e.target.value })}
            rows={3}
            placeholder="Observações sobre a nota fiscal..."
            style={{ ...inp(), resize: 'vertical', minHeight: 64 }}
          />
        </div>
      </div>

      <div style={{ marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
        <button onClick={handleNext} style={btnPrimary}>Próximo →</button>
      </div>
    </div>
  );
}

/* ── Step 2: Produtos ───────────────────────────────────────── */
function Step2({
  items,
  onAdd,
  onRemove,
  onBack,
  onNext,
}: {
  items: NFItem[];
  onAdd: (item: NFItem) => void;
  onRemove: (productId: string) => void;
  onBack: () => void;
  onNext: () => void;
}) {
  const allProducts = useMemo(() => db.products.all().filter(p => p.active !== false), []);
  const [search, setSearch]   = useState('');
  const [selected, setSelected] = useState<DBProduct | null>(null);
  const [qty, setQty]         = useState('1');
  const [cost, setCost]       = useState('');
  const [addErr, setAddErr]   = useState<string | null>(null);
  const [stepErr, setStepErr] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return q ? allProducts.filter(p => p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q)) : [];
  }, [search, allProducts]);

  const total = items.reduce((s, i) => s + i.subtotal, 0);

  function handleSelectProduct(p: DBProduct) {
    setSelected(p);
    setCost(p.costPrice != null ? String(p.costPrice) : '');
    setQty('1');
    setSearch(p.name);
    setAddErr(null);
  }

  function handleAdd() {
    if (!selected) { setAddErr('Selecione um produto da lista.'); return; }
    const qtyN  = parseInt(qty, 10);
    const costN = parseFloat(cost.replace(',', '.'));
    if (!qtyN || qtyN <= 0)   { setAddErr('Quantidade inválida.'); return; }
    if (isNaN(costN) || costN < 0) { setAddErr('Custo unitário inválido.'); return; }
    if (items.some(i => i.productId === selected.id)) { setAddErr('Produto já adicionado.'); return; }
    onAdd({
      productId: selected.id,
      productName: selected.name,
      qty: qtyN,
      unitCost: costN,
      subtotal: qtyN * costN,
    });
    setSelected(null);
    setSearch('');
    setQty('1');
    setCost('');
    setAddErr(null);
  }

  function handleNext() {
    if (items.length === 0) { setStepErr('Adicione ao menos um produto.'); return; }
    setStepErr(null);
    onNext();
  }

  return (
    <div style={formCard}>
      <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 600, color: C.text }}>
        Produtos da Nota Fiscal
      </h3>

      {/* Search + add row */}
      <div style={{ background: C.metalLight, border: `1px solid ${C.metalBorder}`, borderRadius: 8, padding: 16, marginBottom: 16 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr auto auto auto', gap: 10, alignItems: 'flex-end' }}>
          <div style={{ position: 'relative' }}>
            <FLabel>Buscar produto</FLabel>
            <input
              type="text"
              value={search}
              onChange={e => { setSearch(e.target.value); setSelected(null); }}
              placeholder="Nome ou código..."
              style={inp()}
            />
            {filtered.length > 0 && !selected && (
              <div style={{
                position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 20,
                background: C.white, border: `1px solid ${C.border}`, borderRadius: 6,
                boxShadow: '0 4px 12px rgba(0,0,0,0.12)', maxHeight: 220, overflowY: 'auto',
              }}>
                {filtered.slice(0, 30).map(p => (
                  <div
                    key={p.id}
                    onClick={() => handleSelectProduct(p)}
                    style={{ padding: '8px 12px', cursor: 'pointer', borderBottom: ROW_BORDER, fontSize: 13 }}
                    onMouseEnter={e => (e.currentTarget.style.background = C.metalLight)}
                    onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                  >
                    <span style={{ fontWeight: 500 }}>{p.code}</span> — {p.name}
                    <span style={{ float: 'right', color: C.textMuted }}>{fmt(p.price)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div style={{ minWidth: 80 }}>
            <FLabel>Qtd.</FLabel>
            <input
              type="number"
              min="1"
              value={qty}
              onChange={e => setQty(e.target.value)}
              style={{ ...inp(), width: 80 }}
            />
          </div>
          <div style={{ minWidth: 110 }}>
            <FLabel>Custo unit.</FLabel>
            <input
              type="number"
              min="0"
              step="0.01"
              value={cost}
              onChange={e => setCost(e.target.value)}
              placeholder="0,00"
              style={{ ...inp(), width: 110 }}
            />
          </div>
          <div style={{ paddingBottom: 1 }}>
            <button onClick={handleAdd} style={{ ...btnPrimary, padding: '8px 16px' }}>+ Adicionar</button>
          </div>
        </div>
        {addErr && (
          <div style={{ marginTop: 8, color: C.error, fontSize: 12 }}>{addErr}</div>
        )}
      </div>

      {/* Items table */}
      {items.length > 0 ? (
        <div style={tableWrap}>
          <table style={tbl}>
            <thead>
              <tr>
                <th style={TH}>Produto</th>
                <th style={{ ...TH, textAlign: 'right' }}>Qtd.</th>
                <th style={{ ...TH, textAlign: 'right' }}>Custo unit.</th>
                <th style={{ ...TH, textAlign: 'right' }}>Subtotal</th>
                <th style={{ ...TH, width: 36 }}></th>
              </tr>
            </thead>
            <tbody>
              {items.map(item => (
                <tr key={item.productId} style={{ borderBottom: ROW_BORDER }}>
                  <td style={TD}>{item.productName}</td>
                  <td style={{ ...TD, textAlign: 'right' }}>{item.qty}</td>
                  <td style={{ ...TD, textAlign: 'right' }}>{fmt(item.unitCost)}</td>
                  <td style={{ ...TD, textAlign: 'right', fontWeight: 500 }}>{fmt(item.subtotal)}</td>
                  <td style={{ ...TD, textAlign: 'center' }}>
                    <button
                      onClick={() => onRemove(item.productId)}
                      title="Remover"
                      style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.error, fontSize: 15, lineHeight: 1, padding: '2px 6px' }}
                    >
                      ✕
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div style={{ textAlign: 'center', padding: '28px 0', color: C.textMuted, fontSize: 13, background: C.white, border: `1px dashed ${C.border}`, borderRadius: 8 }}>
          Nenhum produto adicionado ainda.
        </div>
      )}

      {/* Running total */}
      {items.length > 0 && (
        <div style={{ marginTop: 12, display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ background: C.metalLight, border: `1px solid ${C.metalBorder}`, borderRadius: 8, padding: '10px 18px', fontSize: 14, fontWeight: 600, color: C.text }}>
            Total: {fmt(total)}
          </div>
        </div>
      )}

      {stepErr && (
        <div style={{ marginTop: 12, color: C.error, fontSize: 12 }}>{stepErr}</div>
      )}

      <div style={{ marginTop: 20, display: 'flex', justifyContent: 'space-between' }}>
        <button onClick={onBack} style={btnSecondary}>← Voltar</button>
        <button onClick={handleNext} style={btnPrimary}>Próximo →</button>
      </div>
    </div>
  );
}

/* ── Step 3: Confirmação ────────────────────────────────────── */
function Step3({
  step1,
  items,
  onBack,
  onConfirm,
}: {
  step1: Step1Data;
  items: NFItem[];
  onBack: () => void;
  onConfirm: () => void;
}) {
  const total = items.reduce((s, i) => s + i.subtotal, 0);
  const fornecedor = useMemo(() => fornecedoresDb.findById(step1.fornecedorId), [step1.fornecedorId]);

  return (
    <div style={formCard}>
      <h3 style={{ margin: '0 0 20px', fontSize: 15, fontWeight: 600, color: C.text }}>
        Confirmar Entrada de Mercadoria
      </h3>

      {/* Summary header */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 24px', background: C.metalLight, border: `1px solid ${C.metalBorder}`, borderRadius: 8, padding: 16, marginBottom: 20, fontSize: 13 }}>
        <div>
          <span style={{ color: C.textMuted }}>Fornecedor:</span>{' '}
          <strong>{fornecedor?.nomeFantasia ?? step1.fornecedorId}</strong>
        </div>
        <div>
          <span style={{ color: C.textMuted }}>NF nº:</span>{' '}
          <strong>{step1.numero}</strong>
        </div>
        <div>
          <span style={{ color: C.textMuted }}>Data:</span>{' '}
          <strong>{step1.data}</strong>
        </div>
        <div>
          <span style={{ color: C.textMuted }}>Responsável:</span>{' '}
          <strong>{step1.responsavelNome}</strong>
        </div>
        {step1.observacoes && (
          <div style={{ gridColumn: '1 / -1' }}>
            <span style={{ color: C.textMuted }}>Obs.:</span>{' '}
            <span>{step1.observacoes}</span>
          </div>
        )}
      </div>

      {/* Items */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              <th style={TH}>Produto</th>
              <th style={{ ...TH, textAlign: 'right' }}>Qtd.</th>
              <th style={{ ...TH, textAlign: 'right' }}>Custo unit.</th>
              <th style={{ ...TH, textAlign: 'right' }}>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => (
              <tr key={item.productId} style={{ borderBottom: ROW_BORDER }}>
                <td style={TD}>{item.productName}</td>
                <td style={{ ...TD, textAlign: 'right' }}>{item.qty}</td>
                <td style={{ ...TD, textAlign: 'right' }}>{fmt(item.unitCost)}</td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 500 }}>{fmt(item.subtotal)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Total */}
      <div style={{ marginTop: 12, display: 'flex', justifyContent: 'flex-end' }}>
        <div style={{ background: C.navy, color: '#fff', borderRadius: 8, padding: '10px 20px', fontSize: 15, fontWeight: 700 }}>
          Total da NF: {fmt(total)}
        </div>
      </div>

      <div style={{ marginTop: 24, display: 'flex', justifyContent: 'space-between' }}>
        <button onClick={onBack} style={btnSecondary}>← Voltar</button>
        <button onClick={onConfirm} style={{ ...btnPrimary, padding: '8px 20px', fontSize: 14 }}>
          Confirmar entrada
        </button>
      </div>
    </div>
  );
}

/* ── Main Compras page ──────────────────────────────────────── */
export default function Compras() {
  const { user } = useApp();

  const defaultStep1 = (): Step1Data => ({
    fornecedorId: '',
    numero: '',
    data: todayBR(),
    responsavelId: user?.id ?? '',
    responsavelNome: user?.name ?? '',
    observacoes: '',
  });

  const [step, setStep]     = useState(0);
  const [step1, setStep1]   = useState<Step1Data>(defaultStep1);
  const [items, setItems]   = useState<NFItem[]>([]);
  const [toast, setToast]   = useState<string | null>(null);

  function addItem(item: NFItem) {
    setItems(prev => [...prev, item]);
  }

  function removeItem(productId: string) {
    setItems(prev => prev.filter(i => i.productId !== productId));
  }

  function handleConfirm() {
    const now = new Date();
    const dateBR = now.toLocaleDateString('pt-BR');
    const timeBR = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    // 1. Update stock for each item
    items.forEach(item => {
      const prod = db.products.findById(item.productId);
      if (!prod) return;
      const newQty = prod.qty + item.qty;
      db.products.update(item.productId, {
        qty: newQty,
        status: calcStatus(newQty, prod.minStock),
      });

      // 2. Record movement
      db.movements.add({
        id: newId(),
        date: dateBR,
        time: timeBR,
        type: 'Entrada',
        productId: item.productId,
        productName: item.productName,
        qty: item.qty,
        userName: step1.responsavelNome,
        createdAt: now.toISOString(),
      });
    });

    // 3. Save NF
    const total = items.reduce((s, i) => s + i.subtotal, 0);
    comprasDb.add({
      numero: step1.numero,
      fornecedorId: step1.fornecedorId,
      fornecedorNome: fornecedoresDb.findById(step1.fornecedorId)?.nomeFantasia ?? '',
      data: step1.data,
      valorTotal: total,
      itens: items,
      responsavelId: step1.responsavelId,
      responsavelNome: step1.responsavelNome,
      observacoes: step1.observacoes || undefined,
    });

    // 4. Reset
    setStep(0);
    setStep1(defaultStep1());
    setItems([]);
    setToast(`NF ${step1.numero} registrada com sucesso! ${items.length} produto(s) entrada em estoque.`);
  }

  return (
    <div style={{ maxWidth: 800, margin: '0 auto' }}>
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: C.text }}>Compras / Entrada de NF</h2>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textMuted }}>
          Registre a entrada de mercadoria via nota fiscal em 3 passos.
        </p>
      </div>

      <StepIndicator current={step} />

      {step === 0 && (
        <Step1
          data={step1}
          onChange={patch => setStep1(prev => ({ ...prev, ...patch }))}
          onNext={() => setStep(1)}
        />
      )}

      {step === 1 && (
        <Step2
          items={items}
          onAdd={addItem}
          onRemove={removeItem}
          onBack={() => setStep(0)}
          onNext={() => setStep(2)}
        />
      )}

      {step === 2 && (
        <Step3
          step1={step1}
          items={items}
          onBack={() => setStep(1)}
          onConfirm={handleConfirm}
        />
      )}

      {toast && <Toast msg={toast} />}
    </div>
  );
}
