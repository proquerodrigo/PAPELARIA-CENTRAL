import { useState, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { db, newId, calcStatus } from '../data/db';
import { caixaDb, newCaixaId } from '../data/caixaDb';
import { C, inp, btnPrimary, btnSecondary, formCard } from '../theme';
import { Modal, Toast } from './Produtos';

// ─── helpers ─────────────────────────────────────────────────────────────────

const TODAY = new Date().toISOString().slice(0, 10);

function fmtBRL(v: number): string {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}
function nowHHMM(): string {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
function nowDDMMYYYY(): string {
  const d = new Date();
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

// ─── types ───────────────────────────────────────────────────────────────────

interface CartItem {
  productId: string;
  name: string;
  unitPrice: number;
  qty: number;
  stock: number;
}

type PayMethod = 'Dinheiro' | 'Pix' | 'Cartão de débito' | 'Cartão de crédito';

interface ReceiptData {
  items: CartItem[];
  customerName: string;
  payMethod: PayMethod;
  discount: number;
  subtotal: number;
  total: number;
  cashReceived: number;
  change: number;
  cashierName: string;
  date: string;
  time: string;
}

// ─── Receipt Modal ────────────────────────────────────────────────────────────

function ReceiptModal({ data, onClose }: { data: ReceiptData; onClose: () => void }) {
  const printRef = useRef<HTMLDivElement>(null);

  const doPrint = () => window.print();

  const receiptStyle: React.CSSProperties = {
    fontFamily: 'monospace',
    fontSize: 13,
    color: '#000',
    background: '#fff',
    padding: '20px',
    maxWidth: 360,
    margin: '0 auto',
    lineHeight: '1.6',
  };

  const dividerStyle: React.CSSProperties = {
    borderTop: '1px dashed #999',
    margin: '8px 0',
  };

  const rowStyle: React.CSSProperties = {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: 12,
  };

  return (
    <Modal title="Recibo de Venda" onClose={onClose}>
      <style>{`
        @media print {
          body * { visibility: hidden !important; }
          #receipt-print, #receipt-print * { visibility: visible !important; }
          #receipt-print { position: fixed; top: 0; left: 0; width: 100%; }
        }
      `}</style>

      <div id="receipt-print" ref={printRef} style={receiptStyle}>
        <div style={{ textAlign: 'center', marginBottom: 8 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>Papelaria Central</div>
          <div style={{ fontSize: 11, color: '#555' }}>CNPJ: 12.345.678/0001-99</div>
          <div style={{ fontSize: 11, color: '#555' }}>Av. Paulista, 1578 — São Paulo, SP</div>
        </div>

        <div style={dividerStyle} />

        <div style={rowStyle}><span>Data:</span><span>{data.date} {data.time}</span></div>
        <div style={rowStyle}><span>Operador:</span><span>{data.cashierName}</span></div>
        {data.customerName && (
          <div style={rowStyle}><span>Cliente:</span><span>{data.customerName}</span></div>
        )}

        <div style={dividerStyle} />

        <div style={{ fontSize: 11, fontWeight: 600, marginBottom: 4 }}>ITENS</div>
        {data.items.map((item) => (
          <div key={item.productId} style={{ marginBottom: 4 }}>
            <div style={{ fontSize: 12 }}>{item.name}</div>
            <div style={rowStyle}>
              <span style={{ color: '#555', fontSize: 11 }}>{item.qty}x {fmtBRL(item.unitPrice)}</span>
              <span style={{ fontWeight: 600, fontSize: 12 }}>{fmtBRL(item.qty * item.unitPrice)}</span>
            </div>
          </div>
        ))}

        <div style={dividerStyle} />

        <div style={rowStyle}><span>Subtotal:</span><span>{fmtBRL(data.subtotal)}</span></div>
        {data.discount > 0 && (
          <div style={{ ...rowStyle, color: C.success }}>
            <span>Desconto ({data.discount}%):</span>
            <span>-{fmtBRL(data.subtotal * data.discount / 100)}</span>
          </div>
        )}
        <div style={{ ...rowStyle, fontWeight: 700, fontSize: 14, marginTop: 4 }}>
          <span>TOTAL:</span><span>{fmtBRL(data.total)}</span>
        </div>

        <div style={dividerStyle} />

        <div style={rowStyle}><span>Pagamento:</span><span>{data.payMethod}</span></div>
        {data.payMethod === 'Dinheiro' && data.cashReceived > 0 && (
          <>
            <div style={rowStyle}><span>Recebido:</span><span>{fmtBRL(data.cashReceived)}</span></div>
            <div style={rowStyle}><span>Troco:</span><span>{fmtBRL(data.change)}</span></div>
          </>
        )}

        <div style={dividerStyle} />

        <div style={{ textAlign: 'center', fontSize: 12, color: '#555', marginTop: 8 }}>
          Obrigado pela preferência!
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20 }}>
        <button style={btnSecondary} onClick={onClose}>Fechar</button>
        <button style={btnPrimary} onClick={doPrint}>🖨️ Imprimir</button>
      </div>
    </Modal>
  );
}

// ─── Cart Item Row ────────────────────────────────────────────────────────────

function CartRow({
  item,
  onQtyChange,
  onRemove,
}: {
  item: CartItem;
  onQtyChange: (id: string, qty: number) => void;
  onRemove: (id: string) => void;
}) {
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '8px 0',
        borderBottom: `1px solid ${C.borderLight}`,
      }}
    >
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: C.text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{item.name}</div>
        <div style={{ fontSize: 11, color: C.textMuted }}>{fmtBRL(item.unitPrice)} / un</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        <button
          style={{ ...btnSecondary, padding: '2px 7px', fontSize: 14 }}
          onClick={() => onQtyChange(item.productId, item.qty - 1)}
          disabled={item.qty <= 1}
        >−</button>
        <span style={{ fontSize: 13, minWidth: 24, textAlign: 'center' }}>{item.qty}</span>
        <button
          style={{ ...btnSecondary, padding: '2px 7px', fontSize: 14 }}
          onClick={() => onQtyChange(item.productId, item.qty + 1)}
          disabled={item.qty >= item.stock}
        >+</button>
      </div>
      <div style={{ fontSize: 13, fontWeight: 600, color: C.text, minWidth: 70, textAlign: 'right' }}>
        {fmtBRL(item.qty * item.unitPrice)}
      </div>
      <button
        style={{ ...btnSecondary, padding: '2px 7px', fontSize: 12, color: C.error, borderColor: C.errorBorder }}
        onClick={() => onRemove(item.productId)}
        title="Remover item"
      >✕</button>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────

export default function Vendas() {
  const { user } = useApp();

  // Product search
  const [search, setSearch] = useState('');
  const products = useMemo(() => db.products.all(), []);
  const customers = useMemo(() => db.customers.all().filter(c => c.status === 'Ativo'), []);

  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return products.filter(p => {
      if (p.qty <= 0) return false;
      if (p.active === false) return false;
      if (!q) return true;
      return (
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        (p.brand ?? '').toLowerCase().includes(q)
      );
    });
  }, [products, search]);

  // Cart state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [customerId, setCustomerId] = useState('');
  const [payMethod, setPayMethod] = useState<PayMethod>('Dinheiro');
  const [cashReceived, setCashReceived] = useState('');
  const [discount, setDiscount] = useState('');
  const [toast, setToast] = useState('');
  const [receipt, setReceipt] = useState<ReceiptData | null>(null);

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 4000); };

  // Cart calculations
  const subtotal = cart.reduce((s, i) => s + i.unitPrice * i.qty, 0);
  const discountPct = Math.min(100, Math.max(0, parseFloat(discount) || 0));
  const discountAmt = subtotal * discountPct / 100;
  const total = subtotal - discountAmt;
  const cashReceivedNum = parseFloat(cashReceived.replace(',', '.')) || 0;
  const change = cashReceivedNum - total;

  const addToCart = (productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (!prod) return;
    setCart(prev => {
      const existing = prev.find(i => i.productId === productId);
      if (existing) {
        if (existing.qty >= prod.qty) {
          msg('Quantidade máxima em estoque atingida.');
          return prev;
        }
        return prev.map(i => i.productId === productId ? { ...i, qty: i.qty + 1 } : i);
      }
      return [...prev, { productId: prod.id, name: prod.name, unitPrice: prod.price, qty: 1, stock: prod.qty }];
    });
  };

  const changeQty = (productId: string, qty: number) => {
    if (qty <= 0) return;
    setCart(prev => prev.map(i => i.productId === productId ? { ...i, qty: Math.min(qty, i.stock) } : i));
  };

  const removeItem = (productId: string) => {
    setCart(prev => prev.filter(i => i.productId !== productId));
  };

  const finalizarVenda = () => {
    if (cart.length === 0) { msg('Adicione produtos ao carrinho.'); return; }
    if (payMethod === 'Dinheiro' && cashReceivedNum > 0 && cashReceivedNum < total) {
      msg('Valor recebido menor que o total.'); return;
    }

    const now = new Date();
    const dateStr = nowDDMMYYYY();
    const timeStr = nowHHMM();

    // Deduct stock and register movements
    cart.forEach(item => {
      const prod = db.products.findById(item.productId);
      if (!prod) return;
      const newQty = Math.max(0, prod.qty - item.qty);
      db.products.update(item.productId, { qty: newQty, status: calcStatus(newQty, prod.minStock) });
      db.movements.add({
        id: newId(),
        date: dateStr,
        time: timeStr,
        type: 'Saída',
        productId: item.productId,
        productName: item.name,
        qty: item.qty,
        userName: user?.name ?? 'Operador',
        createdAt: now.toISOString(),
      });
    });

    // Register caixa lancamento if caixa is open today
    const sessaoAberta = caixaDb.sessoes.byDate(TODAY) ?? caixaDb.sessoes.aberta();
    if (sessaoAberta && sessaoAberta.status === 'aberto') {
      caixaDb.lancamentos.add({
        id: newCaixaId(),
        sessaoId: sessaoAberta.id,
        tipo: 'venda',
        descricao: `Venda PDV — ${cart.length} item(ns)${customerId ? ' — ' + (customers.find(c => c.id === customerId)?.name ?? '') : ''}`,
        valor: total,
        formaPagamento: payMethod,
        responsavelId: user?.id ?? '',
        responsavelNome: user?.name ?? 'Operador',
        hora: timeStr,
        createdAt: now.toISOString(),
      });

      // Update session totals
      const totalKey: Record<PayMethod, keyof import('../data/caixaDb').CaixaSessao> = {
        'Dinheiro': 'totalDinheiro',
        'Pix': 'totalPix',
        'Cartão de débito': 'totalDebito',
        'Cartão de crédito': 'totalCredito',
      };
      const k = totalKey[payMethod];
      const prev = (sessaoAberta[k] as number) || 0;
      caixaDb.sessoes.update(sessaoAberta.id, {
        [k]: prev + total,
        totalEntradas: sessaoAberta.totalEntradas + total,
        valorEsperado: sessaoAberta.valorEsperado + total,
      });
    }

    const customerName = customerId ? (customers.find(c => c.id === customerId)?.name ?? '') : '';

    setReceipt({
      items: [...cart],
      customerName,
      payMethod,
      discount: discountPct,
      subtotal,
      total,
      cashReceived: cashReceivedNum,
      change: Math.max(0, change),
      cashierName: user?.name ?? 'Operador',
      date: dateStr,
      time: timeStr,
    });

    // Reset
    setCart([]);
    setCustomerId('');
    setPayMethod('Dinheiro');
    setCashReceived('');
    setDiscount('');
    msg('Venda finalizada com sucesso!');
  };

  // ─── Layout ─────────────────────────────────────────────────────────────────

  const labelStyle: React.CSSProperties = {
    display: 'block',
    fontSize: 12,
    fontWeight: 500,
    color: C.text,
    marginBottom: 4,
  };

  const sectionTitle: React.CSSProperties = {
    fontSize: 13,
    fontWeight: 600,
    color: C.text,
    margin: '0 0 10px 0',
    paddingBottom: 8,
    borderBottom: `1px solid ${C.borderLight}`,
  };

  return (
    <div style={{ padding: '20px 24px', fontFamily: 'Inter, sans-serif', minHeight: '100vh', background: C.bg }}>
      <Toast msg={toast} />

      {receipt && (
        <ReceiptModal data={receipt} onClose={() => setReceipt(null)} />
      )}

      <div style={{ marginBottom: 16 }}>
        <h1 style={{ fontSize: 20, fontWeight: 700, color: C.text, margin: 0 }}>PDV — Ponto de Venda</h1>
        <p style={{ fontSize: 13, color: C.textMuted, margin: '4px 0 0' }}>Registre vendas e emita recibos</p>
      </div>

      <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start', flexWrap: 'wrap' }}>
        {/* ── LEFT PANEL: Product Search ──────────────────────────────────────── */}
        <div style={{ flex: '0 0 55%', minWidth: 300, ...formCard, padding: 16 }}>
          <h2 style={sectionTitle}>Buscar Produtos</h2>
          <input
            style={{ ...inp(), marginBottom: 12 }}
            placeholder="Buscar por nome, código ou marca…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />

          <div style={{ maxHeight: 'calc(100vh - 260px)', overflowY: 'auto' }}>
            {filteredProducts.length === 0 && (
              <div style={{ textAlign: 'center', color: C.textMuted, fontSize: 13, padding: '32px 0' }}>
                Nenhum produto disponível.
              </div>
            )}
            {filteredProducts.map(prod => {
              const inCart = cart.find(i => i.productId === prod.id);
              return (
                <div
                  key={prod.id}
                  onClick={() => addToCart(prod.id)}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    padding: '10px 12px',
                    marginBottom: 4,
                    borderRadius: 6,
                    border: `1px solid ${inCart ? C.navy : C.borderLight}`,
                    background: inCart ? '#F0F1F3' : C.white,
                    cursor: 'pointer',
                    transition: 'border-color 0.15s',
                  }}
                >
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 500, color: C.text, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                      {prod.name}
                    </div>
                    <div style={{ fontSize: 11, color: C.textMuted }}>
                      {prod.code}{prod.brand ? ` · ${prod.brand}` : ''}
                    </div>
                  </div>
                  <div style={{ textAlign: 'right', marginLeft: 12 }}>
                    <div style={{ fontSize: 13, fontWeight: 700, color: C.navy }}>{fmtBRL(prod.price)}</div>
                    <div style={{ fontSize: 11, color: prod.qty <= prod.minStock ? C.warning : C.textMuted }}>
                      {prod.qty} em estoque
                    </div>
                  </div>
                  {inCart && (
                    <div style={{
                      marginLeft: 10,
                      background: C.navy,
                      color: '#fff',
                      borderRadius: 12,
                      fontSize: 11,
                      padding: '2px 7px',
                      whiteSpace: 'nowrap',
                    }}>
                      {inCart.qty} no carrinho
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* ── RIGHT PANEL: Cart ───────────────────────────────────────────────── */}
        <div style={{ flex: '1 1 40%', minWidth: 300, display: 'flex', flexDirection: 'column', gap: 12 }}>
          {/* Cart items */}
          <div style={{ ...formCard, padding: 16 }}>
            <h2 style={sectionTitle}>Carrinho {cart.length > 0 && `(${cart.length})`}</h2>
            {cart.length === 0 ? (
              <div style={{ textAlign: 'center', color: C.textMuted, fontSize: 13, padding: '24px 0' }}>
                Clique em um produto para adicionar.
              </div>
            ) : (
              <div style={{ maxHeight: 260, overflowY: 'auto' }}>
                {cart.map(item => (
                  <CartRow key={item.productId} item={item} onQtyChange={changeQty} onRemove={removeItem} />
                ))}
              </div>
            )}
          </div>

          {/* Payment & details */}
          <div style={{ ...formCard, padding: 16 }}>
            <h2 style={sectionTitle}>Pagamento</h2>

            {/* Customer */}
            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Cliente (opcional)</label>
              <select
                style={{ ...inp() }}
                value={customerId}
                onChange={e => setCustomerId(e.target.value)}
              >
                <option value="">— Sem identificação —</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>

            {/* Payment method */}
            <div style={{ marginBottom: 12 }}>
              <label style={labelStyle}>Forma de pagamento</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {(['Dinheiro', 'Pix', 'Cartão de débito', 'Cartão de crédito'] as PayMethod[]).map(m => (
                  <button
                    key={m}
                    style={{
                      padding: '5px 10px',
                      fontSize: 12,
                      borderRadius: 6,
                      border: `1px solid ${payMethod === m ? C.navy : C.border}`,
                      background: payMethod === m ? C.navy : C.white,
                      color: payMethod === m ? '#fff' : C.text,
                      cursor: 'pointer',
                      fontFamily: 'Inter, sans-serif',
                    }}
                    onClick={() => setPayMethod(m)}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            {/* Cash fields */}
            {payMethod === 'Dinheiro' && (
              <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>Valor recebido (R$)</label>
                  <input
                    style={inp()}
                    placeholder="0,00"
                    value={cashReceived}
                    onChange={e => setCashReceived(e.target.value)}
                  />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={labelStyle}>Troco</label>
                  <div style={{
                    ...inp(),
                    background: C.metalLight,
                    color: change >= 0 ? C.success : C.error,
                    fontWeight: 600,
                  }}>
                    {cashReceivedNum > 0 ? fmtBRL(Math.max(0, change)) : '—'}
                  </div>
                </div>
              </div>
            )}

            {/* Discount */}
            <div style={{ marginBottom: 16 }}>
              <label style={labelStyle}>Desconto (%)</label>
              <input
                style={{ ...inp(), width: 120 }}
                type="number"
                min={0}
                max={100}
                placeholder="0"
                value={discount}
                onChange={e => setDiscount(e.target.value)}
              />
            </div>

            {/* Totals */}
            <div style={{
              background: C.metalLight,
              border: `1px solid ${C.metalBorder}`,
              borderRadius: 6,
              padding: '12px 14px',
              marginBottom: 14,
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>
                <span>Subtotal</span><span>{fmtBRL(subtotal)}</span>
              </div>
              {discountPct > 0 && (
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: C.success, marginBottom: 4 }}>
                  <span>Desconto ({discountPct}%)</span><span>-{fmtBRL(discountAmt)}</span>
                </div>
              )}
              <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 16, fontWeight: 700, color: C.navy, borderTop: `1px solid ${C.border}`, paddingTop: 8, marginTop: 4 }}>
                <span>Total</span><span>{fmtBRL(total)}</span>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 8 }}>
              <button
                style={{ ...btnSecondary, flex: 1 }}
                onClick={() => { setCart([]); setDiscount(''); setCashReceived(''); }}
                disabled={cart.length === 0}
              >
                Limpar
              </button>
              <button
                style={{ ...btnPrimary, flex: 2, fontSize: 14, padding: '9px 14px' }}
                onClick={finalizarVenda}
                disabled={cart.length === 0}
              >
                Finalizar venda →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
