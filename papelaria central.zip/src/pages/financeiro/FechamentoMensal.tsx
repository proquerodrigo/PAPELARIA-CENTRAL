import { useState, useMemo } from 'react';
import { finDb, fmtBRL, filterByPeriod } from '../../data/finDb';
import { useApp } from '../../context/AppContext';
import { Toast } from '../Produtos';
import { C, btnPrimary, btnSecondary } from '../../theme';

interface Fechamento {
  month: string; // YYYY-MM
  closedAt: string;
  closedBy: string;
}

const CLOSED_KEY = 'pc_v1_meses_fechados';

function loadClosed(): Fechamento[] {
  try {
    const r = localStorage.getItem(CLOSED_KEY);
    return r ? JSON.parse(r) : [];
  } catch {
    return [];
  }
}

function saveClosed(list: Fechamento[]) {
  localStorage.setItem(CLOSED_KEY, JSON.stringify(list));
}

/** Generate list of months from 2025-06 to today */
function generateMonths(): string[] {
  const months: string[] = [];
  const start = new Date(2025, 5, 1); // June 2025
  const today = new Date();
  const end = new Date(today.getFullYear(), today.getMonth(), 1);
  const cur = new Date(start);
  while (cur <= end) {
    months.push(`${cur.getFullYear()}-${String(cur.getMonth() + 1).padStart(2, '0')}`);
    cur.setMonth(cur.getMonth() + 1);
  }
  return months.reverse(); // most recent first
}

function monthLabel(m: string): string {
  const [y, mo] = m.split('-');
  const names = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];
  return `${names[parseInt(mo) - 1]}/${y}`;
}

function monthRange(month: string): { from: string; to: string } {
  const [y, m] = month.split('-').map(Number);
  const lastDay = new Date(y, m, 0).getDate();
  return {
    from: `${month}-01`,
    to: `${month}-${String(lastDay).padStart(2, '0')}`,
  };
}

function calcMonth(month: string) {
  const { from, to } = monthRange(month);

  const allSales = finDb.sales.all();
  const allExpenses = finDb.expenses.all();
  const allRevenues = finDb.revenues.all();
  const allPayroll = finDb.payroll.all();

  const sales = filterByPeriod(allSales, from, to, 'date');
  const expenses = filterByPeriod(allExpenses, from, to, 'date');
  const revenues = filterByPeriod(allRevenues, from, to, 'date');
  const payroll = allPayroll.filter(p => p.month === month);

  const faturamento = sales.reduce((s, x) => s + x.grossValue, 0);
  const numVendas = sales.length;
  const ticketMedio = numVendas > 0 ? faturamento / numVendas : 0;

  const custos = expenses
    .filter(e => e.status === 'Pago' && e.category === 'Compra de estoque')
    .reduce((s, e) => s + e.value, 0);

  const despesas = expenses
    .filter(e => e.status === 'Pago' && e.category !== 'Compra de estoque')
    .reduce((s, e) => s + e.value, 0);

  const payrollPago = payroll
    .filter(p => p.status === 'Pago')
    .reduce((s, p) => s + p.total, 0);

  const lucroBruto = faturamento - custos;
  const lucroLiquido = lucroBruto - despesas - payrollPago;
  const margem = faturamento > 0 ? lucroLiquido / faturamento * 100 : 0;

  const entradas = revenues.filter(r => r.status === 'Pago').reduce((s, r) => s + r.value, 0);
  const saidas = expenses.filter(e => e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const saldo = entradas - saidas;

  return {
    faturamento, custos, despesas, lucroBruto, lucroLiquido,
    margem, numVendas, ticketMedio, entradas, saidas, saldo,
  };
}

function KpiCard({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div style={{
      background: C.white,
      border: `1px solid ${C.border}`,
      borderRadius: 8,
      padding: '12px 16px',
      minWidth: 120,
      flex: 1,
    }}>
      <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {label}
      </div>
      <div style={{ fontSize: 16, fontWeight: 700, color: color ?? C.text }}>
        {value}
      </div>
    </div>
  );
}

export default function FechamentoMensal() {
  const { user } = useApp();
  const months = useMemo(() => generateMonths(), []);
  const [selected, setSelected] = useState(months[0]);
  const [closed, setClosed] = useState<Fechamento[]>(loadClosed);
  const [toast, setToast] = useState('');

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };

  const stats = useMemo(() => calcMonth(selected), [selected]);

  const closedEntry = closed.find(c => c.month === selected);
  const isClosed = !!closedEntry;

  const handleClose = () => {
    if (isClosed) return;
    const entry: Fechamento = {
      month: selected,
      closedAt: new Date().toISOString(),
      closedBy: user?.name ?? 'Administrador',
    };
    const next = [...closed.filter(c => c.month !== selected), entry];
    saveClosed(next);
    setClosed(next);
    msg(`Mês ${monthLabel(selected)} fechado com sucesso.`);
  };

  const handleReopen = () => {
    const next = closed.filter(c => c.month !== selected);
    saveClosed(next);
    setClosed(next);
    msg(`Mês ${monthLabel(selected)} reaberto.`);
  };

  const margemColor = stats.margem >= 10 ? C.success : stats.margem >= 0 ? C.warning : C.error;

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif', display: 'flex', gap: 20, minHeight: '80vh' }}>
      {toast && <Toast msg={toast} />}

      {/* Left column — month list */}
      <div style={{
        width: 160,
        flexShrink: 0,
        background: C.white,
        border: `1px solid ${C.border}`,
        borderRadius: 8,
        overflow: 'hidden',
        alignSelf: 'flex-start',
      }}>
        <div style={{
          padding: '10px 14px',
          background: C.metalLight,
          borderBottom: `1px solid ${C.metalBorder}`,
          fontSize: 11,
          fontWeight: 600,
          color: C.textMuted,
          textTransform: 'uppercase',
          letterSpacing: '0.05em',
        }}>
          Meses
        </div>
        {months.map(m => {
          const fe = closed.find(c => c.month === m);
          const isActive = m === selected;
          return (
            <button
              key={m}
              onClick={() => setSelected(m)}
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
                padding: '9px 14px',
                background: isActive ? C.navy : 'transparent',
                color: isActive ? C.white : C.text,
                border: 'none',
                borderBottom: `1px solid ${C.borderLight}`,
                cursor: 'pointer',
                fontSize: 13,
                textAlign: 'left',
                fontFamily: 'Inter, sans-serif',
              }}
            >
              <span>{monthLabel(m)}</span>
              {fe && (
                <span style={{ fontSize: 12 }}>🔒</span>
              )}
            </button>
          );
        })}
      </div>

      {/* Right — summary panel */}
      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Title row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div>
            <h1 style={{ fontSize: 18, fontWeight: 700, color: C.text, margin: 0 }}>
              Fechamento — {monthLabel(selected)}
            </h1>
            {isClosed && closedEntry && (
              <p style={{ fontSize: 12, color: C.textMuted, margin: '4px 0 0' }}>
                Fechado em {new Date(closedEntry.closedAt).toLocaleDateString('pt-BR')} por {closedEntry.closedBy}
              </p>
            )}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            {isClosed ? (
              <button style={{ ...btnSecondary, fontSize: 12 }} onClick={handleReopen}>
                Reabrir mês
              </button>
            ) : (
              <button style={{ ...btnPrimary, fontSize: 12 }} onClick={handleClose}>
                Marcar como fechado
              </button>
            )}
          </div>
        </div>

        {/* Closed notice */}
        {isClosed && closedEntry && (
          <div style={{
            background: '#ECFDF3',
            border: '1px solid #A9EFC5',
            borderRadius: 8,
            padding: '10px 16px',
            marginBottom: 16,
            fontSize: 13,
            color: C.success,
            display: 'flex',
            alignItems: 'center',
            gap: 8,
          }}>
            <span>🔒</span>
            <span>
              Mês fechado em {new Date(closedEntry.closedAt).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })} por {closedEntry.closedBy}
            </span>
          </div>
        )}

        {/* KPI grid — row 1 */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
          <KpiCard label="Faturamento" value={fmtBRL(stats.faturamento)} />
          <KpiCard label="Custos (CPV)" value={fmtBRL(stats.custos)} color={C.error} />
          <KpiCard label="Despesas" value={fmtBRL(stats.despesas)} color={C.error} />
          <KpiCard label="Lucro Bruto" value={fmtBRL(stats.lucroBruto)} color={stats.lucroBruto >= 0 ? C.success : C.error} />
          <KpiCard label="Lucro Líquido" value={fmtBRL(stats.lucroLiquido)} color={stats.lucroLiquido >= 0 ? C.success : C.error} />
        </div>

        {/* KPI grid — row 2 */}
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 16 }}>
          <KpiCard
            label="Margem líquida"
            value={`${stats.margem.toFixed(1)}%`}
            color={margemColor}
          />
          <KpiCard label="Nº vendas" value={String(stats.numVendas)} />
          <KpiCard label="Ticket médio" value={fmtBRL(stats.ticketMedio)} />
          <KpiCard label="Entradas" value={fmtBRL(stats.entradas)} color={C.success} />
          <KpiCard label="Saídas" value={fmtBRL(stats.saidas)} color={C.error} />
          <KpiCard label="Saldo" value={fmtBRL(stats.saldo)} color={stats.saldo >= 0 ? C.success : C.error} />
        </div>

        {/* Waterfall summary table */}
        <div style={{
          background: C.white,
          border: `1px solid ${C.border}`,
          borderRadius: 8,
          overflow: 'hidden',
        }}>
          <div style={{
            padding: '10px 16px',
            background: C.metalLight,
            borderBottom: `1px solid ${C.metalBorder}`,
            fontSize: 12,
            fontWeight: 600,
            color: C.textMuted,
            textTransform: 'uppercase',
            letterSpacing: '0.05em',
          }}>
            Resumo financeiro
          </div>
          {[
            { label: 'Faturamento bruto', val: stats.faturamento, plus: true },
            { label: 'Custo dos produtos vendidos', val: stats.custos, minus: true },
            { label: 'Lucro bruto', val: stats.lucroBruto, subtotal: true },
            { label: 'Despesas operacionais', val: stats.despesas, minus: true },
            { label: 'Lucro líquido', val: stats.lucroLiquido, subtotal: true, big: true },
          ].map((row, i) => (
            <div
              key={i}
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                padding: row.subtotal ? '10px 16px' : '8px 16px',
                borderBottom: `1px solid ${C.borderLight}`,
                background: row.subtotal ? C.metalLight : C.white,
              }}
            >
              <span style={{
                fontSize: row.big ? 14 : 13,
                fontWeight: row.subtotal ? 700 : 400,
                color: C.text,
                paddingLeft: (!row.subtotal && !row.plus) ? 12 : 0,
              }}>
                {row.label}
              </span>
              <span style={{
                fontSize: row.big ? 15 : 13,
                fontWeight: row.subtotal ? 700 : 400,
                color: row.minus
                  ? C.error
                  : row.subtotal
                  ? (row.val >= 0 ? C.success : C.error)
                  : C.text,
              }}>
                {row.minus ? `−${fmtBRL(row.val)}` : fmtBRL(row.val)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
