import { useState } from 'react';
import { C, inp, btnPrimary, btnSecondary, tbl, TH, TD, tableWrap, ROW_BORDER, formCard } from '../../theme';
import { Toast, Modal } from '../Produtos';
import { marketingDb, MarketingBudget, MarketingGasto, MarketingCanal } from '../../data/marketingDb';
import { useApp } from '../../context/AppContext';

const CANAIS: MarketingCanal[] = ['Instagram', 'Facebook/Meta Ads', 'Google Ads', 'WhatsApp', 'Panfletagem', 'Outros'];

const CANAL_BADGE: Record<MarketingCanal, React.CSSProperties> = {
  'Instagram':       { background: '#F3E8FF', color: '#7C3AED', border: '1px solid #DDD6FE' },
  'Facebook/Meta Ads': { background: '#EFF6FF', color: '#1D4ED8', border: '1px solid #BFDBFE' },
  'Google Ads':      { background: '#FFF7ED', color: '#C2410C', border: '1px solid #FED7AA' },
  'WhatsApp':        { background: '#ECFDF5', color: '#059669', border: '1px solid #A7F3D0' },
  'Panfletagem':     { background: '#F9FAFB', color: '#374151', border: '1px solid #E5E7EB' },
  'Outros':          { background: '#F9FAFB', color: '#374151', border: '1px solid #E5E7EB' },
};

function canalBadge(canal: MarketingCanal) {
  const s = CANAL_BADGE[canal];
  return (
    <span style={{
      ...s,
      padding: '2px 8px',
      borderRadius: 12,
      fontSize: 11,
      fontWeight: 500,
      display: 'inline-block',
      whiteSpace: 'nowrap',
    }}>{canal}</span>
  );
}

function fmt(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

interface GastoForm {
  canal: MarketingCanal;
  campanha: string;
  valor: string;
  date: string;
  responsavel: string;
  observacao: string;
}

export default function Marketing() {
  const { user } = useApp();
  const [budget, setBudget] = useState<MarketingBudget>(() => marketingDb.get());
  const [toast, setToast] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [filterCanal, setFilterCanal] = useState<string>('Todos');
  const [search, setSearch] = useState('');

  // Budget settings editing
  const [editVerba, setEditVerba] = useState(false);
  const [draftVerba, setDraftVerba] = useState(String(budget.verbaMensal));
  const [draftReservada, setDraftReservada] = useState(String(budget.verbaReservada));

  // Add gasto form
  const [form, setForm] = useState<GastoForm>({
    canal: 'Instagram',
    campanha: '',
    valor: '',
    date: today(),
    responsavel: user?.name ?? 'Administrador',
    observacao: '',
  });
  const [formErr, setFormErr] = useState<Partial<GastoForm>>({});

  function refresh() {
    setBudget(marketingDb.get());
  }

  function showToast(msg: string) {
    setToast(msg);
    setTimeout(() => setToast(''), 3200);
  }

  const totalGasto = budget.gastos.reduce((s, g) => s + g.valor, 0);
  const saldo = budget.verbaMensal - budget.verbaReservada - totalGasto;
  const utilPct = budget.verbaMensal > 0
    ? Math.min(100, Math.round(((budget.verbaReservada + totalGasto) / budget.verbaMensal) * 100))
    : 0;

  const gastoByCanal: Record<string, number> = {};
  for (const g of budget.gastos) {
    gastoByCanal[g.canal] = (gastoByCanal[g.canal] ?? 0) + g.valor;
  }

  const sortedGastos = [...budget.gastos].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  const filteredGastos = sortedGastos.filter(g => {
    const canalOk = filterCanal === 'Todos' || g.canal === filterCanal;
    const q = search.toLowerCase();
    const searchOk = !q || g.campanha.toLowerCase().includes(q) || g.canal.toLowerCase().includes(q) || g.responsavel.toLowerCase().includes(q);
    return canalOk && searchOk;
  });

  // Form handling
  function handleFormChange(field: keyof GastoForm, value: string) {
    setForm(f => ({ ...f, [field]: value }));
    setFormErr(e => ({ ...e, [field]: undefined }));
  }

  function validateForm(): boolean {
    const errs: Partial<GastoForm> = {};
    if (!form.campanha.trim()) errs.campanha = 'Obrigatório';
    if (!form.valor || isNaN(Number(form.valor)) || Number(form.valor) <= 0) errs.valor = 'Valor inválido';
    if (!form.date) errs.date = 'Obrigatório';
    if (!form.responsavel.trim()) errs.responsavel = 'Obrigatório';
    setFormErr(errs);
    return Object.keys(errs).length === 0;
  }

  function handleAddGasto() {
    if (!validateForm()) return;
    marketingDb.addGasto({
      canal: form.canal,
      campanha: form.campanha.trim(),
      valor: Number(form.valor),
      date: form.date,
      responsavel: form.responsavel.trim(),
      observacao: form.observacao.trim() || undefined,
    });
    refresh();
    setShowAddModal(false);
    setForm({ canal: 'Instagram', campanha: '', valor: '', date: today(), responsavel: user?.name ?? 'Administrador', observacao: '' });
    setFormErr({});
    showToast('Gasto registrado com sucesso.');
  }

  function handleDelete(id: string) {
    marketingDb.removeGasto(id);
    refresh();
    setDeleteId(null);
    showToast('Gasto excluído.');
  }

  function handleSaveVerba() {
    const vm = Number(draftVerba);
    const vr = Number(draftReservada);
    if (isNaN(vm) || vm < 0 || isNaN(vr) || vr < 0) {
      showToast('Valores inválidos.');
      return;
    }
    const updated = { ...budget, verbaMensal: vm, verbaReservada: vr };
    marketingDb.set(updated);
    refresh();
    setEditVerba(false);
    showToast('Orçamento atualizado.');
  }

  const barColor = utilPct >= 100 ? C.error : utilPct >= 80 ? C.warning : C.success;

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: C.text }}>
      {toast && <Toast msg={toast} />}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: C.text }}>Marketing</h1>
          <p style={{ margin: '2px 0 0', fontSize: 13, color: C.textMuted }}>Controle de verba e gastos por canal</p>
        </div>
        <button style={btnPrimary} onClick={() => setShowAddModal(true)}>+ Registrar gasto</button>
      </div>

      {/* Budget Overview */}
      <div style={{ ...formCard, marginBottom: 20 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <span style={{ fontWeight: 600, fontSize: 14, color: C.text }}>Orçamento mensal</span>
          {!editVerba ? (
            <button style={btnSecondary} onClick={() => { setEditVerba(true); setDraftVerba(String(budget.verbaMensal)); setDraftReservada(String(budget.verbaReservada)); }}>
              Editar
            </button>
          ) : (
            <div style={{ display: 'flex', gap: 8 }}>
              <button style={btnSecondary} onClick={() => setEditVerba(false)}>Cancelar</button>
              <button style={btnPrimary} onClick={handleSaveVerba}>Salvar</button>
            </div>
          )}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 16 }}>
          <BudgetCard
            label="Verba mensal"
            value={editVerba ? undefined : budget.verbaMensal}
            editValue={editVerba ? draftVerba : undefined}
            onEdit={v => setDraftVerba(v)}
          />
          <BudgetCard
            label="Verba reservada"
            value={editVerba ? undefined : budget.verbaReservada}
            editValue={editVerba ? draftReservada : undefined}
            onEdit={v => setDraftReservada(v)}
          />
          <BudgetCard label="Total gasto" value={totalGasto} />
          <BudgetCard label="Saldo disponível" value={saldo} highlight={saldo < 0 ? 'danger' : saldo < budget.verbaMensal * 0.1 ? 'warning' : 'ok'} />
        </div>

        {/* Progress bar */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>
            <span>Utilização do orçamento</span>
            <span style={{ fontWeight: 600, color: barColor }}>{utilPct}%</span>
          </div>
          <div style={{ background: C.metalMid, borderRadius: 6, height: 8, overflow: 'hidden' }}>
            <div style={{ width: `${utilPct}%`, background: barColor, height: '100%', borderRadius: 6, transition: 'width 0.3s' }} />
          </div>
          <div style={{ display: 'flex', gap: 16, marginTop: 8, fontSize: 11, color: C.textMuted }}>
            <span>■ <span style={{ color: C.success }}>Reservado</span>: {fmt(budget.verbaReservada)}</span>
            <span>■ <span style={{ color: C.warning }}>Gasto</span>: {fmt(totalGasto)}</span>
            <span>■ <span style={{ color: C.textMuted }}>Total alocado</span>: {fmt(budget.verbaMensal)}</span>
          </div>
        </div>
      </div>

      {/* Canal breakdown */}
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 14, fontWeight: 600, margin: '0 0 12px', color: C.text }}>Gastos por canal</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
          {CANAIS.map(canal => {
            const gasto = gastoByCanal[canal] ?? 0;
            const pct = totalGasto > 0 ? Math.round((gasto / totalGasto) * 100) : 0;
            const bs = CANAL_BADGE[canal];
            return (
              <div key={canal} style={{ ...formCard, padding: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  {canalBadge(canal)}
                  <span style={{ fontSize: 12, color: C.textMuted }}>{pct}%</span>
                </div>
                <div style={{ fontSize: 18, fontWeight: 700, color: C.text }}>{fmt(gasto)}</div>
                <div style={{ background: C.metalMid, borderRadius: 4, height: 4, marginTop: 8, overflow: 'hidden' }}>
                  <div style={{ width: `${pct}%`, background: (bs as any).color, height: '100%', borderRadius: 4 }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Histórico */}
      <div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <h2 style={{ fontSize: 14, fontWeight: 600, margin: 0, color: C.text }}>Histórico completo</h2>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Buscar..."
              style={{ ...inp(), width: 180 }}
            />
            <select
              value={filterCanal}
              onChange={e => setFilterCanal(e.target.value)}
              style={{ ...inp(), width: 180 }}
            >
              <option value="Todos">Todos os canais</option>
              {CANAIS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div style={tableWrap}>
          <table style={tbl}>
            <thead>
              <tr>
                {['Data', 'Canal', 'Campanha', 'Valor', 'Responsável', 'Observação', 'Ações'].map(h => (
                  <th key={h} style={TH}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredGastos.length === 0 ? (
                <tr>
                  <td colSpan={7} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>
                    Nenhum gasto encontrado.
                  </td>
                </tr>
              ) : filteredGastos.map((g, i) => (
                <tr key={g.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                  <td style={{ ...TD, whiteSpace: 'nowrap', color: C.textMuted, fontSize: 12 }}>
                    {new Date(g.date + 'T12:00:00').toLocaleDateString('pt-BR')}
                  </td>
                  <td style={TD}>{canalBadge(g.canal)}</td>
                  <td style={{ ...TD, maxWidth: 200 }}>{g.campanha}</td>
                  <td style={{ ...TD, fontWeight: 600, whiteSpace: 'nowrap' }}>{fmt(g.valor)}</td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{g.responsavel}</td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12, maxWidth: 200 }}>{g.observacao ?? '—'}</td>
                  <td style={TD}>
                    <button
                      style={{ padding: '4px 10px', background: C.errorBg, color: C.error, border: `1px solid ${C.errorBorder}`, borderRadius: 6, fontSize: 12, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}
                      onClick={() => setDeleteId(g.id)}
                    >
                      Excluir
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredGastos.length > 0 && (
          <div style={{ marginTop: 8, fontSize: 12, color: C.textMuted }}>
            {filteredGastos.length} registro{filteredGastos.length !== 1 ? 's' : ''} — Total: {fmt(filteredGastos.reduce((s, g) => s + g.valor, 0))}
          </div>
        )}
      </div>

      {/* Add Gasto Modal */}
      {showAddModal && (
        <Modal title="Registrar gasto de marketing" onClose={() => { setShowAddModal(false); setFormErr({}); }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div>
              <label style={lbl}>Canal *</label>
              <select value={form.canal} onChange={e => handleFormChange('canal', e.target.value as MarketingCanal)} style={inp()}>
                {CANAIS.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label style={lbl}>Data *</label>
              <input type="date" value={form.date} onChange={e => handleFormChange('date', e.target.value)} style={{ ...inp(!!formErr.date) }} />
              {formErr.date && <span style={errStyle}>{formErr.date}</span>}
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={lbl}>Campanha *</label>
              <input value={form.campanha} onChange={e => handleFormChange('campanha', e.target.value)} placeholder="Nome da campanha" style={inp(!!formErr.campanha)} />
              {formErr.campanha && <span style={errStyle}>{formErr.campanha}</span>}
            </div>
            <div>
              <label style={lbl}>Valor (R$) *</label>
              <input type="number" min="0" step="0.01" value={form.valor} onChange={e => handleFormChange('valor', e.target.value)} placeholder="0,00" style={inp(!!formErr.valor)} />
              {formErr.valor && <span style={errStyle}>{formErr.valor}</span>}
            </div>
            <div>
              <label style={lbl}>Responsável *</label>
              <input value={form.responsavel} onChange={e => handleFormChange('responsavel', e.target.value)} style={inp(!!formErr.responsavel)} />
              {formErr.responsavel && <span style={errStyle}>{formErr.responsavel}</span>}
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <label style={lbl}>Observação</label>
              <textarea
                value={form.observacao}
                onChange={e => handleFormChange('observacao', e.target.value)}
                rows={3}
                placeholder="Opcional"
                style={{ ...inp(), resize: 'vertical' }}
              />
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 16 }}>
            <button style={btnSecondary} onClick={() => { setShowAddModal(false); setFormErr({}); }}>Cancelar</button>
            <button style={btnPrimary} onClick={handleAddGasto}>Salvar</button>
          </div>
        </Modal>
      )}

      {/* Delete confirmation modal */}
      {deleteId && (() => {
        const g = budget.gastos.find(x => x.id === deleteId);
        return (
          <Modal title="Confirmar exclusão" onClose={() => setDeleteId(null)}>
            <p style={{ margin: '0 0 16px', fontSize: 14, color: C.text }}>
              Deseja excluir o gasto <strong>{g?.campanha}</strong> ({g ? fmt(g.valor) : ''})?
            </p>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button style={btnSecondary} onClick={() => setDeleteId(null)}>Cancelar</button>
              <button
                style={{ ...btnPrimary, background: C.error }}
                onClick={() => handleDelete(deleteId)}
              >
                Excluir
              </button>
            </div>
          </Modal>
        );
      })()}
    </div>
  );
}

// Sub-components

interface BudgetCardProps {
  label: string;
  value?: number;
  editValue?: string;
  onEdit?: (v: string) => void;
  highlight?: 'ok' | 'warning' | 'danger';
}

function BudgetCard({ label, value, editValue, onEdit, highlight }: BudgetCardProps) {
  const color = highlight === 'danger' ? C.error : highlight === 'warning' ? C.warning : C.text;
  return (
    <div style={{ background: C.metalLight, borderRadius: 8, padding: '14px 16px', border: `1px solid ${C.metalBorder}` }}>
      <div style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.04em', marginBottom: 6 }}>{label}</div>
      {editValue !== undefined && onEdit ? (
        <input
          type="number"
          min="0"
          step="0.01"
          value={editValue}
          onChange={e => onEdit(e.target.value)}
          style={{ width: '100%', fontSize: 18, fontWeight: 700, color: C.text, border: 'none', borderBottom: `2px solid ${C.navy}`, background: 'transparent', outline: 'none', padding: '2px 0', fontFamily: 'Inter, sans-serif' }}
        />
      ) : (
        <div style={{ fontSize: 18, fontWeight: 700, color }}>{value !== undefined ? value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }) : '—'}</div>
      )}
    </div>
  );
}

const lbl: React.CSSProperties = {
  display: 'block',
  fontSize: 12,
  fontWeight: 500,
  color: C.text,
  marginBottom: 4,
};

const errStyle: React.CSSProperties = {
  fontSize: 11,
  color: C.error,
  marginTop: 2,
  display: 'block',
};
