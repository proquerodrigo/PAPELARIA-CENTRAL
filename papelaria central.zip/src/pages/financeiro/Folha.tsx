import { useState, useMemo } from 'react';
import { finDb, fmtBRL, type FinPayroll } from '../../data/finDb';
import { useApp } from '../../context/AppContext';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER } from '../../theme';
import { Toast } from '../Produtos';

const MONTHS = [
  { value: '2026-09', label: 'Setembro/2026' },
  { value: '2026-08', label: 'Agosto/2026' },
  { value: '2026-07', label: 'Julho/2026' },
];

export default function Folha() {
  const { user } = useApp();
  const [month, setMonth] = useState('2026-09');
  const [items, setItems] = useState<FinPayroll[]>(() => finDb.payroll.all());
  const [toast, setToast] = useState('');

  const refresh = () => setItems(finDb.payroll.all());
  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };

  const monthItems = useMemo(() => items.filter(p => p.month === month), [items, month]);

  const totalSalario = monthItems.reduce((s, p) => s + p.salary, 0);
  const totalVR = monthItems.reduce((s, p) => s + p.vr, 0);
  const totalVT = monthItems.reduce((s, p) => s + p.vt, 0);
  const totalGeral = monthItems.reduce((s, p) => s + p.total, 0);
  const totalPago = monthItems.filter(p => p.status === 'Pago').reduce((s, p) => s + p.total, 0);
  const totalPendente = monthItems.filter(p => p.status === 'Pendente').reduce((s, p) => s + p.total, 0);

  const markPaid = (id: string) => {
    finDb.payroll.markPaid(id, user?.name ?? 'Administrador');
    refresh();
    msg('Pagamento marcado como realizado.');
  };

  const markPending = (id: string) => {
    finDb.payroll.markPending(id);
    refresh();
    msg('Status alterado para pendente.');
  };

  const generateMonth = () => {
    finDb.payroll.generateMonth(month);
    refresh();
    msg('Folha gerada para o período.');
  };

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 8, marginBottom: 16, alignItems: 'center' }}>
        <select value={month} onChange={e => setMonth(e.target.value)} style={sinp}>
          {MONTHS.map(m => <option key={m.value} value={m.value}>{m.label}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        {monthItems.length === 0 && (
          <button onClick={generateMonth} style={{ padding: '6px 12px', fontSize: 13, border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.navy, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
            Gerar folha do mês
          </button>
        )}
      </div>

      {/* Resumo */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))', gap: 10, marginBottom: 20 }}>
        {[
          { label: 'Total salários', value: fmtBRL(totalSalario) },
          { label: 'Total VR', value: fmtBRL(totalVR) },
          { label: 'Total VT', value: fmtBRL(totalVT) },
          { label: 'Total da folha', value: fmtBRL(totalGeral), bold: true },
          { label: 'Total pago', value: fmtBRL(totalPago), color: '#027A48' },
          { label: 'Total pendente', value: fmtBRL(totalPendente), color: totalPendente > 0 ? '#B54708' : C.text },
        ].map(c => (
          <div key={c.label} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '10px 14px' }}>
            <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 3 }}>{c.label}</div>
            <div style={{ fontSize: 15, fontWeight: c.bold ? 700 : 600, color: c.color ?? C.text }}>{c.value}</div>
          </div>
        ))}
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Funcionário', 'Cargo', 'Salário', 'VR', 'VT', 'Total', 'Status', 'Data pgto.', 'Ação'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {monthItems.map((p, i) => (
              <tr key={p.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{p.name}</td>
                <td style={{ ...TD, color: C.textMuted }}>{p.jobTitle}</td>
                <td style={TD}>{fmtBRL(p.salary)}</td>
                <td style={TD}>{fmtBRL(p.vr)}</td>
                <td style={TD}>{fmtBRL(p.vt)}</td>
                <td style={{ ...TD, fontWeight: 600 }}>{fmtBRL(p.total)}</td>
                <td style={TD}>
                  {p.status === 'Pago'
                    ? <span style={{ background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 }}>✓ PAGO</span>
                    : <span style={{ background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '2px 8px', fontSize: 11 }}>PENDENTE</span>}
                </td>
                <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>
                  {p.paymentDate ? p.paymentDate.split('-').reverse().join('/') : '—'}
                </td>
                <td style={TD}>
                  {p.status === 'Pendente'
                    ? <button onClick={() => markPaid(p.id)} style={{ padding: '3px 8px', fontSize: 12, background: '#1B3050', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Marcar pago</button>
                    : <button onClick={() => markPending(p.id)} style={{ padding: '3px 8px', fontSize: 12, background: 'none', color: C.textMuted, border: `1px solid ${C.border}`, borderRadius: 4, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Reverter</button>
                  }
                </td>
              </tr>
            ))}
            {monthItems.length === 0 && (
              <tr><td colSpan={9} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>
                Nenhuma folha gerada para este período.
              </td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };
