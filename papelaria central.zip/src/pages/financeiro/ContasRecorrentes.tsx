import { useState } from 'react';
import { finDb } from '../../data/finDb';
import { Modal, Toast } from '../Produtos';
import { C, inp, btnPrimary, btnSecondary, tbl, TH, TD, tableWrap, ROW_BORDER, badge } from '../../theme';

// ── Types ────────────────────────────────────────────────────

type Frequencia = 'Mensal' | 'Semanal' | 'Quinzenal' | 'Anual';
type StatusConta = 'Ativa' | 'Inativa';

interface ContaRecorrente {
  id: string;
  descricao: string;
  categoria: string;
  valor: number;
  frequencia: Frequencia;
  diaVencimento: number;
  proximoVencimento: string; // YYYY-MM-DD
  contaPagamento: string;
  responsavel: string;
  status: StatusConta;
  observacao?: string;
  createdAt: string;
}

// ── Storage ──────────────────────────────────────────────────

const STORAGE_KEY = 'pc_v1_recorrentes';
const SEEDED_KEY = 'pc_v1_recorrentes_seeded';

function newId(): string {
  return `rec-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function nextDate(from: string, freq: Frequencia): string {
  const d = new Date(from + 'T12:00:00');
  switch (freq) {
    case 'Mensal': d.setMonth(d.getMonth() + 1); break;
    case 'Semanal': d.setDate(d.getDate() + 7); break;
    case 'Quinzenal': d.setDate(d.getDate() + 14); break;
    case 'Anual': d.setFullYear(d.getFullYear() + 1); break;
  }
  return d.toISOString().slice(0, 10);
}

const SEED: ContaRecorrente[] = [
  {
    id: 'rec-001', descricao: 'Aluguel', categoria: 'Aluguel',
    valor: 3500, frequencia: 'Mensal', diaVencimento: 5,
    proximoVencimento: '2026-10-05', contaPagamento: 'Conta corrente principal',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
  {
    id: 'rec-002', descricao: 'Energia elétrica', categoria: 'Energia',
    valor: 420, frequencia: 'Mensal', diaVencimento: 8,
    proximoVencimento: '2026-10-08', contaPagamento: 'Conta corrente principal',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
  {
    id: 'rec-003', descricao: 'Internet — fibra 300mb', categoria: 'Internet',
    valor: 189, frequencia: 'Mensal', diaVencimento: 10,
    proximoVencimento: '2026-10-10', contaPagamento: 'Conta corrente principal',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
  {
    id: 'rec-004', descricao: 'Sistema de gestão (ERP)', categoria: 'Software',
    valor: 99, frequencia: 'Mensal', diaVencimento: 15,
    proximoVencimento: '2026-10-15', contaPagamento: 'Cartão corporativo',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
  {
    id: 'rec-005', descricao: 'Marketing mensal — agência', categoria: 'Marketing',
    valor: 500, frequencia: 'Mensal', diaVencimento: 1,
    proximoVencimento: '2026-10-01', contaPagamento: 'Conta corrente principal',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
  {
    id: 'rec-006', descricao: 'Seguro estabelecimento', categoria: 'Seguros',
    valor: 280, frequencia: 'Mensal', diaVencimento: 20,
    proximoVencimento: '2026-10-20', contaPagamento: 'Conta corrente principal',
    responsavel: 'Administrador', status: 'Ativa', createdAt: '2025-06-01',
  },
];

function loadAll(): ContaRecorrente[] {
  if (!localStorage.getItem(SEEDED_KEY)) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED));
    localStorage.setItem(SEEDED_KEY, '1');
  }
  try {
    const r = localStorage.getItem(STORAGE_KEY);
    return r ? JSON.parse(r) : SEED;
  } catch {
    return SEED;
  }
}

function saveAll(list: ContaRecorrente[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

// ── Constants ────────────────────────────────────────────────

const FREQUENCIAS: Frequencia[] = ['Mensal', 'Semanal', 'Quinzenal', 'Anual'];
const CATEGORIAS = ['Aluguel', 'Energia', 'Internet', 'Software', 'Marketing', 'Seguros', 'Telefone', 'Serviços', 'Outras despesas'];

const emptyForm = (): Omit<ContaRecorrente, 'id' | 'createdAt'> => ({
  descricao: '',
  categoria: 'Aluguel',
  valor: 0,
  frequencia: 'Mensal',
  diaVencimento: 1,
  proximoVencimento: today(),
  contaPagamento: 'Conta corrente principal',
  responsavel: '',
  status: 'Ativa',
  observacao: '',
});

// ── Helpers ──────────────────────────────────────────────────

function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function fmtDate(iso: string) {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

function daysUntil(iso: string): number {
  const now = new Date(today() + 'T00:00:00');
  const dt = new Date(iso + 'T00:00:00');
  return Math.round((dt.getTime() - now.getTime()) / 86400000);
}

// ── Component ─────────────────────────────────────────────────

export default function ContasRecorrentes() {
  const [items, setItems] = useState<ContaRecorrente[]>(() => loadAll());
  const [form, setForm] = useState<Omit<ContaRecorrente, 'id' | 'createdAt'>>(emptyForm());
  const [editId, setEditId] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [toast, setToast] = useState('');

  const refresh = () => setItems(loadAll());
  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3200); };
  const f = (field: string, val: string | number) => setForm(x => ({ ...x, [field]: val }));

  const openNew = () => { setForm(emptyForm()); setEditId(null); setShowModal(true); };
  const openEdit = (r: ContaRecorrente) => {
    const { id, createdAt: _, ...rest } = r;
    setForm(rest);
    setEditId(id);
    setShowModal(true);
  };

  const save = () => {
    if (!form.descricao.trim() || form.valor <= 0) {
      msg('Preencha descrição e valor.');
      return;
    }
    const list = loadAll();
    if (editId) {
      const next = list.map(x => x.id === editId ? { ...x, ...form } : x);
      saveAll(next);
      msg('Conta recorrente atualizada.');
    } else {
      const item: ContaRecorrente = { ...form, id: newId(), createdAt: today() };
      saveAll([item, ...list]);
      msg('Conta recorrente cadastrada.');
    }
    refresh();
    setShowModal(false);
  };

  const toggleStatus = (id: string) => {
    const list = loadAll().map(x =>
      x.id === id ? { ...x, status: x.status === 'Ativa' ? 'Inativa' as StatusConta : 'Ativa' as StatusConta } : x
    );
    saveAll(list);
    refresh();
    msg('Status atualizado.');
  };

  const registerPayment = (item: ContaRecorrente) => {
    const next = loadAll().map(x => {
      if (x.id !== item.id) return x;
      const newProximo = nextDate(item.proximoVencimento, item.frequencia);
      return { ...x, proximoVencimento: newProximo };
    });
    saveAll(next);

    // Add expense record
    finDb.expenses.add({
      description: `Pagamento recorrente — ${item.descricao}`,
      category: (['Aluguel', 'Energia', 'Internet'].includes(item.categoria)
        ? item.categoria
        : 'Outras despesas') as import('../../data/finDb').ExpenseCat,
      value: item.valor,
      date: today(),
      paymentMethod: 'Transferência',
      status: 'Pago',
    });

    refresh();
    msg(`Pagamento de "${item.descricao}" registrado. Próximo vencimento avançado.`);
  };

  const todayStr = today();
  const in7 = new Date(todayStr + 'T00:00:00');
  in7.setDate(in7.getDate() + 7);
  const in7Str = in7.toISOString().slice(0, 10);

  const active = items.filter(x => x.status === 'Ativa');
  const totalMensal = active.reduce((s, x) => {
    switch (x.frequencia) {
      case 'Mensal': return s + x.valor;
      case 'Semanal': return s + x.valor * 4.33;
      case 'Quinzenal': return s + x.valor * 2;
      case 'Anual': return s + x.valor / 12;
    }
  }, 0);
  const nAtivas = active.length;
  const proximasVencer = active.filter(x => x.proximoVencimento >= todayStr && x.proximoVencimento <= in7Str).length;

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif' }}>
      {toast && <Toast msg={toast} />}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 700, color: C.text, margin: 0 }}>Contas Recorrentes</h1>
          <p style={{ fontSize: 13, color: C.textMuted, margin: '4px 0 0' }}>Gestão de despesas fixas e periódicas</p>
        </div>
        <button style={btnPrimary} onClick={openNew}>+ Nova recorrente</button>
      </div>

      {/* KPI row */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <KpiCard label="Total mensal recorrente" value={fmtBRL(totalMensal)} color={C.error} />
        <KpiCard label="Contas ativas" value={String(nAtivas)} />
        <KpiCard label="Vencem em ≤7 dias" value={String(proximasVencer)} color={proximasVencer > 0 ? C.warning : C.text} />
      </div>

      {/* Table */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              <th style={TH}>Descrição</th>
              <th style={TH}>Categoria</th>
              <th style={TH}>Valor</th>
              <th style={TH}>Frequência</th>
              <th style={TH}>Próx. vencimento</th>
              <th style={TH}>Status</th>
              <th style={{ ...TH, textAlign: 'right' }}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {items.map(item => {
              const dias = daysUntil(item.proximoVencimento);
              const vencida = dias < 0 && item.status === 'Ativa';
              const proximaVencer = dias >= 0 && dias <= 7 && item.status === 'Ativa';

              let rowBg = 'transparent';
              if (vencida) rowBg = C.errorBg;
              else if (proximaVencer) rowBg = C.warningBg;

              return (
                <tr key={item.id} style={{ background: rowBg, borderBottom: ROW_BORDER }}>
                  <td style={TD}>
                    <div style={{ fontWeight: 500, color: C.text }}>{item.descricao}</div>
                    {item.observacao && (
                      <div style={{ fontSize: 11, color: C.textMuted }}>{item.observacao}</div>
                    )}
                  </td>
                  <td style={TD}>
                    <span style={{ fontSize: 12, color: C.textMuted }}>{item.categoria}</span>
                  </td>
                  <td style={TD}>
                    <span style={{ fontWeight: 600, color: C.text }}>{fmtBRL(item.valor)}</span>
                    {item.frequencia !== 'Mensal' && (
                      <div style={{ fontSize: 11, color: C.textMuted }}>
                        ≈{fmtBRL(
                          item.frequencia === 'Semanal' ? item.valor * 4.33
                          : item.frequencia === 'Quinzenal' ? item.valor * 2
                          : item.valor / 12
                        )}/mês
                      </div>
                    )}
                  </td>
                  <td style={TD}>{item.frequencia}</td>
                  <td style={TD}>
                    <div style={{
                      color: vencida ? C.error : proximaVencer ? C.warning : C.text,
                      fontWeight: (vencida || proximaVencer) ? 600 : 400,
                      fontSize: 13,
                    }}>
                      {fmtDate(item.proximoVencimento)}
                    </div>
                    {vencida && <div style={{ fontSize: 11, color: C.error }}>Vencida há {Math.abs(dias)} dia(s)</div>}
                    {proximaVencer && <div style={{ fontSize: 11, color: C.warning }}>Vence em {dias} dia(s)</div>}
                  </td>
                  <td style={TD}>
                    <span style={{
                      ...badge[item.status === 'Ativa' ? 'active' : 'inactive'],
                      borderRadius: 4,
                      padding: '1px 7px',
                      fontSize: 11,
                    }}>
                      {item.status}
                    </span>
                  </td>
                  <td style={{ ...TD, textAlign: 'right' }}>
                    <div style={{ display: 'flex', gap: 6, justifyContent: 'flex-end' }}>
                      {item.status === 'Ativa' && (
                        <button
                          style={{
                            padding: '4px 8px',
                            fontSize: 11,
                            background: C.successBg,
                            color: C.success,
                            border: `1px solid ${C.successBorder}`,
                            borderRadius: 4,
                            cursor: 'pointer',
                            fontFamily: 'Inter, sans-serif',
                          }}
                          onClick={() => registerPayment(item)}
                        >
                          Pagar
                        </button>
                      )}
                      <button
                        style={{ ...btnSecondary, padding: '4px 8px', fontSize: 11 }}
                        onClick={() => openEdit(item)}
                      >
                        Editar
                      </button>
                      <button
                        style={{
                          padding: '4px 8px',
                          fontSize: 11,
                          background: item.status === 'Ativa' ? C.errorBg : C.successBg,
                          color: item.status === 'Ativa' ? C.error : C.success,
                          border: `1px solid ${item.status === 'Ativa' ? C.errorBorder : C.successBorder}`,
                          borderRadius: 4,
                          cursor: 'pointer',
                          fontFamily: 'Inter, sans-serif',
                        }}
                        onClick={() => toggleStatus(item.id)}
                      >
                        {item.status === 'Ativa' ? 'Inativar' : 'Ativar'}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {items.length === 0 && (
              <tr>
                <td colSpan={7} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: 32 }}>
                  Nenhuma conta recorrente cadastrada.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {showModal && (
        <Modal title={editId ? 'Editar conta recorrente' : 'Nova conta recorrente'} onClose={() => setShowModal(false)}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <label style={labelStyle}>Descrição *</label>
                <input style={inp()} value={form.descricao} onChange={e => f('descricao', e.target.value)} placeholder="Ex: Aluguel do ponto" />
              </div>
              <div>
                <label style={labelStyle}>Categoria</label>
                <select style={inp()} value={form.categoria} onChange={e => f('categoria', e.target.value)}>
                  {CATEGORIAS.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Valor (R$) *</label>
                <input style={inp()} type="number" min="0" step="0.01" value={form.valor || ''} onChange={e => f('valor', parseFloat(e.target.value) || 0)} />
              </div>
              <div>
                <label style={labelStyle}>Frequência</label>
                <select style={inp()} value={form.frequencia} onChange={e => f('frequencia', e.target.value as Frequencia)}>
                  {FREQUENCIAS.map(fr => <option key={fr}>{fr}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Dia vencimento (1–31)</label>
                <input style={inp()} type="number" min="1" max="31" value={form.diaVencimento} onChange={e => f('diaVencimento', parseInt(e.target.value) || 1)} />
              </div>
              <div>
                <label style={labelStyle}>Próximo vencimento</label>
                <input style={inp()} type="date" value={form.proximoVencimento} onChange={e => f('proximoVencimento', e.target.value)} />
              </div>
              <div>
                <label style={labelStyle}>Conta de pagamento</label>
                <input style={inp()} value={form.contaPagamento} onChange={e => f('contaPagamento', e.target.value)} placeholder="Ex: Conta corrente" />
              </div>
              <div>
                <label style={labelStyle}>Responsável</label>
                <input style={inp()} value={form.responsavel} onChange={e => f('responsavel', e.target.value)} placeholder="Nome do responsável" />
              </div>
            </div>
            <div>
              <label style={labelStyle}>Status</label>
              <select style={inp()} value={form.status} onChange={e => f('status', e.target.value as StatusConta)}>
                <option>Ativa</option>
                <option>Inativa</option>
              </select>
            </div>
            <div>
              <label style={labelStyle}>Observação</label>
              <textarea
                style={{ ...inp(), minHeight: 60, resize: 'vertical' }}
                value={form.observacao ?? ''}
                onChange={e => f('observacao', e.target.value)}
                placeholder="Observações opcionais..."
              />
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 4 }}>
              <button style={btnSecondary} onClick={() => setShowModal(false)}>Cancelar</button>
              <button style={btnPrimary} onClick={save}>
                {editId ? 'Salvar alterações' : 'Cadastrar'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function KpiCard({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div style={{
      background: '#FFFFFF',
      border: `1px solid ${C.border}`,
      borderRadius: 8,
      padding: '12px 16px',
      minWidth: 140,
      flex: 1,
    }}>
      <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {label}
      </div>
      <div style={{ fontSize: 18, fontWeight: 700, color: color ?? C.text }}>
        {value}
      </div>
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: 'block',
  fontSize: 12,
  fontWeight: 500,
  color: C.text,
  marginBottom: 4,
};
