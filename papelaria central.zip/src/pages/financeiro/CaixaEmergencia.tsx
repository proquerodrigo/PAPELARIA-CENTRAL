import { useState } from 'react';
import { C, inp, btnPrimary, btnSecondary, tbl, TH, TD, tableWrap, ROW_BORDER, formCard } from '../../theme';
import { Toast, Modal } from '../Produtos';
import { emergencyDb, EmergencyFund, EmergencyMovement } from '../../data/emergencyDb';

const today = () => new Date().toISOString().slice(0, 10);

const fmtBRL = (v: number) =>
  v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const fmtDate = (d: string) => {
  const [y, m, day] = d.split('-');
  return `${day}/${m}/${y}`;
};

function calcTotals(movimentos: EmergencyMovement[]) {
  let entradas = 0;
  let retiradas = 0;
  for (const m of movimentos) {
    if (m.type === 'entrada') entradas += m.value;
    else retiradas += m.value;
  }
  return { entradas, retiradas };
}

export default function CaixaEmergencia() {
  const [fund, setFund] = useState<EmergencyFund>(() => emergencyDb.get());
  const [toast, setToast] = useState('');
  const [modal, setModal] = useState<'entrada' | 'retirada' | null>(null);

  // form state
  const [fValor, setFValor] = useState('');
  const [fMotivo, setFMotivo] = useState('');
  const [fData, setFData] = useState(today());
  const [fResponsavel, setFResponsavel] = useState('Administrador');
  const [fErr, setFErr] = useState('');

  // meta editing
  const [editingMeta, setEditingMeta] = useState(false);
  const [metaInput, setMetaInput] = useState('');

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  };

  const openModal = (tipo: 'entrada' | 'retirada') => {
    setFValor('');
    setFMotivo('');
    setFData(today());
    setFResponsavel('Administrador');
    setFErr('');
    setModal(tipo);
  };

  const closeModal = () => setModal(null);

  const handleSubmit = () => {
    const valor = parseFloat(fValor);
    if (!fValor || isNaN(valor) || valor <= 0) { setFErr('Informe um valor válido maior que zero.'); return; }
    if (!fMotivo.trim()) { setFErr('O motivo é obrigatório.'); return; }
    if (!fData) { setFErr('Informe a data.'); return; }
    if (!fResponsavel.trim()) { setFErr('Informe o responsável.'); return; }
    const updated = emergencyDb.addMovimento(modal!, valor, fMotivo.trim(), fResponsavel.trim(), fData);
    setFund(updated);
    closeModal();
    showToast(modal === 'entrada' ? 'Entrada registrada com sucesso.' : 'Retirada registrada com sucesso.');
  };

  const handleSaveMeta = () => {
    const v = parseFloat(metaInput.replace(',', '.'));
    if (isNaN(v) || v <= 0) return;
    const updated = { ...fund, metaReserva: v };
    emergencyDb.set(updated);
    setFund(updated);
    setEditingMeta(false);
    showToast('Meta atualizada.');
  };

  const sorted = [...fund.movimentos].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  const { entradas, retiradas } = calcTotals(fund.movimentos);
  const pct = Math.min(100, fund.metaReserva > 0 ? (fund.saldoAtual / fund.metaReserva) * 100 : 0);
  const pctDisplay = pct.toFixed(1);

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: C.text }}>
      {toast && <Toast msg={toast} />}

      {/* KPI bar */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 20 }}>
        {/* Saldo atual */}
        <div style={{ ...formCard, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Saldo Atual</span>
          <span style={{ fontSize: 26, fontWeight: 700, color: C.navy, lineHeight: 1.2 }}>{fmtBRL(fund.saldoAtual)}</span>
        </div>

        {/* Meta */}
        <div style={{ ...formCard, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Meta da Reserva</span>
          {editingMeta ? (
            <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginTop: 2 }}>
              <input
                type="number"
                value={metaInput}
                onChange={e => setMetaInput(e.target.value)}
                style={{ ...inp(), width: 130, fontSize: 13 }}
                autoFocus
                onKeyDown={e => { if (e.key === 'Enter') handleSaveMeta(); if (e.key === 'Escape') setEditingMeta(false); }}
              />
              <button onClick={handleSaveMeta} style={btnPrimary}>Salvar</button>
              <button onClick={() => setEditingMeta(false)} style={btnSecondary}>✕</button>
            </div>
          ) : (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ fontSize: 20, fontWeight: 600, color: C.navy }}>{fmtBRL(fund.metaReserva)}</span>
              <button
                onClick={() => { setMetaInput(fund.metaReserva.toString()); setEditingMeta(true); }}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: C.textMuted, fontSize: 12, padding: '2px 4px', borderRadius: 3 }}
                title="Editar meta"
              >
                ✏️
              </button>
            </div>
          )}
        </div>

        {/* Progresso */}
        <div style={{ ...formCard, display: 'flex', flexDirection: 'column', gap: 6 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Progresso</span>
          <span style={{ fontSize: 20, fontWeight: 700, color: C.navy }}>{pctDisplay}%</span>
          <div style={{ height: 8, background: C.metalMid, borderRadius: 4, overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              width: `${pct}%`,
              background: pct >= 100 ? C.success : pct >= 50 ? C.navy : '#F59E0B',
              borderRadius: 4,
              transition: 'width 0.3s ease',
            }} />
          </div>
        </div>

        {/* Entradas */}
        <div style={{ ...formCard, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Total Entradas</span>
          <span style={{ fontSize: 20, fontWeight: 600, color: C.success }}>{fmtBRL(entradas)}</span>
        </div>

        {/* Retiradas */}
        <div style={{ ...formCard, display: 'flex', flexDirection: 'column', gap: 4 }}>
          <span style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Total Retiradas</span>
          <span style={{ fontSize: 20, fontWeight: 600, color: C.error }}>{fmtBRL(retiradas)}</span>
        </div>
      </div>

      {/* Action buttons */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <button onClick={() => openModal('entrada')} style={btnPrimary}>+ Nova entrada</button>
        <button onClick={() => openModal('retirada')} style={{ ...btnSecondary, color: C.error, borderColor: C.errorBorder }}>− Registrar retirada</button>
      </div>

      {/* History table */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Data', 'Tipo', 'Valor', 'Motivo', 'Responsável', 'Saldo após'].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.length === 0 ? (
              <tr>
                <td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '32px 12px' }}>
                  Nenhuma movimentação registrada
                </td>
              </tr>
            ) : (
              sorted.map((m, i) => (
                <tr key={m.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                  <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap' }}>{fmtDate(m.date)}</td>
                  <td style={TD}>
                    <span style={{
                      display: 'inline-block',
                      padding: '2px 8px',
                      borderRadius: 4,
                      fontSize: 11,
                      fontWeight: 600,
                      ...(m.type === 'entrada'
                        ? { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5' }
                        : { background: '#FEF3F2', color: '#B42318', border: '1px solid #FECDCA' }),
                    }}>
                      {m.type === 'entrada' ? 'Entrada' : 'Retirada'}
                    </span>
                  </td>
                  <td style={{ ...TD, fontWeight: 600, color: m.type === 'entrada' ? C.success : C.error, whiteSpace: 'nowrap' }}>
                    {m.type === 'retirada' ? '−' : '+'}{fmtBRL(m.value)}
                  </td>
                  <td style={{ ...TD, maxWidth: 260 }}>{m.reason}</td>
                  <td style={{ ...TD, color: C.textMuted }}>{m.responsavel}</td>
                  <td style={{ ...TD, fontWeight: 500, whiteSpace: 'nowrap' }}>{fmtBRL(m.balanceAfter)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {modal && (
        <Modal
          title={modal === 'entrada' ? 'Nova Entrada' : 'Registrar Retirada'}
          onClose={closeModal}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {fErr && (
              <div style={{ fontSize: 12, color: C.error, background: '#FEF3F2', border: '1px solid #FECDCA', borderRadius: 5, padding: '6px 10px' }}>
                {fErr}
              </div>
            )}

            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Valor (R$) <span style={{ color: C.error }}>*</span>
              </label>
              <input
                type="number"
                min="0.01"
                step="0.01"
                value={fValor}
                onChange={e => { setFValor(e.target.value); setFErr(''); }}
                placeholder="0,00"
                style={inp()}
                autoFocus
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Motivo <span style={{ color: C.error }}>*</span>
              </label>
              <input
                type="text"
                value={fMotivo}
                onChange={e => { setFMotivo(e.target.value); setFErr(''); }}
                placeholder={modal === 'entrada' ? 'Ex: Aporte mensal' : 'Ex: Reparo emergencial'}
                style={inp()}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Data <span style={{ color: C.error }}>*</span>
              </label>
              <input
                type="date"
                value={fData}
                onChange={e => { setFData(e.target.value); setFErr(''); }}
                style={inp()}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Responsável <span style={{ color: C.error }}>*</span>
              </label>
              <input
                type="text"
                value={fResponsavel}
                onChange={e => { setFResponsavel(e.target.value); setFErr(''); }}
                placeholder="Nome do responsável"
                style={inp()}
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 4 }}>
              <button onClick={closeModal} style={btnSecondary}>Cancelar</button>
              <button onClick={handleSubmit} style={btnPrimary}>
                {modal === 'entrada' ? 'Registrar entrada' : 'Registrar retirada'}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
