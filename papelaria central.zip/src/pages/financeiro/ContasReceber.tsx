import { useState, useMemo } from 'react';
import { finDb, fmtBRL, type FinSale, type SaleStatus } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER } from '../../theme';

const STATUS_OPTS: SaleStatus[] = ['A receber', 'Recebido', 'Cancelado'];
const METHODS = ['Pix', 'Dinheiro', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência'];

const statusStyle = (s: SaleStatus): React.CSSProperties => {
  if (s === 'Recebido') return { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
  if (s === 'A receber') return { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
  return { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
};

function KPICard({ label, value, sub, color = C.text }: { label: string; value: string; sub?: string; color?: string }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '12px 16px', minWidth: 0 }}>
      <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 600, color, lineHeight: 1.2 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

export default function ContasReceber() {
  const [items, setItems] = useState<FinSale[]>(() => finDb.sales.all());
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [methodFilter, setMethodFilter] = useState('Todos');
  const [search, setSearch] = useState('');

  const today = new Date().toISOString().slice(0, 10);

  const refresh = () => setItems(finDb.sales.all());

  const markReceived = (id: string) => {
    finDb.sales.markReceived(id);
    refresh();
  };

  const filtered = useMemo(() => items.filter(s =>
    (statusFilter === 'Todos' || s.status === statusFilter) &&
    (methodFilter === 'Todos' || s.paymentMethod === methodFilter) &&
    (s.client.toLowerCase().includes(search.toLowerCase()) ||
     s.description.toLowerCase().includes(search.toLowerCase()) ||
     s.saleNumber.toLowerCase().includes(search.toLowerCase()))
  ), [items, statusFilter, methodFilter, search]);

  const totalAReceber   = items.filter(s => s.status === 'A receber').reduce((sum, s) => sum + s.netValue, 0);
  const totalRecebido   = items.filter(s => s.status === 'Recebido').reduce((sum, s) => sum + s.netValue, 0);
  const recebidoHoje    = items.filter(s => s.status === 'Recebido' && s.receivedDate === today).reduce((sum, s) => sum + s.netValue, 0);
  const vencidos        = items.filter(s => s.status === 'A receber' && s.expectedDate < today);
  const totalVencido    = vencidos.reduce((sum, s) => sum + s.netValue, 0);
  const totalTaxas      = items.reduce((sum, s) => sum + s.feeValue, 0);
  const totalFaturamento = items.reduce((sum, s) => sum + s.grossValue, 0);

  const byMethod: Record<string, number> = {};
  items.filter(s => s.status === 'A receber').forEach(s => {
    byMethod[s.paymentMethod] = (byMethod[s.paymentMethod] ?? 0) + s.netValue;
  });

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none',
    background: C.white, color: C.text,
  };

  return (
    <div>
      {/* KPI Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 10, marginBottom: 16 }}>
        <KPICard label="Faturamento total" value={fmtBRL(totalFaturamento)} />
        <KPICard label="Total a receber" value={fmtBRL(totalAReceber)} color="#B54708" />
        <KPICard label="Total recebido" value={fmtBRL(totalRecebido)} color="#027A48" />
        <KPICard label="Recebido hoje" value={fmtBRL(recebidoHoje)} color="#027A48" />
        <KPICard label="Vencidos/Atrasados" value={fmtBRL(totalVencido)} sub={`${vencidos.length} registro${vencidos.length !== 1 ? 's' : ''}`} color="#B91C1C" />
        <KPICard label="Taxas debitadas" value={fmtBRL(totalTaxas)} />
      </div>

      {/* Breakdown por forma de pagamento (A receber) */}
      {Object.keys(byMethod).length > 0 && (
        <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '10px 14px', marginBottom: 14 }}>
          <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, marginBottom: 8, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>
            A receber por forma de pagamento
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' as const }}>
            {Object.entries(byMethod).sort(([,a],[,b]) => b - a).map(([method, val]) => (
              <span key={method} style={{
                background: '#F0F4FA', border: `1px solid ${C.border}`,
                borderRadius: 4, padding: '3px 10px', fontSize: 12, color: C.textMuted,
              }}>
                {method}: <strong style={{ color: '#B54708' }}>{fmtBRL(val)}</strong>
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Filtros */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar cliente, nº venda, descrição..."
          style={{ ...sinp, minWidth: 220 }}
        />
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={sinp}>
          <option>Todos</option>
          {STATUS_OPTS.map(s => <option key={s}>{s}</option>)}
        </select>
        <select value={methodFilter} onChange={e => setMethodFilter(e.target.value)} style={sinp}>
          <option>Todos</option>
          {METHODS.map(m => <option key={m}>{m}</option>)}
        </select>
        <span style={{ fontSize: 12, color: C.textMuted, marginLeft: 'auto' }}>
          {filtered.length} registro{filtered.length !== 1 ? 's' : ''}
        </span>
      </div>

      {/* Tabela */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Nº', 'Data venda', 'Cliente', 'Descrição', 'Forma / Parcelas', 'Valor bruto', 'Taxa', 'Líquido', 'Previsão', 'Recebimento', 'Status', ''].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((s, i) => {
              const overdue = s.status === 'A receber' && s.expectedDate < today;
              return (
                <tr key={s.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined, background: overdue ? '#FFF8F6' : undefined }}>
                  <td style={{ ...TD, fontFamily: 'monospace', fontSize: 11, color: C.textMuted }}>{s.saleNumber}</td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12, whiteSpace: 'nowrap' as const }}>{s.date.split('-').reverse().join('/')}</td>
                  <td style={{ ...TD, fontWeight: 500, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const }}>{s.client}</td>
                  <td style={{ ...TD, color: C.textMuted, maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const }}>{s.description}</td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>
                    {s.paymentMethod}{s.installments > 1 ? ` ${s.installments}×` : ''}
                  </td>
                  <td style={{ ...TD, fontWeight: 600 }}>{fmtBRL(s.grossValue)}</td>
                  <td style={{ ...TD, color: s.feeValue > 0 ? '#B54708' : C.textMuted, fontSize: 12 }}>
                    {s.feeRate > 0 ? `${s.feeRate}% / ${fmtBRL(s.feeValue)}` : '—'}
                  </td>
                  <td style={{ ...TD, fontWeight: 600, color: '#1D4ED8' }}>{fmtBRL(s.netValue)}</td>
                  <td style={{ ...TD, color: overdue ? '#B91C1C' : C.textMuted, fontSize: 12, fontWeight: overdue ? 600 : 400, whiteSpace: 'nowrap' as const }}>
                    {s.expectedDate.split('-').reverse().join('/')}
                    {overdue && <span style={{ marginLeft: 4, fontSize: 10 }}>⚠ vencido</span>}
                  </td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12, whiteSpace: 'nowrap' as const }}>
                    {s.receivedDate ? s.receivedDate.split('-').reverse().join('/') : '—'}
                  </td>
                  <td style={TD}><span style={statusStyle(s.status)}>{s.status}</span></td>
                  <td style={TD}>
                    {s.status === 'A receber' && (
                      <button
                        onClick={() => markReceived(s.id)}
                        style={{
                          padding: '3px 8px', fontSize: 11, fontFamily: 'Inter, sans-serif',
                          background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5',
                          borderRadius: 4, cursor: 'pointer',
                        }}
                      >
                        Marcar recebido
                      </button>
                    )}
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={12} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>
                  Nenhum registro encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
