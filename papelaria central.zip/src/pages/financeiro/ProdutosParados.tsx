import React, { useMemo, useState } from 'react';
import { db } from '../../data/db';
import { fornecedoresDb } from '../../data/fornecedoresDb';
import { C, tbl, TH, TD, tableWrap, btnSecondary, ROW_BORDER } from '../../theme';

type Threshold = 30 | 60 | 90 | 180;

const THRESHOLDS: { key: Threshold; label: string }[] = [
  { key: 30, label: '30 dias' },
  { key: 60, label: '60 dias' },
  { key: 90, label: '90 dias' },
  { key: 180, label: '180 dias' },
];

function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function daysDiff(isoDate: string): number {
  const then = new Date(isoDate);
  const now = new Date();
  return Math.floor((now.getTime() - then.getTime()) / (1000 * 60 * 60 * 24));
}

function rowColor(dias: number): string {
  if (dias > 90) return C.errorBg;
  if (dias > 60) return C.warningBg;
  if (dias > 30) return '#FFFDF0';
  return 'transparent';
}

function diasBadgeStyle(dias: number): React.CSSProperties {
  if (dias > 90) return { background: C.errorBg, color: C.error, border: `1px solid ${C.errorBorder}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
  if (dias > 60) return { background: C.warningBg, color: C.warning, border: `1px solid ${C.warningBorder}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
  return { background: '#FFFDF0', color: '#92400E', border: '1px solid #FDE68A', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
}

export default function ProdutosParados() {
  const [threshold, setThreshold] = useState<Threshold>(60);

  const suppliers = useMemo(() => {
    const m = new Map<string, string>();
    fornecedoresDb.all().forEach(f => m.set(f.id, f.nomeFantasia || f.razaoSocial));
    return m;
  }, []);

  const { rows, totalValue } = useMemo(() => {
    const today = new Date();
    const thresholdDate = new Date(today);
    thresholdDate.setDate(thresholdDate.getDate() - threshold);
    const thresholdIso = thresholdDate.toISOString().slice(0, 10);

    const products = db.products.all();
    const movements = db.movements.all().filter(m => m.type === 'Saída');

    // Build last saída date per product
    const lastSaidaMap = new Map<string, string>();
    movements.forEach(m => {
      // createdAt is ISO format
      const dateStr = m.createdAt.slice(0, 10);
      const existing = lastSaidaMap.get(m.productId);
      if (!existing || dateStr > existing) {
        lastSaidaMap.set(m.productId, dateStr);
      }
    });

    const result: {
      id: string;
      name: string;
      brand: string;
      category: string;
      qty: number;
      lastSaida: string | null;
      diasParado: number;
      valorEstoque: number;
      fornecedor: string;
    }[] = [];

    products.forEach(prod => {
      const lastSaida = lastSaidaMap.get(prod.id) ?? null;
      const isParado = !lastSaida || lastSaida < thresholdIso;
      if (!isParado) return;

      const diasParado = lastSaida
        ? daysDiff(lastSaida)
        : daysDiff('2025-06-01'); // if never sold, count from data start

      const valorEstoque = prod.qty * prod.price;
      const fornecedor = prod.supplierId
        ? suppliers.get(prod.supplierId) ?? (prod.brand || '—')
        : (prod.brand || '—');

      result.push({
        id: prod.id,
        name: prod.name,
        brand: prod.brand ?? '—',
        category: prod.category,
        qty: prod.qty,
        lastSaida,
        diasParado,
        valorEstoque,
        fornecedor,
      });
    });

    // Sort by dias parado desc
    result.sort((a, b) => b.diasParado - a.diasParado);

    const totalValue = result.reduce((s, r) => s + r.valorEstoque, 0);
    return { rows: result, totalValue };
  }, [threshold, suppliers]);

  function fmtDate(iso: string): string {
    const [y, m, d] = iso.split('-');
    return `${d}/${m}/${y}`;
  }

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif', color: C.text }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: C.text }}>Produtos Parados</h1>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textMuted }}>
          Produtos sem movimentação de saída no período selecionado
        </p>
      </div>

      {/* Filter */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 8, padding: '16px 20px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <span style={{ fontSize: 13, color: C.textMuted, fontWeight: 500 }}>Dias sem venda:</span>
        <div style={{ display: 'flex', gap: 4 }}>
          {THRESHOLDS.map(t => (
            <button
              key={t.key}
              onClick={() => setThreshold(t.key)}
              style={{
                ...btnSecondary,
                padding: '5px 12px',
                fontSize: 12,
                background: threshold === t.key ? C.navy : C.white,
                color: threshold === t.key ? C.white : C.text,
                border: threshold === t.key ? 'none' : `1px solid ${C.border}`,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ marginLeft: 'auto', display: 'flex', gap: 16 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Produtos parados</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: C.error }}>{rows.length}</div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Valor em estoque</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: C.error }}>{fmtBRL(totalValue)}</div>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        {[
          { color: C.errorBg, border: C.errorBorder, text: C.error, label: '> 90 dias' },
          { color: C.warningBg, border: C.warningBorder, text: C.warning, label: '60–90 dias' },
          { color: '#FFFDF0', border: '#FDE68A', text: '#92400E', label: '30–60 dias' },
        ].map(item => (
          <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.textMuted }}>
            <span style={{ display: 'inline-block', width: 12, height: 12, background: item.color, border: `1px solid ${item.border}`, borderRadius: 2 }} />
            {item.label}
          </div>
        ))}
      </div>

      {/* Table */}
      <div style={tableWrap}>
        {rows.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center', color: C.textMuted, fontSize: 14 }}>
            Nenhum produto parado por mais de {threshold} dias
          </div>
        ) : (
          <table style={tbl}>
            <thead>
              <tr>
                <th style={TH}>Produto</th>
                <th style={TH}>Marca</th>
                <th style={TH}>Categoria</th>
                <th style={{ ...TH, textAlign: 'right' }}>Estoque</th>
                <th style={{ ...TH, textAlign: 'center' }}>Última saída</th>
                <th style={{ ...TH, textAlign: 'center' }}>Dias parado</th>
                <th style={{ ...TH, textAlign: 'right' }}>Valor estoque</th>
                <th style={TH}>Fornecedor</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, idx) => (
                <tr
                  key={row.id}
                  style={{
                    borderTop: idx > 0 ? ROW_BORDER : 'none',
                    background: rowColor(row.diasParado),
                  }}
                >
                  <td style={TD}>
                    <span style={{ fontWeight: 500, fontSize: 13 }}>{row.name}</span>
                  </td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{row.brand}</td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{row.category}</td>
                  <td style={{ ...TD, textAlign: 'right', fontWeight: 500 }}>
                    {row.qty === 0 ? (
                      <span style={{ color: C.textMuted, fontSize: 12 }}>Sem estoque</span>
                    ) : row.qty}
                  </td>
                  <td style={{ ...TD, textAlign: 'center', fontSize: 12, color: C.textMuted }}>
                    {row.lastSaida ? fmtDate(row.lastSaida) : 'Nunca vendido'}
                  </td>
                  <td style={{ ...TD, textAlign: 'center' }}>
                    <span style={diasBadgeStyle(row.diasParado)}>{row.diasParado}d</span>
                  </td>
                  <td style={{ ...TD, textAlign: 'right', fontWeight: 500 }}>
                    {fmtBRL(row.valorEstoque)}
                  </td>
                  <td style={{ ...TD, fontSize: 12, color: C.textMuted }}>{row.fornecedor}</td>
                </tr>
              ))}
              {/* Totals row */}
              <tr style={{ borderTop: `2px solid ${C.metalBorder}`, background: C.metalLight }}>
                <td style={{ ...TD, fontWeight: 600 }} colSpan={6}>
                  Total — {rows.length} produto{rows.length !== 1 ? 's' : ''} parado{rows.length !== 1 ? 's' : ''}
                </td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 700 }}>{fmtBRL(totalValue)}</td>
                <td style={TD} />
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
