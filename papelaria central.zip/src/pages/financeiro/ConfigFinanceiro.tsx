import { useState } from 'react';
import { finDb, DEFAULT_TAX_CONFIG, type TaxConfig } from '../../data/finDb';
import { C, btnPrimary, btnSecondary, inp } from '../../theme';

type MethodKey = keyof TaxConfig;

const METHOD_META: Record<MethodKey, { label: string; desc: string }> = {
  pix:                 { label: 'Pix',                        desc: 'Recebimento imediato, sem prazo' },
  dinheiro:            { label: 'Dinheiro',                   desc: 'Entrada imediata no caixa' },
  debito:              { label: 'Cartão de débito',            desc: 'Prazo típico: 1 dia útil' },
  creditoAvista:       { label: 'Crédito à vista (1×)',        desc: 'Prazo típico: 30 dias' },
  creditoParcelado2a6: { label: 'Crédito parcelado (2–6×)',    desc: 'Prazo por parcela (ex: 30d × nº parcelas)' },
  creditoParcelado7a12:{ label: 'Crédito parcelado (7–12×)',   desc: 'Prazo por parcela (ex: 30d × nº parcelas)' },
  boleto:              { label: 'Boleto bancário',             desc: 'Prazo após compensação bancária' },
  transferencia:       { label: 'Transferência (TED/DOC)',     desc: 'Geralmente no mesmo dia' },
};

export default function ConfigFinanceiro() {
  const [cfg, setCfg] = useState<TaxConfig>(() => finDb.taxConfig.get());
  const [saved, setSaved] = useState(false);

  const update = (key: MethodKey, field: 'rate' | 'days', raw: string) => {
    const value = field === 'rate' ? parseFloat(raw) || 0 : parseInt(raw) || 0;
    setCfg(prev => ({ ...prev, [key]: { ...prev[key], [field]: value } }));
    setSaved(false);
  };

  const save = () => {
    finDb.taxConfig.set(cfg);
    setSaved(true);
    setTimeout(() => setSaved(false), 3500);
  };

  const reset = () => {
    setCfg({ ...DEFAULT_TAX_CONFIG });
    setSaved(false);
  };

  const orderKeys: MethodKey[] = [
    'pix', 'dinheiro', 'debito', 'creditoAvista',
    'creditoParcelado2a6', 'creditoParcelado7a12', 'boleto', 'transferencia',
  ];

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none',
    background: C.white, color: C.text, width: '100%', boxSizing: 'border-box' as const,
  };

  return (
    <div style={{ maxWidth: 680 }}>
      {saved && (
        <div style={{ background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 4, padding: '8px 12px', marginBottom: 16, fontSize: 13, color: '#027A48' }}>
          Configurações salvas com sucesso.
        </div>
      )}

      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 6, padding: 20, marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 4 }}>
          Taxas e prazos por forma de pagamento
        </div>
        <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 20 }}>
          Configure a taxa da operadora (%) e o prazo de recebimento (dias) para cada modalidade.
          Esses valores são usados para calcular o valor líquido e a data prevista de recebimento das vendas.
        </div>

        <div style={{ display: 'grid', gap: 0 }}>
          {/* Header row */}
          <div style={{
            display: 'grid', gridTemplateColumns: '1fr 120px 120px',
            gap: 12, paddingBottom: 8, marginBottom: 4,
            borderBottom: `1px solid ${C.border}`,
          }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>
              Forma de pagamento
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>
              Taxa (%)
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em' }}>
              Prazo (dias)
            </div>
          </div>

          {orderKeys.map((key, idx) => {
            const { label, desc } = METHOD_META[key];
            const val = cfg[key];
            return (
              <div
                key={key}
                style={{
                  display: 'grid', gridTemplateColumns: '1fr 120px 120px',
                  gap: 12, padding: '12px 0', alignItems: 'center',
                  borderBottom: idx < orderKeys.length - 1 ? `1px solid ${C.borderLight}` : undefined,
                }}
              >
                <div>
                  <div style={{ fontSize: 13, fontWeight: 500, color: C.text }}>{label}</div>
                  <div style={{ fontSize: 11, color: C.textMuted, marginTop: 1 }}>{desc}</div>
                </div>
                <div>
                  <input
                    type="number" min="0" max="100" step="0.01"
                    value={val.rate}
                    onChange={e => update(key, 'rate', e.target.value)}
                    style={sinp}
                  />
                </div>
                <div>
                  <input
                    type="number" min="0" max="999" step="1"
                    value={val.days}
                    onChange={e => update(key, 'days', e.target.value)}
                    style={sinp}
                  />
                </div>
              </div>
            );
          })}
        </div>

        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20, paddingTop: 16, borderTop: `1px solid ${C.borderLight}` }}>
          <button onClick={reset} style={btnSecondary}>Restaurar padrões</button>
          <button onClick={save} style={btnPrimary}>Salvar configurações</button>
        </div>
      </div>

      {/* Legenda */}
      <div style={{ background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 6, padding: 16 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 8 }}>Como funciona</div>
        <div style={{ fontSize: 12, color: C.textMuted, lineHeight: 1.7 }}>
          <p style={{ margin: '0 0 4px' }}>• <strong>Taxa (%):</strong> percentual cobrado pela operadora sobre o valor bruto da venda. Ex: crédito 3,49%.</p>
          <p style={{ margin: '0 0 4px' }}>• <strong>Prazo (dias):</strong> dias corridos até o dinheiro entrar no caixa após a venda. Ex: débito = 1 dia.</p>
          <p style={{ margin: '0 0 4px' }}>• <strong>Crédito parcelado:</strong> o prazo é multiplicado pelo número de parcelas escolhido na venda.</p>
          <p style={{ margin: 0 }}>• As configurações afetam apenas <strong>novas vendas</strong> registradas a partir de agora.</p>
        </div>
      </div>
    </div>
  );
}
