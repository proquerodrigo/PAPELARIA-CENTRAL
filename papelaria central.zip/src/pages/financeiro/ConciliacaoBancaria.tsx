import { useState, useMemo } from 'react';
import { bancosDb } from '../../data/bancosDb';
import { newId } from '../../data/db';
import { C, inp, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, ROW_BORDER, formCard } from '../../theme';
import { Modal, Toast } from '../Produtos';
import { useApp } from '../../context/AppContext';

// ─── Types ────────────────────────────────────────────────────────────────
type ConcStatus = 'conferida' | 'pendente' | 'divergente';
type ConcTipo   = 'entrada' | 'saida';

interface Conciliacao {
  id: string;
  contaId: string;
  contaNome: string;
  movimentoId?: string;
  descricao: string;
  valor: number;
  date: string;
  tipo: ConcTipo;
  status: ConcStatus;
  valorSistema?: number;
  valorConferido?: number;
  diferenca?: number;
  observacao?: string;
  conferidoEm?: string;
  conferidoPor?: string;
  createdAt: string;
}

// ─── Persistence ──────────────────────────────────────────────────────────
const KEY_CONC = 'pc_v1_conciliacao';

const SEED: Conciliacao[] = [
  {
    id: 'conc-001', contaId: 'banco-001', contaNome: 'Conta principal — Itaú',
    descricao: 'Recebimento vendas balcão — semana 1 set/2026', valor: 4820.50,
    date: '2026-09-05', tipo: 'entrada', status: 'conferida',
    valorSistema: 4820.50, valorConferido: 4820.50, diferenca: 0,
    conferidoEm: '2026-09-06', conferidoPor: 'Administrador', createdAt: '2026-09-05',
  },
  {
    id: 'conc-002', contaId: 'banco-001', contaNome: 'Conta principal — Itaú',
    descricao: 'Pagamento aluguel setembro/2026', valor: 3800.00,
    date: '2026-09-05', tipo: 'saida', status: 'conferida',
    valorSistema: 3800.00, valorConferido: 3800.00, diferenca: 0,
    conferidoEm: '2026-09-06', conferidoPor: 'Administrador', createdAt: '2026-09-05',
  },
  {
    id: 'conc-003', contaId: 'banco-002', contaNome: 'Conta digital — Nubank',
    descricao: 'Recebimento Pix — pedido corporativo Escola Municipal Norte', valor: 3100.00,
    date: '2026-09-08', tipo: 'entrada', status: 'conferida',
    valorSistema: 3100.00, valorConferido: 3100.00, diferenca: 0,
    conferidoEm: '2026-09-09', conferidoPor: 'Administrador', createdAt: '2026-09-08',
  },
  {
    id: 'conc-004', contaId: 'banco-001', contaNome: 'Conta principal — Itaú',
    descricao: 'Folha de pagamento funcionários agosto/2026', valor: 15800.00,
    date: '2026-09-02', tipo: 'saida', status: 'conferida',
    valorSistema: 15800.00, valorConferido: 15800.00, diferenca: 0,
    conferidoEm: '2026-09-03', conferidoPor: 'Administrador', createdAt: '2026-09-02',
  },
  {
    id: 'conc-005', contaId: 'banco-001', contaNome: 'Conta principal — Itaú',
    descricao: 'Recebimento boleto — Prefeitura Municipal', valor: 2340.00,
    date: '2026-09-22', tipo: 'entrada', status: 'pendente',
    valorSistema: 2340.00, createdAt: '2026-09-22',
  },
  {
    id: 'conc-006', contaId: 'banco-002', contaNome: 'Conta digital — Nubank',
    descricao: 'VR funcionários setembro/2026', valor: 2574.00,
    date: '2026-09-20', tipo: 'saida', status: 'pendente',
    valorSistema: 2574.00, createdAt: '2026-09-20',
  },
  {
    id: 'conc-007', contaId: 'banco-001', contaNome: 'Conta principal — Itaú',
    descricao: 'Recebimento transferência — Rede Aprender', valor: 2800.00,
    date: '2026-09-15', tipo: 'entrada', status: 'divergente',
    valorSistema: 2800.00, valorConferido: 2650.00, diferenca: 150.00,
    observacao: 'Valor bancário menor que o sistema — verificar desconto de taxa',
    conferidoEm: '2026-09-16', conferidoPor: 'Administrador', createdAt: '2026-09-15',
  },
  {
    id: 'conc-008', contaId: 'banco-003', contaNome: 'Poupança — Bradesco',
    descricao: 'Compra de estoque — Fornecedor Compactor (parcela)', valor: 2100.00,
    date: '2026-09-23', tipo: 'saida', status: 'divergente',
    valorSistema: 2100.00, valorConferido: 2180.00, diferenca: -80.00,
    observacao: 'Valor bancário maior — verificar taxa de transferência bancária',
    conferidoEm: '2026-09-24', conferidoPor: 'Administrador', createdAt: '2026-09-23',
  },
];

function loadConc(): Conciliacao[] {
  try { const r = localStorage.getItem(KEY_CONC); return r ? JSON.parse(r) : []; } catch { return []; }
}
function saveConc(data: Conciliacao[]): void {
  localStorage.setItem(KEY_CONC, JSON.stringify(data));
}
function getConc(): Conciliacao[] {
  const data = loadConc();
  if (data.length === 0) { saveConc(SEED); return [...SEED]; }
  return data;
}

// ─── Helpers ──────────────────────────────────────────────────────────────
const brl = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const fmt = (iso: string) => iso.split('-').reverse().join('/');

type StatusStyle = { background: string; color: string; border: string; borderRadius: number; padding: string; fontSize: number };

function statusBadgeStyle(s: ConcStatus): StatusStyle {
  if (s === 'conferida') return { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
  if (s === 'pendente')  return { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
  return { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 4, padding: '2px 8px', fontSize: 11 };
}

function statusLabel(s: ConcStatus) {
  if (s === 'conferida') return 'Conferida';
  if (s === 'pendente')  return 'Pendente';
  return 'Divergente';
}

type PeriodKey = 'mes' | 'mes_ant' | 'custom';

function getPeriodRange(period: PeriodKey, customFrom: string, customTo: string): { from: string; to: string } {
  const today = new Date();
  const y = today.getFullYear();
  const m = today.getMonth();
  const toStr = (dt: Date) => dt.toISOString().slice(0, 10);
  if (period === 'mes') {
    return { from: `${y}-${String(m + 1).padStart(2, '0')}-01`, to: toStr(today) };
  }
  if (period === 'mes_ant') {
    const pm = m === 0 ? 11 : m - 1;
    const py = m === 0 ? y - 1 : y;
    const lastDay = new Date(py, pm + 1, 0).getDate();
    return {
      from: `${py}-${String(pm + 1).padStart(2, '0')}-01`,
      to:   `${py}-${String(pm + 1).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`,
    };
  }
  return { from: customFrom, to: customTo };
}

// ─── Empty form states ────────────────────────────────────────────────────
interface ConferirForm {
  status: ConcStatus;
  valorConferido: string;
  observacao: string;
}

interface AddForm {
  contaId: string;
  descricao: string;
  valor: string;
  date: string;
  tipo: ConcTipo;
  status: ConcStatus;
  observacao: string;
}

function emptyAdd(defaultContaId: string): AddForm {
  return {
    contaId: defaultContaId,
    descricao: '',
    valor: '',
    date: new Date().toISOString().slice(0, 10),
    tipo: 'entrada',
    status: 'pendente',
    observacao: '',
  };
}

// ─── Subcomponents ────────────────────────────────────────────────────────
function KPICard({ label, value, color = C.text, sub }: { label: string; value: string; color?: string; sub?: string }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 6, padding: '12px 16px', minWidth: 0 }}>
      <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 4, fontWeight: 500 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 600, color, lineHeight: 1.2 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

// ─── Main component ───────────────────────────────────────────────────────
export default function ConciliacaoBancaria() {
  const { user } = useApp();

  const contas = useMemo(() => bancosDb.contas.all().filter(c => c.ativa), []);
  const defaultConta = contas[0]?.id ?? '';

  const [selectedConta, setSelectedConta]   = useState(defaultConta);
  const [period, setPeriod]                 = useState<PeriodKey>('mes');
  const [customFrom, setCustomFrom]         = useState('');
  const [customTo, setCustomTo]             = useState('');
  const [statusTab, setStatusTab]           = useState<'todas' | ConcStatus>('todas');
  const [items, setItems]                   = useState<Conciliacao[]>(() => getConc());
  const [toast, setToast]                   = useState('');

  // Conferir modal
  const [conferirId, setConferirId]         = useState<string | null>(null);
  const [conferirForm, setConferirForm]     = useState<ConferirForm>({ status: 'conferida', valorConferido: '', observacao: '' });

  // Add modal
  const [showAdd, setShowAdd]               = useState(false);
  const [addForm, setAddForm]               = useState<AddForm>(() => emptyAdd(defaultConta));

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };
  const refresh = () => setItems(getConc());

  // ── Filtering ──
  const { from, to } = getPeriodRange(period, customFrom, customTo);

  const filtered = useMemo(() => {
    let result = items;
    if (selectedConta) result = result.filter(i => i.contaId === selectedConta);
    if (from && to)    result = result.filter(i => i.date >= from && i.date <= to);
    if (statusTab !== 'todas') result = result.filter(i => i.status === statusTab);
    return result.sort((a, b) => b.date.localeCompare(a.date));
  }, [items, selectedConta, from, to, statusTab]);

  // ── KPIs ──
  const kpis = useMemo(() => {
    const forKPI = items.filter(i => {
      const inConta  = !selectedConta || i.contaId === selectedConta;
      const inPeriod = (!from && !to) || (i.date >= from && i.date <= to);
      return inConta && inPeriod;
    });
    const conferidas   = forKPI.filter(i => i.status === 'conferida');
    const pendentes    = forKPI.filter(i => i.status === 'pendente');
    const divergentes  = forKPI.filter(i => i.status === 'divergente');
    const totalConf    = conferidas.reduce((s, i) => s + (i.valorConferido ?? i.valor) * (i.tipo === 'entrada' ? 1 : -1), 0);
    const totalPend    = pendentes.reduce((s, i)  => s + i.valor * (i.tipo === 'entrada' ? 1 : -1), 0);
    const totalDiv     = divergentes.reduce((s, i) => s + Math.abs(i.diferenca ?? 0), 0);
    const saldo        = totalConf + totalPend;
    return { totalConf, totalPend, totalDiv, saldo, nDivergentes: divergentes.length };
  }, [items, selectedConta, from, to]);

  // ── Conferir action ──
  const openConferir = (item: Conciliacao) => {
    setConferirId(item.id);
    setConferirForm({
      status:         item.status,
      valorConferido: item.valorConferido != null ? String(item.valorConferido) : String(item.valor),
      observacao:     item.observacao ?? '',
    });
  };

  const saveConferir = () => {
    if (!conferirId) return;
    const valorConferido = parseFloat(conferirForm.valorConferido) || 0;
    const updated = loadConc().map(i => {
      if (i.id !== conferirId) return i;
      const diferenca = (i.valorSistema ?? i.valor) - valorConferido;
      return {
        ...i,
        status:         conferirForm.status,
        valorConferido,
        diferenca,
        observacao:     conferirForm.observacao || undefined,
        conferidoEm:    new Date().toISOString().slice(0, 10),
        conferidoPor:   user?.name ?? 'Administrador',
      };
    });
    saveConc(updated);
    refresh();
    setConferirId(null);
    msg('Lançamento atualizado com sucesso.');
  };

  // ── Add action ──
  const openAdd = () => {
    setAddForm(emptyAdd(selectedConta || defaultConta));
    setShowAdd(true);
  };

  const saveAdd = () => {
    const v = parseFloat(addForm.valor);
    if (!addForm.descricao.trim() || !v || v <= 0 || !addForm.date) return;
    const conta = contas.find(c => c.id === addForm.contaId);
    const entry: Conciliacao = {
      id:          newId(),
      contaId:     addForm.contaId,
      contaNome:   conta?.apelido ?? addForm.contaId,
      descricao:   addForm.descricao,
      valor:       v,
      date:        addForm.date,
      tipo:        addForm.tipo,
      status:      addForm.status,
      valorSistema: v,
      observacao:  addForm.observacao || undefined,
      createdAt:   new Date().toISOString().slice(0, 10),
    };
    const all = loadConc();
    saveConc([...all, entry]);
    refresh();
    setShowAdd(false);
    msg('Lançamento adicionado com sucesso.');
  };

  const conferirItem = items.find(i => i.id === conferirId);

  const TABS: Array<{ key: 'todas' | ConcStatus; label: string }> = [
    { key: 'todas',      label: 'Todas' },
    { key: 'conferida',  label: 'Conferidas' },
    { key: 'pendente',   label: 'Pendentes' },
    { key: 'divergente', label: 'Divergentes' },
  ];

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: C.text }}>
      {toast && <Toast msg={toast} />}

      {/* ── Controls row ── */}
      <div style={{ display: 'flex', gap: 10, marginBottom: 14, alignItems: 'flex-end', flexWrap: 'wrap' as const }}>
        {/* Conta selector */}
        <div>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 3, fontWeight: 500 }}>Conta bancária</div>
          <select
            value={selectedConta}
            onChange={e => setSelectedConta(e.target.value)}
            style={{ ...inp(), width: 240 }}
          >
            <option value="">Todas as contas</option>
            {contas.map(c => <option key={c.id} value={c.id}>{c.apelido}</option>)}
          </select>
        </div>

        {/* Period selector */}
        <div>
          <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 3, fontWeight: 500 }}>Período</div>
          <select
            value={period}
            onChange={e => setPeriod(e.target.value as PeriodKey)}
            style={{ ...inp(), width: 160 }}
          >
            <option value="mes">Este mês</option>
            <option value="mes_ant">Mês anterior</option>
            <option value="custom">Personalizado</option>
          </select>
        </div>

        {period === 'custom' && (
          <>
            <div>
              <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 3, fontWeight: 500 }}>De</div>
              <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)} style={{ ...inp(), width: 140 }} />
            </div>
            <div>
              <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 3, fontWeight: 500 }}>Até</div>
              <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)} style={{ ...inp(), width: 140 }} />
            </div>
          </>
        )}

        <div style={{ flex: 1 }} />
        <button onClick={openAdd} style={btnPrimary}>+ Adicionar lançamento</button>
      </div>

      {/* ── KPI row ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10, marginBottom: 16 }}>
        <KPICard
          label="Total conferido"
          value={brl(Math.abs(kpis.totalConf))}
          color={C.success}
          sub={`${items.filter(i => i.status === 'conferida').length} lançamento(s)`}
        />
        <KPICard
          label="Total pendente"
          value={brl(Math.abs(kpis.totalPend))}
          color={C.warning}
          sub={`${items.filter(i => i.status === 'pendente').length} lançamento(s)`}
        />
        <KPICard
          label="Divergências"
          value={brl(kpis.totalDiv)}
          color={kpis.nDivergentes > 0 ? C.error : C.textMuted}
          sub={`${kpis.nDivergentes} lançamento(s)`}
        />
        <KPICard
          label="Saldo conciliado"
          value={brl(Math.abs(kpis.saldo))}
          color={kpis.saldo >= 0 ? C.success : C.error}
          sub={kpis.saldo >= 0 ? 'Saldo positivo' : 'Saldo negativo'}
        />
      </div>

      {/* ── Status tabs ── */}
      <div style={{ display: 'flex', gap: 0, marginBottom: 12, borderBottom: `1px solid ${C.borderLight}` }}>
        {TABS.map(tab => (
          <button
            key={tab.key}
            onClick={() => setStatusTab(tab.key)}
            style={{
              padding: '7px 16px', fontSize: 13, cursor: 'pointer', border: 'none',
              fontFamily: 'Inter, sans-serif', fontWeight: statusTab === tab.key ? 600 : 400,
              background: 'transparent',
              color:  statusTab === tab.key ? C.navy : C.textMuted,
              borderBottom: statusTab === tab.key ? `2px solid ${C.navy}` : '2px solid transparent',
              marginBottom: -1,
            }}
          >
            {tab.label}
          </button>
        ))}
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted, alignSelf: 'center', marginRight: 4 }}>
          {filtered.length} registro(s)
        </span>
      </div>

      {/* ── Table ── */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Data', 'Descrição', 'Conta', 'Tipo', 'Valor sistema', 'Valor conferido', 'Diferença', 'Status', 'Ações'].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={9} style={{ ...TD, textAlign: 'center' as const, color: C.textMuted, fontStyle: 'italic', padding: '24px 12px' }}>
                  Nenhum lançamento encontrado para os filtros selecionados.
                </td>
              </tr>
            )}
            {filtered.map((item, i) => (
              <tr key={item.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, whiteSpace: 'nowrap' as const, color: C.textMuted, fontSize: 12 }}>{fmt(item.date)}</td>
                <td style={{ ...TD, fontWeight: 500, maxWidth: 220 }}>
                  <div>{item.descricao}</div>
                  {item.observacao && (
                    <div style={{ fontSize: 11, color: C.textMuted, marginTop: 2, fontWeight: 400 }}>{item.observacao}</div>
                  )}
                </td>
                <td style={{ ...TD, fontSize: 12, color: C.textMuted, whiteSpace: 'nowrap' as const }}>{item.contaNome}</td>
                <td style={TD}>
                  <span style={{
                    fontSize: 11, borderRadius: 4, padding: '1px 6px',
                    background: item.tipo === 'entrada' ? '#ECFDF3' : '#FEF2F2',
                    color:      item.tipo === 'entrada' ? '#027A48' : '#B42318',
                    border:     item.tipo === 'entrada' ? '1px solid #A9EFC5' : '1px solid #FECDCA',
                  }}>
                    {item.tipo === 'entrada' ? 'Entrada' : 'Saída'}
                  </span>
                </td>
                <td style={{ ...TD, fontWeight: 500, whiteSpace: 'nowrap' as const }}>
                  {item.valorSistema != null ? brl(item.valorSistema) : brl(item.valor)}
                </td>
                <td style={{ ...TD, whiteSpace: 'nowrap' as const, color: item.valorConferido != null ? C.text : C.textMuted }}>
                  {item.valorConferido != null ? brl(item.valorConferido) : '—'}
                </td>
                <td style={{ ...TD, whiteSpace: 'nowrap' as const }}>
                  {item.diferenca != null ? (
                    <span style={{ color: item.diferenca === 0 ? C.success : C.error, fontWeight: 500 }}>
                      {item.diferenca === 0 ? 'OK' : brl(Math.abs(item.diferenca))}
                    </span>
                  ) : '—'}
                </td>
                <td style={TD}>
                  <span style={statusBadgeStyle(item.status)}>{statusLabel(item.status)}</span>
                  {item.conferidoEm && (
                    <div style={{ fontSize: 10, color: C.textMuted, marginTop: 2 }}>
                      {fmt(item.conferidoEm)} · {item.conferidoPor}
                    </div>
                  )}
                </td>
                <td style={TD}>
                  <button
                    onClick={() => openConferir(item)}
                    style={{
                      padding: '3px 10px', fontSize: 12, borderRadius: 4, cursor: 'pointer',
                      fontFamily: 'Inter, sans-serif', fontWeight: 400,
                      background: 'none', color: C.navy, border: `1px solid ${C.border}`,
                    }}
                  >
                    Conferir
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ── Conferir modal ── */}
      {conferirId && conferirItem && (
        <Modal title="Conferir lançamento" onClose={() => setConferirId(null)}>
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 13, fontWeight: 500, color: C.text, marginBottom: 2 }}>{conferirItem.descricao}</div>
            <div style={{ fontSize: 12, color: C.textMuted }}>
              {fmt(conferirItem.date)} · {conferirItem.contaNome} ·{' '}
              <strong>Valor sistema: {brl(conferirItem.valorSistema ?? conferirItem.valor)}</strong>
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Status
              </label>
              <select
                value={conferirForm.status}
                onChange={e => setConferirForm(f => ({ ...f, status: e.target.value as ConcStatus }))}
                style={inp()}
              >
                <option value="conferida">Conferida</option>
                <option value="pendente">Pendente</option>
                <option value="divergente">Divergente</option>
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Valor conferido (R$)
              </label>
              <input
                type="number"
                step="0.01"
                value={conferirForm.valorConferido}
                onChange={e => setConferirForm(f => ({ ...f, valorConferido: e.target.value }))}
                style={inp()}
                placeholder="0,00"
              />
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
                Observação
              </label>
              <textarea
                value={conferirForm.observacao}
                onChange={e => setConferirForm(f => ({ ...f, observacao: e.target.value }))}
                rows={3}
                style={{ ...inp(), resize: 'vertical' as const }}
                placeholder="Nota sobre a conferência (opcional)..."
              />
            </div>
          </div>

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
            <button onClick={() => setConferirId(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={saveConferir} style={btnPrimary}>Salvar conferência</button>
          </div>
        </Modal>
      )}

      {/* ── Add lançamento modal ── */}
      {showAdd && (
        <Modal title="Adicionar lançamento" onClose={() => setShowAdd(false)}>
          <div style={{ display: 'flex', flexDirection: 'column' as const, gap: 12 }}>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Conta bancária</label>
              <select
                value={addForm.contaId}
                onChange={e => setAddForm(f => ({ ...f, contaId: e.target.value }))}
                style={inp()}
              >
                {contas.map(c => <option key={c.id} value={c.id}>{c.apelido}</option>)}
              </select>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Descrição</label>
              <input
                type="text"
                value={addForm.descricao}
                onChange={e => setAddForm(f => ({ ...f, descricao: e.target.value }))}
                style={inp()}
                placeholder="Descrição do lançamento..."
              />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Valor (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  value={addForm.valor}
                  onChange={e => setAddForm(f => ({ ...f, valor: e.target.value }))}
                  style={inp()}
                  placeholder="0,00"
                />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Data</label>
                <input
                  type="date"
                  value={addForm.date}
                  onChange={e => setAddForm(f => ({ ...f, date: e.target.value }))}
                  style={inp()}
                />
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Tipo</label>
                <select value={addForm.tipo} onChange={e => setAddForm(f => ({ ...f, tipo: e.target.value as ConcTipo }))} style={inp()}>
                  <option value="entrada">Entrada</option>
                  <option value="saida">Saída</option>
                </select>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Status</label>
                <select value={addForm.status} onChange={e => setAddForm(f => ({ ...f, status: e.target.value as ConcStatus }))} style={inp()}>
                  <option value="pendente">Pendente</option>
                  <option value="conferida">Conferida</option>
                  <option value="divergente">Divergente</option>
                </select>
              </div>
            </div>
            <div>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Observação</label>
              <textarea
                value={addForm.observacao}
                onChange={e => setAddForm(f => ({ ...f, observacao: e.target.value }))}
                rows={2}
                style={{ ...inp(), resize: 'vertical' as const }}
                placeholder="Observação opcional..."
              />
            </div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
            <button onClick={() => setShowAdd(false)} style={btnSecondary}>Cancelar</button>
            <button
              onClick={saveAdd}
              disabled={!addForm.descricao.trim() || !addForm.valor || !addForm.date}
              style={{ ...btnPrimary, opacity: (!addForm.descricao.trim() || !addForm.valor || !addForm.date) ? 0.5 : 1 }}
            >
              Adicionar
            </button>
          </div>
        </Modal>
      )}

      {/* ── Summary card at bottom ── */}
      {filtered.length > 0 && (
        <div style={{ ...formCard, marginTop: 14, display: 'flex', gap: 24, fontSize: 12, color: C.textMuted, flexWrap: 'wrap' as const }}>
          <span>
            Entradas:&nbsp;
            <strong style={{ color: C.success }}>
              {brl(filtered.filter(i => i.tipo === 'entrada').reduce((s, i) => s + i.valor, 0))}
            </strong>
          </span>
          <span>
            Saídas:&nbsp;
            <strong style={{ color: C.error }}>
              {brl(filtered.filter(i => i.tipo === 'saida').reduce((s, i) => s + i.valor, 0))}
            </strong>
          </span>
          <span>
            Saldo filtrado:&nbsp;
            <strong style={{ color: C.text }}>
              {brl(filtered.reduce((s, i) => s + i.valor * (i.tipo === 'entrada' ? 1 : -1), 0))}
            </strong>
          </span>
        </div>
      )}
    </div>
  );
}
