import { useState } from 'react';
import { finDb, fmtBRL, type FinOrder, type OrderStatus, type PaymentMethod } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, btnDanger, inp, ROW_BORDER } from '../../theme';
import { Modal, Toast } from '../Produtos';

const STATUS_LIST: OrderStatus[] = ['Pendente', 'Em preparação', 'Pronto para entrega', 'Saiu para entrega', 'Entregue', 'Cancelado'];
const METHODS: PaymentMethod[] = ['Pix', 'Dinheiro', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência'];

const statusColor: Record<OrderStatus, React.CSSProperties> = {
  'Pendente': { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A' },
  'Em preparação': { background: '#EFF6FF', color: '#1D4ED8', border: '1px solid #BFDBFE' },
  'Pronto para entrega': { background: '#F3E8FF', color: '#7E22CE', border: '1px solid #E9D5FF' },
  'Saiu para entrega': { background: '#ECFEFF', color: '#0E7490', border: '1px solid #A5F3FC' },
  'Entregue': { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5' },
  'Cancelado': { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA' },
};

const nextOrderNum = (orders: FinOrder[]) => {
  const nums = orders.map(o => parseInt(o.orderNumber.replace('PED-', '')) || 0);
  const max = nums.length ? Math.max(...nums) : 0;
  return `PED-${String(max + 1).padStart(3, '0')}`;
};

const empty = (orders: FinOrder[]): Omit<FinOrder, 'id' | 'createdAt'> => ({
  orderNumber: nextOrderNum(orders), client: '', products: '', qty: 1, total: 0,
  orderDate: new Date().toISOString().slice(0, 10),
  deliveryDate: '', address: '', paymentMethod: 'Pix', status: 'Pendente',
});

export default function Pedidos() {
  const [items, setItems] = useState<FinOrder[]>(() => finDb.orders.all());
  const [form, setForm] = useState<Omit<FinOrder, 'id' | 'createdAt'>>(empty(finDb.orders.all()));
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');
  const [search, setSearch] = useState('');

  const refresh = () => { const all = finDb.orders.all(); setItems(all); setForm(empty(all)); };
  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };
  const f = (field: string, val: string | number) => setForm(x => ({ ...x, [field]: val }));

  const openNew = () => { const all = finDb.orders.all(); setForm(empty(all)); setEditId(null); setShowForm(true); };
  const openEdit = (o: FinOrder) => { const { id, createdAt: _, ...rest } = o; setForm(rest); setEditId(id); setShowForm(true); };

  const save = () => {
    if (!form.client.trim() || !form.total || form.total <= 0) return;
    if (editId) finDb.orders.update(editId, form); else finDb.orders.add(form);
    refresh(); setShowForm(false);
    msg(editId ? 'Pedido atualizado.' : 'Pedido registrado com sucesso.');
  };

  const del = (id: string) => { finDb.orders.remove(id); refresh(); setDeleteId(null); msg('Pedido excluído.'); };

  const filtered = items.filter(o =>
    (statusFilter === 'Todos' || o.status === statusFilter) &&
    (o.client.toLowerCase().includes(search.toLowerCase()) || o.orderNumber.toLowerCase().includes(search.toLowerCase()))
  );

  const ativos = items.filter(o => o.status !== 'Entregue' && o.status !== 'Cancelado');
  const valorAtivo = ativos.reduce((s, o) => s + o.total, 0);

  return (
    <div>
      {toast && <Toast msg={toast} />}
      <div style={{ display: 'flex', gap: 8, marginBottom: 8, flexWrap: 'wrap' as const }}>
        {['Pendente', 'Em preparação', 'Pronto para entrega', 'Saiu para entrega'].map(s => {
          const count = items.filter(o => o.status === s).length;
          if (!count) return null;
          return (
            <span key={s} style={{ ...statusColor[s as OrderStatus], borderRadius: 4, padding: '2px 8px', fontSize: 11 }}>
              {s}: {count}
            </span>
          );
        })}
        <span style={{ fontSize: 12, color: C.textMuted, marginLeft: 'auto' }}>
          {ativos.length} em aberto · {fmtBRL(valorAtivo)}
        </span>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar cliente ou nº pedido..." style={sinp} />
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={sinp}>
          <option>Todos</option>
          {STATUS_LIST.map(s => <option key={s}>{s}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <button onClick={openNew} style={btnPrimary}>+ Novo pedido</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Nº', 'Cliente', 'Produtos', 'Qtd.', 'Total', 'Pedido em', 'Entrega', 'Pagamento', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((o, i) => (
              <tr key={o.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{o.orderNumber}</td>
                <td style={{ ...TD, fontWeight: 500 }}>{o.client}</td>
                <td style={{ ...TD, color: C.textMuted, maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const }}>{o.products}</td>
                <td style={{ ...TD, color: C.textMuted }}>{o.qty}</td>
                <td style={{ ...TD, fontWeight: 600 }}>{fmtBRL(o.total)}</td>
                <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{o.orderDate.split('-').reverse().join('/')}</td>
                <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{o.deliveryDate ? o.deliveryDate.split('-').reverse().join('/') : '—'}</td>
                <td style={{ ...TD, color: C.textMuted }}>{o.paymentMethod}</td>
                <td style={TD}><span style={{ ...statusColor[o.status], borderRadius: 4, padding: '2px 7px', fontSize: 11 }}>{o.status}</span></td>
                <td style={TD}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button onClick={() => openEdit(o)} style={actBtn}>Editar</button>
                    <button onClick={() => setDeleteId(o.id)} style={{ ...actBtn, color: C.error }}>Excluir</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={10} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum pedido encontrado.</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editId ? 'Editar pedido' : 'Novo pedido'} onClose={() => setShowForm(false)}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div><L>Nº Pedido</L><input value={form.orderNumber} onChange={e => f('orderNumber', e.target.value)} style={inp()} /></div>
            <div><L>Cliente *</L><input value={form.client} onChange={e => f('client', e.target.value)} placeholder="Nome do cliente" style={inp()} /></div>
            <div style={{ gridColumn: '1/-1' }}><L>Produtos</L><input value={form.products} onChange={e => f('products', e.target.value)} placeholder="Descrição dos produtos" style={inp()} /></div>
            <div><L>Qtd. total</L><input type="number" min="1" value={form.qty} onChange={e => f('qty', parseInt(e.target.value) || 1)} style={inp()} /></div>
            <div><L>Valor total (R$) *</L><input type="number" min="0.01" step="0.01" value={form.total || ''} onChange={e => f('total', parseFloat(e.target.value) || 0)} style={inp()} /></div>
            <div><L>Data do pedido</L><input type="date" value={form.orderDate} onChange={e => f('orderDate', e.target.value)} style={inp()} /></div>
            <div><L>Previsão de entrega</L><input type="date" value={form.deliveryDate} onChange={e => f('deliveryDate', e.target.value)} style={inp()} /></div>
            <div style={{ gridColumn: '1/-1' }}><L>Endereço / observação</L><input value={form.address} onChange={e => f('address', e.target.value)} placeholder="Endereço de entrega" style={inp()} /></div>
            <div><L>Pagamento</L>
              <select value={form.paymentMethod} onChange={e => f('paymentMethod', e.target.value)} style={inp()}>
                {METHODS.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div><L>Status</L>
              <select value={form.status} onChange={e => f('status', e.target.value)} style={inp()}>
                {STATUS_LIST.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16, borderTop: `1px solid ${C.borderLight}`, paddingTop: 14 }}>
            <button onClick={() => setShowForm(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}

      {deleteId && (
        <Modal title="Excluir pedido" onClose={() => setDeleteId(null)}>
          <p style={{ fontSize: 13, color: C.text, margin: '0 0 16px' }}>Confirmar exclusão deste pedido?</p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setDeleteId(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={() => del(deleteId)} style={btnDanger}>Excluir</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const L = ({ children }: { children: React.ReactNode }) => (
  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{children}</label>
);
const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
