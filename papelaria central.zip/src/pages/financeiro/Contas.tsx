import { useState } from 'react';
import { finDb, fmtBRL, type FinBill, type BillStatus } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, btnDanger, inp, ROW_BORDER } from '../../theme';
import { Modal, Toast } from '../Produtos';

const BILL_CATS = ['Aluguel', 'Energia', 'Internet', 'Salários', 'Benefícios', 'Fornecedores', 'Estoque', 'Outras'];
const STATUS_LIST: BillStatus[] = ['Pendente', 'Pago', 'Vencido'];

const statusStyle = (s: BillStatus): React.CSSProperties =>
  s === 'Pago' ? { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '1px 6px', fontSize: 11 }
  : s === 'Vencido' ? { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 4, padding: '1px 6px', fontSize: 11 }
  : { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '1px 6px', fontSize: 11 };

const empty = (): Omit<FinBill, 'id' | 'createdAt'> => ({
  description: '', category: 'Outras', value: 0,
  dueDate: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10), status: 'Pendente',
});

export default function Contas() {
  const [items, setItems] = useState<FinBill[]>(() => finDb.bills.all());
  const [form, setForm] = useState(empty());
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [statusFilter, setStatusFilter] = useState('Todos');

  const refresh = () => setItems(finDb.bills.all());
  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };
  const f = (field: string, val: string | number) => setForm(x => ({ ...x, [field]: val }));

  const openNew = () => { setForm(empty()); setEditId(null); setShowForm(true); };
  const openEdit = (b: FinBill) => { const { id, createdAt: _, ...rest } = b; setForm(rest); setEditId(id); setShowForm(true); };

  const save = () => {
    if (!form.description.trim() || !form.value || form.value <= 0) return;
    if (editId) finDb.bills.update(editId, form); else finDb.bills.add(form);
    refresh(); setShowForm(false);
    msg(editId ? 'Conta atualizada.' : 'Conta registrada com sucesso.');
  };

  const markPaid = (id: string) => { finDb.bills.update(id, { status: 'Pago' }); refresh(); msg('Conta marcada como paga.'); };

  const del = (id: string) => { finDb.bills.remove(id); refresh(); setDeleteId(null); msg('Conta excluída.'); };

  const filtered = items.filter(b => statusFilter === 'Todos' || b.status === statusFilter);

  const totalPendente = items.filter(b => b.status === 'Pendente' || b.status === 'Vencido').reduce((s, b) => s + b.value, 0);
  const countVencidas = items.filter(b => b.status === 'Vencido').length;

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 10, marginBottom: 16, flexWrap: 'wrap' as const }}>
        <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '10px 14px', flex: 1, minWidth: 130 }}>
          <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 3 }}>A pagar</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: '#B54708' }}>{fmtBRL(totalPendente)}</div>
        </div>
        <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '10px 14px', flex: 1, minWidth: 130 }}>
          <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 3 }}>Contas vencidas</div>
          <div style={{ fontSize: 16, fontWeight: 600, color: countVencidas > 0 ? '#B91C1C' : C.text }}>{countVencidas}</div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center' }}>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={sinp}>
          <option>Todos</option>
          {STATUS_LIST.map(s => <option key={s}>{s}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <button onClick={openNew} style={btnPrimary}>+ Nova conta</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Descrição', 'Categoria', 'Valor', 'Vencimento', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((b, i) => (
              <tr key={b.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{b.description}</td>
                <td style={{ ...TD, color: C.textMuted }}>{b.category}</td>
                <td style={{ ...TD, fontWeight: 600, color: b.status === 'Pago' ? '#027A48' : '#B54708' }}>{fmtBRL(b.value)}</td>
                <td style={{ ...TD, color: b.status === 'Vencido' ? '#B91C1C' : C.textMuted, fontSize: 12 }}>{b.dueDate.split('-').reverse().join('/')}</td>
                <td style={TD}><span style={statusStyle(b.status)}>{b.status}</span></td>
                <td style={TD}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    {b.status !== 'Pago' && <button onClick={() => markPaid(b.id)} style={{ ...actBtn, color: '#027A48' }}>Pagar</button>}
                    <button onClick={() => openEdit(b)} style={actBtn}>Editar</button>
                    <button onClick={() => setDeleteId(b.id)} style={{ ...actBtn, color: C.error }}>Excluir</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhuma conta encontrada.</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editId ? 'Editar conta' : 'Nova conta'} onClose={() => setShowForm(false)}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div style={{ gridColumn: '1/-1' }}><L>Descrição *</L><input value={form.description} onChange={e => f('description', e.target.value)} style={inp()} /></div>
            <div><L>Categoria</L>
              <select value={form.category} onChange={e => f('category', e.target.value)} style={inp()}>
                {BILL_CATS.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div><L>Valor (R$) *</L><input type="number" min="0.01" step="0.01" value={form.value || ''} onChange={e => f('value', parseFloat(e.target.value) || 0)} style={inp()} /></div>
            <div><L>Vencimento</L><input type="date" value={form.dueDate} onChange={e => f('dueDate', e.target.value)} style={inp()} /></div>
            <div><L>Status</L>
              <select value={form.status} onChange={e => f('status', e.target.value)} style={inp()}>
                {STATUS_LIST.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16, borderTop: `1px solid ${C.borderLight}`, paddingTop: 14 }}>
            <button onClick={() => setShowForm(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}

      {deleteId && (
        <Modal title="Excluir conta" onClose={() => setDeleteId(null)}>
          <p style={{ fontSize: 13, color: C.text, margin: '0 0 16px' }}>Confirmar exclusão desta conta?</p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setDeleteId(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={() => del(deleteId)} style={btnDanger}>Excluir</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const L = ({ children }: { children: React.ReactNode }) => (
  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{children}</label>
);
const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
