import { useState } from 'react';
import { finDb, fmtBRL, type FinExpense, type ExpenseCat, type PaymentMethod, type RecStatus } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, btnDanger, inp, ROW_BORDER } from '../../theme';
import { Modal, Toast } from '../Produtos';

const CATS: ExpenseCat[] = ['Compra de estoque', 'Salários', 'VR', 'VT', 'Aluguel', 'Energia', 'Internet', 'Fornecedores', 'Outras despesas'];
const METHODS: PaymentMethod[] = ['Pix', 'Dinheiro', 'Cartão de débito', 'Cartão de crédito', 'Boleto', 'Transferência'];
const STATUS: RecStatus[] = ['Pago', 'Pendente', 'Cancelado'];

const statusStyle = (s: RecStatus): React.CSSProperties =>
  s === 'Pago' ? { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '1px 6px', fontSize: 11 }
  : s === 'Pendente' ? { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '1px 6px', fontSize: 11 }
  : { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 4, padding: '1px 6px', fontSize: 11 };

const empty = (): Omit<FinExpense, 'id' | 'createdAt'> => ({
  description: '', category: 'Compra de estoque', value: 0, date: new Date().toISOString().slice(0,10),
  paymentMethod: 'Boleto', status: 'Pendente',
});

export default function Despesas() {
  const [items, setItems] = useState<FinExpense[]>(() => finDb.expenses.all());
  const [form, setForm] = useState(empty());
  const [editId, setEditId] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [toast, setToast] = useState('');
  const [catFilter, setCatFilter] = useState('Todas');
  const [search, setSearch] = useState('');

  const refresh = () => setItems(finDb.expenses.all());
  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };
  const f = (field: string, val: string | number) => setForm(x => ({ ...x, [field]: val }));

  const openNew = () => { setForm(empty()); setEditId(null); setShowForm(true); };
  const openEdit = (r: FinExpense) => { const { id, createdAt: _, ...rest } = r; setForm(rest); setEditId(id); setShowForm(true); };

  const save = () => {
    if (!form.description.trim() || !form.value || form.value <= 0) return;
    if (editId) finDb.expenses.update(editId, form); else finDb.expenses.add(form);
    refresh(); setShowForm(false);
    msg(editId ? 'Despesa atualizada com sucesso.' : 'Despesa registrada com sucesso.');
  };

  const del = (id: string) => { finDb.expenses.remove(id); refresh(); setDeleteId(null); msg('Despesa excluída.'); };

  const filtered = items.filter(r =>
    (catFilter === 'Todas' || r.category === catFilter) &&
    r.description.toLowerCase().includes(search.toLowerCase())
  );

  const total = filtered.filter(r => r.status === 'Pago').reduce((s, r) => s + r.value, 0);
  const pendente = filtered.filter(r => r.status === 'Pendente').reduce((s, r) => s + r.value, 0);

  return (
    <div>
      {toast && <Toast msg={toast} />}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar descrição..." style={sinp} />
        <select value={catFilter} onChange={e => setCatFilter(e.target.value)} style={sinp}>
          <option>Todas</option>
          {CATS.map(c => <option key={c}>{c}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted }}>
          {filtered.length} reg. · Pago: <strong style={{ color: '#B91C1C' }}>{fmtBRL(total)}</strong>
          {pendente > 0 && <> · Pendente: <strong style={{ color: '#B54708' }}>{fmtBRL(pendente)}</strong></>}
        </span>
        <button onClick={openNew} style={btnPrimary}>+ Nova despesa</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Data', 'Descrição', 'Categoria', 'Pagamento', 'Valor', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr key={r.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, color: C.textMuted, fontSize: 12, whiteSpace: 'nowrap' as const }}>{r.date.split('-').reverse().join('/')}</td>
                <td style={{ ...TD, fontWeight: 500 }}>{r.description}</td>
                <td style={{ ...TD, color: C.textMuted }}>{r.category}</td>
                <td style={{ ...TD, color: C.textMuted }}>{r.paymentMethod}</td>
                <td style={{ ...TD, fontWeight: 600, color: '#B91C1C' }}>{fmtBRL(r.value)}</td>
                <td style={TD}><span style={statusStyle(r.status)}>{r.status}</span></td>
                <td style={TD}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button onClick={() => openEdit(r)} style={actBtn}>Editar</button>
                    <button onClick={() => setDeleteId(r.id)} style={{ ...actBtn, color: C.error }}>Excluir</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhuma despesa encontrada.</td></tr>}
          </tbody>
        </table>
      </div>

      {showForm && (
        <Modal title={editId ? 'Editar despesa' : 'Nova despesa'} onClose={() => setShowForm(false)}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <div style={{ gridColumn: '1/-1' }}>
              <L>Descrição *</L>
              <input value={form.description} onChange={e => f('description', e.target.value)} placeholder="Ex: Compra de estoque — Tilibra" style={inp()} />
            </div>
            <div><L>Categoria *</L>
              <select value={form.category} onChange={e => f('category', e.target.value)} style={inp()}>
                {CATS.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div><L>Valor (R$) *</L>
              <input type="number" min="0.01" step="0.01" value={form.value || ''} onChange={e => f('value', parseFloat(e.target.value) || 0)} style={inp()} />
            </div>
            <div><L>Data *</L>
              <input type="date" value={form.date} onChange={e => f('date', e.target.value)} style={inp()} />
            </div>
            <div><L>Forma de pagamento</L>
              <select value={form.paymentMethod} onChange={e => f('paymentMethod', e.target.value)} style={inp()}>
                {METHODS.map(m => <option key={m}>{m}</option>)}
              </select>
            </div>
            <div><L>Status</L>
              <select value={form.status} onChange={e => f('status', e.target.value)} style={inp()}>
                {STATUS.map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 16, borderTop: `1px solid ${C.borderLight}`, paddingTop: 14 }}>
            <button onClick={() => setShowForm(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}

      {deleteId && (
        <Modal title="Excluir despesa" onClose={() => setDeleteId(null)}>
          <p style={{ fontSize: 13, color: C.text, margin: '0 0 16px' }}>Confirmar exclusão desta despesa?</p>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setDeleteId(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={() => del(deleteId)} style={btnDanger}>Excluir</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

const L = ({ children }: { children: React.ReactNode }) => (
  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{children}</label>
);
const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
