import { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { db } from '../../data/db';
import { finDb, fmtBRL } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER } from '../../theme';

export default function CustosMargem() {
  const products = useMemo(() => db.products.all(), []);
  const revenues = useMemo(() => finDb.revenues.all(), []);
  const expenses = useMemo(() => finDb.expenses.all(), []);

  const totalVendas = revenues.filter(r => r.category === 'Vendas' && r.status === 'Pago').reduce((s, r) => s + r.value, 0);
  const totalCusto = expenses.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const lucroBruto = totalVendas - totalCusto;
  const margem = totalVendas > 0 ? (lucroBruto / totalVendas) * 100 : 0;

  const catData = useMemo(() => {
    const catMap: Record<string, { vendas: number; custo: number }> = {};
    revenues.filter(r => r.category === 'Vendas' && r.status === 'Pago').forEach(r => {
      if (!catMap['Geral']) catMap['Geral'] = { vendas: 0, custo: 0 };
      catMap['Geral'].vendas += r.value;
    });
    expenses.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').forEach(e => {
      if (!catMap['Geral']) catMap['Geral'] = { vendas: 0, custo: 0 };
      catMap['Geral'].custo += e.value;
    });
    return Object.entries(catMap).map(([name, v]) => ({
      name,
      Vendas: Math.round(v.vendas),
      'Custo estoque': Math.round(v.custo),
      'Lucro bruto': Math.round(v.vendas - v.custo),
    }));
  }, [revenues, expenses]);

  // Por categoria de produto — simula distribuição proporcional
  const categoryData = useMemo(() => {
    const catCount: Record<string, number> = {};
    products.forEach(p => { catCount[p.category] = (catCount[p.category] ?? 0) + 1; });
    const totalProds = products.length || 1;
    return Object.entries(catCount).map(([cat, count]) => {
      const pct = count / totalProds;
      const v = Math.round(totalVendas * pct);
      const c = Math.round(totalCusto * pct);
      const mg = v > 0 ? ((v - c) / v) * 100 : 0;
      return { cat, vendas: v, custo: c, margem: Math.round(mg * 10) / 10 };
    }).sort((a, b) => b.vendas - a.vendas);
  }, [products, totalVendas, totalCusto]);

  const tooltipStyle = { contentStyle: { fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 4 } };

  return (
    <div>
      {/* KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10, marginBottom: 24 }}>
        {[
          { label: 'Faturamento total', value: fmtBRL(totalVendas), color: '#2E6FA3' },
          { label: 'Custo de estoque', value: fmtBRL(totalCusto), color: '#E05252' },
          { label: 'Lucro bruto', value: fmtBRL(lucroBruto), color: lucroBruto >= 0 ? '#27AE60' : '#E05252' },
          { label: 'Margem bruta', value: `${margem.toFixed(1)}%`, color: margem >= 30 ? '#27AE60' : margem >= 15 ? '#B54708' : '#E05252' },
          { label: 'Total produtos', value: String(products.length), color: C.text },
        ].map(c => (
          <div key={c.label} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '12px 16px' }}>
            <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 4 }}>{c.label}</div>
            <div style={{ fontSize: 18, fontWeight: 600, color: c.color }}>{c.value}</div>
          </div>
        ))}
      </div>

      {/* Gráfico faturamento vs custo */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '16px', marginBottom: 20 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 12 }}>Faturamento × Custo × Lucro bruto</div>
        <div style={{ height: 200 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={catData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="Vendas" fill="#2E6FA3" radius={[2,2,0,0]} />
              <Bar dataKey="Custo estoque" fill="#E05252" radius={[2,2,0,0]} />
              <Bar dataKey="Lucro bruto" fill="#27AE60" radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Tabela por categoria */}
      <div style={{ fontSize: 12, fontWeight: 600, color: C.text, textTransform: 'uppercase' as const, letterSpacing: '0.05em', marginBottom: 12 }}>
        Análise por categoria de produto
      </div>
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Categoria', 'Produtos', 'Faturamento estimado', 'Custo estimado', 'Lucro estimado', 'Margem estimada'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {categoryData.map((row, i) => {
              const count = products.filter(p => p.category === row.cat).length;
              return (
                <tr key={row.cat} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                  <td style={{ ...TD, fontWeight: 500 }}>{row.cat}</td>
                  <td style={{ ...TD, color: C.textMuted }}>{count}</td>
                  <td style={{ ...TD, color: '#2E6FA3', fontWeight: 600 }}>{fmtBRL(row.vendas)}</td>
                  <td style={{ ...TD, color: '#E05252' }}>{fmtBRL(row.custo)}</td>
                  <td style={{ ...TD, fontWeight: 600, color: row.vendas - row.custo >= 0 ? '#27AE60' : '#E05252' }}>{fmtBRL(row.vendas - row.custo)}</td>
                  <td style={TD}>
                    <span style={{ fontWeight: 600, color: row.margem >= 30 ? '#027A48' : row.margem >= 15 ? '#B54708' : '#B91C1C' }}>
                      {row.margem}%
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      <p style={{ fontSize: 11, color: C.textMuted, marginTop: 8 }}>
        * Os valores por categoria são estimativas proporcionais ao mix de produtos. Para custos unitários precisos, cadastre o preço de custo individualmente em cada produto.
      </p>
    </div>
  );
}
