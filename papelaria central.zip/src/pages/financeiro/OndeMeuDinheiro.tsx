import React, { useMemo } from 'react';
import { finDb } from '../../data/finDb';
import { bancosDb } from '../../data/bancosDb';
import { emergencyDb } from '../../data/emergencyDb';
import { marketingDb } from '../../data/marketingDb';
import { caixaDb } from '../../data/caixaDb';
import { C } from '../../theme';

function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <h2 style={{ margin: '0 0 12px', fontSize: 13, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
      {children}
    </h2>
  );
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      background: C.white,
      border: `1px solid ${C.border}`,
      borderRadius: 10,
      padding: 20,
      ...style,
    }}>
      {children}
    </div>
  );
}

function LineItem({ label, value, muted, highlight }: { label: string; value: string; muted?: boolean; highlight?: 'positive' | 'negative' }) {
  const valueColor = highlight === 'positive' ? C.success : highlight === 'negative' ? C.error : C.text;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: `1px solid ${C.borderLight}` }}>
      <span style={{ fontSize: 13, color: muted ? C.textMuted : C.text }}>{label}</span>
      <span style={{ fontSize: 14, fontWeight: 600, color: valueColor, fontVariantNumeric: 'tabular-nums' }}>{value}</span>
    </div>
  );
}

function SubtotalLine({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingTop: 10, marginTop: 2 }}>
      <span style={{ fontSize: 13, fontWeight: 600, color: color ?? C.text }}>{label}</span>
      <span style={{ fontSize: 15, fontWeight: 700, color: color ?? C.text, fontVariantNumeric: 'tabular-nums' }}>{value}</span>
    </div>
  );
}

export default function OndeMeuDinheiro() {
  const data = useMemo(() => {
    // ── Section 1: Dinheiro disponível ──────────────────────────
    const contas = bancosDb.contas.all().filter(c => c.ativa);
    const totalBancos = contas.reduce((s, c) => s + c.saldoAtual, 0);

    // Caixa: find today's open session or last session balance
    const hoje = new Date().toISOString().slice(0, 10);
    const sessoes = caixaDb.sessoes.all();
    const sessaoAberta = sessoes.find(s => s.status === 'aberto');
    const sessaoHoje = sessoes.find(s => s.data === hoje);
    const sessaoRef = sessaoAberta ?? sessaoHoje;
    const caixaBalance = sessaoRef
      ? sessaoRef.totalEntradas - sessaoRef.totalSangrias + sessaoRef.valorInicial
      : 0;
    const caixaLabel = sessaoRef
      ? `Caixa ${sessaoRef.status === 'aberto' ? '(aberto)' : '(fechado hoje)'}`
      : 'Caixa (sem sessão hoje)';

    const totalDisponivel = totalBancos + caixaBalance;

    // ── Section 2: Reservas ──────────────────────────────────────
    const emergFund = emergencyDb.get();
    const emergValue = emergFund.saldoAtual;
    const marketBudget = marketingDb.get();
    const marketingReservado = marketBudget.verbaReservada;
    const totalReservas = emergValue + marketingReservado;

    // ── Section 3: A receber ─────────────────────────────────────
    const salesAReceber = finDb.sales.all().filter(s => s.status === 'A receber');
    const totalSalesAReceber = salesAReceber.reduce((s, sale) => s + sale.netValue, 0);

    const billsAReceber = finDb.bills.all().filter(b => b.status === 'Pendente' && b.category === 'A receber');
    const totalBillsAReceber = billsAReceber.reduce((s, b) => s + b.value, 0);

    const totalAReceber = totalSalesAReceber + totalBillsAReceber;

    // ── Section 4: Compromissos ──────────────────────────────────
    const billsAPagar = finDb.bills.all().filter(b => b.status === 'Pendente' || b.status === 'Vencido');
    const totalBillsAPagar = billsAPagar.reduce((s, b) => s + b.value, 0);

    const payrollPendente = finDb.payroll.all().filter(p => p.status === 'Pendente');
    const totalPayrollPendente = payrollPendente.reduce((s, p) => s + p.total, 0);

    // Avoid double counting: bills that already include salary category
    // Use payroll only if there's no salary bill overlap
    const totalCompromissos = totalBillsAPagar + totalPayrollPendente;

    // ── Net worth ────────────────────────────────────────────────
    const patrimonioLiquido = totalDisponivel + totalReservas + totalAReceber - totalCompromissos;

    return {
      contas,
      totalBancos,
      caixaBalance,
      caixaLabel,
      totalDisponivel,
      emergValue,
      emergMeta: emergFund.metaReserva,
      marketingReservado,
      totalReservas,
      salesAReceber: { count: salesAReceber.length, total: totalSalesAReceber },
      billsAReceber: { count: billsAReceber.length, total: totalBillsAReceber },
      totalAReceber,
      billsAPagar: { count: billsAPagar.length, total: totalBillsAPagar },
      payrollPendente: { count: payrollPendente.length, total: totalPayrollPendente },
      totalCompromissos,
      patrimonioLiquido,
    };
  }, []);

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif', color: C.text, maxWidth: 860 }}>
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: C.text }}>Onde está meu dinheiro?</h1>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textMuted }}>
          Visão consolidada da posição financeira da empresa
        </p>
      </div>

      {/* Grid: 2 columns on top */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Section 1 — Disponível */}
        <Card>
          <SectionTitle>Dinheiro disponível</SectionTitle>
          {data.contas.map(conta => (
            <LineItem
              key={conta.id}
              label={conta.apelido}
              value={fmtBRL(conta.saldoAtual)}
            />
          ))}
          <LineItem
            label={data.caixaLabel}
            value={fmtBRL(data.caixaBalance)}
            muted={data.caixaBalance === 0}
          />
          <SubtotalLine
            label="Subtotal disponível"
            value={fmtBRL(data.totalDisponivel)}
            color={C.navy}
          />
        </Card>

        {/* Section 2 — Reservas */}
        <Card>
          <SectionTitle>Reservas</SectionTitle>
          <div style={{ marginBottom: 4 }}>
            <LineItem
              label="Caixa de emergência"
              value={fmtBRL(data.emergValue)}
            />
            <div style={{ fontSize: 11, color: C.textMuted, textAlign: 'right', marginTop: -6, marginBottom: 4 }}>
              Meta: {fmtBRL(data.emergMeta)} ({Math.round((data.emergValue / data.emergMeta) * 100)}% atingido)
            </div>
          </div>
          <LineItem
            label="Marketing reservado"
            value={fmtBRL(data.marketingReservado)}
          />
          <div style={{ padding: '8px 0', borderBottom: `1px solid ${C.borderLight}` }}>
            <p style={{ margin: 0, fontSize: 11, color: C.textMuted, fontStyle: 'italic' }}>
              Estas reservas não estão disponíveis para operações diárias.
            </p>
          </div>
          <SubtotalLine
            label="Subtotal reservas"
            value={fmtBRL(data.totalReservas)}
            color={C.textMuted}
          />
        </Card>

        {/* Section 3 — A receber */}
        <Card>
          <SectionTitle>A receber (caixa futuro)</SectionTitle>
          <LineItem
            label={`Vendas pendentes (${data.salesAReceber.count} venda${data.salesAReceber.count !== 1 ? 's' : ''})`}
            value={fmtBRL(data.salesAReceber.total)}
            highlight="positive"
          />
          {data.billsAReceber.count > 0 && (
            <LineItem
              label={`Contas a receber (${data.billsAReceber.count} conta${data.billsAReceber.count !== 1 ? 's' : ''})`}
              value={fmtBRL(data.billsAReceber.total)}
              highlight="positive"
            />
          )}
          {data.billsAReceber.count === 0 && (
            <div style={{ padding: '8px 0', borderBottom: `1px solid ${C.borderLight}`, fontSize: 12, color: C.textMuted }}>
              Sem outras contas a receber cadastradas
            </div>
          )}
          <SubtotalLine
            label="Subtotal a receber"
            value={fmtBRL(data.totalAReceber)}
            color={C.success}
          />
        </Card>

        {/* Section 4 — Compromissos */}
        <Card>
          <SectionTitle>Compromissos</SectionTitle>
          <LineItem
            label={`Contas a pagar (${data.billsAPagar.count} conta${data.billsAPagar.count !== 1 ? 's' : ''})`}
            value={fmtBRL(data.billsAPagar.total)}
            highlight="negative"
          />
          <LineItem
            label={`Folha de pagamento pendente (${data.payrollPendente.count} funcionário${data.payrollPendente.count !== 1 ? 's' : ''})`}
            value={fmtBRL(data.payrollPendente.total)}
            highlight="negative"
          />
          <SubtotalLine
            label="Subtotal compromissos"
            value={fmtBRL(data.totalCompromissos)}
            color={C.error}
          />
        </Card>
      </div>

      {/* Net Worth — full width */}
      <Card style={{ background: C.navy, border: 'none' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'rgba(255,255,255,0.6)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 4 }}>
              Patrimônio Líquido Total
            </div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)' }}>
              Disponível + Reservas + A receber − Compromissos
            </div>
          </div>
          <div style={{
            fontSize: 36,
            fontWeight: 800,
            color: data.patrimonioLiquido >= 0 ? '#4ADE80' : '#F87171',
            fontVariantNumeric: 'tabular-nums',
            letterSpacing: '-0.02em',
          }}>
            {fmtBRL(data.patrimonioLiquido)}
          </div>
        </div>
      </Card>

      {/* Breakdown detail */}
      <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
        {[
          { label: 'Disponível', value: data.totalDisponivel, sign: '+', color: C.text },
          { label: 'Reservas', value: data.totalReservas, sign: '+', color: C.textMuted },
          { label: 'A receber', value: data.totalAReceber, sign: '+', color: C.success },
          { label: 'Compromissos', value: data.totalCompromissos, sign: '−', color: C.error },
        ].map(item => (
          <div key={item.label} style={{
            flex: 1,
            minWidth: 160,
            background: C.white,
            border: `1px solid ${C.border}`,
            borderRadius: 8,
            padding: '12px 16px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}>
            <div>
              <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 2 }}>{item.sign} {item.label}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: item.color, fontVariantNumeric: 'tabular-nums' }}>
                {fmtBRL(item.value)}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Important note */}
      <div style={{
        marginTop: 16,
        background: C.metalLight,
        border: `1px solid ${C.metalBorder}`,
        borderRadius: 8,
        padding: '10px 16px',
        display: 'flex',
        alignItems: 'flex-start',
        gap: 8,
      }}>
        <span style={{ fontSize: 13 }}>ℹ</span>
        <p style={{ margin: 0, fontSize: 12, color: C.textMuted, lineHeight: 1.5 }}>
          <strong style={{ color: C.text }}>Transferências entre contas não alteram o patrimônio total.</strong>{' '}
          Mover dinheiro entre contas bancárias ou para caixa apenas realoca o saldo entre as linhas da seção "Disponível", sem impacto no resultado final.
        </p>
      </div>
    </div>
  );
}
