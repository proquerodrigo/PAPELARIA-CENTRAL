import { useState, useMemo } from 'react';
import { finDb, fmtBRL, filterByPeriod, periodRange } from '../../data/finDb';
import { marketingDb } from '../../data/marketingDb';
import { C, btnPrimary, btnSecondary, formCard } from '../../theme';

type Period = 'mes' | 'mes_ant' | '3m' | '6m' | '12m' | 'tudo';

const PERIODS: { key: Period; label: string }[] = [
  { key: 'mes', label: 'Mês atual' },
  { key: 'mes_ant', label: 'Mês anterior' },
  { key: '3m', label: '3 meses' },
  { key: '6m', label: '6 meses' },
  { key: '12m', label: '12 meses' },
  { key: 'tudo', label: 'Desde jun/2025' },
];

function fmt(v: number) { return fmtBRL(v); }
function pct(num: number, den: number) {
  if (!den) return '—';
  return (num / den * 100).toFixed(1) + '%';
}

export default function DRE() {
  const [period, setPeriod] = useState<Period>('mes');

  const data = useMemo(() => {
    const { from, to } = periodRange(period);

    const allSales = finDb.sales.all();
    const allExpenses = finDb.expenses.all();
    const allPayroll = finDb.payroll.all();
    const allRevenues = finDb.revenues.all();

    const sales = filterByPeriod(allSales, from, to, 'date');
    const expenses = filterByPeriod(allExpenses, from, to, 'date');
    const revenues = filterByPeriod(allRevenues, from, to, 'date');

    // Filter payroll by period: month field is 'YYYY-MM'
    const fromMonth = from.slice(0, 7);
    const toMonth = to.slice(0, 7);
    const payroll = allPayroll.filter(p => p.month >= fromMonth && p.month <= toMonth);

    // Marketing gastos from marketingDb
    const mktGastos = filterByPeriod(marketingDb.get().gastos, from, to, 'date');
    const mktTotal = mktGastos.reduce((s, g) => s + g.valor, 0);

    // 1. Faturamento Bruto
    const faturamento = sales.reduce((s, x) => s + x.grossValue, 0);

    // 2. Descontos (not in model, 0)
    const descontos = 0;

    // 3. Taxas
    const taxas = sales.reduce((s, x) => s + x.feeValue, 0);

    // 4. Receita Líquida
    const receitaLiquida = faturamento - descontos - taxas;

    // 5. CPV = expenses 'Compra de estoque' Pago
    const cpv = expenses
      .filter(e => e.category === 'Compra de estoque' && e.status === 'Pago')
      .reduce((s, e) => s + e.value, 0);

    // 6. Lucro Bruto
    const lucroBruto = receitaLiquida - cpv;

    // 7. Despesas operacionais = non-estoque, non-salários, non-outras
    const despesasOp = expenses
      .filter(e =>
        e.status === 'Pago' &&
        !['Compra de estoque', 'Salários', 'VR', 'VT', 'Outras despesas'].includes(e.category)
      )
      .reduce((s, e) => s + e.value, 0);

    // 8. Marketing
    const marketing = mktTotal +
      expenses.filter(e => e.status === 'Pago' && (e.category as string) === 'Marketing')
        .reduce((s, e) => s + e.value, 0);

    // 9. Salários e benefícios = payroll Pago (salary+vr+vt) + expenses Salários/VR/VT Pago
    const payrollPago = payroll
      .filter(p => p.status === 'Pago')
      .reduce((s, p) => s + p.salary + p.vr + p.vt, 0);
    const expSalarios = expenses
      .filter(e => e.status === 'Pago' && ['Salários', 'VR', 'VT'].includes(e.category))
      .reduce((s, e) => s + e.value, 0);
    // Use only payroll if both would double-count; if no payroll, use expenses
    const salarios = payrollPago > 0 ? payrollPago : expSalarios;

    // 10. Outras despesas
    const outras = expenses
      .filter(e => e.status === 'Pago' && e.category === 'Outras despesas')
      .reduce((s, e) => s + e.value, 0);

    // 11. Lucro Líquido
    const lucroLiquido = lucroBruto - despesasOp - marketing - salarios - outras;

    // Entradas / Saídas for extra context
    const entradas = revenues.filter(r => r.status === 'Pago').reduce((s, r) => s + r.value, 0);
    const saidas = expenses.filter(e => e.status === 'Pago').reduce((s, e) => s + e.value, 0);

    return {
      faturamento, descontos, taxas, receitaLiquida,
      cpv, lucroBruto, despesasOp, marketing, salarios, outras,
      lucroLiquido, entradas, saidas,
    };
  }, [period]);

  const semDados = data.faturamento === 0;

  return (
    <div style={{ padding: 24, maxWidth: 720, margin: '0 auto', fontFamily: 'Inter, sans-serif' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <h1 style={{ fontSize: 18, fontWeight: 700, color: C.text, margin: 0 }}>DRE Simplificada</h1>
          <p style={{ fontSize: 13, color: C.textMuted, margin: '4px 0 0' }}>
            Demonstração do Resultado do Exercício
          </p>
        </div>
      </div>

      {/* Period selector */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, flexWrap: 'wrap' }}>
        {PERIODS.map(p => (
          <button
            key={p.key}
            style={period === p.key ? { ...btnPrimary, fontSize: 12 } : { ...btnSecondary, fontSize: 12 }}
            onClick={() => setPeriod(p.key)}
          >
            {p.label}
          </button>
        ))}
      </div>

      {semDados ? (
        <div style={{ ...formCard, textAlign: 'center', padding: 48 }}>
          <p style={{ color: C.textMuted, fontSize: 14 }}>Sem dados no período selecionado.</p>
        </div>
      ) : (
        <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 8, overflow: 'hidden' }}>
          <DRERow label="Faturamento Bruto" value={data.faturamento} bold />
          <DRERow label="(−) Descontos" value={-data.descontos} muted indent />
          <DRERow label="(−) Taxas operadoras" value={-data.taxas} muted indent />
          <DRESubtotal label="= Receita Líquida" value={data.receitaLiquida} />

          <DRESpacer />
          <DRERow label="(−) Custo dos produtos vendidos (CPV)" value={-data.cpv} red indent />
          <DRESubtotal label="= Lucro Bruto" value={data.lucroBruto} />

          <DRESpacer />
          <DRERow label="(−) Despesas operacionais" value={-data.despesasOp} red indent />
          <DRERow label="(−) Marketing" value={-data.marketing} red indent />
          <DRERow label="(−) Salários e benefícios" value={-data.salarios} red indent />
          <DRERow label="(−) Outras despesas" value={-data.outras} red indent />

          <DRESpacer />
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '14px 20px',
            background: data.lucroLiquido >= 0 ? '#ECFDF3' : '#FEF3F2',
            borderTop: `2px solid ${data.lucroLiquido >= 0 ? C.successBorder : C.errorBorder}`,
          }}>
            <span style={{ fontSize: 15, fontWeight: 700, color: data.lucroLiquido >= 0 ? C.success : C.error }}>
              = Lucro Líquido
            </span>
            <span style={{ fontSize: 15, fontWeight: 700, color: data.lucroLiquido >= 0 ? C.success : C.error }}>
              {fmt(data.lucroLiquido)}
            </span>
          </div>

          {/* Margem */}
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            padding: '10px 20px',
            background: C.metalLight,
            borderTop: `1px solid ${C.border}`,
          }}>
            <span style={{ fontSize: 13, color: C.textMuted }}>Margem líquida</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: C.text }}>
              {pct(data.lucroLiquido, data.faturamento)}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

function DRERow({
  label, value, bold, red, muted, indent,
}: {
  label: string;
  value: number;
  bold?: boolean;
  red?: boolean;
  muted?: boolean;
  indent?: boolean;
}) {
  const positive = value >= 0;
  const color = muted
    ? C.textMuted
    : red
    ? (positive ? C.success : C.error)
    : C.text;

  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '9px 20px',
      borderBottom: `1px solid ${C.borderLight}`,
    }}>
      <span style={{
        fontSize: 13,
        color,
        fontWeight: bold ? 600 : 400,
        paddingLeft: indent ? 16 : 0,
      }}>
        {label}
      </span>
      <span style={{ fontSize: 13, color, fontWeight: bold ? 600 : 400 }}>
        {fmt(Math.abs(value))}
      </span>
    </div>
  );
}

function DRESubtotal({ label, value }: { label: string; value: number }) {
  const pos = value >= 0;
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '10px 20px',
      background: C.metalLight,
      borderBottom: `1px solid ${C.metalBorder}`,
    }}>
      <span style={{ fontSize: 13, fontWeight: 700, color: C.text }}>{label}</span>
      <span style={{ fontSize: 13, fontWeight: 700, color: pos ? C.success : C.error }}>
        {fmt(value)}
      </span>
    </div>
  );
}

function DRESpacer() {
  return <div style={{ height: 4, background: C.metalLight, borderBottom: `1px solid ${C.borderLight}` }} />;
}
