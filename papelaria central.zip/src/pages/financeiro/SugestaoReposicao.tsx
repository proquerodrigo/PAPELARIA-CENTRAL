import React, { useMemo, useState } from 'react';
import { db } from '../../data/db';
import { fornecedoresDb } from '../../data/fornecedoresDb';
import { C, tbl, TH, TD, tableWrap, btnSecondary, ROW_BORDER } from '../../theme';

type ShowMode = 'abaixo' | 'todos';

function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function coverageBadge(dias: number | null): React.CSSProperties {
  if (dias === null) return { background: C.metalLight, color: C.textMuted, border: `1px solid ${C.border}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 };
  if (dias < 0 || dias === 0) return { background: C.errorBg, color: C.error, border: `1px solid ${C.errorBorder}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
  if (dias < 14) return { background: C.warningBg, color: C.warning, border: `1px solid ${C.warningBorder}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
  return { background: C.successBg, color: C.success, border: `1px solid ${C.successBorder}`, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 };
}

function stockBadge(isBelow: boolean): React.CSSProperties {
  if (isBelow) return { background: C.errorBg, color: C.error, border: `1px solid ${C.errorBorder}`, borderRadius: 4, padding: '2px 6px', fontSize: 10, fontWeight: 600 };
  return { background: C.warningBg, color: C.warning, border: `1px solid ${C.warningBorder}`, borderRadius: 4, padding: '2px 6px', fontSize: 10, fontWeight: 500 };
}

export default function SugestaoReposicao() {
  const [filterCat, setFilterCat] = useState('');
  const [filterSupplier, setFilterSupplier] = useState('');
  const [showMode, setShowMode] = useState<ShowMode>('todos');

  const categories = useMemo(() => db.categories.all().filter(c => c.status === 'Ativa'), []);
  const suppliers = useMemo(() => fornecedoresDb.all().filter(f => f.status === 'Ativo'), []);

  const supplierMap = useMemo(() => {
    const m = new Map<string, string>();
    fornecedoresDb.all().forEach(f => m.set(f.id, f.nomeFantasia || f.razaoSocial));
    return m;
  }, []);

  const rows = useMemo(() => {
    const today = new Date();
    const ninetyDaysAgo = new Date(today);
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    const ninetyDaysAgoIso = ninetyDaysAgo.toISOString().slice(0, 10);

    const products = db.products.all();
    const movements = db.movements.all().filter(m => m.type === 'Saída');

    // Aggregate saídas per product in last 90 days
    const saidaMap = new Map<string, number>();
    movements.forEach(m => {
      const movDate = m.createdAt.slice(0, 10);
      if (movDate >= ninetyDaysAgoIso) {
        saidaMap.set(m.productId, (saidaMap.get(m.productId) ?? 0) + m.qty);
      }
    });

    const result: {
      id: string;
      name: string;
      brand: string;
      category: string;
      qty: number;
      minStock: number;
      avgDailyOut: number;
      coverageDias: number | null;
      suggestedQty: number;
      fornecedor: string;
      fornecedorId: string;
      isBelow: boolean;
    }[] = [];

    products.forEach(prod => {
      const totalSaida90 = saidaMap.get(prod.id) ?? 0;
      const avgDailyOut = totalSaida90 / 90;

      const coverageDias: number | null = avgDailyOut > 0
        ? Math.floor(prod.qty / avgDailyOut)
        : null;

      const isBelow = prod.qty <= prod.minStock;
      const needsReplenishment = isBelow || (avgDailyOut > 0 && prod.qty < avgDailyOut * 14);

      if (!needsReplenishment) return;

      // Suggested qty: max of (2x minStock approach) or (30-day coverage)
      const sugByMin = Math.max(0, prod.minStock * 2 - prod.qty);
      const sugBy30d = avgDailyOut > 0
        ? Math.max(0, Math.ceil(avgDailyOut * 30) - prod.qty)
        : 0;
      const suggestedQty = Math.max(sugByMin, sugBy30d);

      const fornecedorId = prod.supplierId ?? '';
      const fornecedor = fornecedorId
        ? supplierMap.get(fornecedorId) ?? (prod.brand || '—')
        : (prod.brand || '—');

      result.push({
        id: prod.id,
        name: prod.name,
        brand: prod.brand ?? '—',
        category: prod.category,
        qty: prod.qty,
        minStock: prod.minStock,
        avgDailyOut,
        coverageDias,
        suggestedQty,
        fornecedor,
        fornecedorId,
        isBelow,
      });
    });

    let filtered = result;

    if (filterCat) filtered = filtered.filter(r => r.category === filterCat);
    if (filterSupplier) filtered = filtered.filter(r => r.fornecedorId === filterSupplier);
    if (showMode === 'abaixo') filtered = filtered.filter(r => r.isBelow);

    // Sort: below minimum first, then by coverage asc
    filtered.sort((a, b) => {
      if (a.isBelow && !b.isBelow) return -1;
      if (!a.isBelow && b.isBelow) return 1;
      const ca = a.coverageDias ?? 9999;
      const cb = b.coverageDias ?? 9999;
      return ca - cb;
    });

    return filtered;
  }, [filterCat, filterSupplier, showMode, supplierMap]);

  function fmtAvg(v: number): string {
    if (v === 0) return '—';
    return v.toFixed(2).replace('.', ',');
  }

  function fmtCoverage(dias: number | null): string {
    if (dias === null) return '—';
    return `${dias}d`;
  }

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif', color: C.text }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: C.text }}>Sugestão de Reposição</h1>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textMuted }}>
          Produtos que precisam de reposição baseado em estoque mínimo e média diária de saídas (últimos 90 dias)
        </p>
      </div>

      {/* Filters */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 8, padding: '16px 20px', marginBottom: 16 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center' }}>
          {/* Show mode */}
          <div style={{ display: 'flex', gap: 4 }}>
            <button
              onClick={() => setShowMode('todos')}
              style={{
                ...btnSecondary,
                padding: '5px 12px',
                fontSize: 12,
                background: showMode === 'todos' ? C.navy : C.white,
                color: showMode === 'todos' ? C.white : C.text,
                border: showMode === 'todos' ? 'none' : `1px solid ${C.border}`,
              }}
            >
              Todos com sugestão
            </button>
            <button
              onClick={() => setShowMode('abaixo')}
              style={{
                ...btnSecondary,
                padding: '5px 12px',
                fontSize: 12,
                background: showMode === 'abaixo' ? C.error : C.white,
                color: showMode === 'abaixo' ? C.white : C.text,
                border: showMode === 'abaixo' ? 'none' : `1px solid ${C.border}`,
              }}
            >
              Abaixo do mínimo
            </button>
          </div>

          <select
            value={filterCat}
            onChange={e => setFilterCat(e.target.value)}
            style={{ padding: '5px 10px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 6, background: C.white, color: C.text, cursor: 'pointer' }}
          >
            <option value="">Todas as categorias</option>
            {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
          </select>

          <select
            value={filterSupplier}
            onChange={e => setFilterSupplier(e.target.value)}
            style={{ padding: '5px 10px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 6, background: C.white, color: C.text, cursor: 'pointer' }}
          >
            <option value="">Todos os fornecedores</option>
            {suppliers.map(f => <option key={f.id} value={f.id}>{f.nomeFantasia || f.razaoSocial}</option>)}
          </select>

          {(filterCat || filterSupplier) && (
            <button
              onClick={() => { setFilterCat(''); setFilterSupplier(''); }}
              style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12, color: C.textMuted }}
            >
              Limpar filtros
            </button>
          )}

          <div style={{ marginLeft: 'auto', fontSize: 13, color: C.textMuted }}>
            <strong style={{ color: C.text }}>{rows.length}</strong> produtos para repor
          </div>
        </div>
      </div>

      {/* Coverage legend */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        {[
          { badge: coverageBadge(0), label: 'Abaixo do mínimo / sem estoque' },
          { badge: coverageBadge(7), label: '< 14 dias de cobertura' },
          { badge: coverageBadge(30), label: 'Cobertura adequada' },
          { badge: coverageBadge(null), label: 'Sem histórico de saídas' },
        ].map((item, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.textMuted }}>
            <span style={{ ...item.badge, pointerEvents: 'none' }}>ex.</span>
            <span>{item.label}</span>
          </div>
        ))}
      </div>

      {/* Table */}
      <div style={tableWrap}>
        {rows.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center', color: C.textMuted, fontSize: 14 }}>
            Nenhum produto necessita reposição com os filtros aplicados
          </div>
        ) : (
          <table style={tbl}>
            <thead>
              <tr>
                <th style={TH}>Produto</th>
                <th style={TH}>Marca</th>
                <th style={{ ...TH, textAlign: 'right' }}>Qtd. atual</th>
                <th style={{ ...TH, textAlign: 'right' }}>Est. mín.</th>
                <th style={{ ...TH, textAlign: 'right' }}>Média diária</th>
                <th style={{ ...TH, textAlign: 'center' }}>Cobertura</th>
                <th style={{ ...TH, textAlign: 'right' }}>Qtd. sugerida</th>
                <th style={TH}>Fornecedor</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, idx) => (
                <tr key={row.id} style={{ borderTop: idx > 0 ? ROW_BORDER : 'none' }}>
                  <td style={TD}>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>{row.name}</div>
                    <div style={{ display: 'flex', gap: 4, marginTop: 2 }}>
                      <span style={{ fontSize: 11, color: C.textMuted }}>{row.category}</span>
                      {row.isBelow && (
                        <span style={stockBadge(true)}>Abaixo mín.</span>
                      )}
                    </div>
                  </td>
                  <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{row.brand}</td>
                  <td style={{ ...TD, textAlign: 'right', fontWeight: 600, color: row.qty === 0 ? C.error : row.isBelow ? C.warning : C.text }}>
                    {row.qty}
                  </td>
                  <td style={{ ...TD, textAlign: 'right', color: C.textMuted }}>{row.minStock}</td>
                  <td style={{ ...TD, textAlign: 'right', color: C.textMuted, fontSize: 12 }}>
                    {fmtAvg(row.avgDailyOut)}
                  </td>
                  <td style={{ ...TD, textAlign: 'center' }}>
                    <span style={coverageBadge(row.coverageDias)}>
                      {fmtCoverage(row.coverageDias)}
                    </span>
                  </td>
                  <td style={{ ...TD, textAlign: 'right', fontWeight: 700, color: C.navy }}>
                    {row.suggestedQty > 0 ? `+${row.suggestedQty}` : '—'}
                  </td>
                  <td style={{ ...TD, fontSize: 12, color: C.textMuted }}>{row.fornecedor}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <p style={{ marginTop: 12, fontSize: 11, color: C.textMuted }}>
        * Sugestão baseada no maior valor entre: (2× estoque mínimo − estoque atual) e (média diária × 30 dias − estoque atual). Dados de saída dos últimos 90 dias.
      </p>
    </div>
  );
}
