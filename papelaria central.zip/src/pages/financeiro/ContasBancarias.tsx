import { useState } from 'react';
import { C, inp, btnPrimary, btnSecondary, tbl, TH, TD, tableWrap, ROW_BORDER, badge, formCard } from '../../theme';
import { Toast, Modal } from '../Produtos';
import { bancosDb, ContaBancaria, BancoMovimento, TipoConta } from '../../data/bancosDb';
import { newId } from '../../data/db';
import { useApp } from '../../context/AppContext';

const TIPOS_CONTA: TipoConta[] = ['Conta corrente', 'Conta poupança', 'Conta digital', 'Conta pagamento'];

const brl = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

const label: React.CSSProperties = { display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 };
const fldWrap: React.CSSProperties = { marginBottom: 14 };
const row2: React.CSSProperties = { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 };

type MovTipo = 'entrada' | 'saida' | 'transferencia';

interface ContaForm {
  apelido: string;
  banco: string;
  agencia: string;
  conta: string;
  tipo: TipoConta;
  saldoInicial: string;
}

interface MovForm {
  type: MovTipo;
  value: string;
  description: string;
  date: string;
  contaDestinoId: string;
}

const emptyContaForm = (): ContaForm => ({
  apelido: '',
  banco: '',
  agencia: '',
  conta: '',
  tipo: 'Conta corrente',
  saldoInicial: '',
});

const emptyMovForm = (): MovForm => ({
  type: 'entrada',
  value: '',
  description: '',
  date: new Date().toISOString().slice(0, 10),
  contaDestinoId: '',
});

export default function ContasBancarias() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';

  const [contas, setContas] = useState<ContaBancaria[]>(() => bancosDb.contas.all());
  const [movimentos, setMovimentos] = useState<BancoMovimento[]>(() => bancosDb.movimentos.all());
  const [toast, setToast] = useState('');

  // Selected account for movements panel
  const [selectedContaId, setSelectedContaId] = useState<string | null>(null);

  // Modal states
  const [showNovaConta, setShowNovaConta] = useState(false);
  const [editingConta, setEditingConta] = useState<ContaBancaria | null>(null);
  const [showNovoMov, setShowNovoMov] = useState(false);

  // Forms
  const [contaForm, setContaForm] = useState<ContaForm>(emptyContaForm());
  const [movForm, setMovForm] = useState<MovForm>(emptyMovForm());
  const [contaErrors, setContaErrors] = useState<Partial<ContaForm>>({});
  const [movErrors, setMovErrors] = useState<Partial<MovForm>>({});

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3000);
  };

  const refreshContas = () => setContas(bancosDb.contas.all());
  const refreshMovs = () => setMovimentos(bancosDb.movimentos.all());

  const saldoTotal = contas.filter(c => c.ativa).reduce((s, c) => s + c.saldoAtual, 0);
  const contasAtivas = contas.filter(c => c.ativa).length;

  // --- Conta form ---
  const openNovaConta = () => {
    setContaForm(emptyContaForm());
    setContaErrors({});
    setShowNovaConta(true);
  };

  const openEditConta = (c: ContaBancaria) => {
    setContaForm({
      apelido: c.apelido,
      banco: c.banco,
      agencia: c.agencia,
      conta: c.conta,
      tipo: c.tipo,
      saldoInicial: String(c.saldoInicial),
    });
    setContaErrors({});
    setEditingConta(c);
  };

  const validateConta = (f: ContaForm): Partial<ContaForm> => {
    const e: Partial<ContaForm> = {};
    if (!f.apelido.trim()) e.apelido = 'Obrigatório';
    if (!f.banco.trim()) e.banco = 'Obrigatório';
    if (!f.agencia.trim()) e.agencia = 'Obrigatório';
    if (!f.conta.trim()) e.conta = 'Obrigatório';
    const v = parseFloat(f.saldoInicial.replace(',', '.'));
    if (isNaN(v)) e.saldoInicial = 'Valor inválido';
    return e;
  };

  const submitNovaConta = () => {
    const errs = validateConta(contaForm);
    if (Object.keys(errs).length) { setContaErrors(errs); return; }
    const saldo = parseFloat(contaForm.saldoInicial.replace(',', '.'));
    bancosDb.contas.add({
      id: newId(),
      apelido: contaForm.apelido.trim(),
      banco: contaForm.banco.trim(),
      agencia: contaForm.agencia.trim(),
      conta: contaForm.conta.trim(),
      tipo: contaForm.tipo,
      saldoInicial: saldo,
      saldoAtual: saldo,
      ativa: true,
      createdAt: new Date().toISOString(),
    });
    refreshContas();
    setShowNovaConta(false);
    showToast('Conta bancária criada com sucesso.');
  };

  const submitEditConta = () => {
    if (!editingConta) return;
    const errs = validateConta(contaForm);
    if (Object.keys(errs).length) { setContaErrors(errs); return; }
    const saldo = parseFloat(contaForm.saldoInicial.replace(',', '.'));
    bancosDb.contas.update(editingConta.id, {
      apelido: contaForm.apelido.trim(),
      banco: contaForm.banco.trim(),
      agencia: contaForm.agencia.trim(),
      conta: contaForm.conta.trim(),
      tipo: contaForm.tipo,
      saldoInicial: saldo,
    });
    refreshContas();
    setEditingConta(null);
    showToast('Conta atualizada com sucesso.');
  };

  const desativarConta = (id: string) => {
    bancosDb.contas.update(id, { ativa: false });
    refreshContas();
    if (selectedContaId === id) setSelectedContaId(null);
    showToast('Conta desativada.');
  };

  // --- Movimento form ---
  const openNovoMov = () => {
    setMovForm(emptyMovForm());
    setMovErrors({});
    setShowNovoMov(true);
  };

  const validateMov = (f: MovForm): Partial<MovForm> => {
    const e: Partial<MovForm> = {};
    const v = parseFloat(f.value.replace(',', '.'));
    if (isNaN(v) || v <= 0) e.value = 'Valor inválido';
    if (!f.description.trim()) e.description = 'Obrigatório';
    if (!f.date) e.date = 'Obrigatório';
    if (f.type === 'transferencia' && !f.contaDestinoId) e.contaDestinoId = 'Selecione a conta destino';
    return e;
  };

  const submitNovoMov = () => {
    if (!selectedContaId) return;
    const errs = validateMov(movForm);
    if (Object.keys(errs).length) { setMovErrors(errs); return; }

    const value = parseFloat(movForm.value.replace(',', '.'));
    const mov: BancoMovimento = {
      id: newId(),
      contaId: selectedContaId,
      type: movForm.type,
      value,
      description: movForm.description.trim(),
      date: movForm.date,
      contaDestinoId: movForm.type === 'transferencia' ? movForm.contaDestinoId : undefined,
      createdAt: new Date().toISOString(),
    };
    bancosDb.movimentos.add(mov);

    // Update saldos
    if (movForm.type === 'entrada') {
      bancosDb.contas.update(selectedContaId, {
        saldoAtual: (bancosDb.contas.findById(selectedContaId)?.saldoAtual ?? 0) + value,
      });
    } else if (movForm.type === 'saida') {
      bancosDb.contas.update(selectedContaId, {
        saldoAtual: (bancosDb.contas.findById(selectedContaId)?.saldoAtual ?? 0) - value,
      });
    } else if (movForm.type === 'transferencia' && movForm.contaDestinoId) {
      bancosDb.contas.update(selectedContaId, {
        saldoAtual: (bancosDb.contas.findById(selectedContaId)?.saldoAtual ?? 0) - value,
      });
      bancosDb.contas.update(movForm.contaDestinoId, {
        saldoAtual: (bancosDb.contas.findById(movForm.contaDestinoId)?.saldoAtual ?? 0) + value,
      });
    }

    refreshContas();
    refreshMovs();
    setShowNovoMov(false);
    showToast('Lançamento registrado com sucesso.');
  };

  const selectedConta = contas.find(c => c.id === selectedContaId) ?? null;
  const contaMovimentos = selectedContaId
    ? movimentos.filter(m => m.contaId === selectedContaId || m.contaDestinoId === selectedContaId)
        .sort((a, b) => b.date.localeCompare(a.date))
    : [];

  const otherContas = contas.filter(c => c.id !== selectedContaId && c.ativa);

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: C.text }}>
      {toast && <Toast msg={toast} />}

      {/* Summary bar */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 20 }}>
        <div style={{ ...formCard, flex: 1, padding: '14px 20px' }}>
          <div style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>
            Saldo total em contas
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, color: C.navy }}>{brl(saldoTotal)}</div>
        </div>
        <div style={{ ...formCard, padding: '14px 20px', minWidth: 140 }}>
          <div style={{ fontSize: 11, fontWeight: 500, color: C.textMuted, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 4 }}>
            Contas ativas
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, color: C.navy }}>{contasAtivas}</div>
        </div>
        {isAdmin && (
          <div style={{ display: 'flex', alignItems: 'flex-end', paddingBottom: 0 }}>
            <button onClick={openNovaConta} style={btnPrimary}>+ Nova conta</button>
          </div>
        )}
      </div>

      {/* Accounts grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14, marginBottom: 24 }}>
        {contas.map(c => {
          const isSelected = c.id === selectedContaId;
          return (
            <div
              key={c.id}
              style={{
                background: C.white,
                border: `1px solid ${isSelected ? C.navy : C.border}`,
                borderRadius: 8,
                padding: '16px 18px',
                boxShadow: isSelected ? `0 0 0 2px ${C.navy}22` : 'none',
                opacity: c.ativa ? 1 : 0.6,
                display: 'flex',
                flexDirection: 'column',
                gap: 8,
              }}
            >
              {/* Header */}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 14, color: C.text }}>{c.apelido}</div>
                  <div style={{ fontSize: 12, color: C.textMuted, marginTop: 1 }}>{c.banco}</div>
                </div>
                <span style={{
                  ...badgeStyle(c.ativa ? 'active' : 'inactive'),
                  fontSize: 11,
                }}>
                  {c.ativa ? 'Ativa' : 'Inativa'}
                </span>
              </div>

              {/* Tipo badge */}
              <div>
                <span style={{ fontSize: 11, padding: '2px 8px', borderRadius: 10, background: C.metalLight, color: C.textMuted, border: `1px solid ${C.metalBorder}` }}>
                  {c.tipo}
                </span>
              </div>

              {/* Saldo */}
              <div style={{ marginTop: 4 }}>
                <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 2 }}>Saldo atual</div>
                <div style={{ fontSize: 20, fontWeight: 700, color: C.navy }}>{brl(c.saldoAtual)}</div>
              </div>

              {/* Ag / Conta */}
              <div style={{ display: 'flex', gap: 16, fontSize: 12, color: C.textMuted }}>
                <span>Ag: {c.agencia}</span>
                <span>Conta: {c.conta}</span>
              </div>

              {/* Actions */}
              <div style={{ display: 'flex', gap: 6, marginTop: 4, flexWrap: 'wrap' }}>
                <button
                  onClick={() => setSelectedContaId(isSelected ? null : c.id)}
                  style={{ ...btnPrimary, fontSize: 12, padding: '4px 10px', background: isSelected ? C.navyHover : C.navy }}
                >
                  {isSelected ? 'Ocultar' : 'Ver movimentos'}
                </button>
                <button
                  onClick={() => openEditConta(c)}
                  style={{ ...btnSecondary, fontSize: 12, padding: '4px 10px' }}
                >
                  Editar
                </button>
                {isAdmin && c.ativa && (
                  <button
                    onClick={() => desativarConta(c.id)}
                    style={{ fontSize: 12, padding: '4px 10px', background: '#FEF3F2', color: C.error, border: `1px solid #FECDCA`, borderRadius: 6, cursor: 'pointer', fontFamily: 'Inter, sans-serif', whiteSpace: 'nowrap' as const }}
                  >
                    Desativar
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Movimentos panel */}
      {selectedConta && (
        <div style={{ ...formCard, padding: 0, overflow: 'hidden' }}>
          {/* Panel header */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '14px 18px', borderBottom: `1px solid ${C.border}`, background: C.metalLight }}>
            <div>
              <div style={{ fontWeight: 600, fontSize: 14, color: C.text }}>Movimentos — {selectedConta.apelido}</div>
              <div style={{ fontSize: 12, color: C.textMuted, marginTop: 2 }}>
                Saldo atual: <strong style={{ color: C.navy }}>{brl(selectedConta.saldoAtual)}</strong>
              </div>
            </div>
            <button onClick={openNovoMov} style={{ ...btnPrimary, fontSize: 12 }}>+ Novo lançamento</button>
          </div>

          {/* Movements table */}
          {contaMovimentos.length === 0 ? (
            <div style={{ padding: '32px 18px', textAlign: 'center', color: C.textMuted, fontSize: 13 }}>
              Nenhum movimento registrado para esta conta.
            </div>
          ) : (
            <div style={{ overflowX: 'auto' }}>
              <table style={tbl}>
                <thead>
                  <tr>
                    {['Data', 'Tipo', 'Descrição', 'Valor', 'Conta destino'].map(h => (
                      <th key={h} style={TH}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {contaMovimentos.map((m, i) => {
                    const isDestino = m.contaDestinoId === selectedContaId && m.contaId !== selectedContaId;
                    const displayType = isDestino ? 'entrada' : m.type;
                    const destConta = m.contaDestinoId ? contas.find(c => c.id === m.contaDestinoId) : null;
                    const originConta = isDestino ? contas.find(c => c.id === m.contaId) : null;

                    return (
                      <tr key={m.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                        <td style={{ ...TD, whiteSpace: 'nowrap' as const, color: C.textMuted, fontSize: 12 }}>
                          {formatDate(m.date)}
                        </td>
                        <td style={TD}>
                          <span style={{ ...movBadge(displayType), fontSize: 11, padding: '2px 8px', borderRadius: 10 }}>
                            {movLabel(displayType)}
                          </span>
                        </td>
                        <td style={TD}>{m.description}</td>
                        <td style={{ ...TD, fontWeight: 600, color: displayType === 'entrada' ? C.success : displayType === 'saida' ? C.error : C.navy, whiteSpace: 'nowrap' as const }}>
                          {displayType === 'entrada' ? '+' : displayType === 'saida' ? '-' : ''}{brl(m.value)}
                        </td>
                        <td style={{ ...TD, fontSize: 12, color: C.textMuted }}>
                          {isDestino && originConta ? originConta.apelido : destConta ? destConta.apelido : '—'}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Modal: Nova conta */}
      {showNovaConta && (
        <Modal title="Nova conta bancária" onClose={() => setShowNovaConta(false)}>
          <ContaFormFields
            form={contaForm}
            errors={contaErrors}
            onChange={f => setContaForm(f)}
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
            <button onClick={() => setShowNovaConta(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={submitNovaConta} style={btnPrimary}>Criar conta</button>
          </div>
        </Modal>
      )}

      {/* Modal: Editar conta */}
      {editingConta && (
        <Modal title="Editar conta bancária" onClose={() => setEditingConta(null)}>
          <ContaFormFields
            form={contaForm}
            errors={contaErrors}
            onChange={f => setContaForm(f)}
          />
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
            <button onClick={() => setEditingConta(null)} style={btnSecondary}>Cancelar</button>
            <button onClick={submitEditConta} style={btnPrimary}>Salvar alterações</button>
          </div>
        </Modal>
      )}

      {/* Modal: Novo movimento */}
      {showNovoMov && selectedConta && (
        <Modal title={`Novo lançamento — ${selectedConta.apelido}`} onClose={() => setShowNovoMov(false)}>
          <div style={fldWrap}>
            <label style={label}>Tipo de lançamento</label>
            <select
              value={movForm.type}
              onChange={e => setMovForm({ ...movForm, type: e.target.value as MovTipo })}
              style={inp()}
            >
              <option value="entrada">Entrada</option>
              <option value="saida">Saída</option>
              <option value="transferencia">Transferência</option>
            </select>
          </div>

          <div style={row2}>
            <div style={fldWrap}>
              <label style={label}>Valor (R$)</label>
              <input
                value={movForm.value}
                onChange={e => setMovForm({ ...movForm, value: e.target.value })}
                placeholder="0,00"
                style={inp(!!movErrors.value)}
              />
              {movErrors.value && <span style={errStyle}>{movErrors.value}</span>}
            </div>
            <div style={fldWrap}>
              <label style={label}>Data</label>
              <input
                type="date"
                value={movForm.date}
                onChange={e => setMovForm({ ...movForm, date: e.target.value })}
                style={inp(!!movErrors.date)}
              />
              {movErrors.date && <span style={errStyle}>{movErrors.date}</span>}
            </div>
          </div>

          <div style={fldWrap}>
            <label style={label}>Descrição</label>
            <input
              value={movForm.description}
              onChange={e => setMovForm({ ...movForm, description: e.target.value })}
              placeholder="Descreva o lançamento..."
              style={inp(!!movErrors.description)}
            />
            {movErrors.description && <span style={errStyle}>{movErrors.description}</span>}
          </div>

          {movForm.type === 'transferencia' && (
            <div style={fldWrap}>
              <label style={label}>Conta destino</label>
              <select
                value={movForm.contaDestinoId}
                onChange={e => setMovForm({ ...movForm, contaDestinoId: e.target.value })}
                style={inp(!!movErrors.contaDestinoId)}
              >
                <option value="">Selecione...</option>
                {otherContas.map(c => (
                  <option key={c.id} value={c.id}>{c.apelido} — {c.banco}</option>
                ))}
              </select>
              {movErrors.contaDestinoId && <span style={errStyle}>{movErrors.contaDestinoId}</span>}
            </div>
          )}

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 6 }}>
            <button onClick={() => setShowNovoMov(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={submitNovoMov} style={btnPrimary}>Registrar lançamento</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// --- Sub-components ---

function ContaFormFields({
  form,
  errors,
  onChange,
}: {
  form: ContaForm;
  errors: Partial<ContaForm>;
  onChange: (f: ContaForm) => void;
}) {
  const set = (k: keyof ContaForm, v: string) => onChange({ ...form, [k]: v });
  return (
    <>
      <div style={fldWrap}>
        <label style={label}>Apelido</label>
        <input
          value={form.apelido}
          onChange={e => set('apelido', e.target.value)}
          placeholder="Ex: Conta principal — Bradesco"
          style={inp(!!errors.apelido)}
        />
        {errors.apelido && <span style={errStyle}>{errors.apelido}</span>}
      </div>

      <div style={fldWrap}>
        <label style={label}>Banco</label>
        <input
          value={form.banco}
          onChange={e => set('banco', e.target.value)}
          placeholder="Ex: Bradesco"
          style={inp(!!errors.banco)}
        />
        {errors.banco && <span style={errStyle}>{errors.banco}</span>}
      </div>

      <div style={row2}>
        <div style={fldWrap}>
          <label style={label}>Agência</label>
          <input
            value={form.agencia}
            onChange={e => set('agencia', e.target.value)}
            placeholder="0000"
            style={inp(!!errors.agencia)}
          />
          {errors.agencia && <span style={errStyle}>{errors.agencia}</span>}
        </div>
        <div style={fldWrap}>
          <label style={label}>Conta</label>
          <input
            value={form.conta}
            onChange={e => set('conta', e.target.value)}
            placeholder="00000-0"
            style={inp(!!errors.conta)}
          />
          {errors.conta && <span style={errStyle}>{errors.conta}</span>}
        </div>
      </div>

      <div style={row2}>
        <div style={fldWrap}>
          <label style={label}>Tipo de conta</label>
          <select
            value={form.tipo}
            onChange={e => set('tipo', e.target.value as TipoConta)}
            style={inp()}
          >
            {TIPOS_CONTA.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
        <div style={fldWrap}>
          <label style={label}>Saldo inicial (R$)</label>
          <input
            value={form.saldoInicial}
            onChange={e => set('saldoInicial', e.target.value)}
            placeholder="0,00"
            style={inp(!!errors.saldoInicial)}
          />
          {errors.saldoInicial && <span style={errStyle}>{errors.saldoInicial}</span>}
        </div>
      </div>
    </>
  );
}

// --- Helpers ---

function badgeStyle(type: 'active' | 'inactive'): React.CSSProperties {
  const b = type === 'active' ? badge.active : badge.inactive;
  return {
    display: 'inline-block',
    padding: '2px 8px',
    borderRadius: 10,
    fontWeight: 500,
    ...b,
  };
}

function movBadge(type: string): React.CSSProperties {
  if (type === 'entrada') return badge.entrada;
  if (type === 'saida') return badge.saida;
  return { background: '#EFF4FF', color: '#3538CD', border: '1px solid #C7D7FD' };
}

function movLabel(type: string): string {
  if (type === 'entrada') return 'Entrada';
  if (type === 'saida') return 'Saída';
  return 'Transferência';
}

function formatDate(dateStr: string): string {
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

const errStyle: React.CSSProperties = { fontSize: 11, color: C.error, marginTop: 3, display: 'block' };
