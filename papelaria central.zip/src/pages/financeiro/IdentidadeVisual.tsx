import { useRef, useState } from 'react';
import { C, btnPrimary, btnSecondary, btnDanger } from '../../theme';

const LOGO_KEY = 'pc_v1_logo_b64';
const MAX_PX = 800;

function compressLogo(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = ev => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, MAX_PX / Math.max(img.width, img.height));
        const w = Math.round(img.width * scale);
        const h = Math.round(img.height * scale);
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d')!;
        // Transparent background for PNG
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/png'));
      };
      img.onerror = reject;
      img.src = ev.target!.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function IdentidadeVisual() {
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const hasSaved = !!localStorage.getItem(LOGO_KEY);
  const currentSaved = localStorage.getItem(LOGO_KEY);

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 4000); };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      msg('Selecione uma imagem válida (PNG, JPG, SVG).');
      return;
    }
    setLoading(true);
    try {
      const b64 = await compressLogo(file);
      setPreview(b64);
    } catch {
      msg('Erro ao processar a imagem. Tente outro arquivo.');
    } finally {
      setLoading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  };

  const save = () => {
    if (!preview) return;
    localStorage.setItem(LOGO_KEY, preview);
    msg('Logo salva com sucesso! Recarregando...');
    setTimeout(() => window.location.reload(), 1200);
  };

  const remove = () => {
    localStorage.removeItem(LOGO_KEY);
    setPreview(null);
    msg('Logo personalizada removida. Voltando ao padrão...');
    setTimeout(() => window.location.reload(), 1200);
  };

  // What's shown in preview: pending upload > saved > system default
  const displaySrc = preview || currentSaved || '/logo-papelaria.png';

  return (
    <div style={{ maxWidth: 620 }}>
      {toast && (
        <div style={{
          background: '#ECFDF3', border: '1px solid #A9EFC5', borderRadius: 4,
          padding: '8px 12px', marginBottom: 16, fontSize: 13, color: '#027A48',
        }}>
          {toast}
        </div>
      )}

      {/* Preview */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 6, padding: 24, marginBottom: 16 }}>
        <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 16 }}>Preview da logo</div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
          {/* Light */}
          <div>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 8 }}>Fundo claro — cabeçalho / login</div>
            <div style={{
              background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 4,
              padding: '20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 90,
            }}>
              <img
                src={displaySrc}
                alt="Logo preview"
                style={{ maxHeight: 60, maxWidth: '100%', objectFit: 'contain' }}
                onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
              />
            </div>
          </div>

          {/* Dark */}
          <div>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 8 }}>Fundo escuro — sidebar</div>
            <div style={{
              background: '#1B3050', borderRadius: 4,
              padding: '20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 90,
            }}>
              <img
                src={displaySrc}
                alt="Logo preview dark"
                style={{ maxHeight: 60, maxWidth: '100%', objectFit: 'contain' }}
                onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }}
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' as const }}>
          <input
            type="file"
            accept="image/*"
            ref={fileRef}
            onChange={handleUpload}
            style={{ display: 'none' }}
          />
          <button
            onClick={() => fileRef.current?.click()}
            disabled={loading}
            style={btnPrimary}
          >
            {loading ? 'Processando...' : preview ? 'Substituir imagem' : 'Selecionar logo'}
          </button>
          {preview && (
            <button
              onClick={save}
              style={{ ...btnPrimary, background: '#027A48', border: '1px solid #027A48' }}
            >
              Salvar e aplicar logo
            </button>
          )}
          {preview && (
            <button onClick={() => setPreview(null)} style={btnSecondary}>
              Cancelar
            </button>
          )}
          {hasSaved && !preview && (
            <button onClick={remove} style={btnDanger}>Remover logo personalizada</button>
          )}
        </div>
      </div>

      {/* Recomendações */}
      <div style={{ background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 6, padding: 16, marginBottom: 14 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 8 }}>Recomendações</div>
        <div style={{ fontSize: 12, color: C.textMuted, lineHeight: 1.7 }}>
          <p style={{ margin: '0 0 3px' }}>• Formato preferido: <strong>PNG com fundo transparente</strong></p>
          <p style={{ margin: '0 0 3px' }}>• Dimensões ideais: <strong>400 × 120 px</strong> (proporção ~3:1)</p>
          <p style={{ margin: '0 0 3px' }}>• Também aceita JPG, GIF e outros formatos de imagem</p>
          <p style={{ margin: '0 0 3px' }}>• A logo é armazenada neste navegador (localStorage)</p>
          <p style={{ margin: 0 }}>• Aparece na sidebar, cabeçalho e tela de login automaticamente</p>
        </div>
      </div>

      {/* Status atual */}
      <div style={{ fontSize: 12, color: C.textMuted }}>
        {hasSaved ? (
          <span style={{ color: '#027A48' }}>✓ Logo personalizada ativa — armazenada neste navegador</span>
        ) : (
          <span>Usando logo padrão do sistema (<code>/public/logo-papelaria.png</code>)</span>
        )}
      </div>
    </div>
  );
}
