import { NavLink, Outlet, useNavigate } from 'react-router';
import { useApp } from '../../context/AppContext';
import { C } from '../../theme';

const tabs = [
  { to: '/financeiro',              label: 'Dashboard',       end: true },
  { to: '/financeiro/fluxo',        label: 'Fluxo de caixa' },
  { to: '/financeiro/receber',      label: 'A receber' },
  { to: '/financeiro/receitas',     label: 'Receitas' },
  { to: '/financeiro/despesas',     label: 'Despesas' },
  { to: '/financeiro/folha',        label: 'Folha' },
  { to: '/financeiro/pedidos',      label: 'Pedidos' },
  { to: '/financeiro/contas',       label: 'Contas' },
  { to: '/financeiro/custos',       label: 'Custos e margens' },
  { to: '/financeiro/relatorios',   label: 'Relatórios' },
  { to: '/financeiro/dre',          label: 'DRE' },
  { to: '/financeiro/fechamento',   label: 'Fechamento mensal' },
  { to: '/financeiro/recorrentes',  label: 'Recorrentes' },
  { to: '/financeiro/curva-abc',    label: 'Curva ABC' },
  { to: '/financeiro/parados',      label: 'Produtos parados' },
  { to: '/financeiro/reposicao',    label: 'Reposição' },
  { to: '/financeiro/posicao',      label: 'Onde está meu dinheiro?' },
  { to: '/financeiro/centrocustos', label: 'Centro de custos' },
  { to: '/financeiro/conciliacao',  label: 'Conciliação bancária' },
  { to: '/financeiro/emergencia',   label: 'Caixa emergência' },
  { to: '/financeiro/bancos',       label: 'Contas bancárias' },
  { to: '/financeiro/marketing',    label: 'Marketing' },
  { to: '/financeiro/config',       label: 'Config. financeira' },
  { to: '/financeiro/identidade',   label: 'Identidade visual' },
];

export default function FinanceiroLayout() {
  const { user } = useApp();
  const navigate = useNavigate();

  if (!user || user.role !== 'admin') {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: 320, gap: 12 }}>
        <span style={{ fontSize: 32, opacity: 0.3 }}>🔒</span>
        <p style={{ fontSize: 14, color: C.textMuted, textAlign: 'center', margin: 0 }}>
          Acesso restrito ao Administrador.
        </p>
        <button onClick={() => navigate('/dashboard')} style={{ fontSize: 13, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
          ← Voltar ao dashboard
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Sub-navegação */}
      <div style={{
        display: 'flex', gap: 0, borderBottom: `1px solid ${C.border}`,
        marginBottom: 20, overflowX: 'auto',
      }}>
        {tabs.map(t => (
          <NavLink
            key={t.to}
            to={t.to}
            end={t.end}
            style={({ isActive }) => ({
              padding: '7px 14px',
              fontSize: 12,
              fontFamily: 'Inter, sans-serif',
              fontWeight: isActive ? 600 : 400,
              color: isActive ? C.navy : C.textMuted,
              borderBottom: isActive ? `2px solid ${C.navy}` : '2px solid transparent',
              marginBottom: -1,
              whiteSpace: 'nowrap' as const,
              cursor: 'pointer',
            })}
          >
            {t.label}
          </NavLink>
        ))}
      </div>
      <Outlet />
    </div>
  );
}
