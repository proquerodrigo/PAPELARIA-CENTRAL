import React, { useMemo, useState } from 'react';
import { db } from '../../data/db';
import { C, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, ROW_BORDER } from '../../theme';

type Period = '3m' | '6m' | '12m' | 'tudo';

const PERIODS: { key: Period; label: string }[] = [
  { key: '3m', label: '3 meses' },
  { key: '6m', label: '6 meses' },
  { key: '12m', label: '12 meses' },
  { key: 'tudo', label: 'Desde jun/2025' },
];

function periodFrom(period: Period): string {
  const today = new Date();
  switch (period) {
    case '3m': { const d = new Date(today); d.setMonth(d.getMonth() - 3); return d.toISOString().slice(0, 10); }
    case '6m': { const d = new Date(today); d.setMonth(d.getMonth() - 6); return d.toISOString().slice(0, 10); }
    case '12m': { const d = new Date(today); d.setFullYear(d.getFullYear() - 1); return d.toISOString().slice(0, 10); }
    case 'tudo': return '2025-06-01';
  }
}

function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function fmtPct(v: number) {
  return v.toFixed(1) + '%';
}

export default function CurvaABC() {
  const [period, setPeriod] = useState<Period>('3m');
  const [filterCat, setFilterCat] = useState('');
  const [filterBrand, setFilterBrand] = useState('');

  const categories = useMemo(() => db.categories.all().filter(c => c.status === 'Ativa'), []);
  const products = useMemo(() => db.products.all(), []);

  // Build brand list from products
  const brands = useMemo(() => {
    const set = new Set<string>();
    products.forEach(p => { if (p.brand) set.add(p.brand); });
    return Array.from(set).sort();
  }, [products]);

  // Build product lookup
  const productMap = useMemo(() => {
    const m = new Map<string, typeof products[0]>();
    products.forEach(p => m.set(p.id, p));
    return m;
  }, [products]);

  // Use movements (Saída) as sales proxy
  const rows = useMemo(() => {
    const from = periodFrom(period);
    const today = new Date().toISOString().slice(0, 10);

    const movements = db.movements.all().filter(m => {
      if (m.type !== 'Saída') return false;
      const movDate = m.createdAt.slice(0, 10);
      return movDate >= from && movDate <= today;
    });

    // Aggregate by productId
    const agg = new Map<string, { productId: string; productName: string; qty: number; revenue: number; category: string; brand: string }>();
    movements.forEach(m => {
      const prod = productMap.get(m.productId);
      const price = prod?.price ?? 0;
      const category = prod?.category ?? '';
      const brand = prod?.brand ?? '';
      const key = m.productId || m.productName;
      if (agg.has(key)) {
        const entry = agg.get(key)!;
        entry.qty += m.qty;
        entry.revenue += m.qty * price;
      } else {
        agg.set(key, {
          productId: m.productId,
          productName: m.productName,
          qty: m.qty,
          revenue: m.qty * price,
          category,
          brand,
        });
      }
    });

    let items = Array.from(agg.values());

    // Apply filters
    if (filterCat) items = items.filter(i => i.category === filterCat);
    if (filterBrand) items = items.filter(i => i.brand === filterBrand);

    // Sort by revenue desc
    items.sort((a, b) => b.revenue - a.revenue);

    const totalRevenue = items.reduce((s, i) => s + i.revenue, 0);
    const totalQty = items.reduce((s, i) => s + i.qty, 0);

    let cumulative = 0;
    return {
      items: items.map((item, idx) => {
        const pct = totalRevenue > 0 ? (item.revenue / totalRevenue) * 100 : 0;
        cumulative += pct;
        const cls: 'A' | 'B' | 'C' = cumulative <= 70 ? 'A' : cumulative <= 90 ? 'B' : 'C';
        return { ...item, rank: idx + 1, pct, cumulative, cls };
      }),
      totalRevenue,
      totalQty,
    };
  }, [period, filterCat, filterBrand, productMap]);

  function badgeForClass(cls: 'A' | 'B' | 'C') {
    if (cls === 'A') return { background: C.navy, color: C.white, border: 'none', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
    if (cls === 'B') return { background: '#6B7280', color: C.white, border: 'none', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
    return { background: '#D1D5DB', color: '#374151', border: 'none', borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 600 };
  }

  return (
    <div style={{ padding: 24, fontFamily: 'Inter, sans-serif', color: C.text }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <h1 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: C.text }}>Curva ABC de Produtos</h1>
        <p style={{ margin: '4px 0 0', fontSize: 13, color: C.textMuted }}>
          Classificação de produtos por representatividade no faturamento
        </p>
      </div>

      {/* Filters */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 8, padding: '16px 20px', marginBottom: 16 }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, alignItems: 'center' }}>
          {/* Period buttons */}
          <div style={{ display: 'flex', gap: 4 }}>
            {PERIODS.map(p => (
              <button
                key={p.key}
                onClick={() => setPeriod(p.key)}
                style={{
                  ...btnSecondary,
                  padding: '5px 12px',
                  fontSize: 12,
                  background: period === p.key ? C.navy : C.white,
                  color: period === p.key ? C.white : C.text,
                  border: period === p.key ? 'none' : `1px solid ${C.border}`,
                }}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Category filter */}
          <select
            value={filterCat}
            onChange={e => setFilterCat(e.target.value)}
            style={{ padding: '5px 10px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 6, background: C.white, color: C.text, cursor: 'pointer' }}
          >
            <option value="">Todas as categorias</option>
            {categories.map(c => <option key={c.id} value={c.name}>{c.name}</option>)}
          </select>

          {/* Brand filter */}
          {brands.length > 0 && (
            <select
              value={filterBrand}
              onChange={e => setFilterBrand(e.target.value)}
              style={{ padding: '5px 10px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 6, background: C.white, color: C.text, cursor: 'pointer' }}
            >
              <option value="">Todas as marcas</option>
              {brands.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          )}

          {(filterCat || filterBrand) && (
            <button
              onClick={() => { setFilterCat(''); setFilterBrand(''); }}
              style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12, color: C.textMuted }}
            >
              Limpar filtros
            </button>
          )}
        </div>
      </div>

      {/* Legend */}
      <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        {([
          { cls: 'A', label: 'Classe A — 0–70% do faturamento (produtos vitais)', bg: C.navy, color: C.white },
          { cls: 'B', label: 'Classe B — 70–90% (produtos importantes)', bg: '#6B7280', color: C.white },
          { cls: 'C', label: 'Classe C — 90–100% (produtos secundários)', bg: '#D1D5DB', color: '#374151' },
        ] as const).map(item => (
          <div key={item.cls} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: C.textMuted }}>
            <span style={{ background: item.bg, color: item.color, padding: '2px 8px', borderRadius: 4, fontSize: 11, fontWeight: 600 }}>
              {item.cls}
            </span>
            <span>{item.label}</span>
          </div>
        ))}
      </div>

      {/* Table */}
      <div style={tableWrap}>
        {rows.items.length === 0 ? (
          <div style={{ padding: 48, textAlign: 'center', color: C.textMuted, fontSize: 14 }}>
            Sem dados de vendas no período
          </div>
        ) : (
          <table style={tbl}>
            <thead>
              <tr>
                <th style={{ ...TH, textAlign: 'center', width: 50 }}>#</th>
                <th style={{ ...TH, textAlign: 'center', width: 70 }}>Class.</th>
                <th style={TH}>Produto</th>
                <th style={{ ...TH, textAlign: 'right' }}>Qtd. vendida</th>
                <th style={{ ...TH, textAlign: 'right' }}>Faturamento</th>
                <th style={{ ...TH, textAlign: 'right' }}>% do total</th>
                <th style={{ ...TH, textAlign: 'right' }}>% acumulado</th>
              </tr>
            </thead>
            <tbody>
              {rows.items.map((item, idx) => (
                <tr key={item.productId || idx} style={{ borderTop: idx > 0 ? ROW_BORDER : 'none' }}>
                  <td style={{ ...TD, textAlign: 'center', color: C.textMuted, fontSize: 12 }}>{item.rank}</td>
                  <td style={{ ...TD, textAlign: 'center' }}>
                    <span style={badgeForClass(item.cls)}>{item.cls}</span>
                  </td>
                  <td style={TD}>
                    <div style={{ fontWeight: 500, fontSize: 13 }}>{item.productName}</div>
                    {item.category && (
                      <div style={{ fontSize: 11, color: C.textMuted }}>{item.category}{item.brand ? ` · ${item.brand}` : ''}</div>
                    )}
                  </td>
                  <td style={{ ...TD, textAlign: 'right', fontVariantNumeric: 'tabular-nums' }}>{item.qty}</td>
                  <td style={{ ...TD, textAlign: 'right', fontVariantNumeric: 'tabular-nums', fontWeight: 500 }}>
                    {fmtBRL(item.revenue)}
                  </td>
                  <td style={{ ...TD, textAlign: 'right', color: C.textMuted }}>
                    {fmtPct(item.pct)}
                  </td>
                  <td style={{ ...TD, textAlign: 'right' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, justifyContent: 'flex-end' }}>
                      <div style={{ width: 60, height: 6, background: C.borderLight, borderRadius: 3, overflow: 'hidden' }}>
                        <div style={{ width: `${Math.min(item.cumulative, 100)}%`, height: '100%', background: C.navy, borderRadius: 3 }} />
                      </div>
                      <span style={{ fontSize: 12, minWidth: 42, textAlign: 'right' }}>{fmtPct(item.cumulative)}</span>
                    </div>
                  </td>
                </tr>
              ))}
              {/* Totals row */}
              <tr style={{ borderTop: `2px solid ${C.metalBorder}`, background: C.metalLight }}>
                <td style={{ ...TD, textAlign: 'center' }} colSpan={3}>
                  <span style={{ fontWeight: 600, fontSize: 13 }}>Total ({rows.items.length} produtos)</span>
                </td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 600 }}>{rows.totalQty}</td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 700 }}>{fmtBRL(rows.totalRevenue)}</td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 600 }}>100%</td>
                <td style={{ ...TD, textAlign: 'right', fontWeight: 600, color: C.textMuted }}>—</td>
              </tr>
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
