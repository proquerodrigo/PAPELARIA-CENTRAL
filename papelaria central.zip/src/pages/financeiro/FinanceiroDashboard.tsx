import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  finDb, periodRange, previousPeriodRange, filterByPeriod, fmtBRL,
} from '../../data/finDb';
import { emergencyDb } from '../../data/emergencyDb';
import { bancosDb } from '../../data/bancosDb';
import { marketingDb } from '../../data/marketingDb';
import { C } from '../../theme';

const PERIODS = [
  { value: 'hoje',    label: 'Hoje' },
  { value: 'ontem',   label: 'Ontem' },
  { value: '7d',      label: 'Últimos 7 dias' },
  { value: 'mes',     label: 'Este mês' },
  { value: 'mes_ant', label: 'Mês anterior' },
  { value: '3m',      label: 'Últimos 3 meses' },
  { value: '6m',      label: 'Últimos 6 meses' },
  { value: '9m',      label: 'Últimos 9 meses' },
  { value: '12m',     label: 'Últimos 12 meses' },
  { value: 'ano',     label: 'Este ano' },
  { value: 'tudo',    label: 'Desde jun/2025' },
  { value: 'custom',  label: 'Personalizado' },
];

const CC = {
  receita: '#2E6FA3',
  despesa: '#E05252',
  saldo:   '#27AE60',
  navy:    '#1B3050',
  margem:  '#8B5CF6',
};

const PIE_COLORS = ['#2E6FA3','#E05252','#27AE60','#F59E0B','#8B5CF6','#06B6D4','#F97316','#EC4899','#6B7280'];
const ORDER_COLORS: Record<string, string> = {
  'Pendente': '#F59E0B', 'Em preparação': '#3B82F6', 'Pronto para entrega': '#8B5CF6',
  'Saiu para entrega': '#06B6D4', 'Entregue': '#27AE60', 'Cancelado': '#E05252',
};

const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];
function monthLabel(ym: string) {
  const [y, m] = ym.split('-');
  return `${MONTHS[parseInt(m)-1]}/${y.slice(2)}`;
}

function delta(curr: number, prev: number): number | null {
  if (prev === 0) return null;
  return ((curr - prev) / prev) * 100;
}

function KPICard({
  label, value, sub, color = C.text, variation,
}: {
  label: string; value: string; sub?: string; color?: string; variation?: number | null;
}) {
  return (
    <div style={{
      background: C.white, border: `1px solid ${C.border}`, borderRadius: 5,
      padding: '12px 16px', minWidth: 0,
    }}>
      <div style={{ fontSize: 11, color: C.textMuted, fontWeight: 500, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 18, fontWeight: 600, color, lineHeight: 1.2 }}>{value}</div>
      {variation !== undefined && variation !== null && (
        <div style={{ fontSize: 11, color: variation >= 0 ? '#027A48' : '#B91C1C', marginTop: 3 }}>
          {variation >= 0 ? '↑' : '↓'} {Math.abs(variation).toFixed(1)}% vs período ant.
        </div>
      )}
      {sub && <div style={{ fontSize: 11, color: C.textMuted, marginTop: 3 }}>{sub}</div>}
    </div>
  );
}

function SectionTitle({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 12, fontWeight: 600, color: C.text, textTransform: 'uppercase' as const,
      letterSpacing: '0.05em', marginBottom: 12, marginTop: 24,
    }}>{children}</div>
  );
}

function ChartCard({ title, children, height = 220 }: { title: string; children: React.ReactNode; height?: number }) {
  return (
    <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 5, padding: '16px 16px 8px' }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: C.text, marginBottom: 12 }}>{title}</div>
      <div style={{ height }}>{children}</div>
    </div>
  );
}

export default function FinanceiroDashboard() {
  const navigate = useNavigate();
  const [period, setPeriod] = useState('3m');
  const [customFrom, setCustomFrom] = useState('');
  const [customTo, setCustomTo] = useState('');

  const { from, to } = useMemo(
    () => periodRange(period, customFrom || undefined, customTo || undefined),
    [period, customFrom, customTo],
  );

  const { from: pf, to: pt } = useMemo(() => previousPeriodRange(period), [period]);

  // Extra financial modules
  const emergency = useMemo(() => emergencyDb.get(), []);
  const saldoBancos = useMemo(() => bancosDb.saldoTotal(), []);
  const marketing = useMemo(() => marketingDb.get(), []);
  const totalMarketing = useMemo(() => marketing.gastos.reduce((s, g) => s + g.valor, 0), [marketing]);

  const allRevenues = finDb.revenues.all();
  const allExpenses = finDb.expenses.all();
  const allSales    = finDb.sales.all();
  const allOrders   = finDb.orders.all();
  const allBills    = finDb.bills.all();
  const allPayroll  = finDb.payroll.all();

  const revenues    = useMemo(() => filterByPeriod(allRevenues, from, to), [allRevenues, from, to]);
  const expenses    = useMemo(() => filterByPeriod(allExpenses, from, to), [allExpenses, from, to]);
  const sales       = useMemo(() => filterByPeriod(allSales,    from, to), [allSales, from, to]);
  const prevSales   = useMemo(() => filterByPeriod(allSales,    pf,   pt), [allSales, pf, pt]);
  const prevRevs    = useMemo(() => filterByPeriod(allRevenues, pf,   pt), [allRevenues, pf, pt]);
  const prevExps    = useMemo(() => filterByPeriod(allExpenses, pf,   pt), [allExpenses, pf, pt]);

  // ── KPIs actuais ──────────────────────────────────────────
  const faturamento   = sales.reduce((s, x) => s + x.grossValue, 0);
  const taxas         = sales.reduce((s, x) => s + x.feeValue, 0);
  const valorRecebido = sales.filter(x => x.status === 'Recebido').reduce((s, x) => s + x.netValue, 0);
  const aReceber      = sales.filter(x => x.status === 'A receber').reduce((s, x) => s + x.netValue, 0);

  const totalReceitas = revenues.filter(r => r.status === 'Pago').reduce((s, r) => s + r.value, 0);
  const totalDespesas = expenses.filter(e => e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const saldo         = totalReceitas - totalDespesas;
  const totalCustos   = expenses.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const lucroBruto    = faturamento - taxas - totalCustos;
  const margem        = faturamento > 0 ? (lucroBruto / faturamento) * 100 : 0;

  const pendBills      = allBills.filter(b => b.status === 'Pendente' || b.status === 'Vencido');
  const pendBillsValue = pendBills.reduce((s, b) => s + b.value, 0);
  const vencidas       = allBills.filter(b => b.status === 'Vencido').length;

  const saldoProjetado = saldo + aReceber - pendBillsValue;

  const currentMonth   = new Date().toISOString().slice(0, 7);
  const payrollCurr    = allPayroll.filter(p => p.month === currentMonth);
  const salPendente    = payrollCurr.filter(p => p.status === 'Pendente').reduce((s, p) => s + p.salary, 0);
  const benefPendente  = payrollCurr.filter(p => p.status === 'Pendente').reduce((s, p) => s + p.vr + p.vt, 0);
  const pedPendentes   = allOrders.filter(o => o.status !== 'Entregue' && o.status !== 'Cancelado');
  const pedValue       = pedPendentes.reduce((s, o) => s + o.total, 0);

  // ── Variações (vs período anterior) ──────────────────────
  const prevFaturamento = prevSales.reduce((s, x) => s + x.grossValue, 0);
  const prevReceitas    = prevRevs.filter(r => r.status === 'Pago').reduce((s, r) => s + r.value, 0);
  const prevDespesas    = prevExps.filter(e => e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const prevSaldo       = prevReceitas - prevDespesas;
  const prevCustos      = prevExps.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').reduce((s, e) => s + e.value, 0);
  const prevTaxas       = prevSales.reduce((s, x) => s + x.feeValue, 0);
  const prevLucro       = prevFaturamento - prevTaxas - prevCustos;
  const prevMargem      = prevFaturamento > 0 ? (prevLucro / prevFaturamento) * 100 : 0;

  // ── Chart data ────────────────────────────────────────────
  const tooltipStyle = { contentStyle: { fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 4 } };

  // Faturamento × Recebido por mês
  const fatVsRecData = useMemo(() => {
    const map: Record<string, { fat: number; rec: number }> = {};
    sales.forEach(s => {
      const k = s.date.slice(0, 7);
      if (!map[k]) map[k] = { fat: 0, rec: 0 };
      map[k].fat += s.grossValue;
      if (s.status === 'Recebido') map[k].rec += s.netValue;
    });
    return Object.entries(map).sort(([a],[b]) => a.localeCompare(b)).map(([ym, v]) => ({
      mes: monthLabel(ym), Faturamento: Math.round(v.fat), Recebido: Math.round(v.rec),
    }));
  }, [sales]);

  // Entradas × Saídas
  const revVsExpData = useMemo(() => {
    const map: Record<string, { r: number; d: number }> = {};
    revenues.filter(r => r.status === 'Pago').forEach(r => { const k = r.date.slice(0,7); if (!map[k]) map[k] = { r:0, d:0 }; map[k].r += r.value; });
    expenses.filter(e => e.status === 'Pago').forEach(e => { const k = e.date.slice(0,7); if (!map[k]) map[k] = { r:0, d:0 }; map[k].d += e.value; });
    return Object.entries(map).sort(([a],[b]) => a.localeCompare(b)).map(([ym, v]) => ({
      mes: monthLabel(ym), Receitas: Math.round(v.r), Despesas: Math.round(v.d),
    }));
  }, [revenues, expenses]);

  // A receber por data futura
  const aReceberData = useMemo(() => {
    const map: Record<string, number> = {};
    allSales.filter(s => s.status === 'A receber').forEach(s => {
      const k = s.expectedDate.slice(0, 7);
      map[k] = (map[k] ?? 0) + s.netValue;
    });
    return Object.entries(map).sort(([a],[b]) => a.localeCompare(b)).map(([ym, v]) => ({
      mes: monthLabel(ym), 'A receber': Math.round(v),
    }));
  }, [allSales]);

  // Taxas por método
  const taxasData = useMemo(() => {
    const map: Record<string, { taxa: number; count: number }> = {};
    sales.filter(s => s.feeValue > 0).forEach(s => {
      if (!map[s.paymentMethod]) map[s.paymentMethod] = { taxa: 0, count: 0 };
      map[s.paymentMethod].taxa += s.feeValue;
      map[s.paymentMethod].count++;
    });
    return Object.entries(map).sort(([,a],[,b]) => b.taxa - a.taxa).map(([name, v]) => ({
      name, Taxa: Math.round(v.taxa), Qtd: v.count,
    }));
  }, [sales]);

  // Formas de pagamento (vendas)
  const methodsData = useMemo(() => {
    const map: Record<string, number> = {};
    sales.forEach(s => { map[s.paymentMethod] = (map[s.paymentMethod] ?? 0) + s.grossValue; });
    return Object.entries(map).sort(([,a],[,b]) => b - a).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [sales]);

  // Composição despesas (pie)
  const expCompositionData = useMemo(() => {
    const map: Record<string, number> = {};
    expenses.filter(e => e.status === 'Pago').forEach(e => { map[e.category] = (map[e.category] ?? 0) + e.value; });
    return Object.entries(map).sort(([,a],[,b]) => b - a).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [expenses]);

  // Margem por mês
  const marginData = useMemo(() => {
    const fatMap: Record<string, number> = {};
    const feeMap: Record<string, number> = {};
    const costMap: Record<string, number> = {};
    sales.forEach(s => {
      fatMap[s.date.slice(0,7)]  = (fatMap[s.date.slice(0,7)]  ?? 0) + s.grossValue;
      feeMap[s.date.slice(0,7)]  = (feeMap[s.date.slice(0,7)]  ?? 0) + s.feeValue;
    });
    expenses.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').forEach(e => {
      costMap[e.date.slice(0,7)] = (costMap[e.date.slice(0,7)] ?? 0) + e.value;
    });
    return [...new Set([...Object.keys(fatMap), ...Object.keys(costMap)])].sort().map(ym => {
      const fat  = fatMap[ym]  ?? 0;
      const fee  = feeMap[ym]  ?? 0;
      const cost = costMap[ym] ?? 0;
      const mg   = fat > 0 ? Math.round(((fat - fee - cost) / fat) * 1000) / 10 : 0;
      return { mes: monthLabel(ym), 'Margem %': mg };
    });
  }, [sales, expenses]);

  // Folha por mês
  const payrollData = useMemo(() => {
    const map: Record<string, { pago: number; pendente: number }> = {};
    allPayroll.forEach(p => {
      if (!map[p.month]) map[p.month] = { pago: 0, pendente: 0 };
      if (p.status === 'Pago') map[p.month].pago += p.total;
      else map[p.month].pendente += p.total;
    });
    return Object.entries(map).sort(([a],[b]) => a.localeCompare(b)).map(([ym, v]) => ({
      mes: monthLabel(ym), Pago: Math.round(v.pago), Pendente: Math.round(v.pendente),
    }));
  }, [allPayroll]);

  // Pedidos por status
  const orderStatusData = useMemo(() => {
    const map: Record<string, number> = {};
    allOrders.forEach(o => { map[o.status] = (map[o.status] ?? 0) + 1; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [allOrders]);

  return (
    <div>
      {/* Filtro de período */}
      <div style={{ display: 'flex', gap: 6, marginBottom: period === 'custom' ? 8 : 20, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <span style={{ fontSize: 12, color: C.textMuted, fontWeight: 500, marginRight: 4 }}>Período:</span>
        {PERIODS.map(p => (
          <button
            key={p.value}
            onClick={() => setPeriod(p.value)}
            style={{
              padding: '4px 10px', fontSize: 12, borderRadius: 4, cursor: 'pointer',
              border: `1px solid ${period === p.value ? C.navy : C.border}`,
              background: period === p.value ? C.navy : C.white,
              color: period === p.value ? '#fff' : C.text,
              fontFamily: 'Inter, sans-serif',
            }}
          >{p.label}</button>
        ))}
      </div>
      {period === 'custom' && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 20, alignItems: 'center' }}>
          <span style={{ fontSize: 12, color: C.textMuted }}>De:</span>
          <input type="date" value={customFrom} onChange={e => setCustomFrom(e.target.value)}
            style={{ padding: '4px 8px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 4, fontFamily: 'Inter, sans-serif' }} />
          <span style={{ fontSize: 12, color: C.textMuted }}>até:</span>
          <input type="date" value={customTo} onChange={e => setCustomTo(e.target.value)}
            style={{ padding: '4px 8px', fontSize: 12, border: `1px solid ${C.border}`, borderRadius: 4, fontFamily: 'Inter, sans-serif' }} />
        </div>
      )}

      {/* ── KPI principal — Vendas ─────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(148px, 1fr))', gap: 10, marginBottom: 10 }}>
        <KPICard label="Faturamento" value={fmtBRL(faturamento)} color={CC.navy}
          variation={delta(faturamento, prevFaturamento)} />
        <KPICard label="Valor recebido" value={fmtBRL(valorRecebido)} color={CC.saldo}
          variation={delta(valorRecebido, prevSales.filter(x => x.status === 'Recebido').reduce((s,x) => s + x.netValue, 0))} />
        <KPICard label="A receber" value={fmtBRL(aReceber)} color="#B54708"
          sub={`${allSales.filter(s => s.status === 'A receber').length} vendas`} />
        <KPICard label="Taxas de cartão" value={fmtBRL(taxas)} color={CC.despesa}
          variation={delta(taxas, prevTaxas)} />
        <KPICard label="Lucro bruto" value={fmtBRL(lucroBruto)} color={lucroBruto >= 0 ? CC.saldo : CC.despesa}
          variation={delta(lucroBruto, prevLucro)} />
        <KPICard label="Margem bruta" value={`${margem.toFixed(1)}%`} color={CC.margem}
          variation={delta(margem, prevMargem)} />
      </div>

      {/* ── KPI secundário — Caixa ─────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(148px, 1fr))', gap: 10, marginBottom: 10 }}>
        <KPICard label="Entradas" value={fmtBRL(totalReceitas)} color={CC.saldo}
          variation={delta(totalReceitas, prevReceitas)} />
        <KPICard label="Saídas" value={fmtBRL(totalDespesas)} color={CC.despesa}
          variation={delta(totalDespesas, prevDespesas)} />
        <KPICard label="Saldo atual" value={fmtBRL(saldo)} color={saldo >= 0 ? CC.saldo : CC.despesa}
          variation={delta(saldo, prevSaldo)} />
        <KPICard label="Saldo projetado" value={fmtBRL(saldoProjetado)} color={saldoProjetado >= 0 ? CC.saldo : CC.despesa}
          sub="Saldo + A receber − Contas pend." />
        <KPICard label="Custo de estoque" value={fmtBRL(totalCustos)} />
      </div>

      {/* ── KPI extra — Reservas e Marketing ─────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(148px, 1fr))', gap: 10, marginBottom: 10 }}>
        <KPICard label="Caixa de emergência" value={fmtBRL(emergency.saldoAtual)} color={CC.navy}
          sub={`Meta: ${fmtBRL(emergency.metaReserva)}`} />
        <KPICard label="Saldo bancário total" value={fmtBRL(saldoBancos)} color={CC.saldo} />
        <KPICard label="Verba marketing" value={fmtBRL(marketing.verbaMensal)} color={CC.margem}
          sub={`Gasto: ${fmtBRL(totalMarketing)}`} />
        <KPICard label="Saldo marketing" value={fmtBRL(marketing.verbaMensal - marketing.verbaReservada - totalMarketing)}
          color={marketing.verbaMensal - marketing.verbaReservada - totalMarketing >= 0 ? CC.saldo : CC.despesa} />
      </div>

      {/* ── KPI terciário — Obrigações ─────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(148px, 1fr))', gap: 10, marginBottom: 24 }}>
        <KPICard label="Contas pendentes" value={String(pendBills.length)} color={vencidas > 0 ? CC.despesa : C.text}
          sub={vencidas > 0 ? `${vencidas} vencida${vencidas > 1 ? 's' : ''}` : `${fmtBRL(pendBillsValue)}`} />
        <KPICard label="Salários pend." value={fmtBRL(salPendente)} color={salPendente > 0 ? '#B54708' : C.text} />
        <KPICard label="Benefícios pend." value={fmtBRL(benefPendente)} />
        <KPICard label="Pedidos em aberto" value={String(pedPendentes.length)} sub={`${fmtBRL(pedValue)}`} />
      </div>

      {/* Atalhos */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' as const }}>
        {[
          { label: '→ Contas a receber', to: '/financeiro/receber' },
          { label: '+ Nova despesa',     to: '/financeiro/despesas' },
          { label: 'Folha de pagamento', to: '/financeiro/folha' },
          { label: 'Caixa emergência',   to: '/financeiro/emergencia' },
          { label: 'Contas bancárias',   to: '/financeiro/bancos' },
          { label: 'Marketing',          to: '/financeiro/marketing' },
          { label: 'Ver relatórios',     to: '/financeiro/relatorios' },
        ].map(b => (
          <button
            key={b.to + b.label}
            onClick={() => navigate(b.to)}
            style={{
              padding: '5px 12px', fontSize: 12, border: `1px solid ${C.border}`,
              borderRadius: 4, background: C.white, color: C.navy,
              cursor: 'pointer', fontFamily: 'Inter, sans-serif',
            }}
          >{b.label}</button>
        ))}
      </div>

      {/* ── Gráficos ─────────────────────────────────────────── */}
      <SectionTitle>Faturamento e recebimentos</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <ChartCard title="Faturamento × Recebido (por mês)">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={fatVsRecData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="Faturamento" fill={CC.navy}    radius={[2,2,0,0]} />
              <Bar dataKey="Recebido"    fill={CC.saldo}   radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Formas de pagamento — volume">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={methodsData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}
                label={({ percent }: { percent?: number }) => (percent ?? 0) > 0.06 ? `${((percent ?? 0) * 100).toFixed(0)}%` : ''}
                labelLine={false}>
                {methodsData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <SectionTitle>Fluxo de caixa e despesas</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <ChartCard title="Entradas × Saídas (por mês)">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={revVsExpData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="Receitas"  fill={CC.receita} radius={[2,2,0,0]} />
              <Bar dataKey="Despesas"  fill={CC.despesa} radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Composição das despesas">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={expCompositionData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80}
                label={({ percent }: { percent?: number }) => (percent ?? 0) > 0.05 ? `${((percent ?? 0)*100).toFixed(0)}%` : ''}
                labelLine={false}>
                {expCompositionData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
              </Pie>
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <SectionTitle>Margem, taxas e projeções</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 12 }}>
        <ChartCard title="Margem bruta (%)">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={marginData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${v}%`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => `${v}%`} />
              <Line type="monotone" dataKey="Margem %" stroke={CC.margem} dot={{ r: 3 }} strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="A receber — projeção por mês">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={aReceberData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Bar dataKey="A receber" fill="#F59E0B" radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <SectionTitle>Taxas, folha e pedidos</SectionTitle>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 24 }}>
        <ChartCard title="Taxas por forma de pagamento" height={200}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={taxasData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Bar dataKey="Taxa" fill={CC.despesa} radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Folha de pagamento" height={200}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={payrollData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#F0F0F0" />
              <XAxis dataKey="mes" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 10 }} tickFormatter={v => `${(v/1000).toFixed(0)}k`} />
              <Tooltip {...tooltipStyle} formatter={(v: unknown) => fmtBRL(Number(v))} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="Pago"     fill={CC.saldo}  radius={[2,2,0,0]} />
              <Bar dataKey="Pendente" fill="#F59E0B"   radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Pedidos por status" height={200}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={orderStatusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70}
                label={({ value }) => value} labelLine={false}>
                {orderStatusData.map((e, i) => <Cell key={i} fill={ORDER_COLORS[e.name] ?? PIE_COLORS[i]} />)}
              </Pie>
              <Tooltip {...tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}
