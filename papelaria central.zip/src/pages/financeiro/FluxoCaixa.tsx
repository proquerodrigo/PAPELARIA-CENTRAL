import { useState, useMemo } from 'react';
import { finDb, periodRange, filterByPeriod, fmtBRL, type FinRevenue, type FinExpense } from '../../data/finDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER } from '../../theme';

const PERIODS = [
  { value: 'mes', label: 'Este mês' },
  { value: 'mes_ant', label: 'Mês anterior' },
  { value: '3m', label: 'Últimos 3 meses' },
  { value: '6m', label: 'Últimos 6 meses' },
  { value: 'ano', label: 'Este ano' },
];

type CashItem = {
  id: string; date: string; description: string; category: string;
  entrada: number; saida: number; paymentMethod: string; status: string;
};

export default function FluxoCaixa() {
  const [period, setPeriod] = useState('3m');
  const [typeFilter, setTypeFilter] = useState('Todos');
  const [statusFilter, setStatusFilter] = useState('Todos');

  const { from, to } = useMemo(() => periodRange(period), [period]);

  const rows = useMemo(() => {
    const revs = filterByPeriod(finDb.revenues.all(), from, to).map(r => ({
      id: r.id, date: r.date, description: r.description, category: r.category,
      entrada: r.status === 'Pago' ? r.value : 0, saida: 0,
      paymentMethod: r.paymentMethod, status: r.status,
    }));
    const exps = filterByPeriod(finDb.expenses.all(), from, to).map(e => ({
      id: e.id, date: e.date, description: e.description, category: e.category,
      entrada: 0, saida: e.status === 'Pago' ? e.value : 0,
      paymentMethod: e.paymentMethod, status: e.status,
    }));
    return [...revs, ...exps].sort((a, b) => a.date.localeCompare(b.date));
  }, [from, to]);

  const filtered = useMemo(() => rows.filter(r =>
    (typeFilter === 'Todos' || (typeFilter === 'Entradas' ? r.entrada > 0 : r.saida > 0)) &&
    (statusFilter === 'Todos' || r.status === statusFilter)
  ), [rows, typeFilter, statusFilter]);

  const saldoAcc = useMemo(() => {
    let acc = 0;
    return filtered.map(r => { acc += r.entrada - r.saida; return acc; });
  }, [filtered]);

  const totalEntradas = filtered.reduce((s, r) => s + r.entrada, 0);
  const totalSaidas = filtered.reduce((s, r) => s + r.saida, 0);
  const saldoFinal = totalEntradas - totalSaidas;

  const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text };

  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <select value={period} onChange={e => setPeriod(e.target.value)} style={sinp}>
          {PERIODS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)} style={sinp}>
          <option>Todos</option><option>Entradas</option><option>Saídas</option>
        </select>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={sinp}>
          <option>Todos</option><option>Pago</option><option>Pendente</option>
        </select>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted }}>
          Entradas: <strong style={{ color: '#027A48' }}>{fmtBRL(totalEntradas)}</strong>
          {' · '}Saídas: <strong style={{ color: '#B91C1C' }}>{fmtBRL(totalSaidas)}</strong>
          {' · '}Saldo: <strong style={{ color: saldoFinal >= 0 ? '#027A48' : '#B91C1C' }}>{fmtBRL(saldoFinal)}</strong>
        </span>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Data', 'Descrição', 'Categoria', 'Pagamento', 'Entrada', 'Saída', 'Status', 'Saldo acumulado'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr key={r.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, color: C.textMuted, fontSize: 12, whiteSpace: 'nowrap' as const }}>{r.date.split('-').reverse().join('/')}</td>
                <td style={{ ...TD, fontWeight: 500 }}>{r.description}</td>
                <td style={{ ...TD, color: C.textMuted }}>{r.category}</td>
                <td style={{ ...TD, color: C.textMuted }}>{r.paymentMethod}</td>
                <td style={{ ...TD, color: r.entrada > 0 ? '#027A48' : C.textMuted, fontWeight: r.entrada > 0 ? 600 : 400 }}>
                  {r.entrada > 0 ? fmtBRL(r.entrada) : '—'}
                </td>
                <td style={{ ...TD, color: r.saida > 0 ? '#B91C1C' : C.textMuted, fontWeight: r.saida > 0 ? 600 : 400 }}>
                  {r.saida > 0 ? fmtBRL(r.saida) : '—'}
                </td>
                <td style={TD}>
                  <span style={r.status === 'Pago'
                    ? { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '1px 6px', fontSize: 11 }
                    : { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '1px 6px', fontSize: 11 }}>
                    {r.status}
                  </span>
                </td>
                <td style={{ ...TD, fontWeight: 600, color: saldoAcc[i] >= 0 ? '#027A48' : '#B91C1C' }}>
                  {fmtBRL(saldoAcc[i])}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={8} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum lançamento no período.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
