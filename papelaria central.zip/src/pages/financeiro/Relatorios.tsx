import { useState, useMemo } from 'react';
import { finDb, fmtBRL, periodRange, filterByPeriod } from '../../data/finDb';
import { C } from '../../theme';

const PERIODS = [
  { value: 'mes',     label: 'Este mês' },
  { value: 'mes_ant', label: 'Mês anterior' },
  { value: '3m',      label: 'Últimos 3 meses' },
  { value: '6m',      label: 'Últimos 6 meses' },
  { value: 'ano',     label: 'Este ano' },
];

const REPORT_TYPES = [
  { value: 'geral',    label: 'Resumo Geral' },
  { value: 'vendas',   label: 'Vendas / A Receber' },
  { value: 'despesas', label: 'Despesas' },
  { value: 'folha',    label: 'Folha de Pagamento' },
  { value: 'pedidos',  label: 'Pedidos' },
];

const MONTHS = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

function SectionHeader({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 11, fontWeight: 700, color: C.navy, textTransform: 'uppercase' as const,
      letterSpacing: '0.06em', borderBottom: `2px solid ${C.navy}`, paddingBottom: 6, marginBottom: 12, marginTop: 24,
    }}>{children}</div>
  );
}

function Row({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', padding: '5px 0',
      borderBottom: `1px solid ${C.borderLight}`,
      fontWeight: bold ? 600 : 400,
    }}>
      <span style={{ fontSize: 13, color: C.text }}>{label}</span>
      <span style={{ fontSize: 13, color: bold ? C.navy : C.text }}>{value}</span>
    </div>
  );
}

export default function Relatorios() {
  const [period, setPeriod] = useState('mes');
  const [reportType, setReportType] = useState('geral');

  const { from, to } = useMemo(() => periodRange(period), [period]);
  const periodLabel = PERIODS.find(p => p.value === period)?.label ?? '';

  const allRevenues  = finDb.revenues.all();
  const allExpenses  = finDb.expenses.all();
  const allSales     = finDb.sales.all();
  const allOrders    = finDb.orders.all();
  const allBills     = finDb.bills.all();
  const allPayroll   = finDb.payroll.all();

  const revenues = useMemo(() => filterByPeriod(allRevenues, from, to), [allRevenues, from, to]);
  const expenses = useMemo(() => filterByPeriod(allExpenses, from, to), [allExpenses, from, to]);
  const sales    = useMemo(() => filterByPeriod(allSales,    from, to), [allSales, from, to]);
  const orders   = useMemo(() => allOrders.filter(o => o.orderDate >= from && o.orderDate <= to), [allOrders, from, to]);

  // Summary numbers
  const totalReceitas  = revenues.filter(r => r.status === 'Pago').reduce((s,r) => s + r.value, 0);
  const totalDespesas  = expenses.filter(e => e.status === 'Pago').reduce((s,e) => s + e.value, 0);
  const saldo          = totalReceitas - totalDespesas;
  const faturamento    = sales.reduce((s, sale) => s + sale.grossValue, 0);
  const valorRecebido  = sales.filter(s => s.status === 'Recebido').reduce((s, sale) => s + sale.netValue, 0);
  const aReceber       = sales.filter(s => s.status === 'A receber').reduce((s, sale) => s + sale.netValue, 0);
  const totalTaxas     = sales.reduce((s, sale) => s + sale.feeValue, 0);
  const lucroBruto     = totalReceitas - expenses.filter(e => e.category === 'Compra de estoque' && e.status === 'Pago').reduce((s,e) => s + e.value, 0);
  const margem         = faturamento > 0 ? ((lucroBruto / faturamento) * 100) : 0;

  // Expenses breakdown
  const expByCategory: Record<string, number> = {};
  expenses.filter(e => e.status === 'Pago').forEach(e => {
    expByCategory[e.category] = (expByCategory[e.category] ?? 0) + e.value;
  });

  // Sales by method
  const salesByMethod: Record<string, { count: number; gross: number; fee: number; net: number }> = {};
  sales.forEach(s => {
    if (!salesByMethod[s.paymentMethod]) salesByMethod[s.paymentMethod] = { count: 0, gross: 0, fee: 0, net: 0 };
    salesByMethod[s.paymentMethod].count++;
    salesByMethod[s.paymentMethod].gross += s.grossValue;
    salesByMethod[s.paymentMethod].fee   += s.feeValue;
    salesByMethod[s.paymentMethod].net   += s.netValue;
  });

  // Payroll months in period
  const months = new Set<string>();
  for (let d = new Date(from + 'T00:00:00'); d <= new Date(to + 'T00:00:00'); d.setMonth(d.getMonth() + 1)) {
    months.add(d.toISOString().slice(0, 7));
  }
  const periodPayroll = allPayroll.filter(p => months.has(p.month));
  const payrollPago    = periodPayroll.filter(p => p.status === 'Pago').reduce((s,p) => s + p.total, 0);
  const payrollPend    = periodPayroll.filter(p => p.status === 'Pendente').reduce((s,p) => s + p.total, 0);

  const printDate = new Date().toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  const sinp: React.CSSProperties = {
    padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none',
    background: C.white, color: C.text,
  };

  return (
    <div>
      {/* Controls — hidden on print */}
      <div className="no-print" style={{ display: 'flex', gap: 8, marginBottom: 20, alignItems: 'center', flexWrap: 'wrap' as const }}>
        <select value={period} onChange={e => setPeriod(e.target.value)} style={sinp}>
          {PERIODS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <select value={reportType} onChange={e => setReportType(e.target.value)} style={sinp}>
          {REPORT_TYPES.map(r => <option key={r.value} value={r.value}>{r.label}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        <button
          onClick={() => window.print()}
          style={{
            padding: '6px 16px', fontSize: 13, fontFamily: 'Inter, sans-serif',
            background: C.navy, color: '#fff', border: 'none',
            borderRadius: 4, cursor: 'pointer',
          }}
        >
          Imprimir / Exportar PDF
        </button>
      </div>

      {/* Report body */}
      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: 6, padding: '24px 28px', maxWidth: 800 }}>
        {/* Report header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24, paddingBottom: 16, borderBottom: `1px solid ${C.border}` }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 700, color: C.navy }}>Papelaria Central</div>
            <div style={{ fontSize: 13, color: C.textMuted, marginTop: 2 }}>
              {REPORT_TYPES.find(r => r.value === reportType)?.label} — {periodLabel}
            </div>
            <div style={{ fontSize: 12, color: C.textMuted, marginTop: 1 }}>
              Período: {from.split('-').reverse().join('/')} a {to.split('-').reverse().join('/')}
            </div>
          </div>
          <div style={{ fontSize: 11, color: C.textMuted, textAlign: 'right' as const }}>
            Gerado em<br />{printDate}
          </div>
        </div>

        {/* ── RELATÓRIO GERAL ── */}
        {(reportType === 'geral') && (
          <>
            <SectionHeader>Resumo financeiro</SectionHeader>
            <Row label="Faturamento bruto (vendas)"      value={fmtBRL(faturamento)} />
            <Row label="Taxas de cartão / operadoras"    value={`− ${fmtBRL(totalTaxas)}`} />
            <Row label="Valor efetivamente recebido"     value={fmtBRL(valorRecebido)} />
            <Row label="A receber (em aberto)"           value={fmtBRL(aReceber)} />
            <Row label="Total de entradas (receitas)"    value={fmtBRL(totalReceitas)} />
            <Row label="Total de saídas (despesas)"      value={`− ${fmtBRL(totalDespesas)}`} />
            <Row label="Saldo do período"                value={fmtBRL(saldo)} bold />
            <Row label="Lucro bruto estimado"            value={fmtBRL(lucroBruto)} bold />
            <Row label="Margem bruta estimada"           value={`${margem.toFixed(1)}%`} bold />

            <SectionHeader>Despesas por categoria</SectionHeader>
            {Object.entries(expByCategory).sort(([,a],[,b]) => b - a).map(([cat, val]) => (
              <Row key={cat} label={cat} value={fmtBRL(val)} />
            ))}
            {Object.keys(expByCategory).length === 0 && (
              <div style={{ fontSize: 13, color: C.textMuted, padding: '8px 0' }}>Nenhuma despesa no período.</div>
            )}

            <SectionHeader>Contas pendentes</SectionHeader>
            {allBills.filter(b => b.status !== 'Pago').map(b => (
              <Row key={b.id} label={`${b.description} (venc. ${b.dueDate.split('-').reverse().join('/')})`} value={fmtBRL(b.value)} />
            ))}
            {allBills.filter(b => b.status !== 'Pago').length === 0 && (
              <div style={{ fontSize: 13, color: C.textMuted, padding: '8px 0' }}>Nenhuma conta pendente.</div>
            )}
          </>
        )}

        {/* ── RELATÓRIO VENDAS ── */}
        {reportType === 'vendas' && (
          <>
            <SectionHeader>Resumo de vendas</SectionHeader>
            <Row label="Total de vendas"           value={String(sales.length)} />
            <Row label="Faturamento bruto"         value={fmtBRL(faturamento)} />
            <Row label="Total de taxas"            value={fmtBRL(totalTaxas)} />
            <Row label="Valor líquido total"       value={fmtBRL(faturamento - totalTaxas)} bold />
            <Row label="Recebido"                  value={fmtBRL(valorRecebido)} />
            <Row label="A receber"                 value={fmtBRL(aReceber)} />

            <SectionHeader>Por forma de pagamento</SectionHeader>
            {Object.entries(salesByMethod).sort(([,a],[,b]) => b.gross - a.gross).map(([method, data]) => (
              <div key={method} style={{ padding: '8px 0', borderBottom: `1px solid ${C.borderLight}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>{method} ({data.count} venda{data.count !== 1 ? 's' : ''})</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.navy }}>{fmtBRL(data.gross)}</span>
                </div>
                {data.fee > 0 && (
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
                    <span style={{ fontSize: 12, color: C.textMuted }}>Taxa: {fmtBRL(data.fee)}</span>
                    <span style={{ fontSize: 12, color: '#027A48' }}>Líquido: {fmtBRL(data.net)}</span>
                  </div>
                )}
              </div>
            ))}

            <SectionHeader>Detalhamento — A receber</SectionHeader>
            {sales.filter(s => s.status === 'A receber').length === 0 && (
              <div style={{ fontSize: 13, color: C.textMuted, padding: '8px 0' }}>Nenhum valor pendente no período.</div>
            )}
            {sales.filter(s => s.status === 'A receber').map(s => (
              <Row
                key={s.id}
                label={`${s.saleNumber} · ${s.client} (prev. ${s.expectedDate.split('-').reverse().join('/')})`}
                value={fmtBRL(s.netValue)}
              />
            ))}
          </>
        )}

        {/* ── RELATÓRIO DESPESAS ── */}
        {reportType === 'despesas' && (
          <>
            <SectionHeader>Resumo de despesas</SectionHeader>
            <Row label="Total de despesas"  value={fmtBRL(totalDespesas)} bold />
            <Row label="Despesas pagas"     value={fmtBRL(expenses.filter(e => e.status === 'Pago').reduce((s,e) => s + e.value, 0))} />
            <Row label="Despesas pendentes" value={fmtBRL(expenses.filter(e => e.status === 'Pendente').reduce((s,e) => s + e.value, 0))} />

            <SectionHeader>Por categoria</SectionHeader>
            {Object.entries(expByCategory).sort(([,a],[,b]) => b - a).map(([cat, val]) => (
              <Row key={cat} label={cat} value={fmtBRL(val)} />
            ))}

            <SectionHeader>Detalhamento</SectionHeader>
            {expenses.sort((a,b) => a.date.localeCompare(b.date)).map(e => (
              <Row
                key={e.id}
                label={`${e.date.split('-').reverse().join('/')} · ${e.description} · ${e.category}`}
                value={fmtBRL(e.value)}
              />
            ))}
          </>
        )}

        {/* ── RELATÓRIO FOLHA ── */}
        {reportType === 'folha' && (
          <>
            <SectionHeader>Folha de pagamento</SectionHeader>
            <Row label="Total pago"    value={fmtBRL(payrollPago)} />
            <Row label="Total pendente" value={fmtBRL(payrollPend)} />
            <Row label="Total geral"   value={fmtBRL(payrollPago + payrollPend)} bold />

            {[...months].sort().map(month => {
              const mp = allPayroll.filter(p => p.month === month);
              if (!mp.length) return null;
              const [y, m] = month.split('-');
              return (
                <div key={month}>
                  <SectionHeader>{MONTHS[parseInt(m)-1]}/{y}</SectionHeader>
                  {mp.map(p => (
                    <Row
                      key={p.id}
                      label={`${p.name} — ${p.jobTitle}`}
                      value={`${fmtBRL(p.total)} · ${p.status}`}
                    />
                  ))}
                </div>
              );
            })}
          </>
        )}

        {/* ── RELATÓRIO PEDIDOS ── */}
        {reportType === 'pedidos' && (
          <>
            <SectionHeader>Resumo de pedidos</SectionHeader>
            <Row label="Total de pedidos"     value={String(orders.length)} />
            <Row label="Valor total"          value={fmtBRL(orders.reduce((s,o) => s + o.total, 0))} bold />
            <Row label="Pedidos entregues"    value={String(orders.filter(o => o.status === 'Entregue').length)} />
            <Row label="Pedidos em aberto"    value={String(orders.filter(o => o.status !== 'Entregue' && o.status !== 'Cancelado').length)} />
            <Row label="Pedidos cancelados"   value={String(orders.filter(o => o.status === 'Cancelado').length)} />

            <SectionHeader>Detalhamento</SectionHeader>
            {orders.sort((a,b) => a.orderDate.localeCompare(b.orderDate)).map(o => (
              <div key={o.id} style={{ padding: '8px 0', borderBottom: `1px solid ${C.borderLight}` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: 13, fontWeight: 500, color: C.text }}>{o.orderNumber} · {o.client}</span>
                  <span style={{ fontSize: 13, fontWeight: 600, color: C.navy }}>{fmtBRL(o.total)}</span>
                </div>
                <div style={{ fontSize: 12, color: C.textMuted, marginTop: 2 }}>
                  {o.orderDate.split('-').reverse().join('/')} · {o.products} · {o.status}
                </div>
              </div>
            ))}
            {orders.length === 0 && (
              <div style={{ fontSize: 13, color: C.textMuted, padding: '8px 0' }}>Nenhum pedido no período.</div>
            )}
          </>
        )}

        {/* Footer */}
        <div style={{ marginTop: 32, paddingTop: 12, borderTop: `1px solid ${C.border}`, fontSize: 11, color: C.textMuted }}>
          Papelaria Central — Sistema de Gestão · Relatório gerado em {printDate}
        </div>
      </div>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          body { background: white; }
        }
      `}</style>
    </div>
  );
}
