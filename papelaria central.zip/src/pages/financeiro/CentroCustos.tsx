import { useState, useMemo, Fragment } from 'react';
import { finDb, filterByPeriod, periodRange, fmtBRL } from '../../data/finDb';
import { marketingDb } from '../../data/marketingDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER, formCard } from '../../theme';

// ─── Cost center → expense category mapping ───────────────────────────────
const CENTERS: Record<string, string[]> = {
  'Estoque/Fornecedores': ['Compra de estoque', 'Fornecedores'],
  'Funcionários': ['Salários', 'VR', 'VT'],
  'Infraestrutura': ['Aluguel', 'Energia', 'Internet'],
  'Marketing': ['Marketing'],
  'Administrativo': ['Outras despesas'],
};

const CAT_TO_CENTER: Record<string, string> = {};
for (const [center, cats] of Object.entries(CENTERS)) {
  for (const cat of cats) CAT_TO_CENTER[cat] = center;
}

const PERIOD_OPTS = [
  { key: 'mes',  label: 'Este mês' },
  { key: '3m',   label: '3 meses' },
  { key: '6m',   label: '6 meses' },
  { key: '12m',  label: '12 meses' },
  { key: 'tudo', label: 'Desde jun/2025' },
];

const CENTER_COLORS: Record<string, string> = {
  'Estoque/Fornecedores': '#3B82F6',
  'Funcionários':         '#8B5CF6',
  'Infraestrutura':       '#F59E0B',
  'Marketing':            '#EC4899',
  'Administrativo':       '#6B7280',
};

// ─── Types ────────────────────────────────────────────────────────────────
interface CenterItem {
  id: string;
  date: string;
  description: string;
  value: number;
  status: string;
}

interface PayrollItem {
  id: string;
  name: string;
  month: string;
  total: number;
  status: string;
}

interface CenterData {
  name: string;
  total: number;
  count: number;
  pct: number;
  items: CenterItem[];
  payrollItems: PayrollItem[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────
function statusBadge(s: string): React.CSSProperties {
  if (s === 'Pago')     return { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5', borderRadius: 4, padding: '1px 6px', fontSize: 11 };
  if (s === 'Pendente') return { background: '#FFFAEB', color: '#B54708', border: '1px solid #FDE68A', borderRadius: 4, padding: '1px 6px', fontSize: 11 };
  return { background: '#FEF2F2', color: '#B91C1C', border: '1px solid #FECACA', borderRadius: 4, padding: '1px 6px', fontSize: 11 };
}

function fmt(iso: string) { return iso.split('-').reverse().join('/'); }

// ─── Component ────────────────────────────────────────────────────────────
export default function CentroCustos() {
  const [period, setPeriod]   = useState('mes');
  const [expanded, setExpanded] = useState<string | null>(null);

  const { centers, grandTotal } = useMemo(() => {
    const { from, to } = periodRange(period);

    const expenses  = filterByPeriod(finDb.expenses.all(), from, to);
    const mktGastos = filterByPeriod(marketingDb.get().gastos, from, to);
    const payroll   = finDb.payroll.all().filter(
      p => p.month >= from.slice(0, 7) && p.month <= to.slice(0, 7)
    );

    // Build per-center item lists
    const centerMap: Record<string, CenterItem[]> = {};
    for (const name of Object.keys(CENTERS)) centerMap[name] = [];

    for (const exp of expenses) {
      const center = CAT_TO_CENTER[exp.category];
      if (center) {
        centerMap[center].push({
          id: exp.id, date: exp.date,
          description: exp.description,
          value: exp.value, status: exp.status,
        });
      }
    }

    for (const g of mktGastos) {
      centerMap['Marketing'].push({
        id: g.id, date: g.date,
        description: `${g.campanha} (${g.canal})`,
        value: g.valor, status: 'Pago',
      });
    }

    const grandTotal = Object.values(centerMap).flat().reduce((s, i) => s + i.value, 0);

    const payrollItems: PayrollItem[] = payroll.map(p => ({
      id: p.id, name: p.name, month: p.month, total: p.total, status: p.status,
    }));

    const centers: CenterData[] = Object.entries(centerMap)
      .map(([name, items]) => {
        const total = items.reduce((s, i) => s + i.value, 0);
        return {
          name, total,
          count: items.length,
          pct: grandTotal > 0 ? (total / grandTotal) * 100 : 0,
          items: [...items].sort((a, b) => b.date.localeCompare(a.date)),
          payrollItems: name === 'Funcionários' ? payrollItems : [],
        };
      })
      .sort((a, b) => b.total - a.total);

    return { centers, grandTotal };
  }, [period]);

  const toggle = (name: string) => setExpanded(x => (x === name ? null : name));

  const totalLancamentos = centers.reduce((s, c) => s + c.count, 0);
  const activeCenters    = centers.filter(c => c.count > 0 || c.payrollItems.length > 0).length;

  return (
    <div style={{ fontFamily: 'Inter, sans-serif', color: C.text }}>

      {/* ── Period filter ── */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' as const }}>
        {PERIOD_OPTS.map(p => (
          <button
            key={p.key}
            onClick={() => { setPeriod(p.key); setExpanded(null); }}
            style={{
              padding: '5px 12px', fontSize: 12, borderRadius: 5, cursor: 'pointer',
              fontFamily: 'Inter, sans-serif',
              background: period === p.key ? C.navy : C.white,
              color:      period === p.key ? '#fff' : C.text,
              border:     `1px solid ${period === p.key ? C.navy : C.border}`,
              fontWeight: period === p.key ? 500 : 400,
            }}
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* ── Summary bar ── */}
      <div style={{ ...formCard, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 32, flexWrap: 'wrap' as const }}>
        {[
          { label: 'Total gasto no período', value: fmtBRL(grandTotal), color: C.text },
          { label: 'Centros com lançamentos', value: String(activeCenters), color: C.text },
          { label: 'Total de lançamentos', value: String(totalLancamentos), color: C.text },
        ].map((kpi, idx) => (
          <Fragment key={kpi.label}>
            {idx > 0 && <div style={{ width: 1, height: 40, background: C.borderLight }} />}
            <div>
              <div style={{ fontSize: 11, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.04em', marginBottom: 2 }}>
                {kpi.label}
              </div>
              <div style={{ fontSize: 20, fontWeight: 600, color: kpi.color }}>{kpi.value}</div>
            </div>
          </Fragment>
        ))}
      </div>

      {/* ── Centers table ── */}
      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Centro de custo', 'Total gasto', '% do total', 'Lançamentos', 'Distribuição', ''].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {centers.map((c, i) => {
              const color  = CENTER_COLORS[c.name] ?? '#6B7280';
              const isOpen = expanded === c.name;
              return (
                <Fragment key={c.name}>
                  {/* ── Main row ── */}
                  <tr
                    style={{ borderTop: i > 0 ? ROW_BORDER : undefined, cursor: 'pointer', background: isOpen ? '#F8F9FB' : undefined }}
                    onClick={() => toggle(c.name)}
                  >
                    <td style={{ ...TD, fontWeight: 500 }}>
                      <span style={{
                        display: 'inline-block', width: 8, height: 8,
                        borderRadius: '50%', background: color, marginRight: 8, verticalAlign: 'middle',
                      }} />
                      {c.name}
                    </td>
                    <td style={{ ...TD, fontWeight: 600, color: c.total > 0 ? C.text : C.textMuted }}>
                      {c.total > 0 ? fmtBRL(c.total) : '—'}
                    </td>
                    <td style={{ ...TD, color: C.textMuted }}>
                      {c.pct > 0 ? `${c.pct.toFixed(1)}%` : '—'}
                    </td>
                    <td style={{ ...TD, color: C.textMuted }}>{c.count}</td>
                    <td style={{ ...TD, minWidth: 160 }}>
                      <div style={{ background: C.metalMid, borderRadius: 4, height: 8, width: '100%', overflow: 'hidden' }}>
                        <div style={{
                          height: '100%', borderRadius: 4, background: color,
                          width: `${Math.min(c.pct, 100)}%`,
                          transition: 'width 0.3s ease',
                        }} />
                      </div>
                    </td>
                    <td style={{ ...TD, color: C.textMuted, fontSize: 12, textAlign: 'center' as const }}>
                      {isOpen ? '▲' : '▼'}
                    </td>
                  </tr>

                  {/* ── Expanded detail ── */}
                  {isOpen && (
                    <tr style={{ background: '#FAFBFC' }}>
                      <td colSpan={6} style={{ padding: 0, borderTop: ROW_BORDER }}>
                        <div style={{ padding: '0 0 4px' }}>

                          {/* Expense items */}
                          {c.items.length > 0 && (
                            <table style={{ ...tbl, fontSize: 12 }}>
                              <thead>
                                <tr>
                                  {['Data', 'Descrição', 'Valor', 'Status'].map(h => (
                                    <th key={h} style={{ ...TH, fontSize: 10, background: '#F0F2F5' }}>{h}</th>
                                  ))}
                                </tr>
                              </thead>
                              <tbody>
                                {c.items.map((item, idx) => (
                                  <tr key={item.id} style={{ borderTop: idx > 0 ? ROW_BORDER : undefined }}>
                                    <td style={{ ...TD, color: C.textMuted, whiteSpace: 'nowrap' as const }}>{fmt(item.date)}</td>
                                    <td style={TD}>{item.description}</td>
                                    <td style={{ ...TD, fontWeight: 500, whiteSpace: 'nowrap' as const }}>{fmtBRL(item.value)}</td>
                                    <td style={TD}><span style={statusBadge(item.status)}>{item.status}</span></td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          )}

                          {/* Payroll breakdown (Funcionários only) */}
                          {c.payrollItems.length > 0 && (
                            <div style={{ borderTop: c.items.length > 0 ? ROW_BORDER : undefined }}>
                              <div style={{ padding: '8px 12px 4px', fontSize: 10, fontWeight: 600, color: C.textMuted, textTransform: 'uppercase' as const, letterSpacing: '0.05em' }}>
                                Detalhamento folha de pagamento
                              </div>
                              <table style={{ ...tbl, fontSize: 12 }}>
                                <thead>
                                  <tr>
                                    {['Funcionário', 'Competência', 'Total (salário + VR + VT)', 'Status'].map(h => (
                                      <th key={h} style={{ ...TH, fontSize: 10, background: '#ECEEF2' }}>{h}</th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  {c.payrollItems.map((p, idx) => (
                                    <tr key={p.id} style={{ borderTop: idx > 0 ? ROW_BORDER : undefined }}>
                                      <td style={TD}>{p.name}</td>
                                      <td style={{ ...TD, color: C.textMuted }}>{p.month}</td>
                                      <td style={{ ...TD, fontWeight: 500 }}>{fmtBRL(p.total)}</td>
                                      <td style={TD}><span style={statusBadge(p.status)}>{p.status}</span></td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          )}

                          {/* Empty state */}
                          {c.items.length === 0 && c.payrollItems.length === 0 && (
                            <div style={{ padding: '12px 16px', color: C.textMuted, fontSize: 12, fontStyle: 'italic' }}>
                              Sem lançamentos no período selecionado.
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
