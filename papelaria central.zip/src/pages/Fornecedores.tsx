import { useState } from 'react';
import { C, inp, btnPrimary, btnSecondary, tbl, TH, TD, tableWrap, ROW_BORDER, badge } from '../theme';
import { Badge } from '../components/Badge';
import { Modal, Toast } from './Produtos';
import { useApp } from '../context/AppContext';
import { fornecedoresDb, DBFornecedor } from '../data/fornecedoresDb';

function newId() {
  return 'f-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function formatCnpj(v: string) {
  const d = v.replace(/\D/g, '').slice(0, 14);
  if (d.length <= 2) return d;
  if (d.length <= 5) return d.slice(0, 2) + '.' + d.slice(2);
  if (d.length <= 8) return d.slice(0, 2) + '.' + d.slice(2, 5) + '.' + d.slice(5);
  if (d.length <= 12) return d.slice(0, 2) + '.' + d.slice(2, 5) + '.' + d.slice(5, 8) + '/' + d.slice(8);
  return d.slice(0, 2) + '.' + d.slice(2, 5) + '.' + d.slice(5, 8) + '/' + d.slice(8, 12) + '-' + d.slice(12);
}

function isCnpjValid(cnpj: string) {
  return /^\d{2}\.\d{3}\.\d{3}\/\d{4}-\d{2}$/.test(cnpj);
}

const ESTADOS = [
  'AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG',
  'PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO',
];

interface FormState {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual: string;
  email: string;
  telefone: string;
  whatsapp: string;
  cep: string;
  endereco: string;
  numero: string;
  bairro: string;
  cidade: string;
  estado: string;
  contato: string;
  observacoes: string;
  status: 'Ativo' | 'Inativo';
}

const EMPTY_FORM: FormState = {
  razaoSocial: '',
  nomeFantasia: '',
  cnpj: '',
  inscricaoEstadual: '',
  email: '',
  telefone: '',
  whatsapp: '',
  cep: '',
  endereco: '',
  numero: '',
  bairro: '',
  cidade: '',
  estado: 'SP',
  contato: '',
  observacoes: '',
  status: 'Ativo',
};

function toForm(f: DBFornecedor): FormState {
  return {
    razaoSocial: f.razaoSocial,
    nomeFantasia: f.nomeFantasia,
    cnpj: f.cnpj,
    inscricaoEstadual: f.inscricaoEstadual ?? '',
    email: f.email,
    telefone: f.telefone,
    whatsapp: f.whatsapp ?? '',
    cep: f.cep ?? '',
    endereco: f.endereco ?? '',
    numero: f.numero ?? '',
    bairro: f.bairro ?? '',
    cidade: f.cidade,
    estado: f.estado,
    contato: f.contato ?? '',
    observacoes: f.observacoes ?? '',
    status: f.status,
  };
}

export default function Fornecedores() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';

  const [list, setList] = useState<DBFornecedor[]>(() => fornecedoresDb.all());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'Todos' | 'Ativo' | 'Inativo'>('Todos');
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<DBFornecedor | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [toast, setToast] = useState('');

  const refresh = () => setList(fornecedoresDb.all());

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => {
    setForm(f => ({ ...f, [k]: v }));
    setErrors(e => ({ ...e, [k]: undefined }));
  };

  const openNew = () => {
    setEditing(null);
    setForm(EMPTY_FORM);
    setErrors({});
    setShowModal(true);
  };

  const openEdit = (f: DBFornecedor) => {
    setEditing(f);
    setForm(toForm(f));
    setErrors({});
    setShowModal(true);
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 3500);
  };

  const validate = (): Partial<Record<keyof FormState, string>> => {
    const e: Partial<Record<keyof FormState, string>> = {};
    if (!form.razaoSocial.trim()) e.razaoSocial = 'Campo obrigatório.';
    if (!form.nomeFantasia.trim()) e.nomeFantasia = 'Campo obrigatório.';
    if (!form.cnpj.trim()) {
      e.cnpj = 'Campo obrigatório.';
    } else if (!isCnpjValid(form.cnpj)) {
      e.cnpj = 'CNPJ inválido. Use o formato XX.XXX.XXX/XXXX-XX.';
    } else {
      const duplicate = fornecedoresDb.all().find(f => f.cnpj === form.cnpj && f.id !== editing?.id);
      if (duplicate) e.cnpj = 'CNPJ já cadastrado.';
    }
    if (!form.email.trim()) {
      e.email = 'Campo obrigatório.';
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      e.email = 'E-mail inválido.';
    }
    if (!form.cidade.trim()) e.cidade = 'Campo obrigatório.';
    return e;
  };

  const save = () => {
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }
    const payload: Omit<DBFornecedor, 'id' | 'createdAt'> = {
      razaoSocial: form.razaoSocial.trim(),
      nomeFantasia: form.nomeFantasia.trim(),
      cnpj: form.cnpj,
      inscricaoEstadual: form.inscricaoEstadual.trim() || undefined,
      email: form.email.trim().toLowerCase(),
      telefone: form.telefone.trim(),
      whatsapp: form.whatsapp.trim() || undefined,
      cep: form.cep.trim() || undefined,
      endereco: form.endereco.trim() || undefined,
      numero: form.numero.trim() || undefined,
      bairro: form.bairro.trim() || undefined,
      cidade: form.cidade.trim(),
      estado: form.estado,
      contato: form.contato.trim() || undefined,
      observacoes: form.observacoes.trim() || undefined,
      status: form.status,
    };
    if (editing) {
      fornecedoresDb.update(editing.id, payload);
      showToast('Fornecedor atualizado com sucesso.');
    } else {
      fornecedoresDb.add({ ...payload, id: newId(), createdAt: new Date().toISOString() });
      showToast('Fornecedor cadastrado com sucesso.');
    }
    setShowModal(false);
    refresh();
  };

  const toggleStatus = (f: DBFornecedor) => {
    const next = f.status === 'Ativo' ? 'Inativo' : 'Ativo';
    fornecedoresDb.update(f.id, { status: next });
    refresh();
    showToast(`Fornecedor ${next === 'Ativo' ? 'ativado' : 'inativado'}.`);
  };

  const filtered = list.filter(f => {
    if (statusFilter !== 'Todos' && f.status !== statusFilter) return false;
    const q = search.toLowerCase();
    if (!q) return true;
    return (
      f.nomeFantasia.toLowerCase().includes(q) ||
      f.razaoSocial.toLowerCase().includes(q) ||
      f.cnpj.replace(/\D/g, '').includes(q.replace(/\D/g, '')) ||
      f.cidade.toLowerCase().includes(q)
    );
  });

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 14, flexWrap: 'wrap' }}>
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar por nome, CNPJ ou cidade..."
          style={sinp}
        />
        <select
          value={statusFilter}
          onChange={e => setStatusFilter(e.target.value as typeof statusFilter)}
          style={selStyle}
        >
          <option value="Todos">Todos</option>
          <option value="Ativo">Ativos</option>
          <option value="Inativo">Inativos</option>
        </select>
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted }}>
          {filtered.length} registro{filtered.length !== 1 ? 's' : ''}
        </span>
        {isAdmin && (
          <button onClick={openNew} style={btnPrimary}>+ Novo fornecedor</button>
        )}
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>
              {['Nome Fantasia', 'CNPJ', 'Cidade / UF', 'Telefone', 'Contato', 'Status', 'Ações'].map(h => (
                <th key={h} style={TH}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((f, i) => (
              <tr key={f.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>
                  <div>{f.nomeFantasia}</div>
                  <div style={{ fontSize: 11, color: C.textMuted, marginTop: 1 }}>{f.razaoSocial}</div>
                </td>
                <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{f.cnpj}</td>
                <td style={{ ...TD, color: C.textMuted }}>{f.cidade} / {f.estado}</td>
                <td style={{ ...TD, color: C.textMuted }}>{f.telefone || '—'}</td>
                <td style={{ ...TD, color: C.textMuted }}>{f.contato || '—'}</td>
                <td style={TD}>
                  <Badge style={f.status === 'Ativo' ? badge.active : badge.inactive}>{f.status}</Badge>
                </td>
                <td style={TD}>
                  {isAdmin && (
                    <>
                      <button onClick={() => openEdit(f)} style={actBtn}>Editar</button>
                      <button
                        onClick={() => toggleStatus(f)}
                        style={{ ...actBtn, color: C.textMuted }}
                      >
                        {f.status === 'Ativo' ? 'Desativar' : 'Ativar'}
                      </button>
                    </>
                  )}
                  {!isAdmin && (
                    <span style={{ fontSize: 12, color: C.textMuted }}>—</span>
                  )}
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '28px 12px' }}>
                  Nenhum fornecedor encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal
          title={editing ? `Editar fornecedor — ${editing.nomeFantasia}` : 'Novo fornecedor'}
          onClose={() => setShowModal(false)}
        >
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>

            {/* Dados da empresa */}
            <section>
              <div style={sectionLabel}>Dados da empresa</div>
              <div style={grid2}>
                <div style={{ gridColumn: '1/-1' }}>
                  <F label="Razão Social *" err={errors.razaoSocial}>
                    <input
                      value={form.razaoSocial}
                      onChange={e => set('razaoSocial', e.target.value)}
                      placeholder="Razão Social Ltda"
                      style={inp(!!errors.razaoSocial)}
                    />
                  </F>
                </div>
                <F label="Nome Fantasia *" err={errors.nomeFantasia}>
                  <input
                    value={form.nomeFantasia}
                    onChange={e => set('nomeFantasia', e.target.value)}
                    placeholder="Nome Fantasia"
                    style={inp(!!errors.nomeFantasia)}
                  />
                </F>
                <F label="Status" err="">
                  <select
                    value={form.status}
                    onChange={e => set('status', e.target.value as 'Ativo' | 'Inativo')}
                    style={inp()}
                  >
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                  </select>
                </F>
                <F label="CNPJ *" err={errors.cnpj}>
                  <input
                    value={form.cnpj}
                    onChange={e => set('cnpj', formatCnpj(e.target.value))}
                    placeholder="XX.XXX.XXX/XXXX-XX"
                    maxLength={18}
                    style={{ ...inp(!!errors.cnpj), fontFamily: 'monospace' }}
                  />
                </F>
                <F label="Inscrição Estadual" err="">
                  <input
                    value={form.inscricaoEstadual}
                    onChange={e => set('inscricaoEstadual', e.target.value)}
                    placeholder="Opcional"
                    style={inp()}
                  />
                </F>
              </div>
            </section>

            {/* Contato */}
            <section>
              <div style={sectionLabel}>Contato</div>
              <div style={grid2}>
                <div style={{ gridColumn: '1/-1' }}>
                  <F label="E-mail *" err={errors.email}>
                    <input
                      type="email"
                      value={form.email}
                      onChange={e => set('email', e.target.value)}
                      placeholder="email@empresa.com.br"
                      style={inp(!!errors.email)}
                    />
                  </F>
                </div>
                <F label="Telefone" err="">
                  <input
                    value={form.telefone}
                    onChange={e => set('telefone', e.target.value)}
                    placeholder="(11) 3000-0000"
                    style={inp()}
                  />
                </F>
                <F label="WhatsApp" err="">
                  <input
                    value={form.whatsapp}
                    onChange={e => set('whatsapp', e.target.value)}
                    placeholder="(11) 99000-0000"
                    style={inp()}
                  />
                </F>
                <div style={{ gridColumn: '1/-1' }}>
                  <F label="Responsável (nome do contato)" err="">
                    <input
                      value={form.contato}
                      onChange={e => set('contato', e.target.value)}
                      placeholder="Nome do responsável comercial"
                      style={inp()}
                    />
                  </F>
                </div>
              </div>
            </section>

            {/* Endereço */}
            <section>
              <div style={sectionLabel}>Endereço</div>
              <div style={grid2}>
                <F label="CEP" err="">
                  <input
                    value={form.cep}
                    onChange={e => set('cep', e.target.value)}
                    placeholder="00000-000"
                    maxLength={9}
                    style={inp()}
                  />
                </F>
                <div />
                <div style={{ gridColumn: '1/-1' }}>
                  <F label="Logradouro" err="">
                    <input
                      value={form.endereco}
                      onChange={e => set('endereco', e.target.value)}
                      placeholder="Rua / Av. / Alameda"
                      style={inp()}
                    />
                  </F>
                </div>
                <F label="Número" err="">
                  <input
                    value={form.numero}
                    onChange={e => set('numero', e.target.value)}
                    placeholder="123"
                    style={inp()}
                  />
                </F>
                <F label="Bairro" err="">
                  <input
                    value={form.bairro}
                    onChange={e => set('bairro', e.target.value)}
                    placeholder="Bairro"
                    style={inp()}
                  />
                </F>
                <F label="Cidade *" err={errors.cidade}>
                  <input
                    value={form.cidade}
                    onChange={e => set('cidade', e.target.value)}
                    placeholder="Cidade"
                    style={inp(!!errors.cidade)}
                  />
                </F>
                <F label="Estado" err="">
                  <select
                    value={form.estado}
                    onChange={e => set('estado', e.target.value)}
                    style={inp()}
                  >
                    {ESTADOS.map(uf => (
                      <option key={uf} value={uf}>{uf}</option>
                    ))}
                  </select>
                </F>
              </div>
            </section>

            {/* Observações */}
            <section>
              <div style={sectionLabel}>Observações</div>
              <F label="" err="">
                <textarea
                  value={form.observacoes}
                  onChange={e => set('observacoes', e.target.value)}
                  placeholder="Condições de pagamento, prazo de entrega, observações gerais..."
                  rows={3}
                  style={{ ...inp(), resize: 'vertical' as const }}
                />
              </F>
            </section>
          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 20, paddingTop: 16, borderTop: `1px solid ${C.borderLight}` }}>
            <button onClick={() => setShowModal(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function F({ label: lbl, err, children }: { label: string; err: string | undefined; children: React.ReactNode }) {
  return (
    <div>
      {lbl && (
        <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>
          {lbl}
        </label>
      )}
      {children}
      {err && <span style={{ display: 'block', fontSize: 11, color: C.error, marginTop: 3 }}>{err}</span>}
    </div>
  );
}

const sinp: React.CSSProperties = {
  padding: '6px 10px',
  fontSize: 13,
  fontFamily: 'Inter, sans-serif',
  border: `1px solid ${C.border}`,
  borderRadius: 4,
  outline: 'none',
  background: C.white,
  color: C.text,
  width: 280,
};

const selStyle: React.CSSProperties = {
  padding: '6px 10px',
  fontSize: 13,
  fontFamily: 'Inter, sans-serif',
  border: `1px solid ${C.border}`,
  borderRadius: 4,
  outline: 'none',
  background: C.white,
  color: C.text,
  cursor: 'pointer',
};

const actBtn: React.CSSProperties = {
  padding: '3px 8px',
  fontSize: 12,
  fontFamily: 'Inter, sans-serif',
  background: 'none',
  color: C.navy,
  border: 'none',
  cursor: 'pointer',
};

const sectionLabel: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 600,
  color: C.textMuted,
  textTransform: 'uppercase',
  letterSpacing: '0.06em',
  marginBottom: 10,
  paddingBottom: 6,
  borderBottom: `1px solid ${C.borderLight}`,
};

const grid2: React.CSSProperties = {
  display: 'grid',
  gridTemplateColumns: '1fr 1fr',
  gap: 12,
};

export { Toast };
