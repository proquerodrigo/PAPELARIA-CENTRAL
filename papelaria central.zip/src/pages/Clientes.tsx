import { useState } from 'react';
import { C, badge, tbl, TH, TD, tableWrap, btnPrimary, btnSecondary, inp, ROW_BORDER } from '../theme';
import { Badge } from '../components/Badge';
import { Modal, Toast } from './Produtos';
import { db, newId, DBCustomer } from '../data/db';

export default function Clientes() {
  const [clients, setClients] = useState<DBCustomer[]>(() => db.customers.all());
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<DBCustomer | null>(null);
  const [form, setForm] = useState({ name: '', cpf: '', email: '', phone: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [search, setSearch] = useState('');
  const [toast, setToast] = useState('');

  const refresh = () => setClients(db.customers.all());
  const set = (k: string, v: string) => { setForm(f => ({ ...f, [k]: v })); setErrors(x => ({ ...x, [k]: '' })); };
  const openNew = () => { setEditing(null); setForm({ name: '', cpf: '', email: '', phone: '' }); setErrors({}); setShowModal(true); };
  const openEdit = (c: DBCustomer) => { setEditing(c); setForm({ name: c.name, cpf: c.cpf, email: c.email, phone: c.phone }); setErrors({}); setShowModal(true); };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = 'Campo obrigatório.';
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = 'E-mail inválido.';
    if (form.cpf && db.customers.all().some(c => c.cpf === form.cpf && c.id !== editing?.id)) e.cpf = 'CPF/CNPJ já cadastrado.';
    return e;
  };

  const save = () => {
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    if (editing) {
      db.customers.update(editing.id, { name: form.name.trim(), cpf: form.cpf, email: form.email.trim(), phone: form.phone });
      setToast('Cliente atualizado com sucesso.');
    } else {
      db.customers.add({ id: newId(), name: form.name.trim(), cpf: form.cpf, email: form.email.trim().toLowerCase(), phone: form.phone, status: 'Ativo' });
      setToast('Cliente cadastrado com sucesso.');
    }
    setShowModal(false);
    refresh();
    setTimeout(() => setToast(''), 3000);
  };

  const filtered = clients.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) || c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      {toast && <Toast msg={toast} />}

      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 14 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar cliente..." style={sinp} />
        <div style={{ flex: 1 }} />
        <span style={{ fontSize: 12, color: C.textMuted }}>{filtered.length} registro{filtered.length !== 1 ? 's' : ''}</span>
        <button onClick={openNew} style={btnPrimary}>+ Novo cliente</button>
      </div>

      <div style={tableWrap}>
        <table style={tbl}>
          <thead>
            <tr>{['Nome', 'CPF / CNPJ', 'E-mail', 'Telefone', 'Status', 'Ações'].map(h => <th key={h} style={TH}>{h}</th>)}</tr>
          </thead>
          <tbody>
            {filtered.map((c, i) => (
              <tr key={c.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                <td style={{ ...TD, fontWeight: 500 }}>{c.name}</td>
                <td style={{ ...TD, color: C.textMuted, fontFamily: 'monospace', fontSize: 12 }}>{c.cpf || '—'}</td>
                <td style={{ ...TD, color: C.textMuted }}>{c.email}</td>
                <td style={{ ...TD, color: C.textMuted }}>{c.phone || '—'}</td>
                <td style={TD}><Badge style={c.status === 'Ativo' ? badge.active : badge.inactive}>{c.status}</Badge></td>
                <td style={TD}>
                  <button onClick={() => openEdit(c)} style={actBtn}>Editar</button>
                  <button onClick={() => { db.customers.update(c.id, { status: c.status === 'Ativo' ? 'Inativo' : 'Ativo' }); refresh(); }} style={{ ...actBtn, color: C.textMuted }}>
                    {c.status === 'Ativo' ? 'Desativar' : 'Ativar'}
                  </button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={6} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '24px 12px' }}>Nenhum cliente encontrado.</td></tr>}
          </tbody>
        </table>
      </div>

      {showModal && (
        <Modal title={editing ? 'Editar cliente' : 'Novo cliente'} onClose={() => setShowModal(false)}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 18 }}>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="Nome completo *" err={errors.name}>
                <input value={form.name} onChange={e => set('name', e.target.value)} placeholder="Nome" style={inp(!!errors.name)} />
              </F>
            </div>
            <F label="CPF / CNPJ" err={errors.cpf}>
              <input value={form.cpf} onChange={e => set('cpf', e.target.value)} placeholder="000.000.000-00" style={inp(!!errors.cpf)} />
            </F>
            <F label="Telefone" err="">
              <input value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="(11) 99999-0000" style={inp()} />
            </F>
            <div style={{ gridColumn: '1/-1' }}>
              <F label="E-mail *" err={errors.email}>
                <input type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="email@dominio.com" style={inp(!!errors.email)} />
              </F>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={() => setShowModal(false)} style={btnSecondary}>Cancelar</button>
            <button onClick={save} style={btnPrimary}>Salvar</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

function F({ label: lbl, err, children }: { label: string; err: string; children: React.ReactNode }) {
  return (
    <div>
      <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{lbl}</label>
      {children}
      {err && <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 }}>{err}</span>}
    </div>
  );
}

const sinp: React.CSSProperties = { padding: '6px 10px', fontSize: 13, fontFamily: 'Inter, sans-serif', border: `1px solid ${C.border}`, borderRadius: 4, outline: 'none', background: C.white, color: C.text, width: 240 };
const actBtn: React.CSSProperties = { padding: '3px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif', background: 'none', color: C.navy, border: 'none', cursor: 'pointer' };
