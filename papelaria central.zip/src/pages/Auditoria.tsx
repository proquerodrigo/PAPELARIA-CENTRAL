import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { auditDb, type AuditEntry, type AuditModule } from '../data/auditDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER, inp, btnPrimary, btnSecondary } from '../theme';
import { Toast } from './Produtos';

const MODULES: AuditModule[] = [
  'Produtos', 'Estoque', 'Clientes', 'Funcionários',
  'Financeiro', 'Caixa', 'Pedidos', 'Fornecedores', 'Sistema', 'Usuários',
];

const MODULE_BADGE: Record<AuditModule, React.CSSProperties> = {
  Produtos:     { background: '#EFF4FF', color: '#3538CD', border: '1px solid #C7D7FD' },
  Estoque:      { background: '#F0FDF4', color: '#166534', border: '1px solid #86EFAC' },
  Clientes:     { background: '#FFF7ED', color: '#9A3412', border: '1px solid #FDBA74' },
  'Funcionários': { background: '#F5F3FF', color: '#5B21B6', border: '1px solid #C4B5FD' },
  Financeiro:   { background: '#ECFDF5', color: '#065F46', border: '1px solid #6EE7B7' },
  Caixa:        { background: '#FEF9C3', color: '#713F12', border: '1px solid #FDE047' },
  Pedidos:      { background: '#FEF2F2', color: '#991B1B', border: '1px solid #FECACA' },
  Fornecedores: { background: '#F0F9FF', color: '#0C4A6E', border: '1px solid #7DD3FC' },
  Sistema:      { background: '#F8FAFC', color: '#475569', border: '1px solid #CBD5E1' },
  'Usuários':   { background: '#FDF4FF', color: '#6B21A8', border: '1px solid #E9D5FF' },
};

function ModuleBadge({ module }: { module: AuditModule }) {
  return (
    <span style={{
      ...MODULE_BADGE[module],
      fontSize: 11, fontWeight: 500, padding: '2px 7px',
      borderRadius: 4, whiteSpace: 'nowrap',
    }}>
      {module}
    </span>
  );
}

export default function Auditoria() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';

  const [entries, setEntries] = useState<AuditEntry[]>(() =>
    auditDb.all().slice().reverse()
  );
  const [search, setSearch] = useState('');
  const [moduleFilter, setModuleFilter] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [confirmClear, setConfirmClear] = useState(false);
  const [toast, setToast] = useState('');

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return entries.filter(e => {
      if (moduleFilter && e.module !== moduleFilter) return false;

      if (dateFrom) {
        const [fy, fm, fd] = dateFrom.split('-').map(Number);
        const [ed, em, ey] = e.date.split('/').map(Number);
        const eDate = new Date(ey, em - 1, ed);
        const fDate = new Date(fy, fm - 1, fd);
        if (eDate < fDate) return false;
      }
      if (dateTo) {
        const [ty, tm, td] = dateTo.split('-').map(Number);
        const [ed, em, ey] = e.date.split('/').map(Number);
        const eDate = new Date(ey, em - 1, ed);
        const tDate = new Date(ty, tm - 1, td);
        if (eDate > tDate) return false;
      }

      if (q) {
        const hay = `${e.action} ${e.target} ${e.userName} ${e.details ?? ''}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }

      return true;
    });
  }, [entries, search, moduleFilter, dateFrom, dateTo]);

  const handleClear = () => {
    auditDb.clear();
    setEntries([]);
    setConfirmClear(false);
    msg('Histórico de auditoria limpo.');
  };

  return (
    <div style={{ maxWidth: 1100 }}>
      {toast && <Toast msg={toast} />}

      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: C.text }}>Auditoria do Sistema</h2>
          <p style={{ margin: '2px 0 0', fontSize: 12, color: C.textMuted }}>
            Registro de todas as ações realizadas no sistema. Somente leitura.
          </p>
        </div>
        {isAdmin && (
          <button
            onClick={() => setConfirmClear(true)}
            style={{
              padding: '6px 14px', fontSize: 12, fontWeight: 500,
              background: '#FEF3F2', color: C.error,
              border: `1px solid ${C.errorBorder}`, borderRadius: 6,
              cursor: 'pointer', fontFamily: 'Inter, sans-serif',
            }}
          >
            Limpar histórico
          </button>
        )}
      </div>

      {/* Filters */}
      <div style={{
        background: C.white, border: `1px solid ${C.border}`, borderRadius: 8,
        padding: '12px 16px', marginBottom: 12,
        display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'flex-end',
      }}>
        <div style={{ flex: '1 1 200px', minWidth: 180 }}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 500, color: C.textMuted, marginBottom: 4 }}>
            Buscar
          </label>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Ação, item, usuário..."
            style={inp()}
          />
        </div>

        <div style={{ flex: '0 0 160px' }}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 500, color: C.textMuted, marginBottom: 4 }}>
            Módulo
          </label>
          <select
            value={moduleFilter}
            onChange={e => setModuleFilter(e.target.value)}
            style={{ ...inp(), cursor: 'pointer' }}
          >
            <option value="">Todos os módulos</option>
            {MODULES.map(m => <option key={m} value={m}>{m}</option>)}
          </select>
        </div>

        <div style={{ flex: '0 0 140px' }}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 500, color: C.textMuted, marginBottom: 4 }}>
            Data inicial
          </label>
          <input
            type="date"
            value={dateFrom}
            onChange={e => setDateFrom(e.target.value)}
            style={inp()}
          />
        </div>

        <div style={{ flex: '0 0 140px' }}>
          <label style={{ display: 'block', fontSize: 11, fontWeight: 500, color: C.textMuted, marginBottom: 4 }}>
            Data final
          </label>
          <input
            type="date"
            value={dateTo}
            onChange={e => setDateTo(e.target.value)}
            style={inp()}
          />
        </div>

        {(search || moduleFilter || dateFrom || dateTo) && (
          <button
            onClick={() => { setSearch(''); setModuleFilter(''); setDateFrom(''); setDateTo(''); }}
            style={{ ...btnSecondary, alignSelf: 'flex-end', fontSize: 12 }}
          >
            Limpar filtros
          </button>
        )}
      </div>

      {/* Count */}
      <div style={{ fontSize: 12, color: C.textMuted, marginBottom: 8 }}>
        {filtered.length === entries.length
          ? `${entries.length} registro${entries.length !== 1 ? 's' : ''}`
          : `${filtered.length} de ${entries.length} registros`}
      </div>

      {/* Table */}
      <div style={tableWrap}>
        {filtered.length === 0 ? (
          <div style={{ padding: '48px 0', textAlign: 'center' }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🔍</div>
            <div style={{ fontSize: 14, fontWeight: 500, color: C.text, marginBottom: 4 }}>
              Nenhum registro encontrado
            </div>
            <div style={{ fontSize: 12, color: C.textMuted }}>
              {entries.length === 0
                ? 'O histórico de auditoria está vazio.'
                : 'Tente ajustar os filtros de busca.'}
            </div>
          </div>
        ) : (
          <table style={tbl}>
            <thead>
              <tr>
                <th style={{ ...TH, width: 110 }}>Data / Hora</th>
                <th style={{ ...TH, width: 120 }}>Módulo</th>
                <th style={TH}>Ação</th>
                <th style={TH}>Item</th>
                <th style={{ ...TH, width: 150 }}>Usuário</th>
                <th style={TH}>Detalhes</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((e, i) => (
                <tr key={e.id} style={{ borderTop: i === 0 ? 'none' : ROW_BORDER }}>
                  <td style={{ ...TD, whiteSpace: 'nowrap' }}>
                    <span style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text }}>{e.date}</span>
                    <span style={{ display: 'block', fontSize: 11, color: C.textMuted }}>{e.time}</span>
                  </td>
                  <td style={TD}>
                    <ModuleBadge module={e.module} />
                  </td>
                  <td style={{ ...TD, fontWeight: 500, fontSize: 12 }}>{e.action}</td>
                  <td style={{ ...TD, fontSize: 12, color: C.text }}>{e.target}</td>
                  <td style={{ ...TD, fontSize: 12, color: C.textMuted }}>{e.userName}</td>
                  <td style={{ ...TD, fontSize: 11, color: C.textMuted, maxWidth: 260 }}>
                    {e.details ?? '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Confirm clear dialog */}
      {confirmClear && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000,
        }}>
          <div style={{
            background: C.white, borderRadius: 10, padding: '28px 32px',
            maxWidth: 400, width: '90%', boxShadow: '0 8px 32px rgba(0,0,0,0.18)',
          }}>
            <h3 style={{ margin: '0 0 8px', fontSize: 14, fontWeight: 600, color: C.text }}>
              Limpar histórico de auditoria?
            </h3>
            <p style={{ margin: '0 0 20px', fontSize: 13, color: C.textMuted, lineHeight: 1.5 }}>
              Esta ação é irreversível. Todos os {entries.length} registros de auditoria serão permanentemente removidos.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setConfirmClear(false)} style={btnSecondary}>
                Cancelar
              </button>
              <button
                onClick={handleClear}
                style={{
                  ...btnPrimary,
                  background: C.error,
                  border: 'none',
                }}
              >
                Confirmar exclusão
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
