import { useState } from 'react';
import { Link, useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { ADMIN_EMAIL, ADMIN_PASSWORD, ACCESS_KEY } from '../data/db';

const PHOTO_URL =
  'https://images.unsplash.com/photo-1589987824703-827057a41910?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&q=80&w=800';

export default function Login() {
  const { login } = useApp();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverErr, setServerErr] = useState('');

  const validate = () => {
    const e: Record<string, string> = {};
    if (!email.trim()) e.email = 'Campo obrigatório.';
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = 'E-mail inválido.';
    if (!password) e.password = 'Campo obrigatório.';
    return e;
  };

  const handleSubmit = (ev: React.FormEvent) => {
    ev.preventDefault();
    setServerErr('');
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const err = login(email.trim(), password);
    if (err) { setServerErr(err); return; }
    navigate('/dashboard');
  };

  return (
    <div style={{
      minHeight: '100vh',
      background: '#EFEFEF',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '20px',
    }}>
      {/* Main card */}
      <div style={{
        width: '100%',
        maxWidth: 920,
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        borderRadius: 28,
        border: '1.5px solid #111',
        overflow: 'hidden',
        boxShadow: '0 24px 64px rgba(0,0,0,0.14)',
        background: '#fff',
        minHeight: 560,
      }}>

        {/* ── Left: stationery photo ── */}
        <div style={{
          backgroundImage: `url(${PHOTO_URL})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }} />

        {/* ── Right: form panel ── */}
        <div style={{
          background: '#fff',
          padding: '48px 44px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          {/* Logo */}
          <div style={{ marginBottom: 20, textAlign: 'center' }}>
            <img
              src="/logo-papelaria.png"
              alt="Papelaria Central"
              style={{ height: 88, objectFit: 'contain', display: 'block', margin: '0 auto' }}
            />
          </div>

          {/* Heading */}
          <div style={{ width: '100%', marginBottom: 20 }}>
            <h1 style={{ fontSize: 44, fontWeight: 700, color: '#101828', margin: 0, lineHeight: 1.1, letterSpacing: '-0.02em' }}>
              Entrar
            </h1>
          </div>

          {/* Server error */}
          {serverErr && (
            <div style={{ width: '100%', background: '#FEF3F2', border: '1px solid #FECDCA', borderRadius: 12, padding: '10px 16px', marginBottom: 14, fontSize: 13, color: '#B42318' }}>
              {serverErr}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate style={{ width: '100%' }}>
            {/* Email */}
            <div style={{ marginBottom: 12 }}>
              <PillField err={!!errors.email}>
                <UserIcon />
                <input
                  className="pill-input"
                  type="email"
                  value={email}
                  autoComplete="email"
                  onChange={e => { setEmail(e.target.value); setErrors(x => ({ ...x, email: '' })); setServerErr(''); }}
                  placeholder="Usuário"
                  style={pillinp}
                />
              </PillField>
              {errors.email && <ErrMsg>{errors.email}</ErrMsg>}
            </div>

            {/* Password */}
            <div style={{ marginBottom: 14 }}>
              <PillField err={!!errors.password}>
                <LockIcon />
                <input
                  className="pill-input"
                  type={showPw ? 'text' : 'password'}
                  value={password}
                  autoComplete="current-password"
                  onChange={e => { setPassword(e.target.value); setErrors(x => ({ ...x, password: '' })); setServerErr(''); }}
                  placeholder="Senha"
                  style={pillinp}
                />
                <button type="button" onClick={() => setShowPw(v => !v)} style={eyeBtn}>
                  {showPw ? <EyeOffIcon /> : <EyeIcon />}
                </button>
              </PillField>
              {errors.password && <ErrMsg>{errors.password}</ErrMsg>}
            </div>

            {/* Remember + forgot */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24, padding: '0 4px' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#344054', cursor: 'pointer', userSelect: 'none' }}>
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={e => setRemember(e.target.checked)}
                  style={{ width: 15, height: 15, accentColor: '#1A3D2B' }}
                />
                Lembrar de mim
              </label>
              <Link to="/recuperar-senha" style={{ fontSize: 13, color: '#344054', fontFamily: 'Inter, sans-serif' }}>
                Esqueci a senha
              </Link>
            </div>

            {/* Submit */}
            <button type="submit" style={{
              width: '100%',
              padding: '14px',
              background: '#1A3D2B',
              color: '#fff',
              border: 'none',
              borderRadius: 999,
              fontSize: 15,
              fontWeight: 600,
              cursor: 'pointer',
              fontFamily: 'Inter, sans-serif',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8,
              marginBottom: 16,
              letterSpacing: '0.01em',
            }}>
              Entrar <span style={{ fontSize: 16 }}>→</span>
            </button>
          </form>

          {/* Divider */}
          <div style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ flex: 1, height: 1, background: '#E4E7EC' }} />
            <span style={{ fontSize: 13, color: '#98A2B3' }}>Ou</span>
            <div style={{ flex: 1, height: 1, background: '#E4E7EC' }} />
          </div>

          {/* Request access */}
          <Link
            to="/cadastro"
            style={{
              width: '100%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 10,
              padding: '13px 20px',
              background: '#EBEBEB',
              borderRadius: 999,
              fontSize: 14,
              color: '#344054',
              fontFamily: 'Inter, sans-serif',
              textDecoration: 'none',
              marginBottom: 24,
            }}
          >
            <UserIcon color="#667085" />
            Solicitar acesso
          </Link>

          {/* Demo credentials */}
          <div style={{ width: '100%', background: '#FFFDF0', border: '1px solid #E8E0A0', borderRadius: 12, padding: '12px 16px' }}>
            <div style={{ fontSize: 10, fontWeight: 600, color: '#7A6800', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>
              Acesso para demonstração
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '3px 10px', fontSize: 12 }}>
              <span style={{ color: '#7A6800' }}>E-mail:</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 600, color: '#101828', userSelect: 'all' }}>{ADMIN_EMAIL}</span>
              <span style={{ color: '#7A6800' }}>Senha:</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 600, color: '#101828', userSelect: 'all' }}>{ADMIN_PASSWORD}</span>
              <span style={{ color: '#7A6800' }}>Chave:</span>
              <span style={{ fontFamily: 'monospace', fontWeight: 600, color: '#3538CD', userSelect: 'all' }}>{ACCESS_KEY}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ── Sub-components ──────────────────────────────── */

function PillField({ children, err }: { children: React.ReactNode; err: boolean }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      background: err ? '#FEF3F2' : '#EBEBEB',
      borderRadius: 999,
      padding: '12px 20px',
      gap: 10,
      border: err ? '1.5px solid #FECDCA' : '1.5px solid transparent',
      transition: 'border-color 0.15s',
    }}>
      {children}
    </div>
  );
}

function ErrMsg({ children }: { children: React.ReactNode }) {
  return <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 5, paddingLeft: 18 }}>{children}</span>;
}

const pillinp: React.CSSProperties = {
  flex: 1,
  border: 'none',
  background: 'transparent',
  fontSize: 14,
  color: '#101828',
  outline: 'none',
  fontFamily: 'Inter, sans-serif',
};

const eyeBtn: React.CSSProperties = {
  background: 'none',
  border: 'none',
  cursor: 'pointer',
  padding: 0,
  color: '#9EA8B3',
  display: 'flex',
  alignItems: 'center',
  flexShrink: 0,
};

function UserIcon({ color = '#9EA8B3' }: { color?: string }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
    </svg>
  );
}

function LockIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#9EA8B3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0 }}>
      <rect x="3" y="11" width="18" height="11" rx="2" ry="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function EyeOffIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
      <line x1="1" y1="1" x2="23" y2="23" />
    </svg>
  );
}
