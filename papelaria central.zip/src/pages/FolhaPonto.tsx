import { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { pontoDb, newPontoId, type PontoRegistro, type PontoStatus, type OcorrenciaTipo } from '../data/pontoDb';
import { C, tbl, TH, TD, tableWrap, ROW_BORDER, formCard, inp, btnPrimary, btnSecondary } from '../theme';

const TODAY = new Date().toISOString().slice(0, 10);

function fmtDate(d: string): string { return d.split('-').reverse().join('/'); }
function fmtMin(m: number): string {
  if (m <= 0) return '—';
  const h = Math.floor(m / 60);
  const min = m % 60;
  return h > 0 ? `${h}h ${min}min` : `${min}min`;
}

const STATUS_BADGE: Record<PontoStatus, React.CSSProperties> = {
  presente:  { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5' },
  ausente:   { background: '#FEF3F2', color: '#B42318', border: '1px solid #FECDCA' },
  folga:     { background: '#EFF6FF', color: '#1D4ED8', border: '1px solid #BFDBFE' },
  ferias:    { background: '#F5F3FF', color: '#6D28D9', border: '1px solid #DDD6FE' },
  atestado:  { background: '#FFFBEB', color: '#B45309', border: '1px solid #FDE68A' },
};
const STATUS_LABELS: Record<PontoStatus, string> = {
  presente: 'Presente', ausente: 'Ausente', folga: 'Folga', ferias: 'Férias', atestado: 'Atestado',
};

const OC_LABELS: Record<OcorrenciaTipo, string> = {
  falta: 'Falta', falta_justificada: 'Falta justificada', atraso: 'Atraso',
  saida_antecipada: 'Saída antecipada', folga: 'Folga', ferias: 'Férias', atestado: 'Atestado médico',
};

type Tab = 'hoje' | 'historico' | 'ocorrencias' | 'decimo';

function Badge({ s }: { s: PontoStatus }) {
  return (
    <span style={{ ...STATUS_BADGE[s], borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 }}>
      {STATUS_LABELS[s]}
    </span>
  );
}

function PunchSection({ userId, userName }: { userId: string; userName: string }) {
  const [registro, setRegistro] = useState<PontoRegistro | undefined>(
    () => pontoDb.registros.byUserDate(userId, TODAY)
  );
  const [obs, setObs] = useState('');

  const refresh = () => setRegistro(pontoDb.registros.byUserDate(userId, TODAY));

  const punch = (field: 'entrada' | 'saidaAlmoco' | 'retornoAlmoco' | 'saida') => {
    const now = new Date();
    const time = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;

    if (!registro) {
      if (field !== 'entrada') return;
      const r: PontoRegistro = {
        id: newPontoId(), userId, userName, date: TODAY,
        entrada: time,
        horasPrevistas: 8, horasTrabalhadas: 0, horasExtras: 0,
        atrasoMin: 0, saidaAntecMin: 0,
        status: 'presente', observacoes: obs,
        createdAt: new Date().toISOString(),
      };
      pontoDb.registros.add(r);
      refresh();
    } else {
      pontoDb.registros.update(registro.id, { [field]: time });
      refresh();
    }
  };

  const btnStyle = (enabled: boolean): React.CSSProperties => ({
    padding: '8px 16px', fontSize: 13, fontFamily: 'Inter, sans-serif',
    background: enabled ? C.navy : '#E5E7EB', color: enabled ? '#fff' : '#9CA3AF',
    border: 'none', borderRadius: 4, cursor: enabled ? 'pointer' : 'not-allowed',
    fontWeight: 500,
  });

  const hasEntrada = !!registro?.entrada;
  const hasSalmoc = !!registro?.saidaAlmoco;
  const hasRetorno = !!registro?.retornoAlmoco;
  const hasSaida = !!registro?.saida;

  return (
    <div style={{ ...formCard, marginBottom: 16 }}>
      <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 12 }}>
        Registro de ponto — {fmtDate(TODAY)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8, marginBottom: 16 }}>
        {[
          { label: 'Entrada', key: 'entrada' as const,       val: registro?.entrada,        enabled: !hasEntrada },
          { label: 'Saída Almoço', key: 'saidaAlmoco' as const, val: registro?.saidaAlmoco, enabled: hasEntrada && !hasSalmoc },
          { label: 'Retorno', key: 'retornoAlmoco' as const, val: registro?.retornoAlmoco,  enabled: hasSalmoc && !hasRetorno },
          { label: 'Saída', key: 'saida' as const,           val: registro?.saida,          enabled: hasEntrada && !hasSaida },
        ].map(f => (
          <div key={f.key} style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 11, color: C.textMuted, marginBottom: 4 }}>{f.label}</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: f.val ? C.navy : '#9CA3AF', marginBottom: 8 }}>
              {f.val ?? '--:--'}
            </div>
            <button
              onClick={() => punch(f.key)}
              disabled={!f.enabled}
              style={btnStyle(f.enabled)}
            >
              Registrar
            </button>
          </div>
        ))}
      </div>

      {!registro && (
        <div>
          <label style={{ fontSize: 12, color: C.textMuted, display: 'block', marginBottom: 4 }}>
            Observação (opcional)
          </label>
          <input value={obs} onChange={e => setObs(e.target.value)} style={inp(false)} placeholder="Ex.: chegando de ônibus" />
        </div>
      )}

      {registro && (
        <div style={{ fontSize: 12, color: C.textMuted, display: 'flex', gap: 20 }}>
          {registro.horasTrabalhadas > 0 && (
            <span>Trabalhadas: <strong style={{ color: C.text }}>{registro.horasTrabalhadas}h</strong></span>
          )}
          {registro.horasExtras > 0 && (
            <span style={{ color: '#027A48' }}>Extras: <strong>+{registro.horasExtras}h</strong></span>
          )}
          {registro.atrasoMin > 0 && (
            <span style={{ color: '#B42318' }}>Atraso: <strong>{fmtMin(registro.atrasoMin)}</strong></span>
          )}
          <span><Badge s={registro.status} /></span>
        </div>
      )}
    </div>
  );
}

export default function FolhaPonto() {
  const { user } = useApp();
  const isAdmin = user?.role === 'admin';
  const [tab, setTab] = useState<Tab>('hoje');
  const [dateSel, setDateSel] = useState(TODAY);

  // Admin: date picker + all employees
  // Employee: only own records

  const todayMap = useMemo(() => pontoDb.todayMap(TODAY), [tab]);

  const [editRec, setEditRec] = useState<PontoRegistro | null>(null);
  const [editForm, setEditForm] = useState<Partial<PontoRegistro>>({});
  const [newOcForm, setNewOcForm] = useState(false);
  const [ocForm, setOcForm] = useState({
    userId: '', tipo: 'atraso' as OcorrenciaTipo, horas: 1, observacao: '',
  });

  const ocorrencias = useMemo(() => pontoDb.ocorrencias.all(), [tab]);
  const decimos = useMemo(() => pontoDb.decimo.all(), [tab]);

  const histRecords = useMemo(() => {
    const all = pontoDb.registros.all();
    if (isAdmin) return all.filter(r => r.date === dateSel);
    return all.filter(r => r.userId === user?.id);
  }, [tab, dateSel, isAdmin]);

  const openEdit = (r: PontoRegistro) => {
    setEditRec(r);
    setEditForm({ entrada: r.entrada, saidaAlmoco: r.saidaAlmoco, retornoAlmoco: r.retornoAlmoco, saida: r.saida, status: r.status, observacoes: r.observacoes });
  };

  const saveEdit = () => {
    if (!editRec) return;
    pontoDb.registros.update(editRec.id, { ...editForm, editadoPor: user?.name });
    setEditRec(null);
  };

  const saveOc = () => {
    if (!ocForm.userId || !ocForm.observacao) return;
    const u = pontoDb.users.find(x => x.id === ocForm.userId);
    pontoDb.ocorrencias.add({
      id: newPontoId(), userId: ocForm.userId, userName: u?.name ?? '',
      date: TODAY, tipo: ocForm.tipo, horas: ocForm.horas,
      observacao: ocForm.observacao, registradoPor: user?.name ?? '',
      statusOc: 'aprovado', createdAt: new Date().toISOString(),
    });
    setNewOcForm(false);
    setOcForm({ userId: '', tipo: 'atraso', horas: 1, observacao: '' });
    setTab('ocorrencias');
  };

  const tabs: { k: Tab; label: string }[] = [
    { k: 'hoje',       label: isAdmin ? 'Presença hoje' : 'Meu ponto hoje' },
    { k: 'historico',  label: 'Histórico' },
    { k: 'ocorrencias',label: 'Ocorrências' },
    { k: 'decimo',     label: '13° Salário' },
  ];

  const sinp: React.CSSProperties = {
    padding: '5px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.text,
  };

  return (
    <div>
      {/* Tab nav */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.k} onClick={() => setTab(t.k)} style={{
            padding: '7px 14px', fontSize: 12, fontFamily: 'Inter, sans-serif',
            fontWeight: tab === t.k ? 600 : 400,
            color: tab === t.k ? C.navy : C.textMuted,
            borderBottom: tab === t.k ? `2px solid ${C.navy}` : '2px solid transparent',
            marginBottom: -1, background: 'none', border: 'none',
            borderLeft: 'none', borderRight: 'none', borderTop: 'none',
            cursor: 'pointer',
          }}>{t.label}</button>
        ))}
      </div>

      {/* ── TAB: HOJE ── */}
      {tab === 'hoje' && (
        <div>
          {!isAdmin && user && (
            <PunchSection userId={user.id} userName={user.name} />
          )}

          {isAdmin && (
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 12 }}>
                Presença em {fmtDate(TODAY)}
              </div>
              <div style={tableWrap}>
                <table style={tbl}>
                  <thead>
                    <tr>
                      {['Funcionário','Cargo','Entrada','Saída Alm.','Retorno','Saída','Trab.','Extras','Atraso','Status',''].map(h => (
                        <th key={h} style={TH}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {todayMap.map(({ user: u, registro: r }, i) => (
                      <tr key={u.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                        <td style={{ ...TD, fontWeight: 500 }}>{u.name}</td>
                        <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>
                          {u.id === 'u-002' ? 'Gerente' : u.id === 'u-003' ? 'Vendedor' : u.id === 'u-004' ? 'Caixa' : u.id === 'u-007' ? 'Atendente' : 'Vendedor'}
                        </td>
                        <td style={{ ...TD, fontFamily: 'monospace' }}>{r?.entrada ?? '—'}</td>
                        <td style={{ ...TD, fontFamily: 'monospace' }}>{r?.saidaAlmoco ?? '—'}</td>
                        <td style={{ ...TD, fontFamily: 'monospace' }}>{r?.retornoAlmoco ?? '—'}</td>
                        <td style={{ ...TD, fontFamily: 'monospace' }}>{r?.saida ?? '—'}</td>
                        <td style={{ ...TD, textAlign: 'right' }}>{r?.horasTrabalhadas ? `${r.horasTrabalhadas}h` : '—'}</td>
                        <td style={{ ...TD, textAlign: 'right', color: (r?.horasExtras ?? 0) > 0 ? '#027A48' : C.textMuted }}>
                          {(r?.horasExtras ?? 0) > 0 ? `+${r!.horasExtras}h` : '—'}
                        </td>
                        <td style={{ ...TD, color: (r?.atrasoMin ?? 0) > 0 ? '#B42318' : C.textMuted }}>
                          {fmtMin(r?.atrasoMin ?? 0)}
                        </td>
                        <td style={TD}>
                          {r ? <Badge s={r.status} /> : (
                            <span style={{ ...STATUS_BADGE.ausente, borderRadius: 4, padding: '2px 8px', fontSize: 11, fontWeight: 500 }}>Sem registro</span>
                          )}
                        </td>
                        <td style={TD}>
                          {r && (
                            <button onClick={() => openEdit(r)} style={{ fontSize: 11, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
                              Corrigir
                            </button>
                          )}
                          {!r && (
                            <button onClick={() => {
                              const nr: PontoRegistro = {
                                id: newPontoId(), userId: u.id, userName: u.name, date: TODAY,
                                horasPrevistas: 8, horasTrabalhadas: 0, horasExtras: 0,
                                atrasoMin: 0, saidaAntecMin: 0, status: 'ausente',
                                observacoes: 'Falta registrada pelo admin', createdAt: new Date().toISOString(),
                              };
                              pontoDb.registros.add(nr);
                              setTab('historico'); setTab('hoje');
                            }} style={{ fontSize: 11, color: '#B42318', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
                              Marcar falta
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── TAB: HISTÓRICO ── */}
      {tab === 'historico' && (
        <div>
          {isAdmin && (
            <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center' }}>
              <label style={{ fontSize: 12, color: C.textMuted }}>Data:</label>
              <input type="date" value={dateSel} onChange={e => setDateSel(e.target.value)} style={sinp} />
              <span style={{ fontSize: 12, color: C.textMuted }}>{histRecords.length} registros</span>
            </div>
          )}
          <div style={tableWrap}>
            <table style={tbl}>
              <thead>
                <tr>
                  {(isAdmin
                    ? ['Data', 'Funcionário', 'Entrada', 'Saída Alm.', 'Retorno', 'Saída', 'Trabalhadas', 'Extras', 'Atraso', 'Status', 'Obs.', '']
                    : ['Data', 'Entrada', 'Saída Alm.', 'Retorno', 'Saída', 'Trabalhadas', 'Extras', 'Atraso', 'Status']
                  ).map(h => <th key={h} style={TH}>{h}</th>)}
                </tr>
              </thead>
              <tbody>
                {[...histRecords].sort((a, b) => b.date.localeCompare(a.date)).slice(0, isAdmin ? 50 : 60).map((r, i) => (
                  <tr key={r.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                    <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted, whiteSpace: 'nowrap' }}>{fmtDate(r.date)}</td>
                    {isAdmin && <td style={{ ...TD, fontWeight: 500, whiteSpace: 'nowrap' }}>{r.userName}</td>}
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{r.entrada ?? '—'}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{r.saidaAlmoco ?? '—'}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{r.retornoAlmoco ?? '—'}</td>
                    <td style={{ ...TD, fontFamily: 'monospace' }}>{r.saida ?? '—'}</td>
                    <td style={{ ...TD, textAlign: 'right' }}>{r.horasTrabalhadas > 0 ? `${r.horasTrabalhadas}h` : '—'}</td>
                    <td style={{ ...TD, textAlign: 'right', color: r.horasExtras > 0 ? '#027A48' : C.textMuted }}>
                      {r.horasExtras > 0 ? `+${r.horasExtras}h` : '—'}
                    </td>
                    <td style={{ ...TD, color: r.atrasoMin > 0 ? '#B42318' : C.textMuted }}>{fmtMin(r.atrasoMin)}</td>
                    <td style={TD}><Badge s={r.status} /></td>
                    {isAdmin && (
                      <>
                        <td style={{ ...TD, color: C.textMuted, fontSize: 11, maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.observacoes || '—'}</td>
                        <td style={TD}>
                          <button onClick={() => openEdit(r)} style={{ fontSize: 11, color: C.navy, background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Editar</button>
                        </td>
                      </>
                    )}
                  </tr>
                ))}
                {histRecords.length === 0 && (
                  <tr><td colSpan={12} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '20px 12px' }}>
                    {isAdmin ? `Nenhum registro em ${fmtDate(dateSel)}.` : 'Nenhum registro encontrado.'}
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── TAB: OCORRÊNCIAS ── */}
      {tab === 'ocorrencias' && (
        <div>
          {isAdmin && (
            <div style={{ marginBottom: 14, display: 'flex', justifyContent: 'flex-end' }}>
              <button onClick={() => setNewOcForm(true)} style={btnPrimary}>+ Nova ocorrência</button>
            </div>
          )}

          {newOcForm && (
            <div style={{ ...formCard, marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 12 }}>Nova ocorrência</div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 12 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Funcionário</label>
                  <select value={ocForm.userId} onChange={e => setOcForm(f => ({ ...f, userId: e.target.value }))} style={sinp}>
                    <option value="">Selecione</option>
                    {pontoDb.users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Tipo</label>
                  <select value={ocForm.tipo} onChange={e => setOcForm(f => ({ ...f, tipo: e.target.value as OcorrenciaTipo }))} style={sinp}>
                    {(Object.entries(OC_LABELS) as [OcorrenciaTipo, string][]).map(([k, v]) => (
                      <option key={k} value={k}>{v}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Horas</label>
                  <input type="number" min={0.5} max={8} step={0.5} value={ocForm.horas} onChange={e => setOcForm(f => ({ ...f, horas: +e.target.value }))} style={sinp} />
                </div>
              </div>
              <div style={{ marginBottom: 12 }}>
                <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 4 }}>Observação</label>
                <input value={ocForm.observacao} onChange={e => setOcForm(f => ({ ...f, observacao: e.target.value }))} style={inp(false)} placeholder="Descreva a ocorrência" />
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button onClick={() => setNewOcForm(false)} style={btnSecondary}>Cancelar</button>
                <button onClick={saveOc} style={btnPrimary}>Salvar ocorrência</button>
              </div>
            </div>
          )}

          <div style={tableWrap}>
            <table style={tbl}>
              <thead>
                <tr>
                  {['Data', 'Funcionário', 'Tipo', 'Horas', 'Observação', 'Registrado por', 'Status'].map(h => (
                    <th key={h} style={TH}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...ocorrencias].sort((a, b) => b.date.localeCompare(a.date)).map((o, i) => (
                  <tr key={o.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                    <td style={{ ...TD, fontFamily: 'monospace', fontSize: 12, color: C.textMuted }}>{fmtDate(o.date)}</td>
                    <td style={{ ...TD, fontWeight: 500 }}>{o.userName}</td>
                    <td style={TD}>{OC_LABELS[o.tipo]}</td>
                    <td style={{ ...TD, textAlign: 'right' }}>{o.horas}h</td>
                    <td style={{ ...TD, color: C.textMuted, maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{o.observacao}</td>
                    <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{o.registradoPor}</td>
                    <td style={TD}>
                      <span style={{ ...(o.statusOc === 'aprovado' ? { background: '#ECFDF3', color: '#027A48', border: '1px solid #A9EFC5' } : { background: '#FEF3F2', color: '#B42318', border: '1px solid #FECDCA' }), borderRadius: 4, padding: '2px 8px', fontSize: 11 }}>
                        {o.statusOc === 'aprovado' ? 'Aprovada' : o.statusOc === 'rejeitado' ? 'Rejeitada' : 'Pendente'}
                      </span>
                    </td>
                  </tr>
                ))}
                {ocorrencias.length === 0 && (
                  <tr><td colSpan={7} style={{ ...TD, textAlign: 'center', color: C.textMuted, padding: '20px 12px' }}>Nenhuma ocorrência registrada.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ── TAB: 13° SALÁRIO ── */}
      {tab === 'decimo' && (
        <div>
          <div style={{ fontSize: 13, color: C.textMuted, marginBottom: 14 }}>
            Décimo terceiro salário – competência 2026. Base de cálculo: avos = meses trabalhados no ano (jan–set = 9 avos).
          </div>
          <div style={tableWrap}>
            <table style={tbl}>
              <thead>
                <tr>
                  {['Funcionário','Salário base','Avos','Valor total','1ª Parcela','Venc. 1ª','2ª Parcela','Venc. 2ª','Status',''].map(h => (
                    <th key={h} style={TH}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {decimos.map((d, i) => {
                  const fmtBRL = (v: number) => v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
                  return (
                    <tr key={d.id} style={{ borderTop: i > 0 ? ROW_BORDER : undefined }}>
                      <td style={{ ...TD, fontWeight: 500 }}>{d.userName}</td>
                      <td style={{ ...TD, fontFamily: 'monospace' }}>{fmtBRL(d.salarioBase)}</td>
                      <td style={{ ...TD, textAlign: 'center' }}>{d.avos}/12</td>
                      <td style={{ ...TD, fontWeight: 600 }}>{fmtBRL(d.valorTotal)}</td>
                      <td style={{ ...TD, fontFamily: 'monospace' }}>
                        {fmtBRL(d.parcela1)}
                        {isAdmin && !d.parcela1Paga && (
                          <button onClick={() => { pontoDb.decimo.update(d.id, { parcela1Paga: true }); setTab('ocorrencias'); setTab('decimo'); }} style={{ marginLeft: 6, fontSize: 10, color: '#027A48', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Pagar</button>
                        )}
                        {d.parcela1Paga && <span style={{ marginLeft: 6, fontSize: 10, color: '#027A48' }}>✓ Paga</span>}
                      </td>
                      <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{fmtDate(d.dataParcela1)}</td>
                      <td style={{ ...TD, fontFamily: 'monospace' }}>
                        {fmtBRL(d.parcela2)}
                        {isAdmin && d.parcela1Paga && !d.parcela2Paga && (
                          <button onClick={() => { pontoDb.decimo.update(d.id, { parcela2Paga: true }); setTab('ocorrencias'); setTab('decimo'); }} style={{ marginLeft: 6, fontSize: 10, color: '#027A48', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>Pagar</button>
                        )}
                        {d.parcela2Paga && <span style={{ marginLeft: 6, fontSize: 10, color: '#027A48' }}>✓ Paga</span>}
                      </td>
                      <td style={{ ...TD, color: C.textMuted, fontSize: 12 }}>{fmtDate(d.dataParcela2)}</td>
                      <td style={TD}>
                        <span style={{
                          background: d.status === 'pago' ? '#ECFDF3' : d.status === 'parcial' ? '#FFFBEB' : '#F9FAFB',
                          color: d.status === 'pago' ? '#027A48' : d.status === 'parcial' ? '#B45309' : C.textMuted,
                          border: `1px solid ${d.status === 'pago' ? '#A9EFC5' : d.status === 'parcial' ? '#FDE68A' : C.border}`,
                          borderRadius: 4, padding: '2px 8px', fontSize: 11,
                        }}>
                          {d.status === 'pago' ? 'Pago' : d.status === 'parcial' ? 'Parcial' : 'Pendente'}
                        </span>
                      </td>
                      <td style={TD}>
                        <span style={{ fontSize: 11, color: C.textMuted }}>
                          {d.valorTotal.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 16, background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 4, padding: '10px 14px', fontSize: 12, color: C.textMuted }}>
            <strong style={{ color: C.text }}>Regras:</strong>{' '}
            1ª parcela — até 30/11/2026 · 2ª parcela — até 20/12/2026.
            Cada avo = 1 mês integral (ou fração ≥ 15 dias) de serviço prestado.
          </div>
        </div>
      )}

      {/* ── Modal de edição ── */}
      {editRec && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
          <div style={{ background: C.white, borderRadius: 6, padding: 24, width: 400, boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
            <div style={{ fontSize: 14, fontWeight: 600, color: C.text, marginBottom: 16 }}>
              Corrigir ponto — {editRec.userName} — {fmtDate(editRec.date)}
            </div>
            {[
              { label: 'Entrada', k: 'entrada' },
              { label: 'Saída Almoço', k: 'saidaAlmoco' },
              { label: 'Retorno Almoço', k: 'retornoAlmoco' },
              { label: 'Saída', k: 'saida' },
            ].map(f => (
              <div key={f.k} style={{ marginBottom: 10 }}>
                <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>{f.label}</label>
                <input
                  type="time"
                  value={(editForm as Record<string, string>)[f.k] ?? ''}
                  onChange={e => setEditForm(x => ({ ...x, [f.k]: e.target.value }))}
                  style={sinp}
                />
              </div>
            ))}
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Status</label>
              <select value={editForm.status ?? 'presente'} onChange={e => setEditForm(f => ({ ...f, status: e.target.value as PontoStatus }))} style={sinp}>
                {(Object.entries(STATUS_LABELS) as [PontoStatus, string][]).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div style={{ marginBottom: 16 }}>
              <label style={{ display: 'block', fontSize: 12, color: C.textMuted, marginBottom: 3 }}>Observação</label>
              <input value={editForm.observacoes ?? ''} onChange={e => setEditForm(f => ({ ...f, observacoes: e.target.value }))} style={inp(false)} />
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={() => setEditRec(null)} style={btnSecondary}>Cancelar</button>
              <button onClick={saveEdit} style={btnPrimary}>Salvar alteração</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
