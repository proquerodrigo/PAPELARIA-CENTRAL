import { useState } from 'react';
import { useNavigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { C, inp, btnPrimary, btnSecondary, formCard } from '../theme';
import { Toast } from './Produtos';
import { horariosDb, DIAS_ORDER, DIAS_LABELS, type HorarioFuncionamento } from '../data/horariosDb';
import { empresaDb, type DadosEmpresa } from '../data/empresaDb';

type Tab = 'conta' | 'senha' | 'horarios' | 'empresa' | 'sair';

export default function Configuracoes() {
  const { user, logout } = useApp();
  const navigate = useNavigate();
  const isAdmin = user?.role === 'admin';

  const [tab, setTab] = useState<Tab>('conta');
  const [pw, setPw] = useState({ current: '', next: '', confirm: '' });
  const [pwErr, setPwErr] = useState<Record<string, string>>({});
  const [toast, setToast] = useState('');
  const [horarios, setHorarios] = useState<HorarioFuncionamento>(() => horariosDb.get());
  const [empresa, setEmpresa] = useState<DadosEmpresa>(() => empresaDb.get());
  const [empresaOrig, setEmpresaOrig] = useState<DadosEmpresa>(() => empresaDb.get());

  const setEmpField = <K extends keyof DadosEmpresa>(key: K, value: DadosEmpresa[K]) =>
    setEmpresa(prev => ({ ...prev, [key]: value }));
  const setRedeField = (rede: keyof NonNullable<DadosEmpresa['redesSociais']>, value: string) =>
    setEmpresa(prev => ({ ...prev, redesSociais: { ...prev.redesSociais, [rede]: value } }));

  const msg = (t: string) => { setToast(t); setTimeout(() => setToast(''), 3000); };
  const setPwField = (k: string, v: string) => { setPw(p => ({ ...p, [k]: v })); setPwErr(x => ({ ...x, [k]: '' })); };

  const savePw = () => {
    const e: Record<string, string> = {};
    if (!pw.current) e.current = 'Campo obrigatório.';
    if (pw.next.length < 8) e.next = 'Mínimo de 8 caracteres.';
    if (pw.confirm !== pw.next) e.confirm = 'As senhas não coincidem.';
    setPwErr(e);
    if (Object.keys(e).length) return;
    setPw({ current: '', next: '', confirm: '' });
    msg('Senha alterada com sucesso.');
  };

  const handleLogout = () => { logout(); navigate('/'); };
  const saveHorarios = () => { horariosDb.set(horarios); msg('Horários de funcionamento salvos.'); };
  const saveEmpresa = () => { empresaDb.set(empresa); setEmpresaOrig(empresa); msg('Dados da empresa salvos com sucesso.'); };
  const discardEmpresa = () => { setEmpresa(empresaOrig); msg('Alterações descartadas.'); };

  const status = horariosDb.isAberta();

  const sinp: React.CSSProperties = {
    padding: '5px 8px', fontSize: 12, fontFamily: 'Inter, sans-serif',
    border: `1px solid ${C.border}`, borderRadius: 4, background: C.white, color: C.text,
  };

  const tabs: { k: Tab; label: string }[] = [
    { k: 'conta', label: 'Minha conta' },
    { k: 'senha', label: 'Alterar senha' },
    ...(isAdmin ? [{ k: 'horarios' as Tab, label: 'Horário de funcionamento' }] : []),
    ...(isAdmin ? [{ k: 'empresa' as Tab, label: 'Dados da empresa' }] : []),
    { k: 'sair', label: 'Sair' },
  ];

  return (
    <div style={{ maxWidth: 600 }}>
      {toast && <Toast msg={toast} />}

      {/* Tab nav */}
      <div style={{ display: 'flex', borderBottom: `1px solid ${C.border}`, marginBottom: 20 }}>
        {tabs.map(t => (
          <button key={t.k} onClick={() => setTab(t.k)} style={{
            padding: '7px 14px', fontSize: 12, fontFamily: 'Inter, sans-serif',
            fontWeight: tab === t.k ? 600 : 400,
            color: tab === t.k ? C.navy : C.textMuted,
            borderBottom: tab === t.k ? `2px solid ${C.navy}` : '2px solid transparent',
            marginBottom: -1, background: 'none', border: 'none',
            borderLeft: 'none', borderRight: 'none', borderTop: 'none',
            cursor: 'pointer',
          }}>{t.label}</button>
        ))}
      </div>

      {/* ── Minha conta ── */}
      {tab === 'conta' && (
        <div style={formCard}>
          <h3 style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 600, color: C.text }}>Minha conta</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr', gap: '10px 16px', fontSize: 13 }}>
            <span style={{ color: C.textMuted }}>Nome</span>
            <span style={{ fontWeight: 500 }}>{user?.name}</span>
            <span style={{ color: C.textMuted }}>E-mail</span>
            <span>{user?.email}</span>
            <span style={{ color: C.textMuted }}>Perfil</span>
            <span>{user?.role === 'admin' ? 'Administrador' : 'Funcionário'}</span>
            <span style={{ color: C.textMuted }}>Status</span>
            <span style={{ color: C.success, fontWeight: 500 }}>Ativo</span>
          </div>
        </div>
      )}

      {/* ── Alterar senha ── */}
      {tab === 'senha' && (
        <div style={formCard}>
          <h3 style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 600, color: C.text }}>Alterar senha</h3>
          {[
            { label: 'Senha atual', key: 'current' },
            { label: 'Nova senha', key: 'next' },
            { label: 'Confirmar nova senha', key: 'confirm' },
          ].map(f => (
            <div key={f.key} style={{ marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>{f.label}</label>
              <input
                type="password"
                value={(pw as Record<string, string>)[f.key]}
                onChange={e => setPwField(f.key, e.target.value)}
                placeholder="••••••••"
                style={inp(!!(pwErr as Record<string, string>)[f.key])}
              />
              {(pwErr as Record<string, string>)[f.key] && (
                <span style={{ display: 'block', fontSize: 11, color: '#B42318', marginTop: 3 }}>{(pwErr as Record<string, string>)[f.key]}</span>
              )}
            </div>
          ))}
          <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={savePw} style={btnPrimary}>Salvar nova senha</button>
          </div>
        </div>
      )}

      {/* ── Horário de funcionamento (admin only) ── */}
      {tab === 'horarios' && isAdmin && (
        <div>
          <div style={{
            background: status.aberta ? '#ECFDF3' : '#FEF3F2',
            border: `1px solid ${status.aberta ? '#A9EFC5' : '#FECDCA'}`,
            borderRadius: 5, padding: '10px 16px', marginBottom: 16,
            display: 'flex', alignItems: 'center', gap: 12,
          }}>
            <span style={{ fontSize: 20 }}>{status.aberta ? '🟢' : '🔴'}</span>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13, color: status.aberta ? '#027A48' : '#B42318' }}>
                Loja {status.aberta ? 'ABERTA' : 'FECHADA'} agora
              </div>
              <div style={{ fontSize: 12, color: C.textMuted }}>
                {DIAS_LABELS[status.dia]} · {status.aberta ? `Fecha às ${status.fechamento}` : `Abre às ${status.abertura}`}
              </div>
            </div>
          </div>

          <div style={formCard}>
            <div style={{ fontSize: 13, fontWeight: 600, color: C.text, marginBottom: 16 }}>Horários por dia da semana</div>
            <div style={{ display: 'grid', gridTemplateColumns: '130px 70px 90px 16px 90px', gap: '8px 12px', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 600 }}>Dia</span>
              <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 600 }}>Aberto</span>
              <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 600 }}>Abertura</span>
              <span />
              <span style={{ fontSize: 11, color: C.textMuted, fontWeight: 600 }}>Fechamento</span>
            </div>
            {DIAS_ORDER.map(dia => {
              const h = horarios[dia];
              return (
                <div key={dia} style={{ display: 'grid', gridTemplateColumns: '130px 70px 90px 16px 90px', gap: '8px 12px', alignItems: 'center', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, color: C.text }}>{DIAS_LABELS[dia]}</span>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 6, cursor: 'pointer' }}>
                    <input
                      type="checkbox"
                      checked={h.aberto}
                      onChange={e => setHorarios(x => ({ ...x, [dia]: { ...x[dia], aberto: e.target.checked } }))}
                    />
                    <span style={{ fontSize: 12, color: h.aberto ? '#027A48' : C.textMuted }}>{h.aberto ? 'Sim' : 'Não'}</span>
                  </label>
                  <input
                    type="time" value={h.abertura} disabled={!h.aberto}
                    onChange={e => setHorarios(x => ({ ...x, [dia]: { ...x[dia], abertura: e.target.value } }))}
                    style={{ ...sinp, opacity: h.aberto ? 1 : 0.4 }}
                  />
                  <span style={{ textAlign: 'center', color: C.textMuted, fontSize: 12 }}>–</span>
                  <input
                    type="time" value={h.fechamento} disabled={!h.aberto}
                    onChange={e => setHorarios(x => ({ ...x, [dia]: { ...x[dia], fechamento: e.target.value } }))}
                    style={{ ...sinp, opacity: h.aberto ? 1 : 0.4 }}
                  />
                </div>
              );
            })}
            <div style={{ marginTop: 16, display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={() => { setHorarios(horariosDb.get()); msg('Alterações descartadas.'); }} style={btnSecondary}>Descartar</button>
              <button onClick={saveHorarios} style={btnPrimary}>Salvar horários</button>
            </div>
          </div>

          <div style={{ marginTop: 12, background: '#F8FAFC', border: `1px solid ${C.border}`, borderRadius: 4, padding: '10px 14px', fontSize: 12, color: C.textMuted }}>
            O status da loja é calculado automaticamente e exibido no painel operacional do Dashboard.
          </div>
        </div>
      )}

      {/* ── Dados da empresa ── */}
      {tab === 'empresa' && isAdmin && (
        <div>
          <div style={{ ...formCard, marginBottom: 12 }}>
            <h3 style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 600, color: C.text }}>Identificação da empresa</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Razão social</label>
                <input value={empresa.razaoSocial} onChange={e => setEmpField('razaoSocial', e.target.value)} style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Nome fantasia</label>
                <input value={empresa.nomeFantasia} onChange={e => setEmpField('nomeFantasia', e.target.value)} style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>CNPJ</label>
                <input value={empresa.cnpj} onChange={e => setEmpField('cnpj', e.target.value)} placeholder="00.000.000/0000-00" style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Inscrição estadual</label>
                <input value={empresa.inscricaoEstadual} onChange={e => setEmpField('inscricaoEstadual', e.target.value)} style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Telefone</label>
                <input value={empresa.telefone} onChange={e => setEmpField('telefone', e.target.value)} placeholder="(00) 0000-0000" style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>WhatsApp</label>
                <input value={empresa.whatsapp} onChange={e => setEmpField('whatsapp', e.target.value)} placeholder="(00) 00000-0000" style={inp()} />
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>E-mail</label>
                <input value={empresa.email} onChange={e => setEmpField('email', e.target.value)} placeholder="contato@empresa.com.br" style={inp()} />
              </div>
            </div>
          </div>

          <div style={{ ...formCard, marginBottom: 12 }}>
            <h3 style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 600, color: C.text }}>Endereço</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>CEP</label>
                <input value={empresa.cep ?? ''} onChange={e => setEmpField('cep', e.target.value)} placeholder="00000-000" style={inp()} />
              </div>
              <div style={{ gridColumn: '1 / -1', display: 'grid', gridTemplateColumns: '1fr 80px', gap: 12 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Logradouro</label>
                  <input value={empresa.endereco} onChange={e => setEmpField('endereco', e.target.value)} style={inp()} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Número</label>
                  <input value={empresa.numero ?? ''} onChange={e => setEmpField('numero', e.target.value)} style={inp()} />
                </div>
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Bairro</label>
                <input value={empresa.bairro ?? ''} onChange={e => setEmpField('bairro', e.target.value)} style={inp()} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 60px', gap: 12 }}>
                <div>
                  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Cidade</label>
                  <input value={empresa.cidade ?? ''} onChange={e => setEmpField('cidade', e.target.value)} style={inp()} />
                </div>
                <div>
                  <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>UF</label>
                  <input value={empresa.estado ?? ''} onChange={e => setEmpField('estado', e.target.value)} placeholder="SP" maxLength={2} style={inp()} />
                </div>
              </div>
            </div>
          </div>

          <div style={{ ...formCard, marginBottom: 12 }}>
            <h3 style={{ margin: '0 0 16px', fontSize: 13, fontWeight: 600, color: C.text }}>Redes sociais e horário</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px 16px' }}>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Horário de funcionamento</label>
                <input value={empresa.horarioFuncionamento ?? ''} onChange={e => setEmpField('horarioFuncionamento', e.target.value)} placeholder="Ex: Seg–Sex 8h–18h | Sáb 8h–13h" style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Instagram</label>
                <input value={empresa.redesSociais?.instagram ?? ''} onChange={e => setRedeField('instagram', e.target.value)} placeholder="@usuario" style={inp()} />
              </div>
              <div>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Facebook</label>
                <input value={empresa.redesSociais?.facebook ?? ''} onChange={e => setRedeField('facebook', e.target.value)} placeholder="pagina" style={inp()} />
              </div>
              <div style={{ gridColumn: '1 / -1' }}>
                <label style={{ display: 'block', fontSize: 12, fontWeight: 500, color: C.text, marginBottom: 4 }}>Website</label>
                <input value={empresa.redesSociais?.website ?? ''} onChange={e => setRedeField('website', e.target.value)} placeholder="www.empresa.com.br" style={inp()} />
              </div>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
            <button onClick={discardEmpresa} style={btnSecondary}>Descartar</button>
            <button onClick={saveEmpresa} style={btnPrimary}>Salvar dados da empresa</button>
          </div>
        </div>
      )}

      {/* ── Sair ── */}
      {tab === 'sair' && (
        <div style={formCard}>
          <h3 style={{ margin: '0 0 8px', fontSize: 13, fontWeight: 600, color: C.text }}>Encerrar sessão</h3>
          <p style={{ margin: '0 0 14px', fontSize: 13, color: C.textMuted }}>Você será redirecionado para a tela de login.</p>
          <button onClick={handleLogout} style={{ padding: '6px 14px', background: '#FEF3F2', color: '#B42318', border: '1px solid #FECDCA', borderRadius: 4, fontSize: 13, cursor: 'pointer', fontFamily: 'Inter, sans-serif' }}>
            Sair do sistema
          </button>
        </div>
      )}
    </div>
  );
}
