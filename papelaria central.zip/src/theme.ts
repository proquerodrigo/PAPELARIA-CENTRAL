export const C = {
  bg: '#F1F3F5',
  white: '#FFFFFF',
  navy: '#1D2129',        /* dark graphite — primary buttons / text accents */
  navyHover: '#252B34',
  primary: '#1D2129',
  accent: '#1A3D2B',      /* forest green — used ONLY for active states & success */
  text: '#101828',
  textMuted: '#6B7280',
  border: '#D1D5DB',
  borderLight: '#E5E7EB',
  /* metallic surface tokens */
  metalLight: '#F4F6F8',  /* very light silver-gray */
  metalMid:   '#E8ECF0',  /* medium silver for dividers/table headers */
  metalBorder: '#C4CAD4', /* metallic gray border */
  /* semantic */
  success: '#027A48',
  successBg: '#ECFDF3',
  successBorder: '#A9EFC5',
  warning: '#B54708',
  warningBg: '#FFFAEB',
  warningBorder: '#FEDF89',
  error: '#B42318',
  errorBg: '#FEF3F2',
  errorBorder: '#FECDCA',
  tableHeader: '#F4F6F8',
};

export const ROW_BORDER = `1px solid ${C.borderLight}`;

export const badge = {
  inStock:  { background: C.successBg,  color: C.success,  border: `1px solid ${C.successBorder}` },
  lowStock: { background: C.warningBg,  color: C.warning,  border: `1px solid ${C.warningBorder}` },
  noStock:  { background: C.errorBg,    color: C.error,    border: `1px solid ${C.errorBorder}` },
  active:   { background: C.successBg,  color: C.success,  border: `1px solid ${C.successBorder}` },
  inactive: { background: '#F9FAFB',    color: '#6B7280',  border: '1px solid #E4E7EC' },
  blocked:  { background: C.errorBg,    color: C.error,    border: `1px solid ${C.errorBorder}` },
  admin:    { background: '#EFF4FF',    color: '#3538CD',  border: '1px solid #C7D7FD' },
  employee: { background: '#F9FAFB',    color: '#344054',  border: '1px solid #E4E7EC' },
  entrada:  { background: C.successBg,  color: C.success,  border: `1px solid ${C.successBorder}` },
  saida:    { background: C.errorBg,    color: C.error,    border: `1px solid ${C.errorBorder}` },
};

export const inp = (err = false): React.CSSProperties => ({
  width: '100%',
  padding: '7px 10px',
  fontSize: 13,
  fontFamily: 'Inter, sans-serif',
  border: `1px solid ${err ? C.error : C.border}`,
  borderRadius: 6,
  outline: 'none',
  background: C.white,
  color: C.text,
  boxSizing: 'border-box' as const,
  lineHeight: '1.4',
});

export const btnPrimary: React.CSSProperties = {
  padding: '6px 14px',
  background: C.navy,
  color: C.white,
  border: 'none',
  borderRadius: 6,
  fontSize: 13,
  fontWeight: 500,
  cursor: 'pointer',
  fontFamily: 'Inter, sans-serif',
  whiteSpace: 'nowrap' as const,
};

export const btnSecondary: React.CSSProperties = {
  padding: '6px 14px',
  background: C.white,
  color: C.text,
  border: `1px solid ${C.border}`,
  borderRadius: 6,
  fontSize: 13,
  fontWeight: 400,
  cursor: 'pointer',
  fontFamily: 'Inter, sans-serif',
  whiteSpace: 'nowrap' as const,
};

export const btnDanger: React.CSSProperties = {
  padding: '6px 14px',
  background: C.errorBg,
  color: C.error,
  border: `1px solid ${C.errorBorder}`,
  borderRadius: 6,
  fontSize: 13,
  fontWeight: 400,
  cursor: 'pointer',
  fontFamily: 'Inter, sans-serif',
};

export const tbl: React.CSSProperties = {
  width: '100%',
  borderCollapse: 'collapse',
  fontSize: 13,
  color: C.text,
};

export const TH: React.CSSProperties = {
  padding: '8px 12px',
  textAlign: 'left',
  fontWeight: 500,
  color: C.textMuted,
  fontSize: 11,
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
  background: C.metalLight,
  borderBottom: `1px solid ${C.metalBorder}`,
  whiteSpace: 'nowrap' as const,
};

export const TD: React.CSSProperties = {
  padding: '9px 12px',
  color: C.text,
  verticalAlign: 'middle',
};

export const tableWrap: React.CSSProperties = {
  background: C.white,
  border: `1px solid ${C.border}`,
  borderRadius: 8,
  overflow: 'hidden',
};

export const sectionHeader: React.CSSProperties = {
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 12,
};

export const pageTitle: React.CSSProperties = {
  fontSize: 16,
  fontWeight: 600,
  color: C.text,
  margin: 0,
};

export const label: React.CSSProperties = {
  display: 'block',
  fontSize: 12,
  fontWeight: 500,
  color: C.text,
  marginBottom: 4,
};

export const formCard: React.CSSProperties = {
  background: C.white,
  border: `1px solid ${C.border}`,
  borderRadius: 8,
  padding: 24,
};
