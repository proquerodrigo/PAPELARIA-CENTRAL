Crie um protótipo de sistema web chamado “Papelaria Central”, um sistema simples de gerenciamento de uma papelaria, com foco em controle de estoque.

O projeto será apresentado como um TCC de alunos do 3º ano de Desenvolvimento de Sistemas. Portanto, NÃO quero um sistema exageradamente complexo. Quero algo realista, bonito, organizado e simples de entender, com aparência de um sistema desenvolvido por estudantes, sem aparência genérica de interface criada por IA.

IMPORTANTE:
- Criar todas as telas necessárias para representar o funcionamento do sistema.
- Organizar cada tela separadamente.
- Usar componentes simples e fáceis de editar.
- Nomear as camadas de forma clara.
- Evitar elementos muito complexos.
- Evitar excesso de animações.
- Evitar glassmorphism, gradientes exagerados e efeitos futuristas.
- Usar uma interface profissional, mas simples.
- Manter o mesmo padrão visual em todas as telas.
- Criar protótipo navegável entre as telas quando possível.

IDENTIDADE VISUAL:
Nome: Papelaria Central

Estilo:
- moderno
- limpo
- profissional
- simples
- aparência de sistema empresarial pequeno
- fácil de usar

Cores:
- fundo branco e cinza muito claro
- azul escuro como cor principal
- azul mais claro para detalhes
- verde para informações positivas
- vermelho/laranja para alertas de estoque
- textos em cinza escuro

Usar fonte Inter ou outra fonte simples e comum.

==================================================
SPRINT 1 — USUÁRIOS
==================================================

Criar as seguintes telas:

1. LOGIN

Elementos:
- Logo/nome “Papelaria Central”
- Texto “Controle de Estoque”
- Campo E-mail
- Campo Senha
- Checkbox “Lembrar de mim”
- Botão “Entrar”
- Link “Esqueci minha senha”
- Link “Criar uma conta”

O login deve possuir mensagens visuais de validação para:
- campos obrigatórios
- e-mail inválido
- senha incorreta
- usuário inativo ou bloqueado

2. CADASTRO DE USUÁRIO

Campos:
- Nome completo
- CPF
- E-mail
- Senha
- Confirmar senha
- Tipo de usuário

Tipos:
- Administrador
- Funcionário

Botões:
- Criar conta
- Cancelar
- Voltar para login

3. RECUPERAÇÃO DE SENHA

Criar tela com:
- E-mail
- Botão “Enviar recuperação”
- Mensagem de confirmação
- Link para voltar ao login

4. GERENCIAMENTO DE USUÁRIOS

Criar uma tabela contendo:
- Nome
- CPF
- E-mail
- Tipo
- Status
- Ações

Status:
- Ativo
- Inativo
- Bloqueado

Ações:
- Editar
- Alterar status

5. DASHBOARD

Criar um dashboard diferente conforme o tipo de usuário.

Administrador:
- Total de produtos
- Produtos com estoque baixo
- Total de clientes
- Total de funcionários
- Valor aproximado do estoque

Funcionário:
- Total de produtos
- Produtos com estoque baixo
- Atalhos para produtos e clientes

Menu lateral:
- Dashboard
- Produtos
- Categorias
- Clientes
- Funcionários
- Usuários
- Estoque
- Configurações
- Sair

==================================================
SPRINT 2 — CRUDS PRINCIPAIS
==================================================

Criar telas de CRUD para:

1. CATEGORIAS

Tabela:
- Nome da categoria
- Descrição
- Status
- Ações

Botão:
“+ Nova categoria”

Exemplos:
- Cadernos
- Escrita
- Material escolar
- Acessórios

2. PRODUTOS

Tela principal de produtos com:
- Campo de pesquisa
- Filtro por categoria
- Botão “+ Novo produto”

Tabela:
- Produto
- Categoria
- Quantidade
- Preço
- Status
- Ações

Exemplos:
- Caderno 10 matérias
- Caneta azul
- Lápis HB
- Borracha branca
- Marca-texto

Status:
- Em estoque
- Estoque baixo
- Sem estoque

3. CADASTRO/EDIÇÃO DE PRODUTO

Campos:
- Nome
- Categoria
- Descrição
- Quantidade
- Preço
- Estoque mínimo

Botões:
- Salvar produto
- Cancelar

4. CLIENTES

Tabela:
- Nome
- CPF
- E-mail
- Telefone
- Status
- Ações

Botão:
“+ Novo cliente”

Criar formulário de cadastro de cliente.

5. FUNCIONÁRIOS

Tabela:
- Nome
- CPF
- E-mail
- Cargo
- Status
- Ações

Botão:
“+ Novo funcionário”

Criar formulário simples de cadastro.

==================================================
SPRINT 3 — REGRAS DE NEGÓCIO
==================================================

Representar visualmente as seguintes regras:

1. Não permitir cadastrar produto com quantidade negativa.

2. Não permitir cadastrar produto sem nome, categoria ou preço.

3. Não permitir venda de produto quando o estoque estiver zerado.

4. Ao registrar uma venda, diminuir automaticamente a quantidade do produto no estoque.

5. Não permitir login de usuários inativos ou bloqueados.

6. Exibir alerta quando o produto atingir ou ficar abaixo do estoque mínimo.

Criar uma tela simples de “Movimentações de Estoque” mostrando:

- Produto
- Tipo de movimentação
- Quantidade
- Data
- Usuário responsável

Tipos:
- Entrada
- Saída

==================================================
TELA DE ESTOQUE
==================================================

Criar uma tela específica chamada “Estoque”.

Mostrar:
- Total de produtos
- Produtos em estoque
- Produtos com estoque baixo
- Produtos sem estoque

Criar tabela:
- Produto
- Quantidade atual
- Estoque mínimo
- Status
- Última movimentação

Adicionar botão:
“Registrar movimentação”

==================================================
CONFIGURAÇÕES
==================================================

Criar uma tela simples de configurações contendo:
- Nome do usuário
- E-mail
- Tipo de usuário
- Alterar senha
- Sair da conta

==================================================
NAVEGAÇÃO DO PROTÓTIPO
==================================================

Criar protótipo navegável entre as telas.

Fluxo principal:

Login → Dashboard

Login → Cadastro de usuário

Login → Recuperação de senha

Dashboard → Produtos

Dashboard → Categorias

Dashboard → Clientes

Dashboard → Funcionários

Dashboard → Usuários

Dashboard → Estoque

Produtos → Cadastro de produto

Produtos → Editar produto

Estoque → Movimentação de estoque

Configurações → Alterar senha

Todos os botões de voltar devem retornar para a tela anterior ou para o dashboard.

==================================================
DESIGN
==================================================

Quero um design bonito, mas NÃO exagerado.

Usar:
- cards simples
- tabelas organizadas
- botões claros
- ícones discretos
- bordas levemente arredondadas
- sombras muito sutis
- bastante espaço em branco

Não usar:
- neon
- 3D
- glassmorphism
- gradientes exagerados
- gráficos complexos
- elementos futuristas
- excesso de decoração

O resultado deve parecer um sistema real de uma pequena empresa e ser suficientemente simples para que um aluno consiga explicar cada tela durante uma apresentação.

ORGANIZE TODAS AS TELAS DE FORMA CLARA NO ARQUIVO DO FIGMA E DEIXE OS ELEMENTOS FÁCEIS DE SELECIONAR E EDITAR.