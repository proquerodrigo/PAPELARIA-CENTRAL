import type { DBProduct } from './db';

const MIG_KEY = 'pc_mig_v2_prods';
const PRODS_KEY = 'pc_v1_prods';

// =============================================================
// Banco de produtos estendido — Papelaria Central
// Aproximadamente 220 novos produtos + 10 existentes = ~230 total
// Distribuídos entre categorias usando marcas brasileiras reais
// =============================================================

const EXTENDED: Omit<DBProduct, 'photo'>[] = [
  // ── CANETAS (30) ─────────────────────────────────────────
  { id: 'p-011', code: 'P-011', name: 'BIC Cristal Azul Ponta Média 1.0mm', category: 'Escrita', price: 1.80, qty: 120, minStock: 50, description: 'Caneta esferográfica BIC Cristal, ponta média 1.0mm, tinta azul.', status: 'Em estoque' },
  { id: 'p-012', code: 'P-012', name: 'BIC Cristal Vermelha Ponta Média', category: 'Escrita', price: 1.80, qty: 80, minStock: 40, description: 'Caneta esferográfica BIC Cristal, tinta vermelha.', status: 'Em estoque' },
  { id: 'p-013', code: 'P-013', name: 'BIC Cristal Preta Ponta Média', category: 'Escrita', price: 1.80, qty: 95, minStock: 40, description: 'Caneta esferográfica BIC Cristal, tinta preta.', status: 'Em estoque' },
  { id: 'p-014', code: 'P-014', name: 'BIC Cristal Verde Ponta Média', category: 'Escrita', price: 1.80, qty: 40, minStock: 30, description: 'Caneta esferográfica BIC Cristal, tinta verde.', status: 'Em estoque' },
  { id: 'p-015', code: 'P-015', name: 'BIC 4 Cores Clássica', category: 'Escrita', price: 8.90, qty: 35, minStock: 20, description: 'Caneta BIC 4 cores: azul, vermelha, verde e preta.', status: 'Em estoque' },
  { id: 'p-016', code: 'P-016', name: 'BIC 4 Cores Grip', category: 'Escrita', price: 13.90, qty: 20, minStock: 10, description: 'Caneta BIC 4 cores com grip antiderrapante.', status: 'Em estoque' },
  { id: 'p-017', code: 'P-017', name: 'BIC Comfort 1 Azul', category: 'Escrita', price: 2.50, qty: 90, minStock: 40, description: 'Caneta esferográfica BIC Comfort, tinta azul.', status: 'Em estoque' },
  { id: 'p-018', code: 'P-018', name: 'BIC Comfort 1 Preta', category: 'Escrita', price: 2.50, qty: 60, minStock: 30, description: 'Caneta esferográfica BIC Comfort, tinta preta.', status: 'Em estoque' },
  { id: 'p-019', code: 'P-019', name: 'BIC Intensity Azul 0.7mm', category: 'Escrita', price: 3.50, qty: 45, minStock: 20, description: 'Caneta esferográfica BIC Intensity, ponta 0.7mm, azul.', status: 'Em estoque' },
  { id: 'p-020', code: 'P-020', name: 'BIC Gelocity Gel Azul 0.7mm', category: 'Escrita', price: 4.90, qty: 30, minStock: 15, description: 'Caneta gel BIC Gelocity, 0.7mm, escrita suave.', status: 'Em estoque' },
  { id: 'p-021', code: 'P-021', name: 'Pilot BP-1 Azul', category: 'Escrita', price: 1.90, qty: 100, minStock: 50, description: 'Caneta esferográfica Pilot BP-1, tinta azul.', status: 'Em estoque' },
  { id: 'p-022', code: 'P-022', name: 'Pilot BP-1 Preta', category: 'Escrita', price: 1.90, qty: 70, minStock: 40, description: 'Caneta esferográfica Pilot BP-1, tinta preta.', status: 'Em estoque' },
  { id: 'p-023', code: 'P-023', name: 'Pilot Super Grip Azul 0.7mm', category: 'Escrita', price: 3.90, qty: 50, minStock: 25, description: 'Caneta esferográfica Pilot Super Grip, grip emborrachado.', status: 'Em estoque' },
  { id: 'p-024', code: 'P-024', name: 'Pilot G-2 Gel Azul 0.7mm', category: 'Escrita', price: 7.90, qty: 25, minStock: 12, description: 'Caneta gel retrátil Pilot G-2, ponta 0.7mm.', status: 'Em estoque' },
  { id: 'p-025', code: 'P-025', name: 'Pilot G-2 Gel Preta 0.7mm', category: 'Escrita', price: 7.90, qty: 18, minStock: 12, description: 'Caneta gel retrátil Pilot G-2, tinta preta.', status: 'Em estoque' },
  { id: 'p-026', code: 'P-026', name: 'Faber-Castell Trilux 032 Azul', category: 'Escrita', price: 2.20, qty: 85, minStock: 40, description: 'Caneta Faber-Castell Trilux 032, tinta azul, ponta arredondada.', status: 'Em estoque' },
  { id: 'p-027', code: 'P-027', name: 'Faber-Castell Trilux 032 Preta', category: 'Escrita', price: 2.20, qty: 60, minStock: 30, description: 'Caneta Faber-Castell Trilux 032, tinta preta.', status: 'Em estoque' },
  { id: 'p-028', code: 'P-028', name: 'Faber-Castell Trilux 032 Vermelha', category: 'Escrita', price: 2.20, qty: 45, minStock: 25, description: 'Caneta Faber-Castell Trilux 032, tinta vermelha.', status: 'Em estoque' },
  { id: 'p-029', code: 'P-029', name: 'Faber-Castell Grip Azul 0.7mm', category: 'Escrita', price: 5.90, qty: 30, minStock: 15, description: 'Caneta Faber-Castell Grip, zona antiderrapante.', status: 'Em estoque' },
  { id: 'p-030', code: 'P-030', name: 'Faber-Castell Fine Pen 0.4mm Preta', category: 'Escrita', price: 6.90, qty: 22, minStock: 10, description: 'Caneta fina Faber-Castell, ponta 0.4mm, tinta preta.', status: 'Em estoque' },
  { id: 'p-031', code: 'P-031', name: 'Compactor 07 Azul', category: 'Escrita', price: 2.10, qty: 75, minStock: 35, description: 'Caneta esferográfica Compactor 07, tinta azul.', status: 'Em estoque' },
  { id: 'p-032', code: 'P-032', name: 'Compactor 07 Preta', category: 'Escrita', price: 2.10, qty: 55, minStock: 30, description: 'Caneta esferográfica Compactor 07, tinta preta.', status: 'Em estoque' },
  { id: 'p-033', code: 'P-033', name: 'Pentel R.S.V.P. Azul', category: 'Escrita', price: 4.90, qty: 28, minStock: 15, description: 'Caneta esferográfica Pentel R.S.V.P., tinta azul.', status: 'Em estoque' },
  { id: 'p-034', code: 'P-034', name: 'Pentel Energel Gel 0.7 Azul', category: 'Escrita', price: 8.90, qty: 20, minStock: 10, description: 'Caneta gel Pentel Energel, escrita rápida, 0.7mm.', status: 'Em estoque' },
  { id: 'p-035', code: 'P-035', name: 'Stabilo Liner 808 Azul', category: 'Escrita', price: 4.90, qty: 35, minStock: 15, description: 'Caneta esferográfica Stabilo Liner 808, tinta azul.', status: 'Em estoque' },
  { id: 'p-036', code: 'P-036', name: 'CIS Serena Azul', category: 'Escrita', price: 1.70, qty: 110, minStock: 50, description: 'Caneta esferográfica CIS Serena, tinta azul.', status: 'Em estoque' },
  { id: 'p-037', code: 'P-037', name: 'Tris GP4 Azul', category: 'Escrita', price: 1.60, qty: 90, minStock: 45, description: 'Caneta esferográfica Tris GP4, tinta azul.', status: 'Em estoque' },
  { id: 'p-038', code: 'P-038', name: 'Caneta Nanquim Staedtler 0.1mm', category: 'Escrita', price: 12.90, qty: 15, minStock: 5, description: 'Caneta técnica nanquim Staedtler Pigment Liner, 0.1mm.', status: 'Em estoque' },
  { id: 'p-039', code: 'P-039', name: 'Caneta Nanquim Staedtler 0.3mm', category: 'Escrita', price: 12.90, qty: 12, minStock: 5, description: 'Caneta técnica nanquim Staedtler Pigment Liner, 0.3mm.', status: 'Em estoque' },
  { id: 'p-040', code: 'P-040', name: 'Caneta Nanquim Staedtler 0.5mm', category: 'Escrita', price: 12.90, qty: 10, minStock: 5, description: 'Caneta técnica nanquim Staedtler Pigment Liner, 0.5mm.', status: 'Em estoque' },

  // ── LÁPIS (12) ──────────────────────────────────────────
  { id: 'p-041', code: 'P-041', name: 'Faber-Castell Escolar Nº 2 HB Cx 12', category: 'Escrita', price: 9.90, qty: 50, minStock: 20, description: 'Lápis grafite Faber-Castell nº 2 HB, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-042', code: 'P-042', name: 'Faber-Castell Escolar Nº 2 HB Cx 24', category: 'Escrita', price: 18.90, qty: 30, minStock: 12, description: 'Lápis grafite Faber-Castell nº 2 HB, caixa com 24 unidades.', status: 'Em estoque' },
  { id: 'p-043', code: 'P-043', name: 'Faber-Castell 9000 HB', category: 'Escrita', price: 2.50, qty: 60, minStock: 20, description: 'Lápis profissional Faber-Castell 9000, graduação HB.', status: 'Em estoque' },
  { id: 'p-044', code: 'P-044', name: 'Faber-Castell 9000 2B', category: 'Escrita', price: 2.50, qty: 40, minStock: 15, description: 'Lápis profissional Faber-Castell 9000, graduação 2B.', status: 'Em estoque' },
  { id: 'p-045', code: 'P-045', name: 'Faber-Castell 9000 4B', category: 'Escrita', price: 2.80, qty: 30, minStock: 10, description: 'Lápis profissional Faber-Castell 9000, graduação 4B.', status: 'Em estoque' },
  { id: 'p-046', code: 'P-046', name: 'Faber-Castell Jumbo Triangular Cx 12', category: 'Escrita', price: 24.90, qty: 18, minStock: 8, description: 'Lápis Jumbo triangular Faber-Castell, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-047', code: 'P-047', name: 'BIC Evolution Stripes HB Cx 12', category: 'Escrita', price: 8.50, qty: 42, minStock: 18, description: 'Lápis BIC Evolution Stripes HB, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-048', code: 'P-048', name: 'Staedtler Noris 122 HB Cx 12', category: 'Escrita', price: 12.90, qty: 25, minStock: 10, description: 'Lápis Staedtler Noris 122 HB, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-049', code: 'P-049', name: 'Maped Black Peps HB Cx 12', category: 'Escrita', price: 9.90, qty: 35, minStock: 15, description: 'Lápis Maped Black\'Peps HB, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-050', code: 'P-050', name: 'Tilibra Lápis Preto HB Cx 12', category: 'Escrita', price: 7.90, qty: 55, minStock: 22, description: 'Lápis grafite Tilibra HB, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-051', code: 'P-051', name: 'Leo & Leo Redondo Nº 2 Cx 12', category: 'Escrita', price: 6.90, qty: 45, minStock: 20, description: 'Lápis Leo&Leo redondo nº 2, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-052', code: 'P-052', name: 'Molin Lápis HB Cx 12', category: 'Escrita', price: 6.50, qty: 38, minStock: 15, description: 'Lápis Molin HB, caixa com 12 unidades.', status: 'Em estoque' },

  // ── LAPISEIRAS (12) ─────────────────────────────────────
  { id: 'p-053', code: 'P-053', name: 'Faber-Castell Grip 0.5mm Lapiseira', category: 'Escrita', price: 12.90, qty: 25, minStock: 10, description: 'Lapiseira Faber-Castell Grip 0.5mm com zona antiderrapante.', status: 'Em estoque' },
  { id: 'p-054', code: 'P-054', name: 'Pentel PD105 Lapiseira 0.5mm', category: 'Escrita', price: 11.90, qty: 20, minStock: 8, description: 'Lapiseira Pentel PD105, 0.5mm, confiável e ergonômica.', status: 'Em estoque' },
  { id: 'p-055', code: 'P-055', name: 'Pentel P205 Lapiseira 0.5mm Metal', category: 'Escrita', price: 18.90, qty: 14, minStock: 6, description: 'Lapiseira Pentel P205, corpo metálico, 0.5mm.', status: 'Em estoque' },
  { id: 'p-056', code: 'P-056', name: 'Pilot H-185 Lapiseira 0.5mm', category: 'Escrita', price: 13.90, qty: 18, minStock: 8, description: 'Lapiseira Pilot H-185, ponta 0.5mm, grip emborrachado.', status: 'Em estoque' },
  { id: 'p-057', code: 'P-057', name: 'Maped Croc Lapiseira 0.5mm', category: 'Escrita', price: 9.90, qty: 22, minStock: 10, description: 'Lapiseira Maped Croc, 0.5mm, design ergonômico.', status: 'Em estoque' },
  { id: 'p-058', code: 'P-058', name: 'BIC Matic Original Lapiseira 0.5mm', category: 'Escrita', price: 8.90, qty: 30, minStock: 12, description: 'Lapiseira BIC Matic Original, 0.5mm, clássica.', status: 'Em estoque' },
  { id: 'p-059', code: 'P-059', name: 'BIC Matic Grip Lapiseira 0.7mm', category: 'Escrita', price: 9.90, qty: 25, minStock: 10, description: 'Lapiseira BIC Matic Grip, 0.7mm, grip antiderrapante.', status: 'Em estoque' },
  { id: 'p-060', code: 'P-060', name: 'Faber-Castell Poly Matic 0.7mm', category: 'Escrita', price: 14.90, qty: 16, minStock: 7, description: 'Lapiseira Faber-Castell Poly Matic, 0.7mm.', status: 'Em estoque' },
  { id: 'p-061', code: 'P-061', name: 'Pilot H-285 Lapiseira 0.7mm', category: 'Escrita', price: 14.90, qty: 12, minStock: 5, description: 'Lapiseira Pilot H-285, ponta 0.7mm.', status: 'Em estoque' },
  { id: 'p-062', code: 'P-062', name: 'Pentel PD107 Lapiseira 0.7mm', category: 'Escrita', price: 11.90, qty: 18, minStock: 8, description: 'Lapiseira Pentel PD107, 0.7mm.', status: 'Em estoque' },
  { id: 'p-063', code: 'P-063', name: 'Maped Croc Lapiseira 0.7mm', category: 'Escrita', price: 9.90, qty: 20, minStock: 8, description: 'Lapiseira Maped Croc, 0.7mm.', status: 'Em estoque' },
  { id: 'p-064', code: 'P-064', name: 'Stabilo EasyErgo Lapiseira 0.5mm', category: 'Escrita', price: 19.90, qty: 10, minStock: 4, description: 'Lapiseira ergonômica Stabilo EasyErgo, especial para aprendizado.', status: 'Em estoque' },

  // ── MARCA-TEXTOS (12) ───────────────────────────────────
  { id: 'p-065', code: 'P-065', name: 'Stabilo Boss Original Amarelo', category: 'Escrita', price: 5.90, qty: 55, minStock: 25, description: 'Marca-texto Stabilo Boss Original, amarelo, ponta chanfrada.', status: 'Em estoque' },
  { id: 'p-066', code: 'P-066', name: 'Stabilo Boss Original Rosa', category: 'Escrita', price: 5.90, qty: 40, minStock: 20, description: 'Marca-texto Stabilo Boss Original, rosa.', status: 'Em estoque' },
  { id: 'p-067', code: 'P-067', name: 'Stabilo Boss Original Verde', category: 'Escrita', price: 5.90, qty: 38, minStock: 20, description: 'Marca-texto Stabilo Boss Original, verde.', status: 'Em estoque' },
  { id: 'p-068', code: 'P-068', name: 'Stabilo Boss Original Azul', category: 'Escrita', price: 5.90, qty: 32, minStock: 15, description: 'Marca-texto Stabilo Boss Original, azul claro.', status: 'Em estoque' },
  { id: 'p-069', code: 'P-069', name: 'Stabilo Boss Original Laranja', category: 'Escrita', price: 5.90, qty: 28, minStock: 15, description: 'Marca-texto Stabilo Boss Original, laranja.', status: 'Em estoque' },
  { id: 'p-070', code: 'P-070', name: 'Stabilo Boss Kit 6 Cores', category: 'Escrita', price: 32.90, qty: 14, minStock: 6, description: 'Kit Stabilo Boss 6 cores: amarelo, rosa, verde, azul, laranja e lilás.', status: 'Em estoque' },
  { id: 'p-071', code: 'P-071', name: 'Pilot Frixion Light Amarelo', category: 'Escrita', price: 9.90, qty: 22, minStock: 10, description: 'Marca-texto Pilot Frixion Light apagável, amarelo.', status: 'Em estoque' },
  { id: 'p-072', code: 'P-072', name: 'Pilot Frixion Light Rosa', category: 'Escrita', price: 9.90, qty: 18, minStock: 8, description: 'Marca-texto Pilot Frixion Light apagável, rosa.', status: 'Em estoque' },
  { id: 'p-073', code: 'P-073', name: 'Faber-Castell Grifpen Amarelo', category: 'Escrita', price: 4.90, qty: 45, minStock: 20, description: 'Marca-texto Faber-Castell Grifpen, amarelo.', status: 'Em estoque' },
  { id: 'p-074', code: 'P-074', name: 'Faber-Castell Grifpen Verde', category: 'Escrita', price: 4.90, qty: 35, minStock: 15, description: 'Marca-texto Faber-Castell Grifpen, verde.', status: 'Em estoque' },
  { id: 'p-075', code: 'P-075', name: 'Maped Fluorescent Amarelo', category: 'Escrita', price: 3.90, qty: 40, minStock: 18, description: 'Marca-texto Maped Fluorescent, amarelo.', status: 'Em estoque' },
  { id: 'p-076', code: 'P-076', name: 'BIC Marking Fluorescent Amarelo', category: 'Escrita', price: 4.50, qty: 38, minStock: 18, description: 'Marca-texto BIC Marking Fluorescent, amarelo.', status: 'Em estoque' },

  // ── CADERNOS E BLOCOS (21) ──────────────────────────────
  { id: 'p-077', code: 'P-077', name: 'Tilibra Universitário 1 Matéria Esp. 96fl', category: 'Cadernos', price: 11.90, qty: 38, minStock: 15, description: 'Caderno universitário espiral Tilibra, 1 matéria, 96 folhas.', status: 'Em estoque' },
  { id: 'p-078', code: 'P-078', name: 'Tilibra Universitário 5 Matérias Esp.', category: 'Cadernos', price: 22.90, qty: 25, minStock: 10, description: 'Caderno universitário espiral Tilibra, 5 matérias, 200 folhas.', status: 'Em estoque' },
  { id: 'p-079', code: 'P-079', name: 'Tilibra Universitário 10 Matérias Esp.', category: 'Cadernos', price: 34.90, qty: 20, minStock: 8, description: 'Caderno universitário espiral Tilibra, 10 matérias, capa dura.', status: 'Em estoque' },
  { id: 'p-080', code: 'P-080', name: 'Tilibra Brochura Universitário 200fl', category: 'Cadernos', price: 19.90, qty: 30, minStock: 12, description: 'Caderno brochura universitário Tilibra, 200 folhas.', status: 'Em estoque' },
  { id: 'p-081', code: 'P-081', name: 'Spiral Smart Universitário 1 Matéria', category: 'Cadernos', price: 13.90, qty: 28, minStock: 12, description: 'Caderno universitário espiral Spiral Smart, 1 matéria.', status: 'Em estoque' },
  { id: 'p-082', code: 'P-082', name: 'Spiral Smart Universitário 5 Matérias', category: 'Cadernos', price: 24.90, qty: 18, minStock: 8, description: 'Caderno universitário espiral Spiral Smart, 5 matérias.', status: 'Em estoque' },
  { id: 'p-083', code: 'P-083', name: 'Spiral Universitário 10 Matérias Capa Dura', category: 'Cadernos', price: 36.90, qty: 15, minStock: 6, description: 'Caderno universitário espiral Spiral, 10 matérias, capa dura.', status: 'Em estoque' },
  { id: 'p-084', code: 'P-084', name: 'Foroni Universitário 10 Matérias', category: 'Cadernos', price: 29.90, qty: 16, minStock: 7, description: 'Caderno universitário Foroni, 10 matérias.', status: 'Em estoque' },
  { id: 'p-085', code: 'P-085', name: 'Foroni Universitário 1 Matéria 96fl', category: 'Cadernos', price: 12.90, qty: 30, minStock: 12, description: 'Caderno universitário Foroni, 1 matéria, 96 folhas.', status: 'Em estoque' },
  { id: 'p-086', code: 'P-086', name: 'Caderno Brochura Capa Dura 96fl Tilibra', category: 'Cadernos', price: 8.90, qty: 40, minStock: 18, description: 'Caderno brochura capa dura Tilibra, 96 folhas.', status: 'Em estoque' },
  { id: 'p-087', code: 'P-087', name: 'Caderno Quadriculado Brochura 48fl', category: 'Cadernos', price: 7.90, qty: 28, minStock: 12, description: 'Caderno quadriculado brochura, 48 folhas.', status: 'Em estoque' },
  { id: 'p-088', code: 'P-088', name: 'Caderno Pedagógico Pequeno 96fl', category: 'Cadernos', price: 9.90, qty: 22, minStock: 10, description: 'Caderno pedagógico pequeno, 96 folhas.', status: 'Em estoque' },
  { id: 'p-089', code: 'P-089', name: 'Bloco de Anotações A4 Sem Pauta 50fl', category: 'Cadernos', price: 9.90, qty: 25, minStock: 10, description: 'Bloco de anotações A4 sem pauta, 50 folhas.', status: 'Em estoque' },
  { id: 'p-090', code: 'P-090', name: 'Bloco Post-it 3M 76x76mm Amarelo 100fl', category: 'Cadernos', price: 14.90, qty: 35, minStock: 15, description: 'Bloco de notas autoadesivo Post-it 3M, 76x76mm, 100 folhas.', status: 'Em estoque' },
  { id: 'p-091', code: 'P-091', name: 'Bloco Post-it 3M 76x76mm 4 Cores', category: 'Cadernos', price: 22.90, qty: 20, minStock: 8, description: 'Bloco Post-it 3M, 4 cores, 76x76mm.', status: 'Em estoque' },
  { id: 'p-092', code: 'P-092', name: 'Bloco Post-it 3M 38x51mm Amarelo', category: 'Cadernos', price: 9.90, qty: 42, minStock: 18, description: 'Bloco Post-it 3M, 38x51mm, amarelo.', status: 'Em estoque' },
  { id: 'p-093', code: 'P-093', name: 'Agenda 2026 Diária Tilibra', category: 'Cadernos', price: 34.90, qty: 12, minStock: 5, description: 'Agenda diária Tilibra 2026, capa dura.', status: 'Em estoque' },
  { id: 'p-094', code: 'P-094', name: 'Agenda 2026 Semanal Tilibra', category: 'Cadernos', price: 24.90, qty: 15, minStock: 6, description: 'Agenda semanal Tilibra 2026.', status: 'Em estoque' },
  { id: 'p-095', code: 'P-095', name: 'Caderno Brochurão 160fl Tilibra', category: 'Cadernos', price: 15.90, qty: 20, minStock: 8, description: 'Caderno brochurão Tilibra, 160 folhas.', status: 'Em estoque' },
  { id: 'p-096', code: 'P-096', name: 'Bloco Reporter Espiral 80fl', category: 'Cadernos', price: 12.90, qty: 18, minStock: 7, description: 'Bloco de reporter espiral, 80 folhas.', status: 'Em estoque' },
  { id: 'p-097', code: 'P-097', name: 'Caderneta Pequena 48fl Foroni', category: 'Cadernos', price: 5.90, qty: 35, minStock: 15, description: 'Caderneta pequena Foroni, 48 folhas.', status: 'Em estoque' },

  // ── PAPÉIS E CARTOLINAS (17) ────────────────────────────
  { id: 'p-098', code: 'P-098', name: 'Papel Sulfite A4 75g 500fl Chamex Office', category: 'Impressão', price: 26.90, qty: 40, minStock: 15, description: 'Papel Chamex Office A4 75g/m², 500 folhas, brancura 91%.', status: 'Em estoque' },
  { id: 'p-099', code: 'P-099', name: 'Papel Sulfite A4 75g 500fl Report', category: 'Impressão', price: 24.90, qty: 35, minStock: 15, description: 'Papel Report A4 75g/m², 500 folhas.', status: 'Em estoque' },
  { id: 'p-100', code: 'P-100', name: 'Papel Sulfite A4 90g 500fl Chamex', category: 'Impressão', price: 34.90, qty: 20, minStock: 8, description: 'Papel Chamex A4 90g/m², 500 folhas, para impressoras laser.', status: 'Em estoque' },
  { id: 'p-101', code: 'P-101', name: 'Papel Kraft A4 100g Cx 100fl', category: 'Impressão', price: 18.90, qty: 15, minStock: 5, description: 'Papel kraft A4 100g, caixa com 100 folhas.', status: 'Em estoque' },
  { id: 'p-102', code: 'P-102', name: 'Cartolina Colorida 50x66cm', category: 'Impressão', price: 1.90, qty: 80, minStock: 30, description: 'Cartolina colorida 50x66cm, cores sortidas.', status: 'Em estoque' },
  { id: 'p-103', code: 'P-103', name: 'Cartolina Branca 50x66cm', category: 'Impressão', price: 1.90, qty: 60, minStock: 25, description: 'Cartolina branca 50x66cm.', status: 'Em estoque' },
  { id: 'p-104', code: 'P-104', name: 'Cartolina Duplex 50x66cm', category: 'Impressão', price: 2.90, qty: 45, minStock: 18, description: 'Cartolina duplex 50x66cm.', status: 'Em estoque' },
  { id: 'p-105', code: 'P-105', name: 'Papel para Desenho A3 90g', category: 'Impressão', price: 1.50, qty: 50, minStock: 20, description: 'Folha papel para desenho A3 90g.', status: 'Em estoque' },
  { id: 'p-106', code: 'P-106', name: 'Papel para Desenho A4 Bloco 20fl', category: 'Impressão', price: 12.90, qty: 18, minStock: 7, description: 'Bloco de papel para desenho A4 90g, 20 folhas.', status: 'Em estoque' },
  { id: 'p-107', code: 'P-107', name: 'Papel Reciclado A4 75g 500fl', category: 'Impressão', price: 22.90, qty: 16, minStock: 6, description: 'Papel reciclado A4 75g, 500 folhas.', status: 'Em estoque' },
  { id: 'p-108', code: 'P-108', name: 'EVA Liso 40x60cm Sortido Cx 10fl', category: 'Impressão', price: 5.90, qty: 30, minStock: 12, description: 'Folha de EVA liso 40x60cm, cores sortidas, caixa com 10 folhas.', status: 'Em estoque' },
  { id: 'p-109', code: 'P-109', name: 'EVA com Glitter 40x60cm', category: 'Impressão', price: 4.90, qty: 25, minStock: 10, description: 'Folha de EVA com glitter 40x60cm.', status: 'Em estoque' },
  { id: 'p-110', code: 'P-110', name: 'Papel de Origami Sortido 15x15cm 100fl', category: 'Impressão', price: 9.90, qty: 20, minStock: 8, description: 'Papel de origami sortido 15x15cm, 100 folhas.', status: 'Em estoque' },
  { id: 'p-111', code: 'P-111', name: 'Papel Contact Transparente 45cm x 5m', category: 'Impressão', price: 12.90, qty: 14, minStock: 5, description: 'Rolo de papel contact transparente, 45cm x 5m.', status: 'Em estoque' },
  { id: 'p-112', code: 'P-112', name: 'Papel Seda 50x70cm Pct 25fl', category: 'Impressão', price: 8.90, qty: 18, minStock: 6, description: 'Papel seda colorido 50x70cm, pacote com 25 folhas.', status: 'Em estoque' },
  { id: 'p-113', code: 'P-113', name: 'Bobina Papel Kraft 60cm x 30m', category: 'Impressão', price: 29.90, qty: 8, minStock: 3, description: 'Bobina de papel kraft 60cm de largura, 30 metros.', status: 'Em estoque' },
  { id: 'p-114', code: 'P-114', name: 'Papel Vegetal A4 90g 50fl', category: 'Impressão', price: 19.90, qty: 10, minStock: 4, description: 'Papel vegetal A4 90g, pacote com 50 folhas.', status: 'Em estoque' },

  // ── BORRACHAS E APONTADORES (12) ────────────────────────
  { id: 'p-115', code: 'P-115', name: 'Borracha Faber-Castell Mágica Pequena', category: 'Material Escolar', price: 1.90, qty: 90, minStock: 40, description: 'Borracha Faber-Castell Mágica, pequena.', status: 'Em estoque' },
  { id: 'p-116', code: 'P-116', name: 'Borracha Faber-Castell Mágica Grande', category: 'Material Escolar', price: 2.90, qty: 65, minStock: 30, description: 'Borracha Faber-Castell Mágica, grande.', status: 'Em estoque' },
  { id: 'p-117', code: 'P-117', name: 'Borracha Staedtler Mars Plastic', category: 'Material Escolar', price: 3.90, qty: 40, minStock: 18, description: 'Borracha Staedtler Mars Plastic para desenho técnico.', status: 'Em estoque' },
  { id: 'p-118', code: 'P-118', name: 'Borracha Tilibra Economy', category: 'Material Escolar', price: 0.90, qty: 120, minStock: 50, description: 'Borracha Tilibra Economy, econômica.', status: 'Em estoque' },
  { id: 'p-119', code: 'P-119', name: 'Borracha Pentel Hyperaser', category: 'Material Escolar', price: 3.50, qty: 25, minStock: 10, description: 'Borracha Pentel Hyperaser plástica, alta eficiência.', status: 'Em estoque' },
  { id: 'p-120', code: 'P-120', name: 'Apontador Faber-Castell Duplo com Depósito', category: 'Material Escolar', price: 4.90, qty: 55, minStock: 25, description: 'Apontador Faber-Castell duplo com depósito, lápis normal e jumbo.', status: 'Em estoque' },
  { id: 'p-121', code: 'P-121', name: 'Apontador Maped Twist Curl com Depósito', category: 'Material Escolar', price: 7.90, qty: 30, minStock: 12, description: 'Apontador Maped Twist & Curl com depósito.', status: 'Em estoque' },
  { id: 'p-122', code: 'P-122', name: 'Apontador BIC Duplo com Depósito', category: 'Material Escolar', price: 5.90, qty: 35, minStock: 15, description: 'Apontador BIC Sharpener duplo com depósito.', status: 'Em estoque' },
  { id: 'p-123', code: 'P-123', name: 'Apontador Elétrico Tilibra 110V', category: 'Material Escolar', price: 49.90, qty: 6, minStock: 2, description: 'Apontador elétrico Tilibra 110V, afia lápis rapidamente.', status: 'Em estoque' },
  { id: 'p-124', code: 'P-124', name: 'Apontador Molin 2 Furos com Depósito', category: 'Material Escolar', price: 3.90, qty: 40, minStock: 18, description: 'Apontador Molin 2 furos com depósito.', status: 'Em estoque' },
  { id: 'p-125', code: 'P-125', name: 'Apontador Metálico 2 Furos Leo & Leo', category: 'Material Escolar', price: 2.90, qty: 28, minStock: 12, description: 'Apontador metálico Leo&Leo, 2 furos.', status: 'Em estoque' },
  { id: 'p-126', code: 'P-126', name: 'Borracha CIS Spiral Pequena', category: 'Material Escolar', price: 1.50, qty: 55, minStock: 25, description: 'Borracha CIS Spiral, pequena.', status: 'Em estoque' },

  // ── LÁPIS DE COR / CANETINHAS / ARTÍSTICO (21) ─────────
  { id: 'p-127', code: 'P-127', name: 'Faber-Castell Ecolápis de Cor 12 Cores', category: 'Papelaria Artística', price: 12.90, qty: 35, minStock: 15, description: 'Lápis de cor Faber-Castell Ecolápis, 12 cores.', status: 'Em estoque' },
  { id: 'p-128', code: 'P-128', name: 'Faber-Castell Ecolápis de Cor 24 Cores', category: 'Papelaria Artística', price: 24.90, qty: 25, minStock: 10, description: 'Lápis de cor Faber-Castell Ecolápis, 24 cores.', status: 'Em estoque' },
  { id: 'p-129', code: 'P-129', name: 'Faber-Castell Ecolápis de Cor 36 Cores', category: 'Papelaria Artística', price: 36.90, qty: 16, minStock: 6, description: 'Lápis de cor Faber-Castell Ecolápis, 36 cores.', status: 'Em estoque' },
  { id: 'p-130', code: 'P-130', name: 'Faber-Castell Ecolápis de Cor 60 Cores', category: 'Papelaria Artística', price: 59.90, qty: 8, minStock: 3, description: 'Lápis de cor Faber-Castell Ecolápis, 60 cores, estojo metálico.', status: 'Em estoque' },
  { id: 'p-131', code: 'P-131', name: 'Faber-Castell Aquarela 12 Cores', category: 'Papelaria Artística', price: 28.90, qty: 12, minStock: 5, description: 'Lápis aquarela Faber-Castell, 12 cores.', status: 'Em estoque' },
  { id: 'p-132', code: 'P-132', name: 'Maped ColorPeps Lápis de Cor 12 Cores', category: 'Papelaria Artística', price: 14.90, qty: 30, minStock: 12, description: 'Lápis de cor Maped Color\'Peps, 12 cores.', status: 'Em estoque' },
  { id: 'p-133', code: 'P-133', name: 'Maped ColorPeps Lápis de Cor 24 Cores', category: 'Papelaria Artística', price: 22.90, qty: 18, minStock: 8, description: 'Lápis de cor Maped Color\'Peps, 24 cores.', status: 'Em estoque' },
  { id: 'p-134', code: 'P-134', name: 'Staedtler Luna Lápis de Cor 12 Cores', category: 'Papelaria Artística', price: 16.90, qty: 22, minStock: 8, description: 'Lápis de cor Staedtler Luna, 12 cores.', status: 'Em estoque' },
  { id: 'p-135', code: 'P-135', name: 'BIC Kids Lápis de Cor 12 Cores', category: 'Papelaria Artística', price: 11.90, qty: 28, minStock: 12, description: 'Lápis de cor BIC Kids, 12 cores.', status: 'Em estoque' },
  { id: 'p-136', code: 'P-136', name: 'Tilibra Vai-Vem Lápis de Cor 12 Cores', category: 'Papelaria Artística', price: 9.90, qty: 32, minStock: 14, description: 'Lápis de cor Tilibra Vai-Vem, 12 cores.', status: 'Em estoque' },
  { id: 'p-137', code: 'P-137', name: 'Faber-Castell Canetinha 12 Cores', category: 'Papelaria Artística', price: 14.90, qty: 30, minStock: 12, description: 'Canetinha hidrográfica Faber-Castell, 12 cores.', status: 'Em estoque' },
  { id: 'p-138', code: 'P-138', name: 'Faber-Castell Canetinha 24 Cores', category: 'Papelaria Artística', price: 24.90, qty: 20, minStock: 8, description: 'Canetinha hidrográfica Faber-Castell, 24 cores.', status: 'Em estoque' },
  { id: 'p-139', code: 'P-139', name: 'BIC Kids Canetinha 12 Cores', category: 'Papelaria Artística', price: 13.90, qty: 25, minStock: 10, description: 'Canetinha hidrográfica BIC Kids, 12 cores.', status: 'Em estoque' },
  { id: 'p-140', code: 'P-140', name: 'Stabilo Power Canetinha 12 Cores', category: 'Papelaria Artística', price: 29.90, qty: 15, minStock: 6, description: 'Canetinha hidrográfica Stabilo Power, 12 cores.', status: 'Em estoque' },
  { id: 'p-141', code: 'P-141', name: 'Stabilo Power Canetinha 24 Cores', category: 'Papelaria Artística', price: 44.90, qty: 10, minStock: 4, description: 'Canetinha hidrográfica Stabilo Power, 24 cores.', status: 'Em estoque' },
  { id: 'p-142', code: 'P-142', name: 'Acrilex Tinta Guache 6 Cores 15ml', category: 'Papelaria Artística', price: 12.90, qty: 20, minStock: 8, description: 'Tinta guache Acrilex, 6 cores, potes de 15ml.', status: 'Em estoque' },
  { id: 'p-143', code: 'P-143', name: 'Acrilex Tinta Guache 12 Cores 15ml', category: 'Papelaria Artística', price: 24.90, qty: 14, minStock: 5, description: 'Tinta guache Acrilex, 12 cores, potes de 15ml.', status: 'Em estoque' },
  { id: 'p-144', code: 'P-144', name: 'Acrilex Tinta Acrílica 37ml', category: 'Papelaria Artística', price: 8.90, qty: 25, minStock: 10, description: 'Tinta acrílica Acrilex, frasco 37ml, cor sortida.', status: 'Em estoque' },
  { id: 'p-145', code: 'P-145', name: 'Giz de Cera Faber-Castell 12 Cores', category: 'Papelaria Artística', price: 9.90, qty: 35, minStock: 15, description: 'Giz de cera Faber-Castell, 12 cores.', status: 'Em estoque' },
  { id: 'p-146', code: 'P-146', name: 'Giz de Cera Faber-Castell 24 Cores', category: 'Papelaria Artística', price: 16.90, qty: 20, minStock: 8, description: 'Giz de cera Faber-Castell, 24 cores.', status: 'Em estoque' },
  { id: 'p-147', code: 'P-147', name: 'Giz de Cera Molin 12 Cores', category: 'Papelaria Artística', price: 6.90, qty: 28, minStock: 12, description: 'Giz de cera Molin, 12 cores.', status: 'Em estoque' },

  // ── COLAS E ADESIVOS (13) ───────────────────────────────
  { id: 'p-148', code: 'P-148', name: 'Cola Branca Escolar Tilibra 90g', category: 'Acessórios', price: 3.90, qty: 60, minStock: 25, description: 'Cola branca escolar Tilibra, 90g.', status: 'Em estoque' },
  { id: 'p-149', code: 'P-149', name: 'Cola Branca Faber-Castell 90g', category: 'Acessórios', price: 4.50, qty: 45, minStock: 20, description: 'Cola branca Faber-Castell, 90g.', status: 'Em estoque' },
  { id: 'p-150', code: 'P-150', name: 'Cola Branca Escolar 250g', category: 'Acessórios', price: 7.90, qty: 30, minStock: 12, description: 'Cola branca escolar, frasco 250g.', status: 'Em estoque' },
  { id: 'p-151', code: 'P-151', name: 'Cola Bastão Faber-Castell 21g', category: 'Acessórios', price: 4.90, qty: 55, minStock: 22, description: 'Cola bastão Faber-Castell, 21g.', status: 'Em estoque' },
  { id: 'p-152', code: 'P-152', name: 'Pritt Cola Bastão 22g', category: 'Acessórios', price: 5.90, qty: 40, minStock: 18, description: 'Cola bastão Pritt 22g, sem toxicidade.', status: 'Em estoque' },
  { id: 'p-153', code: 'P-153', name: 'Pritt Cola Bastão 43g', category: 'Acessórios', price: 8.90, qty: 25, minStock: 10, description: 'Cola bastão Pritt 43g.', status: 'Em estoque' },
  { id: 'p-154', code: 'P-154', name: 'Fita Durex Magic Tape 12mm x 30m', category: 'Acessórios', price: 7.90, qty: 35, minStock: 15, description: 'Fita adesiva Durex Magic Tape 12mm x 30m.', status: 'Em estoque' },
  { id: 'p-155', code: 'P-155', name: 'Fita Scotch 3M 12mm x 25m', category: 'Acessórios', price: 8.90, qty: 28, minStock: 12, description: 'Fita adesiva Scotch 3M, 12mm x 25m.', status: 'Em estoque' },
  { id: 'p-156', code: 'P-156', name: 'Fita Crepe 18mm x 50m', category: 'Acessórios', price: 3.90, qty: 40, minStock: 18, description: 'Fita crepe 18mm x 50m.', status: 'Em estoque' },
  { id: 'p-157', code: 'P-157', name: 'Fita Adesiva Dupla Face 12mm x 10m', category: 'Acessórios', price: 5.90, qty: 25, minStock: 10, description: 'Fita adesiva dupla face Compactor, 12mm x 10m.', status: 'Em estoque' },
  { id: 'p-158', code: 'P-158', name: 'Fita Isolante Preta 18mm x 10m', category: 'Acessórios', price: 3.50, qty: 22, minStock: 8, description: 'Fita isolante preta 18mm x 10m.', status: 'Em estoque' },
  { id: 'p-159', code: 'P-159', name: 'UHU Cola Líquida 35ml', category: 'Acessórios', price: 8.90, qty: 18, minStock: 7, description: 'Cola líquida UHU, frasco 35ml.', status: 'Em estoque' },
  { id: 'p-160', code: 'P-160', name: 'Cola Epóxi Loctite 15min 25ml', category: 'Acessórios', price: 12.90, qty: 12, minStock: 4, description: 'Cola epóxi Loctite, cura em 15 minutos, 25ml.', status: 'Em estoque' },

  // ── MATERIAIS DE ESCRITÓRIO (18) ────────────────────────
  { id: 'p-161', code: 'P-161', name: 'Grampeador Maped Vulcano 15fl', category: 'Acessórios', price: 24.90, qty: 18, minStock: 5, description: 'Grampeador Maped Vulcano, capacidade 15 folhas.', status: 'Em estoque' },
  { id: 'p-162', code: 'P-162', name: 'Grampeador Maped Ginger 30fl', category: 'Acessórios', price: 39.90, qty: 12, minStock: 4, description: 'Grampeador Maped Ginger, capacidade 30 folhas.', status: 'Em estoque' },
  { id: 'p-163', code: 'P-163', name: 'Grampos 26/6 Compactor Cx 5000', category: 'Acessórios', price: 9.90, qty: 30, minStock: 10, description: 'Grampos Compactor 26/6, caixa com 5000 unidades.', status: 'Em estoque' },
  { id: 'p-164', code: 'P-164', name: 'Grampos 24/6 Jocar Office Cx 5000', category: 'Acessórios', price: 8.90, qty: 25, minStock: 10, description: 'Grampos Jocar Office 24/6, caixa com 5000 unidades.', status: 'Em estoque' },
  { id: 'p-165', code: 'P-165', name: 'Perfurador 2 Furos Tilibra 20fl', category: 'Acessórios', price: 19.90, qty: 14, minStock: 4, description: 'Perfurador Tilibra 2 furos, capacidade 20 folhas.', status: 'Em estoque' },
  { id: 'p-166', code: 'P-166', name: 'Perfurador 4 Furos Maped 40fl', category: 'Acessórios', price: 39.90, qty: 8, minStock: 3, description: 'Perfurador Maped 4 furos, capacidade 40 folhas.', status: 'Em estoque' },
  { id: 'p-167', code: 'P-167', name: 'Corretivo Líquido BIC Wite-Out 20ml', category: 'Acessórios', price: 5.90, qty: 45, minStock: 18, description: 'Corretivo líquido BIC Wite-Out, 20ml.', status: 'Em estoque' },
  { id: 'p-168', code: 'P-168', name: 'Corretivo Líquido Faber-Castell 18ml', category: 'Acessórios', price: 5.50, qty: 40, minStock: 15, description: 'Corretivo líquido Faber-Castell, 18ml.', status: 'Em estoque' },
  { id: 'p-169', code: 'P-169', name: 'Fita Corretiva Maped Sweepy 5m', category: 'Acessórios', price: 8.90, qty: 30, minStock: 12, description: 'Fita corretiva Maped Sweepy, 5m x 4.2mm.', status: 'Em estoque' },
  { id: 'p-170', code: 'P-170', name: 'Fita Corretiva BIC Wite-Out Exact Liner', category: 'Acessórios', price: 7.90, qty: 28, minStock: 10, description: 'Fita corretiva BIC Wite-Out Exact Liner, 5m.', status: 'Em estoque' },
  { id: 'p-171', code: 'P-171', name: 'Pincel Atômico Pilot Jumbo Preto', category: 'Acessórios', price: 9.90, qty: 22, minStock: 8, description: 'Pincel atômico Pilot Jumbo, tinta preta.', status: 'Em estoque' },
  { id: 'p-172', code: 'P-172', name: 'Pincel Atômico Pilot 400 Preto', category: 'Acessórios', price: 7.90, qty: 28, minStock: 10, description: 'Pincel atômico Pilot 400, tinta preta.', status: 'Em estoque' },
  { id: 'p-173', code: 'P-173', name: 'Pincel Atômico BIC Marking Preto', category: 'Acessórios', price: 6.90, qty: 32, minStock: 12, description: 'Pincel atômico BIC Marking, tinta preta.', status: 'Em estoque' },
  { id: 'p-174', code: 'P-174', name: 'Clipes Galvanizados Nº 2 Cx 100 Jocar', category: 'Acessórios', price: 4.90, qty: 40, minStock: 15, description: 'Clipes galvanizados Jocar nº 2, caixa com 100 unidades.', status: 'Em estoque' },
  { id: 'p-175', code: 'P-175', name: 'Clipes Galvanizados Nº 3 Cx 100 Jocar', category: 'Acessórios', price: 5.90, qty: 35, minStock: 12, description: 'Clipes galvanizados Jocar nº 3, caixa com 100 unidades.', status: 'Em estoque' },
  { id: 'p-176', code: 'P-176', name: 'Elásticos Coloridos 50g Maped', category: 'Acessórios', price: 4.90, qty: 25, minStock: 10, description: 'Elásticos coloridos Maped, 50g.', status: 'Em estoque' },
  { id: 'p-177', code: 'P-177', name: 'Calculadora Casio MS-10B 10 Dígitos', category: 'Acessórios', price: 39.90, qty: 10, minStock: 3, description: 'Calculadora de mesa Casio MS-10B, 10 dígitos.', status: 'Em estoque' },
  { id: 'p-178', code: 'P-178', name: 'Grampo de Pressão Binder 25mm Cx 12', category: 'Acessórios', price: 8.90, qty: 20, minStock: 7, description: 'Grampo de pressão binder clip 25mm, caixa com 12 unidades.', status: 'Em estoque' },

  // ── PASTAS E ORGANIZADORES (14) ─────────────────────────
  { id: 'p-179', code: 'P-179', name: 'Pasta AZ L Ofício Preta DAC', category: 'Organização', price: 16.90, qty: 20, minStock: 7, description: 'Pasta AZ L ofício Preta DAC.', status: 'Em estoque' },
  { id: 'p-180', code: 'P-180', name: 'Pasta AZ L Ofício Azul DAC', category: 'Organização', price: 16.90, qty: 18, minStock: 7, description: 'Pasta AZ L ofício Azul DAC.', status: 'Em estoque' },
  { id: 'p-181', code: 'P-181', name: 'Pasta Sanfonada A4 12 Divisórias', category: 'Organização', price: 22.90, qty: 15, minStock: 5, description: 'Pasta sanfonada A4, 12 divisórias, com elástico.', status: 'Em estoque' },
  { id: 'p-182', code: 'P-182', name: 'Pasta Suspensa Kraft Vermelha', category: 'Organização', price: 4.90, qty: 30, minStock: 12, description: 'Pasta suspensa kraft vermelha, para arquivos.', status: 'Em estoque' },
  { id: 'p-183', code: 'P-183', name: 'Porta-Documentos A4 60fl Waleu', category: 'Organização', price: 14.90, qty: 12, minStock: 4, description: 'Porta-documentos A4 Waleu, 60 folhas.', status: 'Em estoque' },
  { id: 'p-184', code: 'P-184', name: 'Fichário Universitário 4 Argolas 200fl', category: 'Organização', price: 19.90, qty: 14, minStock: 5, description: 'Fichário universitário 4 argolas, 200 folhas.', status: 'Em estoque' },
  { id: 'p-185', code: 'P-185', name: 'Fichário Universitário 2 Argolas DAC', category: 'Organização', price: 14.90, qty: 16, minStock: 6, description: 'Fichário universitário 2 argolas DAC.', status: 'Em estoque' },
  { id: 'p-186', code: 'P-186', name: 'Pasta Catálogo 50 Envelopes DAC', category: 'Organização', price: 29.90, qty: 10, minStock: 4, description: 'Pasta catálogo DAC com 50 envelopes plásticos.', status: 'Em estoque' },
  { id: 'p-187', code: 'P-187', name: 'Porta-Lápis Acrílico 1 Compartimento', category: 'Organização', price: 9.90, qty: 18, minStock: 6, description: 'Porta-lápis em acrílico, 1 compartimento.', status: 'Em estoque' },
  { id: 'p-188', code: 'P-188', name: 'Porta-Lápis DAC 4 Divisórias', category: 'Organização', price: 14.90, qty: 12, minStock: 4, description: 'Porta-lápis DAC, 4 divisórias.', status: 'Em estoque' },
  { id: 'p-189', code: 'P-189', name: 'Divisórias A-Z Kraft para Fichário', category: 'Organização', price: 7.90, qty: 22, minStock: 8, description: 'Divisórias A-Z em kraft para fichário.', status: 'Em estoque' },
  { id: 'p-190', code: 'P-190', name: 'Plástico PP A4 Grosso Cx 100fl DAC', category: 'Organização', price: 24.90, qty: 15, minStock: 5, description: 'Envelopes plásticos PP A4 grosso, caixa com 100 folhas DAC.', status: 'Em estoque' },
  { id: 'p-191', code: 'P-191', name: 'Pasta L Transparente Ofício', category: 'Organização', price: 1.90, qty: 60, minStock: 25, description: 'Pasta L transparente tamanho ofício.', status: 'Em estoque' },
  { id: 'p-192', code: 'P-192', name: 'Caixa Arquivo Morto Kraft', category: 'Organização', price: 5.90, qty: 25, minStock: 10, description: 'Caixa arquivo morto em kraft.', status: 'Em estoque' },

  // ── MATERIAIS ESCOLARES DIVERSOS (16) ───────────────────
  { id: 'p-193', code: 'P-193', name: 'Estojo Simples DAC Plástico', category: 'Material Escolar', price: 12.90, qty: 22, minStock: 8, description: 'Estojo simples em plástico DAC.', status: 'Em estoque' },
  { id: 'p-194', code: 'P-194', name: 'Régua 15cm Plástico Faber-Castell', category: 'Material Escolar', price: 2.50, qty: 50, minStock: 20, description: 'Régua plástica Faber-Castell, 15cm.', status: 'Em estoque' },
  { id: 'p-195', code: 'P-195', name: 'Régua 50cm Tilibra', category: 'Material Escolar', price: 5.90, qty: 25, minStock: 10, description: 'Régua plástica Tilibra, 50cm.', status: 'Em estoque' },
  { id: 'p-196', code: 'P-196', name: 'Transferidor 180° Faber-Castell', category: 'Material Escolar', price: 3.90, qty: 35, minStock: 14, description: 'Transferidor semicircular 180° Faber-Castell.', status: 'Em estoque' },
  { id: 'p-197', code: 'P-197', name: 'Esquadro 45° Faber-Castell', category: 'Material Escolar', price: 4.90, qty: 28, minStock: 10, description: 'Esquadro 45° Faber-Castell, transparente.', status: 'Em estoque' },
  { id: 'p-198', code: 'P-198', name: 'Esquadro 60° Faber-Castell', category: 'Material Escolar', price: 4.90, qty: 28, minStock: 10, description: 'Esquadro 60° Faber-Castell, transparente.', status: 'Em estoque' },
  { id: 'p-199', code: 'P-199', name: 'Compasso Maped Geo Twist', category: 'Material Escolar', price: 14.90, qty: 16, minStock: 5, description: 'Compasso Maped Geo Twist, para lapiseira e lápis.', status: 'Em estoque' },
  { id: 'p-200', code: 'P-200', name: 'Estojo de Geometria Faber-Castell 8 Peças', category: 'Material Escolar', price: 24.90, qty: 12, minStock: 4, description: 'Estojo de geometria Faber-Castell, 8 peças.', status: 'Em estoque' },
  { id: 'p-201', code: 'P-201', name: 'Estojo de Geometria Maped 8 Peças', category: 'Material Escolar', price: 22.90, qty: 14, minStock: 5, description: 'Estojo de geometria Maped, 8 peças.', status: 'Em estoque' },
  { id: 'p-202', code: 'P-202', name: 'Etiqueta Adesiva Branca 32x101mm Pimaco', category: 'Material Escolar', price: 9.90, qty: 20, minStock: 7, description: 'Etiqueta adesiva Pimaco branca 32,5x101mm, 100 folhas.', status: 'Em estoque' },
  { id: 'p-203', code: 'P-203', name: 'Etiqueta Colorida Redonda 25mm Pimaco', category: 'Material Escolar', price: 8.90, qty: 18, minStock: 6, description: 'Etiqueta adesiva Pimaco colorida redonda 25mm.', status: 'Em estoque' },
  { id: 'p-204', code: 'P-204', name: 'Quadro Branco 60x90cm com Suporte', category: 'Material Escolar', price: 89.90, qty: 5, minStock: 2, description: 'Quadro branco laminado 60x90cm com suporte.', status: 'Em estoque' },
  { id: 'p-205', code: 'P-205', name: 'Apagador para Quadro Branco Tilibra', category: 'Material Escolar', price: 9.90, qty: 14, minStock: 4, description: 'Apagador para quadro branco Tilibra.', status: 'Em estoque' },
  { id: 'p-206', code: 'P-206', name: 'Pincel para Quadro Branco Azul', category: 'Material Escolar', price: 4.90, qty: 20, minStock: 7, description: 'Marcador para quadro branco, cor azul.', status: 'Em estoque' },
  { id: 'p-207', code: 'P-207', name: 'Pincel para Quadro Branco Preto', category: 'Material Escolar', price: 4.90, qty: 20, minStock: 7, description: 'Marcador para quadro branco, cor preta.', status: 'Em estoque' },
  { id: 'p-208', code: 'P-208', name: 'Extrator de Grampos Maped', category: 'Acessórios', price: 5.90, qty: 18, minStock: 6, description: 'Extrator de grampos Maped, corpo plástico.', status: 'Em estoque' },

  // ── EXTRA / COMPLEMENTOS (12) ───────────────────────────
  { id: 'p-209', code: 'P-209', name: 'Caneta Pincel Pentel Brush Sign Preta', category: 'Escrita', price: 14.90, qty: 12, minStock: 4, description: 'Caneta pincel aquarela Pentel Brush Sign, tinta preta.', status: 'Em estoque' },
  { id: 'p-210', code: 'P-210', name: 'Caneta Retrô Tipo Pena Azul', category: 'Escrita', price: 9.90, qty: 10, minStock: 3, description: 'Caneta retrô tipo pena com tinta azul.', status: 'Em estoque' },
  { id: 'p-211', code: 'P-211', name: 'Caderno de Sketching A5 80g 80fl', category: 'Cadernos', price: 19.90, qty: 12, minStock: 4, description: 'Caderno de sketching A5, papel 80g, 80 folhas.', status: 'Em estoque' },
  { id: 'p-212', code: 'P-212', name: 'Papel Color Plus A4 180g 10fl', category: 'Impressão', price: 12.90, qty: 18, minStock: 6, description: 'Papel Color Plus A4 180g, pacote com 10 folhas, colorido.', status: 'Em estoque' },
  { id: 'p-213', code: 'P-213', name: 'Pasta Sanfonada A4 6 Divisórias', category: 'Organização', price: 16.90, qty: 12, minStock: 4, description: 'Pasta sanfonada A4, 6 divisórias.', status: 'Em estoque' },
  { id: 'p-214', code: 'P-214', name: 'Grampo de Pressão Binder 32mm Cx 12', category: 'Acessórios', price: 9.90, qty: 16, minStock: 5, description: 'Grampo de pressão binder clip 32mm, caixa com 12 unidades.', status: 'Em estoque' },
  { id: 'p-215', code: 'P-215', name: 'Maped ColorPeps Canetinha 12 Cores', category: 'Papelaria Artística', price: 14.90, qty: 20, minStock: 7, description: 'Canetinha hidrográfica Maped Color\'Peps, 12 cores.', status: 'Em estoque' },
  { id: 'p-216', code: 'P-216', name: 'Caixa Arquivo Morto Plástica Preta', category: 'Organização', price: 9.90, qty: 15, minStock: 4, description: 'Caixa arquivo morto plástica preta.', status: 'Em estoque' },
  { id: 'p-217', code: 'P-217', name: 'Porta-Recado Magnético DAC', category: 'Organização', price: 7.90, qty: 12, minStock: 4, description: 'Porta-recado magnético DAC para uso em geladeira ou quadro.', status: 'Em estoque' },
  { id: 'p-218', code: 'P-218', name: 'Caneta Retroprojetor Azul Pilot', category: 'Escrita', price: 4.90, qty: 15, minStock: 5, description: 'Caneta para retroprojetor Pilot, tinta azul.', status: 'Em estoque' },
  { id: 'p-219', code: 'P-219', name: 'Faber-Castell Lápis de Cor Triangular 12', category: 'Papelaria Artística', price: 18.90, qty: 15, minStock: 5, description: 'Lápis de cor triangular Faber-Castell, 12 cores.', status: 'Em estoque' },
  { id: 'p-220', code: 'P-220', name: 'Régua 30cm Faber-Castell Transparente', category: 'Material Escolar', price: 3.90, qty: 42, minStock: 16, description: 'Régua transparente Faber-Castell, 30cm.', status: 'Em estoque' },
];

export function runMigrations(): void {
  // Verifica se a migração v2 já foi executada
  if (localStorage.getItem(MIG_KEY)) return;

  try {
    // Carrega produtos existentes (sem apagar os cadastrados manualmente)
    const raw = localStorage.getItem(PRODS_KEY);
    const current: DBProduct[] = raw ? JSON.parse(raw) : [];
    const existingCodes = new Set(current.map((p: DBProduct) => p.code));

    // Adiciona apenas os produtos que ainda não existem por código
    const toAdd = EXTENDED.filter(p => !existingCodes.has(p.code));
    const merged = [...current, ...toAdd];

    localStorage.setItem(PRODS_KEY, JSON.stringify(merged));
  } catch {}

  localStorage.setItem(MIG_KEY, '1');
}
