export type WppStatus =
  | 'novo'
  | 'separacao'
  | 'aguardando_pagamento'
  | 'pronto'
  | 'retirado'
  | 'cancelado';

export interface WppItem {
  produtoNome: string;
  qty: number;
  precoUnit: number;
}

export interface WppPedido {
  id: string;
  numeroPedido: string;
  clienteNome: string;
  clienteWhatsapp: string;
  itens: WppItem[];
  subtotal: number;
  desconto: number;
  total: number;
  formaPagamento: string;
  observacoes: string;
  dataPedido: string;    // YYYY-MM-DD
  horaPedido: string;    // HH:MM
  previsaoRetirada: string; // HH:MM
  responsavelId: string;
  responsavelNome: string;
  status: WppStatus;
  dataRetirada?: string;
  horaRetirada?: string;
  quemConfirmou?: string;
  finSaleId?: string;    // linked FinSale after payment
  createdAt: string;
}

const K = {
  pedidos: 'pc_v1_wpp_pedidos',
  seeded: 'pc_v1_wpp_seeded',
  counter: 'pc_v1_wpp_counter',
};

let _ctr = 1;
function newId(): string { return `wpp-${Date.now()}-${(_ctr++).toString(36)}`; }
function load<T>(key: string, def: T[]): T[] {
  try { const r = localStorage.getItem(key); if (r !== null) return JSON.parse(r) as T[]; } catch {}
  localStorage.setItem(key, JSON.stringify(def));
  return [...def];
}
function persist(key: string, data: unknown[]): void { localStorage.setItem(key, JSON.stringify(data)); }

export function nextPedidoNum(): string {
  const n = parseInt(localStorage.getItem(K.counter) ?? '0', 10) + 1;
  localStorage.setItem(K.counter, String(n));
  return `WPP-${String(n).padStart(4, '0')}`;
}

const SEED_PEDIDOS: WppPedido[] = [
  {
    id: 'wpp-001', numeroPedido: 'WPP-0001',
    clienteNome: 'Fernanda Oliveira', clienteWhatsapp: '(11) 98765-4321',
    itens: [
      { produtoNome: 'Caderno Universitário 10 Matérias', qty: 2, precoUnit: 21.90 },
      { produtoNome: 'Caneta Pilot G2 Preta', qty: 3, precoUnit: 8.90 },
    ],
    subtotal: 70.50, desconto: 0, total: 70.50,
    formaPagamento: 'Pix',
    observacoes: 'Entregar em sacola própria, por favor.',
    dataPedido: '2026-09-28', horaPedido: '08:32', previsaoRetirada: '11:00',
    responsavelId: 'u-003', responsavelNome: 'Lucas Henrique Almeida',
    status: 'pronto',
    createdAt: '2026-09-28T08:32:00.000Z',
  },
  {
    id: 'wpp-002', numeroPedido: 'WPP-0002',
    clienteNome: 'Escola Municipal Jardim das Flores', clienteWhatsapp: '(11) 3387-9900',
    itens: [
      { produtoNome: 'Papel Sulfite A4 500fls', qty: 10, precoUnit: 32.90 },
      { produtoNome: 'Pincel Atômico Pilot Preto', qty: 20, precoUnit: 5.90 },
      { produtoNome: 'Cola Escolar BIC 40g', qty: 30, precoUnit: 4.90 },
    ],
    subtotal: 594.00, desconto: 30.00, total: 564.00,
    formaPagamento: 'Boleto',
    observacoes: 'Pedido para início do semestre. CNPJ: 12.345.678/0001-90',
    dataPedido: '2026-09-28', horaPedido: '09:15', previsaoRetirada: '14:00',
    responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
    status: 'separacao',
    createdAt: '2026-09-28T09:15:00.000Z',
  },
  {
    id: 'wpp-003', numeroPedido: 'WPP-0003',
    clienteNome: 'Bruno Carvalho', clienteWhatsapp: '(11) 97654-3210',
    itens: [
      { produtoNome: 'Lapiseira Faber-Castell 0.5mm', qty: 1, precoUnit: 18.90 },
      { produtoNome: 'Kit Marca-texto Stabilo 4 cores', qty: 2, precoUnit: 17.90 },
    ],
    subtotal: 54.70, desconto: 0, total: 54.70,
    formaPagamento: 'Cartão de débito',
    observacoes: '',
    dataPedido: '2026-09-28', horaPedido: '10:45', previsaoRetirada: '13:00',
    responsavelId: 'u-004', responsavelNome: 'Camila Fernandes Rocha',
    status: 'aguardando_pagamento',
    createdAt: '2026-09-28T10:45:00.000Z',
  },
  {
    id: 'wpp-004', numeroPedido: 'WPP-0004',
    clienteNome: 'Márcia Souza', clienteWhatsapp: '(11) 96543-2109',
    itens: [
      { produtoNome: 'Agenda 2026 Tilibra Espiral Semanal', qty: 1, precoUnit: 35.00 },
      { produtoNome: 'Post-it 3M 76x76mm 4 Blocos', qty: 1, precoUnit: 18.90 },
    ],
    subtotal: 53.90, desconto: 0, total: 53.90,
    formaPagamento: 'Pix',
    observacoes: 'Cliente pagou via Pix às 11:30.',
    dataPedido: '2026-09-27', horaPedido: '11:10', previsaoRetirada: '15:00',
    responsavelId: 'u-003', responsavelNome: 'Lucas Henrique Almeida',
    status: 'retirado',
    dataRetirada: '2026-09-27', horaRetirada: '14:55',
    quemConfirmou: 'Lucas Henrique Almeida',
    createdAt: '2026-09-27T11:10:00.000Z',
  },
  {
    id: 'wpp-005', numeroPedido: 'WPP-0005',
    clienteNome: 'Rafael Teixeira', clienteWhatsapp: '(11) 95432-1098',
    itens: [
      { produtoNome: 'Tinta Guache Acrilex 12 cores', qty: 2, precoUnit: 29.90 },
      { produtoNome: 'Pincéis Artísticos Set 7 peças', qty: 1, precoUnit: 24.90 },
    ],
    subtotal: 84.70, desconto: 5.00, total: 79.70,
    formaPagamento: 'Cartão de crédito',
    observacoes: 'Desconto para cliente fidelidade.',
    dataPedido: '2026-09-26', horaPedido: '14:22', previsaoRetirada: '10:00',
    responsavelId: 'u-007', responsavelNome: 'Juliana Carvalho Mendes',
    status: 'retirado',
    dataRetirada: '2026-09-27', horaRetirada: '10:15',
    quemConfirmou: 'Camila Fernandes Rocha',
    createdAt: '2026-09-26T14:22:00.000Z',
  },
  {
    id: 'wpp-006', numeroPedido: 'WPP-0006',
    clienteNome: 'Empresa Soluções Tech Ltda', clienteWhatsapp: '(11) 3211-5500',
    itens: [
      { produtoNome: 'Papel Sulfite Chamex A4 90g 500fls', qty: 5, precoUnit: 42.90 },
      { produtoNome: 'Caneta BIC Cristal Azul cx/50', qty: 2, precoUnit: 75.00 },
    ],
    subtotal: 364.50, desconto: 14.50, total: 350.00,
    formaPagamento: 'Boleto',
    observacoes: 'Emitir NF. CNPJ: 78.901.234/0001-56',
    dataPedido: '2026-09-25', horaPedido: '09:00', previsaoRetirada: '11:00',
    responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
    status: 'retirado',
    dataRetirada: '2026-09-26', horaRetirada: '11:30',
    quemConfirmou: 'Ana Beatriz Martins',
    createdAt: '2026-09-25T09:00:00.000Z',
  },
  {
    id: 'wpp-007', numeroPedido: 'WPP-0007',
    clienteNome: 'Isabela Santos', clienteWhatsapp: '(11) 94321-0987',
    itens: [
      { produtoNome: 'Kit Faber-Castell Lápis 24 cores', qty: 1, precoUnit: 34.90 },
    ],
    subtotal: 34.90, desconto: 0, total: 34.90,
    formaPagamento: 'Dinheiro',
    observacoes: 'Presente para a filha.',
    dataPedido: '2026-09-28', horaPedido: '11:20', previsaoRetirada: '17:00',
    responsavelId: 'u-004', responsavelNome: 'Camila Fernandes Rocha',
    status: 'novo',
    createdAt: '2026-09-28T11:20:00.000Z',
  },
  {
    id: 'wpp-008', numeroPedido: 'WPP-0008',
    clienteNome: 'Colégio Particular São Paulo', clienteWhatsapp: '(11) 3299-1122',
    itens: [
      { produtoNome: 'Caderno Universitário 10 Mat.', qty: 50, precoUnit: 21.90 },
      { produtoNome: 'Borracha Faber-Castell', qty: 50, precoUnit: 2.50 },
      { produtoNome: 'Cola Bastão Pritt 20g', qty: 50, precoUnit: 9.90 },
    ],
    subtotal: 1715.00, desconto: 115.00, total: 1600.00,
    formaPagamento: 'Transferência',
    observacoes: 'Kit escolar para 50 alunos. TED realizado.',
    dataPedido: '2026-09-22', horaPedido: '08:00', previsaoRetirada: '09:00',
    responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
    status: 'cancelado',
    createdAt: '2026-09-22T08:00:00.000Z',
  },
];

export function newWppId(): string { return newId(); }

export const wppDb = {
  pedidos: {
    all(): WppPedido[] {
      if (!localStorage.getItem(K.seeded)) {
        localStorage.setItem(K.pedidos, JSON.stringify(SEED_PEDIDOS));
        localStorage.setItem(K.counter, String(SEED_PEDIDOS.length));
        localStorage.setItem(K.seeded, '1');
        return SEED_PEDIDOS;
      }
      return load<WppPedido>(K.pedidos, []);
    },
    hoje(): WppPedido[] {
      const today = new Date().toISOString().slice(0, 10);
      return this.all().filter(p => p.dataPedido === today);
    },
    paraRetirarHoje(): WppPedido[] {
      const today = new Date().toISOString().slice(0, 10);
      return this.all().filter(p =>
        p.dataPedido === today &&
        (p.status === 'pronto' || p.status === 'aguardando_pagamento')
      );
    },
    add(p: WppPedido): void { const l = this.all(); l.push(p); persist(K.pedidos, l); },
    update(id: string, patch: Partial<WppPedido>): void {
      persist(K.pedidos, this.all().map(p => p.id === id ? { ...p, ...patch } : p));
    },
    findById(id: string): WppPedido | undefined { return this.all().find(p => p.id === id); },
  },
};

export const WPP_STATUS_LABELS: Record<WppStatus, string> = {
  novo: 'Novo',
  separacao: 'Em separação',
  aguardando_pagamento: 'Ag. pagamento',
  pronto: 'Pronto p/ retirada',
  retirado: 'Retirado',
  cancelado: 'Cancelado',
};

export const WPP_STATUS_NEXT: Partial<Record<WppStatus, WppStatus>> = {
  novo: 'separacao',
  separacao: 'aguardando_pagamento',
  aguardando_pagamento: 'pronto',
  pronto: 'retirado',
};
