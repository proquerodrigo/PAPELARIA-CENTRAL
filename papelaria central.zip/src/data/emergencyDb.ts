import { newId } from './db';

export interface EmergencyMovement {
  id: string;
  type: 'entrada' | 'retirada';
  value: number;
  reason: string;
  responsavel: string;
  date: string;
  balanceBefore: number;
  balanceAfter: number;
  createdAt: string;
}

export interface EmergencyFund {
  saldoAtual: number;
  metaReserva: number;
  movimentos: EmergencyMovement[];
}

const KEY = 'pc_v1_emergency';

function seed(): EmergencyFund {
  return {
    saldoAtual: 12500,
    metaReserva: 20000,
    movimentos: [
      {
        id: newId(), type: 'entrada', value: 5000, reason: 'Constituição inicial da reserva',
        responsavel: 'Administrador', date: '2025-06-10',
        balanceBefore: 0, balanceAfter: 5000, createdAt: '2025-06-10T10:00:00.000Z',
      },
      {
        id: newId(), type: 'entrada', value: 3000, reason: 'Aporte mensal — julho/2025',
        responsavel: 'Administrador', date: '2025-07-01',
        balanceBefore: 5000, balanceAfter: 8000, createdAt: '2025-07-01T09:00:00.000Z',
      },
      {
        id: newId(), type: 'retirada', value: 1500, reason: 'Reparo emergencial — encanamento',
        responsavel: 'Administrador', date: '2025-08-14',
        balanceBefore: 8000, balanceAfter: 6500, createdAt: '2025-08-14T14:30:00.000Z',
      },
      {
        id: newId(), type: 'entrada', value: 2000, reason: 'Aporte mensal — setembro/2025',
        responsavel: 'Administrador', date: '2025-09-01',
        balanceBefore: 6500, balanceAfter: 8500, createdAt: '2025-09-01T09:00:00.000Z',
      },
      {
        id: newId(), type: 'entrada', value: 2000, reason: 'Aporte mensal — outubro/2025',
        responsavel: 'Administrador', date: '2025-10-01',
        balanceBefore: 8500, balanceAfter: 10500, createdAt: '2025-10-01T09:00:00.000Z',
      },
      {
        id: newId(), type: 'entrada', value: 2000, reason: 'Aporte mensal — novembro/2025',
        responsavel: 'Administrador', date: '2025-11-01',
        balanceBefore: 10500, balanceAfter: 12500, createdAt: '2025-11-01T09:00:00.000Z',
      },
    ],
  };
}

export const emergencyDb = {
  get(): EmergencyFund {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw) as EmergencyFund;
    } catch {}
    const s = seed();
    localStorage.setItem(KEY, JSON.stringify(s));
    return s;
  },

  set(fund: EmergencyFund): void {
    localStorage.setItem(KEY, JSON.stringify(fund));
  },

  addMovimento(
    type: 'entrada' | 'retirada',
    value: number,
    reason: string,
    responsavel: string,
    date: string,
  ): EmergencyFund {
    const fund = this.get();
    const balanceBefore = fund.saldoAtual;
    const balanceAfter = type === 'entrada' ? balanceBefore + value : Math.max(0, balanceBefore - value);
    const mov: EmergencyMovement = {
      id: newId(), type, value, reason, responsavel, date,
      balanceBefore, balanceAfter,
      createdAt: new Date().toISOString(),
    };
    fund.movimentos = [...fund.movimentos, mov];
    fund.saldoAtual = balanceAfter;
    this.set(fund);
    return fund;
  },
};
