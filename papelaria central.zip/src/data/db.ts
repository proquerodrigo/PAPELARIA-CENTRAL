export const ADMIN_EMAIL = 'admin@papelariacentral.com';
export const ADMIN_PASSWORD = 'Papelaria@123';
export const ACCESS_KEY = 'PAPELARIA2026';

export interface DBUser {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'funcionario';
  status: 'Ativo' | 'Inativo' | 'Bloqueado';
  cpf: string;
  phone: string;
  jobTitle: string;
  createdAt: string;
}

export interface DBCategory {
  id: string;
  name: string;
  description: string;
  status: 'Ativa' | 'Inativa';
}

export type PStatus = 'Em estoque' | 'Estoque baixo' | 'Sem estoque';

export interface DBProduct {
  id: string;
  code: string;
  name: string;
  category: string;
  price: number;
  qty: number;
  minStock: number;
  description: string;
  status: PStatus;
  photo?: string;
  /* V4 extended fields — all optional for backward compatibility */
  brand?: string;
  costPrice?: number;
  unit?: string;
  ean?: string;
  color?: string;
  size?: string;
  model?: string;
  supplierId?: string;
  active?: boolean;     /* true = active, undefined/true = active, false = inactive */
}

export interface DBCustomer {
  id: string;
  name: string;
  cpf: string;
  email: string;
  phone: string;
  status: 'Ativo' | 'Inativo';
  /* V4 extended fields */
  whatsapp?: string;
  cep?: string;
  endereco?: string;
  numero?: string;
  bairro?: string;
  cidade?: string;
  estado?: string;
  createdAt?: string;
}

export interface DBMovement {
  id: string;
  date: string;
  time: string;
  type: 'Entrada' | 'Saída';
  productId: string;
  productName: string;
  qty: number;
  userName: string;
  createdAt: string;
}

const K = {
  users: 'pc_v1_users',
  cats: 'pc_v1_cats',
  prods: 'pc_v1_prods',
  custs: 'pc_v1_custs',
  movs: 'pc_v1_movs',
  session: 'pc_v1_session',
};

export function newId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
}

export function calcStatus(qty: number, min: number): PStatus {
  return qty === 0 ? 'Sem estoque' : qty <= min ? 'Estoque baixo' : 'Em estoque';
}

const SEED_USERS: DBUser[] = [
  { id: 'u-admin', name: 'Administrador', email: 'admin@papelariacentral.com', password: 'Papelaria@123', role: 'admin', status: 'Ativo', cpf: '', phone: '', jobTitle: 'Administrador do Sistema', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'u-002', name: 'Ana Beatriz Martins', email: 'ana.martins@papelariacentral.com.br', password: 'Central@2026', role: 'admin', status: 'Ativo', cpf: '384.921.570-06', phone: '(11) 99847-2103', jobTitle: 'Gerente', createdAt: '2026-01-15T00:00:00.000Z' },
  { id: 'u-003', name: 'Lucas Henrique Almeida', email: 'lucas.almeida@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Ativo', cpf: '729.305.841-90', phone: '(11) 98732-5501', jobTitle: 'Vendedor', createdAt: '2026-02-01T00:00:00.000Z' },
  { id: 'u-004', name: 'Camila Fernandes Rocha', email: 'camila.rocha@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Ativo', cpf: '195.064.837-22', phone: '(11) 97654-3219', jobTitle: 'Caixa', createdAt: '2026-02-10T00:00:00.000Z' },
  { id: 'u-005', name: 'Mariana Oliveira Costa', email: 'mariana.costa@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Inativo', cpf: '512.047.389-11', phone: '(11) 96312-0087', jobTitle: 'Atendente', createdAt: '2026-03-01T00:00:00.000Z' },
  { id: 'u-006', name: 'Rafael Mendes Souza', email: 'rafael.souza@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Bloqueado', cpf: '648.730.912-48', phone: '(11) 95421-7734', jobTitle: 'Estoquista', createdAt: '2026-03-15T00:00:00.000Z' },
  { id: 'u-007', name: 'Juliana Carvalho Mendes', email: 'juliana.mendes@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Ativo', cpf: '271.583.049-63', phone: '(11) 94876-2290', jobTitle: 'Atendente', createdAt: '2026-04-01T00:00:00.000Z' },
  { id: 'u-008', name: 'Pedro Henrique Nascimento', email: 'pedro.nascimento@papelariacentral.com.br', password: 'Central@2026', role: 'funcionario', status: 'Ativo', cpf: '930.217.864-15', phone: '(11) 93210-5678', jobTitle: 'Vendedor', createdAt: '2026-04-15T00:00:00.000Z' },
];

const SEED_CATS: DBCategory[] = [
  { id: 'c-001', name: 'Cadernos', description: 'Cadernos de todos os formatos e tipos', status: 'Ativa' },
  { id: 'c-002', name: 'Escrita', description: 'Canetas, lápis, marcadores e lapiseiras', status: 'Ativa' },
  { id: 'c-003', name: 'Material Escolar', description: 'Itens de uso geral para o ambiente escolar', status: 'Ativa' },
  { id: 'c-004', name: 'Organização', description: 'Pastas, fichários, arquivos e divisórias', status: 'Ativa' },
  { id: 'c-005', name: 'Papelaria Artística', description: 'Tintas, pincéis e materiais para arte', status: 'Ativa' },
  { id: 'c-006', name: 'Acessórios', description: 'Tesouras, réguas, apontadores e grampeadores', status: 'Ativa' },
  { id: 'c-007', name: 'Impressão', description: 'Papel, cartuchos, tonners e acessórios', status: 'Inativa' },
];

const SEED_PRODS: DBProduct[] = [
  { id: 'p-001', code: 'P-001', name: 'Caderno Universitário 10 Matérias', category: 'Cadernos', price: 18.90, qty: 45, minStock: 10, description: '', status: 'Em estoque' },
  { id: 'p-002', code: 'P-002', name: 'Caneta Esferográfica Azul', category: 'Escrita', price: 2.50, qty: 3, minStock: 20, description: '', status: 'Estoque baixo' },
  { id: 'p-003', code: 'P-003', name: 'Lápis Grafite HB', category: 'Escrita', price: 1.20, qty: 0, minStock: 15, description: '', status: 'Sem estoque' },
  { id: 'p-004', code: 'P-004', name: 'Borracha Branca Escolar', category: 'Material Escolar', price: 1.50, qty: 80, minStock: 15, description: '', status: 'Em estoque' },
  { id: 'p-005', code: 'P-005', name: 'Marca-texto Amarelo', category: 'Escrita', price: 4.90, qty: 3, minStock: 10, description: '', status: 'Estoque baixo' },
  { id: 'p-006', code: 'P-006', name: 'Papel Sulfite A4 500 folhas', category: 'Impressão', price: 29.90, qty: 22, minStock: 5, description: '', status: 'Em estoque' },
  { id: 'p-007', code: 'P-007', name: 'Cola Bastão 20g', category: 'Material Escolar', price: 5.50, qty: 2, minStock: 15, description: '', status: 'Estoque baixo' },
  { id: 'p-008', code: 'P-008', name: 'Tesoura Escolar 13cm', category: 'Acessórios', price: 8.70, qty: 18, minStock: 8, description: '', status: 'Em estoque' },
  { id: 'p-009', code: 'P-009', name: 'Régua 30 cm', category: 'Acessórios', price: 3.80, qty: 24, minStock: 10, description: '', status: 'Em estoque' },
  { id: 'p-010', code: 'P-010', name: 'Bloco de Notas A5', category: 'Organização', price: 12.00, qty: 35, minStock: 10, description: '', status: 'Em estoque' },
];

const SEED_CUSTS: DBCustomer[] = [
  { id: 'cl-001', name: 'Ana Beatriz Martins', cpf: '384.921.570-06', email: 'ana.martins@email.com.br', phone: '(11) 99847-2103', status: 'Ativo' },
  { id: 'cl-002', name: 'Lucas Henrique Almeida', cpf: '729.305.841-90', email: 'lucas.almeida@gmail.com', phone: '(21) 98732-5501', status: 'Ativo' },
  { id: 'cl-003', name: 'Escola Estadual Prof. Wanderley', cpf: '12.784.390/0001-72', email: 'secretaria@eeprofw.edu.br', phone: '(11) 3456-7890', status: 'Ativo' },
  { id: 'cl-004', name: 'Mariana Oliveira Costa', cpf: '512.047.389-11', email: 'mariana.costa@hotmail.com', phone: '(31) 98241-6070', status: 'Ativo' },
  { id: 'cl-005', name: 'Gabriel Santos Ferreira', cpf: '863.140.295-37', email: 'gabriel.ferreira@empresa.com.br', phone: '(41) 99103-8824', status: 'Inativo' },
  { id: 'cl-006', name: 'Beatriz Rodrigues Lima', cpf: '230.916.748-55', email: 'beatriz.lima@outlook.com', phone: '(11) 97654-3210', status: 'Ativo' },
  { id: 'cl-007', name: 'Papelaria do Bairro LTDA', cpf: '34.892.175/0001-89', email: 'contato@papelariadobairro.com.br', phone: '(11) 2234-5678', status: 'Ativo' },
];

const SEED_MOVS: DBMovement[] = [
  { id: 'm-001', date: '24/09/2026', time: '09:14', type: 'Entrada', productId: 'p-001', productName: 'Caderno Universitário 10 Matérias', qty: 20, userName: 'Ana B. Martins', createdAt: '2026-09-24T09:14:00.000Z' },
  { id: 'm-002', date: '24/09/2026', time: '11:32', type: 'Saída', productId: 'p-002', productName: 'Caneta Esferográfica Azul', qty: 5, userName: 'Lucas H. Almeida', createdAt: '2026-09-24T11:32:00.000Z' },
  { id: 'm-003', date: '23/09/2026', time: '08:55', type: 'Entrada', productId: 'p-006', productName: 'Papel Sulfite A4 500 folhas', qty: 15, userName: 'Ana B. Martins', createdAt: '2026-09-23T08:55:00.000Z' },
  { id: 'm-004', date: '23/09/2026', time: '14:18', type: 'Saída', productId: 'p-004', productName: 'Borracha Branca Escolar', qty: 12, userName: 'Camila F. Rocha', createdAt: '2026-09-23T14:18:00.000Z' },
  { id: 'm-005', date: '22/09/2026', time: '16:05', type: 'Saída', productId: 'p-005', productName: 'Marca-texto Amarelo', qty: 8, userName: 'Lucas H. Almeida', createdAt: '2026-09-22T16:05:00.000Z' },
  { id: 'm-006', date: '21/09/2026', time: '10:00', type: 'Entrada', productId: 'p-004', productName: 'Borracha Branca Escolar', qty: 50, userName: 'Rafael M. Souza', createdAt: '2026-09-21T10:00:00.000Z' },
  { id: 'm-007', date: '20/09/2026', time: '13:44', type: 'Saída', productId: 'p-009', productName: 'Régua 30 cm', qty: 6, userName: 'Lucas H. Almeida', createdAt: '2026-09-20T13:44:00.000Z' },
  { id: 'm-008', date: '19/09/2026', time: '09:30', type: 'Entrada', productId: 'p-008', productName: 'Tesoura Escolar 13cm', qty: 10, userName: 'Ana B. Martins', createdAt: '2026-09-19T09:30:00.000Z' },
  { id: 'm-009', date: '18/09/2026', time: '15:20', type: 'Saída', productId: 'p-007', productName: 'Cola Bastão 20g', qty: 5, userName: 'Camila F. Rocha', createdAt: '2026-09-18T15:20:00.000Z' },
  { id: 'm-010', date: '17/09/2026', time: '11:10', type: 'Entrada', productId: 'p-003', productName: 'Lápis Grafite HB', qty: 30, userName: 'Rafael M. Souza', createdAt: '2026-09-17T11:10:00.000Z' },
];

function load<T>(key: string, seed: T[]): T[] {
  try {
    const raw = localStorage.getItem(key);
    if (raw !== null) return JSON.parse(raw) as T[];
  } catch {}
  const copy = [...seed];
  localStorage.setItem(key, JSON.stringify(copy));
  return copy;
}

function persist(key: string, data: unknown[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

function ensureAdmin(users: DBUser[]): DBUser[] {
  if (!users.some(u => u.email === ADMIN_EMAIL)) {
    users.unshift(SEED_USERS[0]);
    persist(K.users, users);
  }
  return users;
}

export const db = {
  users: {
    all(): DBUser[] { return ensureAdmin(load<DBUser>(K.users, SEED_USERS)); },
    findByEmail(email: string): DBUser | undefined {
      return this.all().find(u => u.email.toLowerCase() === email.toLowerCase());
    },
    findById(id: string): DBUser | undefined {
      return this.all().find(u => u.id === id);
    },
    add(u: DBUser): void { const list = this.all(); list.push(u); persist(K.users, list); },
    update(id: string, patch: Partial<DBUser>): DBUser[] {
      const list = this.all().map(u => u.id === id ? { ...u, ...patch } : u);
      persist(K.users, list);
      return list;
    },
    remove(id: string): DBUser[] {
      const list = this.all().filter(u => u.id !== id && u.id !== 'u-admin');
      persist(K.users, list);
      return list;
    },
  },

  categories: {
    all(): DBCategory[] { return load<DBCategory>(K.cats, SEED_CATS); },
    add(c: DBCategory): void { const list = this.all(); list.push(c); persist(K.cats, list); },
    update(id: string, patch: Partial<DBCategory>): DBCategory[] {
      const list = this.all().map(c => c.id === id ? { ...c, ...patch } : c);
      persist(K.cats, list);
      return list;
    },
  },

  products: {
    all(): DBProduct[] { return load<DBProduct>(K.prods, SEED_PRODS); },
    findById(id: string): DBProduct | undefined { return this.all().find(p => p.id === id); },
    add(p: DBProduct): void { const list = this.all(); list.push(p); persist(K.prods, list); },
    update(id: string, patch: Partial<DBProduct>): DBProduct[] {
      const list = this.all().map(p => p.id === id ? { ...p, ...patch } : p);
      persist(K.prods, list);
      return list;
    },
    remove(id: string): DBProduct[] {
      const list = this.all().filter(p => p.id !== id);
      persist(K.prods, list);
      return list;
    },
  },

  customers: {
    all(): DBCustomer[] { return load<DBCustomer>(K.custs, SEED_CUSTS); },
    add(c: DBCustomer): void { const list = this.all(); list.push(c); persist(K.custs, list); },
    update(id: string, patch: Partial<DBCustomer>): DBCustomer[] {
      const list = this.all().map(c => c.id === id ? { ...c, ...patch } : c);
      persist(K.custs, list);
      return list;
    },
    remove(id: string): DBCustomer[] {
      const list = this.all().filter(c => c.id !== id);
      persist(K.custs, list);
      return list;
    },
  },

  movements: {
    all(): DBMovement[] { return load<DBMovement>(K.movs, SEED_MOVS); },
    add(m: DBMovement): void {
      const list = this.all();
      list.unshift(m);
      persist(K.movs, list);
    },
  },

  session: {
    get(): string | null { return localStorage.getItem(K.session); },
    set(userId: string): void { localStorage.setItem(K.session, userId); },
    clear(): void { localStorage.removeItem(K.session); },
  },
};

// ─── V2 migration: adds 221 additional products (P-011 to P-231) ────────────

const V2_KEY = 'pc_v2_migrated';

function p(id: string, code: string, name: string, cat: string, price: number, qty: number, min: number): DBProduct {
  return { id, code, name, category: cat, price, qty, minStock: min, description: '', status: calcStatus(qty, min) };
}

const V2_PRODUCTS: DBProduct[] = [
  // Cadernos
  p('v2-011','P-011','Caderno Universitário Tilibra 10 Matérias 200fls','Cadernos',21.90,38,10),
  p('v2-012','P-012','Caderno Universitário Foroni 10 Matérias Capa Dura','Cadernos',24.50,27,10),
  p('v2-013','P-013','Caderno Espiral 5 Matérias São Domingos Capa Dura','Cadernos',14.90,42,8),
  p('v2-014','P-014','Caderno 1/4 Tilibra Pequeno 80fls','Cadernos',6.90,55,15),
  p('v2-015','P-015','Caderno Pautado A4 Universitário Spiral 200fls','Cadernos',16.50,31,10),
  p('v2-016','P-016','Caderno Quadriculado Tilibra 5mm 80fls','Cadernos',8.90,29,10),
  p('v2-017','P-017','Caderno Universitário 1 Matéria Foroni 96fls','Cadernos',7.50,48,12),
  p('v2-018','P-018','Caderno de Desenho A4 São Domingos 48fls','Cadernos',9.90,33,8),
  p('v2-019','P-019','Caderno Capa Dura Tilibra 10 Matérias 200fls Colorido','Cadernos',26.90,19,8),
  p('v2-020','P-020','Agenda Executiva 2026 Tilibra Costurada','Cadernos',42.00,3,5),
  p('v2-021','P-021','Caderno Universitário Jandaia 10 Matérias','Cadernos',19.90,23,8),
  p('v2-022','P-022','Caderno Brochura Capa Dura Grande Tilibra 80fls','Cadernos',10.90,36,10),
  p('v2-023','P-023','Caderno 5x1 Tilibra Resistente 200fls','Cadernos',22.50,15,8),
  p('v2-024','P-024','Sketchbook A5 Canson 80fls','Cadernos',32.00,12,5),
  p('v2-025','P-025','Caderno Universitário Credeal 10 Matérias Neon','Cadernos',17.90,0,10),
  p('v2-026','P-026','Caderno de Atas São Domingos 50fls Capa Dura','Cadernos',18.00,14,8),
  p('v2-027','P-027','Bloco de Notas A4 80fls Tilibra','Cadernos',14.50,22,8),
  p('v2-028','P-028','Caderno Escolar Brochura 40fls Tilibra','Cadernos',5.90,60,15),
  p('v2-029','P-029','Caderno Universitário Espiral Foroni 12 Matérias','Cadernos',26.90,17,8),
  p('v2-030','P-030','Diário Íntimo Tilibra Com Cadeado 80fls','Cadernos',22.00,9,5),
  p('v2-031','P-031','Caderno Quadriculado A4 Foroni 80fls','Cadernos',11.90,25,8),
  p('v2-032','P-032','Agenda 2026 Espiral Semanal Tilibra','Cadernos',35.00,6,5),
  p('v2-033','P-033','Caderno Executivo Tilibra A5 96fls Capa Dura','Cadernos',18.90,20,8),
  p('v2-034','P-034','Bloco de Rascunho A4 Tilibra 100fls','Cadernos',8.90,40,10),
  p('v2-035','P-035','Caderno Kraft São Domingos A5 80fls','Cadernos',15.90,18,5),
  p('v2-036','P-036','Caderno Universitário Credeal 10 Matérias Colorido','Cadernos',23.00,28,8),
  p('v2-037','P-037','Planner Anual Tilibra 2026','Cadernos',49.00,2,3),
  p('v2-038','P-038','Caderno Brochura Pequeno 48fls Foroni','Cadernos',4.50,70,15),
  p('v2-039','P-039','Caderno Universitário Spiral 10 Matérias 200fls','Cadernos',20.90,33,10),
  p('v2-040','P-040','Caderno Costurado A4 São Domingos 96fls','Cadernos',13.90,25,8),
  p('v2-041','P-041','Caderno de Música Tilibra 48fls Pauta Dupla','Cadernos',9.90,11,5),
  p('v2-042','P-042','Bloco Financeiro Tilibra 50fls','Cadernos',12.50,16,5),
  p('v2-043','P-043','Caderno Universitário Jandaia 10M Estampado','Cadernos',21.00,22,8),
  p('v2-044','P-044','Caderno Quadriculado Foroni A5 80fls','Cadernos',9.90,30,8),
  p('v2-045','P-045','Planner Semanal Tilibra 2026 Capa Dura','Cadernos',38.00,2,3),
  p('v2-046','P-046','Caderno Capa Dura Foroni Universitário 1M 96fls','Cadernos',12.00,27,8),
  p('v2-047','P-047','Caderno Universitário Spiral 5 Matérias 100fls','Cadernos',14.90,35,10),
  p('v2-048','P-048','Caderno de Atas Capa Dura 100fls São Domingos','Cadernos',24.90,10,5),
  p('v2-049','P-049','Agenda Executiva Costurada Tilibra 2026 Couro','Cadernos',55.00,2,3),
  p('v2-050','P-050','Caderno de Campo Tilibra A4 Capa Resistente','Cadernos',16.90,19,5),
  // Escrita
  p('v2-051','P-051','Caneta Esferográfica BIC Cristal 0,8mm Azul','Escrita',1.50,120,30),
  p('v2-052','P-052','Caneta Esferográfica BIC Cristal Ponta Média Preta','Escrita',1.50,98,30),
  p('v2-053','P-053','Caneta Esferográfica BIC Cristal Ponta Média Vermelha','Escrita',1.50,87,20),
  p('v2-054','P-054','Kit Canetas BIC 4 Cores Classic','Escrita',5.90,35,10),
  p('v2-055','P-055','Lapiseira Pentel GraphGear 1000 0.5mm','Escrita',42.00,2,3),
  p('v2-056','P-056','Lapiseira Faber-Castell Grip Matic 0.5mm','Escrita',18.90,22,5),
  p('v2-057','P-057','Lapiseira BIC Velocity Pro 0.7mm','Escrita',12.90,30,8),
  p('v2-058','P-058','Lápis Grafite Faber-Castell HB Nº2 Sextavado','Escrita',1.00,150,40),
  p('v2-059','P-059','Lápis Grafite Faber-Castell 9000 HB','Escrita',4.50,45,15),
  p('v2-060','P-060','Lápis de Cor Faber-Castell 12 cores Ecolápis','Escrita',19.90,28,8),
  p('v2-061','P-061','Lápis de Cor Faber-Castell 24 cores Ecolápis','Escrita',34.90,18,5),
  p('v2-062','P-062','Lápis de Cor Aquarelável Faber-Castell 36 cores','Escrita',79.90,2,3),
  p('v2-063','P-063','Caneta Pilot G2 0.7mm Preta Gel Retrátil','Escrita',8.90,40,10),
  p('v2-064','P-064','Caneta Pilot G2 0.5mm Azul Gel Retrátil','Escrita',8.90,35,10),
  p('v2-065','P-065','Caneta Pilot Fine Tip 0.4mm Preta','Escrita',7.90,29,8),
  p('v2-066','P-066','Caneta Hidrográfica Faber-Castell 12 cores','Escrita',12.90,25,8),
  p('v2-067','P-067','Caneta Hidrográfica Faber-Castell 36 cores','Escrita',39.90,10,3),
  p('v2-068','P-068','Marca-texto Stabilo Boss Original Amarelo','Escrita',5.50,42,15),
  p('v2-069','P-069','Kit Marca-texto Stabilo Boss 4 cores Sortidas','Escrita',17.90,18,5),
  p('v2-070','P-070','Caneta Permanente Pilot Superflex Preta','Escrita',9.90,22,8),
  p('v2-071','P-071','Caneta para CD/DVD Pilot CD-Writer Preta','Escrita',8.50,15,5),
  p('v2-072','P-072','Caneta Edding 400 Ponta Fina Permanente Preta','Escrita',6.90,28,8),
  p('v2-073','P-073','Lápis Grafite Staedtler Noris HB c/12','Escrita',12.90,0,20),
  p('v2-074','P-074','Borracha Faber-Castell Dust Free','Escrita',2.50,65,20),
  p('v2-075','P-075','Apontador Faber-Castell Duplo Com Depósito','Escrita',4.90,38,10),
  p('v2-076','P-076','Caneta BIC Evolution Lápis Preto','Escrita',1.20,85,25),
  p('v2-077','P-077','Caneta Faber-Castell CX Azul Esferográfica','Escrita',2.00,72,20),
  p('v2-078','P-078','Caneta Roller Pilot V7 Hi-Tecpoint 0.7mm','Escrita',11.90,18,5),
  p('v2-079','P-079','Caneta Pincel Pentel Arts Aquash Média','Escrita',14.90,9,3),
  p('v2-080','P-080','Marcador Permanente Pilot MR Ponta Grossa Preta','Escrita',7.50,24,8),
  p('v2-081','P-081','Caneta Nankin Faber-Castell 0.1mm','Escrita',9.90,14,5),
  p('v2-082','P-082','Caneta Nankin Faber-Castell 0.3mm','Escrita',9.90,13,5),
  p('v2-083','P-083','Caneta Nankin Faber-Castell 0.5mm','Escrita',9.90,12,5),
  p('v2-084','P-084','Kit Caneta Nankin Faber-Castell 4 tamanhos','Escrita',32.00,6,3),
  p('v2-085','P-085','Caneta Gel Pentel EnerGel 0.7mm Preta','Escrita',7.90,32,10),
  p('v2-086','P-086','Caneta Gel Pentel EnerGel 0.7mm Azul','Escrita',7.90,28,10),
  p('v2-087','P-087','Caneta Pilot FriXion Ball Apagável 0.7mm Preta','Escrita',12.90,20,5),
  p('v2-088','P-088','Caneta Pilot FriXion Ball Apagável 0.7mm Azul','Escrita',12.90,18,5),
  p('v2-089','P-089','Kit Canetas Pilot FriXion 3 cores','Escrita',31.90,8,3),
  p('v2-090','P-090','Lápis de Cor Stabilo Aquacolor 12 cores','Escrita',24.90,15,5),
  p('v2-091','P-091','Lapiseira Staedtler 925 0.5mm Metal','Escrita',28.00,10,3),
  p('v2-092','P-092','Grafite Pentel 0.5mm HB c/12','Escrita',5.90,30,10),
  p('v2-093','P-093','Grafite Pentel 0.7mm HB c/12','Escrita',5.90,28,10),
  p('v2-094','P-094','Giz de Cera Faber-Castell 12 cores','Escrita',8.50,22,8),
  p('v2-095','P-095','Giz de Cera Tilibra 24 cores','Escrita',14.90,17,5),
  p('v2-096','P-096','Caneta Marcador Artístico Pilot Parallel Pen','Escrita',38.00,1,2),
  p('v2-097','P-097','Caneta Stabilo Point 88 0.4mm Kit 20 cores','Escrita',49.90,1,2),
  p('v2-098','P-098','Caneta Stabilo Sensor 0.3mm Preta','Escrita',8.90,11,5),
  p('v2-099','P-099','Lápis Grafite Faber-Castell 2B c/12','Escrita',12.90,14,5),
  p('v2-100','P-100','Caixa Lápis Faber-Castell 6 Dureza Graduados','Escrita',18.90,9,3),
  // Material Escolar
  p('v2-101','P-101','Cola Escolar Branca BIC 40g','Material Escolar',4.90,55,15),
  p('v2-102','P-102','Cola Escolar Branca BIC 90g','Material Escolar',7.90,38,10),
  p('v2-103','P-103','Cola Bastão Pritt 10g','Material Escolar',6.90,45,12),
  p('v2-104','P-104','Cola Bastão Pritt 20g','Material Escolar',9.90,33,10),
  p('v2-105','P-105','Cola Bastão Pritt 36g','Material Escolar',14.50,22,8),
  p('v2-106','P-106','Fita Adesiva Scotch 3M 12mm x 40m','Material Escolar',5.90,48,12),
  p('v2-107','P-107','Fita Adesiva Scotch 3M 18mm x 40m','Material Escolar',7.90,35,10),
  p('v2-108','P-108','Fita Adesiva Transparente 18mm x 50m','Material Escolar',4.50,60,15),
  p('v2-109','P-109','Borracha Branca Escolar Faber-Castell 40x20mm','Material Escolar',1.90,90,25),
  p('v2-110','P-110','Borracha Plástica Staedtler Mars 526 50','Material Escolar',4.50,42,10),
  p('v2-111','P-111','Tesoura Escolar Maped Sensoft 13cm','Material Escolar',9.90,25,8),
  p('v2-112','P-112','Tesoura Maped Comfort 21cm','Material Escolar',16.90,15,5),
  p('v2-113','P-113','Tesoura Pontas Redondas Faber-Castell 13cm','Material Escolar',10.90,18,5),
  p('v2-114','P-114','Compasso Escolar Maped Com Lapiseira','Material Escolar',14.90,14,5),
  p('v2-115','P-115','Compasso Profissional Maped Study','Material Escolar',29.90,8,3),
  p('v2-116','P-116','Transferidor 180° Maped 15cm','Material Escolar',5.90,30,8),
  p('v2-117','P-117','Esquadro 45° Waleu 25cm Transparente','Material Escolar',7.90,22,8),
  p('v2-118','P-118','Esquadro 60° Waleu 25cm Transparente','Material Escolar',7.90,20,8),
  p('v2-119','P-119','Régua 15cm Faber-Castell','Material Escolar',3.50,45,10),
  p('v2-120','P-120','Régua Antideslizante Maped 30cm','Material Escolar',6.90,28,8),
  p('v2-121','P-121','Apontador Faber-Castell Simples Com Depósito','Material Escolar',3.90,65,15),
  p('v2-122','P-122','Apontador Elétrico Multilaser AE001','Material Escolar',34.90,1,2),
  p('v2-123','P-123','Lousa Branca de Mesa A4 Com Caneta','Material Escolar',18.90,12,4),
  p('v2-124','P-124','Pincel Atômico Pilot Ponta Grossa Preto','Material Escolar',5.90,32,10),
  p('v2-125','P-125','Pincel Atômico Pilot Ponta Grossa Vermelho','Material Escolar',5.90,28,10),
  p('v2-126','P-126','Kit Pincel Atômico Pilot 12 cores Sortidas','Material Escolar',59.90,6,2),
  p('v2-127','P-127','Caixa de Giz Branco Escolar c/50 Silgi','Material Escolar',9.90,15,5),
  p('v2-128','P-128','Kit Escolar Completo Tilibra Básico','Material Escolar',29.90,10,3),
  p('v2-129','P-129','Líquido Corretor BIC Wite-Out 20ml','Material Escolar',5.90,35,10),
  p('v2-130','P-130','Fita Corretora BIC Wite-Out 6m','Material Escolar',7.50,28,8),
  // Acessórios
  p('v2-131','P-131','Grampeador Maped Mini Plus 24/6','Acessórios',24.90,12,4),
  p('v2-132','P-132','Grampeador Rocama Plástico N.26/6','Acessórios',14.90,18,5),
  p('v2-133','P-133','Grampo Galvanizado 26/6 c/5000un Bacchi','Acessórios',8.90,20,5),
  p('v2-134','P-134','Grampo 26/6 Caixa 5000un Tilibra','Acessórios',7.50,25,5),
  p('v2-135','P-135','Desgrampeador Maped Metal','Acessórios',8.90,15,5),
  p('v2-136','P-136','Perfurador de Papel Rocama 2 Furos','Acessórios',18.90,10,3),
  p('v2-137','P-137','Perfurador de Papel Maped 2 Furos Metal','Acessórios',24.90,8,3),
  p('v2-138','P-138','Clipes Galvanizados N.3/0 c/500un','Acessórios',6.90,18,5),
  p('v2-139','P-139','Clipes Niquelados N.2/0 c/100un','Acessórios',3.90,30,8),
  p('v2-140','P-140','Elástico N.18 Tilibra 100g','Acessórios',5.50,22,5),
  p('v2-141','P-141','Barbante de Sisal N.8 100m','Acessórios',12.90,14,4),
  p('v2-142','P-142','Durex Dupla Face 12mm x 20m','Acessórios',8.50,20,5),
  p('v2-143','P-143','Fita Empacotadora Marrom 48mm x 50m','Acessórios',9.90,15,4),
  p('v2-144','P-144','Etiqueta Adesiva Branca 100x50mm c/100','Acessórios',14.90,12,4),
  p('v2-145','P-145','Etiqueta Adesiva Redonda Colorida c/100','Acessórios',6.90,20,5),
  p('v2-146','P-146','Porta-Lápis Duplo Plástico Waleu','Acessórios',8.90,16,5),
  p('v2-147','P-147','Bandeja Organizadora de Mesa Plástica','Acessórios',24.90,10,3),
  p('v2-148','P-148','Porta-Objetos de Mesa Acrimet 5 Compartimentos','Acessórios',19.90,12,4),
  p('v2-149','P-149','Clipes Coloridos Maped c/50','Acessórios',5.90,25,8),
  p('v2-150','P-150','Percevejo de Aço Latonado c/100un','Acessórios',7.90,18,5),
  p('v2-151','P-151','Prancheta Acrimet A4 Com Clip','Acessórios',14.90,14,4),
  p('v2-152','P-152','Prancheta Maped A4 Com Clip e Régua','Acessórios',16.90,10,4),
  p('v2-153','P-153','Calculadora Científica Casio FX-82MS','Acessórios',79.90,1,2),
  p('v2-154','P-154','Calculadora Básica Casio HL-4A 8 Dígitos','Acessórios',19.90,12,4),
  p('v2-155','P-155','Fita Dupla Face Espumada 3M 12mm x 2m','Acessórios',9.90,22,5),
  p('v2-156','P-156','Post-it 3M 76x76mm 4 Blocos Coloridos','Acessórios',18.90,15,5),
  p('v2-157','P-157','Post-it 3M 38x50mm c/100 Amarelo','Acessórios',8.90,20,5),
  p('v2-158','P-158','Mola De Arquivo a/Z N.5 Tilibra','Acessórios',3.90,35,10),
  p('v2-159','P-159','Régua de Metal Inox 50cm Maped','Acessórios',18.90,8,3),
  p('v2-160','P-160','Cortador de Papel A4 Waleu 30cm','Acessórios',89.90,1,2),
  // Organização
  p('v2-161','P-161','Pasta Polionda A4 Amarela','Organização',5.90,30,8),
  p('v2-162','P-162','Pasta Polionda A4 Verde','Organização',5.90,28,8),
  p('v2-163','P-163','Pasta Polionda A4 Azul','Organização',5.90,32,8),
  p('v2-164','P-164','Pasta Com Elástico A4 ACP Transparente','Organização',8.90,22,6),
  p('v2-165','P-165','Pasta Sanfonada 12 Divisórias A4 Polipropileno','Organização',24.90,14,4),
  p('v2-166','P-166','Pasta Sanfonada 26 Divisórias A4','Organização',39.90,8,3),
  p('v2-167','P-167','Fichário A4 2 Argolas Tilibra Capa Dura','Organização',14.90,20,5),
  p('v2-168','P-168','Fichário A4 4 Argolas Tilibra','Organização',19.90,15,5),
  p('v2-169','P-169','Fichário Universitário 2 Argolas Foroni','Organização',16.90,18,5),
  p('v2-170','P-170','Divisórias para Fichário A4 5 posições Waleu','Organização',6.90,25,8),
  p('v2-171','P-171','Pasta Catálogo A4 10 Folhas Polibras','Organização',8.90,22,6),
  p('v2-172','P-172','Pasta Catálogo A4 50 Folhas Polibras','Organização',29.90,12,4),
  p('v2-173','P-173','Caixa Arquivo Morto A4 Polionda','Organização',9.90,24,6),
  p('v2-174','P-174','Caixa Arquivo Polionda Ofício','Organização',11.90,18,5),
  p('v2-175','P-175','Envelope Kraft A4 c/10','Organização',12.90,15,4),
  p('v2-176','P-176','Envelope Saco Kraft Grande c/10','Organização',18.90,10,3),
  p('v2-177','P-177','Porta-Recado De Parede Magnético','Organização',19.90,8,3),
  p('v2-178','P-178','Quadro Branco de Parede 60x90cm','Organização',89.90,1,2),
  p('v2-179','P-179','Quadro de Cortiça 60x90cm Com Moldura','Organização',69.90,1,2),
  p('v2-180','P-180','Organizador de Gaveta 6 Divisórias Plástico','Organização',24.90,9,3),
  p('v2-181','P-181','Porta-Documentos A4 Com Zíper','Organização',19.90,12,4),
  p('v2-182','P-182','Capa Protetora A4 Cristal c/10 Waleu','Organização',8.90,22,6),
  p('v2-183','P-183','Pasta Suspensa Cartão A4 c/10','Organização',29.90,8,3),
  p('v2-184','P-184','Porta-Papel A4 de Mesa Acrílico','Organização',34.90,7,2),
  p('v2-185','P-185','Arquivo Bancário A4 Tilibra','Organização',24.90,9,3),
  p('v2-186','P-186','Pasta Aba Elástica Polipropileno A4','Organização',12.90,18,5),
  p('v2-187','P-187','Pasta Grampo Rígida Tilibra','Organização',5.90,28,8),
  p('v2-188','P-188','Pasta Dossier A4 Com Espiral Foroni','Organização',7.90,20,6),
  p('v2-189','P-189','Índice Plástico A4 5 posições Tilibra','Organização',4.90,32,8),
  p('v2-190','P-190','Etiqueta para Arquivo c/50 Tilibra','Organização',6.90,25,8),
  // Papelaria Artística
  p('v2-191','P-191','Tinta Guache Acrilex 12 cores 15ml','Papelaria Artística',29.90,14,4),
  p('v2-192','P-192','Tinta Guache Acrilex 6 cores 250ml','Papelaria Artística',49.90,8,3),
  p('v2-193','P-193','Tinta Acrílica Acrilex 60ml Branca','Papelaria Artística',9.90,20,5),
  p('v2-194','P-194','Tinta Acrílica Acrilex 60ml Preta','Papelaria Artística',9.90,18,5),
  p('v2-195','P-195','Tinta Acrílica Acrilex 60ml Azul Cobalto','Papelaria Artística',11.90,15,4),
  p('v2-196','P-196','Kit Tintas Acrílicas Acrilex 6 cores 60ml','Papelaria Artística',49.90,7,2),
  p('v2-197','P-197','Massa de Modelar Acrilex 12 cores','Papelaria Artística',19.90,12,4),
  p('v2-198','P-198','Pincéis Artísticos Tigre Set 7 peças','Papelaria Artística',24.90,9,3),
  p('v2-199','P-199','Pincel Chanfrado Tigre N.14','Papelaria Artística',6.90,15,5),
  p('v2-200','P-200','Pincel Redondo Tigre N.8','Papelaria Artística',5.90,18,5),
  p('v2-201','P-201','Papel Para Aquarela Canson A4 300g c/10','Papelaria Artística',49.90,8,2),
  p('v2-202','P-202','Papel Para Aquarela A3 Canson 200g c/5','Papelaria Artística',12.90,10,3),
  p('v2-203','P-203','Bloco Canson Montval A4 300g 12fls','Papelaria Artística',69.90,1,2),
  p('v2-204','P-204','Carvão Vegetal Natural Faber-Castell c/6','Papelaria Artística',14.90,11,3),
  p('v2-205','P-205','Pastel Seco Faber-Castell 12 cores','Papelaria Artística',49.90,6,2),
  p('v2-206','P-206','Pastel Oleoso CIS 12 cores','Papelaria Artística',14.90,12,4),
  p('v2-207','P-207','Papel Color Plus Torino Branco 180g A4 c/20','Papelaria Artística',18.90,15,4),
  p('v2-208','P-208','Papel Color A4 180g Colorido Mix c/25','Papelaria Artística',24.90,12,4),
  p('v2-209','P-209','Tesoura de Corte Artesanato Maped','Papelaria Artística',29.90,7,2),
  p('v2-210','P-210','Pistola Para Cola Quente Mini Multilaser','Papelaria Artística',24.90,9,3),
  p('v2-211','P-211','Bastão de Cola Quente 11mm c/20','Papelaria Artística',8.90,18,5),
  p('v2-212','P-212','EVA Colorido Liso 40x60cm c/10','Papelaria Artística',14.90,10,3),
  p('v2-213','P-213','Glitter Acrilex Flocado 5g Ouro','Papelaria Artística',4.90,25,8),
  p('v2-214','P-214','Papel Crepom 48x200cm Sortido','Papelaria Artística',5.90,22,6),
  p('v2-215','P-215','Fita Washi Tape Decorada c/3 Rolos','Papelaria Artística',14.90,14,4),
  // Impressão
  p('v2-216','P-216','Papel Sulfite Chamex A4 75g 500fls','Impressão',32.90,18,5),
  p('v2-217','P-217','Papel Sulfite Chamex A4 90g 500fls','Impressão',42.90,12,4),
  p('v2-218','P-218','Papel Fotográfico Glossy A4 180g c/50','Impressão',34.90,8,3),
  p('v2-219','P-219','Papel Fotográfico Fosco A4 180g c/50','Impressão',36.90,6,2),
  p('v2-220','P-220','Papel Adesivo A4 Transparente c/25','Impressão',29.90,10,3),
  p('v2-221','P-221','Papel Kraft A4 80g c/100','Impressão',19.90,14,4),
  p('v2-222','P-222','Papel Transfer Sublimação A4 c/25','Impressão',39.90,8,2),
  p('v2-223','P-223','Cartucho HP 664 Colorido Original','Impressão',49.90,7,2),
  p('v2-224','P-224','Cartucho HP 664 Preto Original','Impressão',39.90,8,3),
  p('v2-225','P-225','Cartucho Canon PG-145 Preto','Impressão',44.90,6,2),
  p('v2-226','P-226','Cartucho Epson T664 Preto','Impressão',29.90,1,2),
  p('v2-227','P-227','Tinta para Recarga Preto Universal 100ml','Impressão',14.90,10,3),
  p('v2-228','P-228','Toner HP 85A CE285A Para LaserJet','Impressão',159.90,1,2),
  p('v2-229','P-229','Envelope para CD/DVD Branco c/50 Multilaser','Impressão',14.90,7,2),
  p('v2-230','P-230','Papel Opaline A4 180g c/50','Impressão',29.90,9,3),
  p('v2-231','P-231','Papel Adesivo Branco 100x25cm Rolo','Impressão',24.90,12,3),
];

function ensureV2Products(): void {
  if (localStorage.getItem(V2_KEY)) return;
  try {
    const raw = localStorage.getItem(K.prods);
    const existing: DBProduct[] = raw ? JSON.parse(raw) : [...SEED_PRODS];
    const existingIds = new Set(existing.map((x: DBProduct) => x.id));
    const toAdd = V2_PRODUCTS.filter(x => !existingIds.has(x.id));
    if (toAdd.length > 0) {
      persist(K.prods, [...existing, ...toAdd]);
    }
  } catch {}
  localStorage.setItem(V2_KEY, '1');
}

ensureV2Products();

// ─── V3 migration: more customers (30+) + impulse products + new categories ──

const V3_KEY = 'pc_v3_migrated';

const V3_CUSTOMERS: DBCustomer[] = [
  { id: 'cl-v3-01', name: 'Roberto Augusto Pereira',      cpf: '045.678.912-34', email: 'roberto.pereira@gmail.com',       phone: '(11) 98711-2233', status: 'Ativo' },
  { id: 'cl-v3-02', name: 'Fernanda Cristina Lima',       cpf: '156.789.023-45', email: 'fernanda.lima@hotmail.com',       phone: '(11) 97622-3344', status: 'Ativo' },
  { id: 'cl-v3-03', name: 'André Luís Nascimento',        cpf: '267.890.134-56', email: 'andre.nascimento@outlook.com',    phone: '(11) 96533-4455', status: 'Ativo' },
  { id: 'cl-v3-04', name: 'Priscila Santos Rocha',        cpf: '378.901.245-67', email: 'priscila.rocha@gmail.com',        phone: '(11) 95444-5566', status: 'Ativo' },
  { id: 'cl-v3-05', name: 'Diego Moreira Teixeira',       cpf: '489.012.356-78', email: 'diego.teixeira@email.com',        phone: '(11) 94355-6677', status: 'Ativo' },
  { id: 'cl-v3-06', name: 'Luciana Ferreira Gomes',       cpf: '590.123.467-89', email: 'luciana.gomes@gmail.com',         phone: '(11) 93266-7788', status: 'Ativo' },
  { id: 'cl-v3-07', name: 'Thiago Barbosa Alves',         cpf: '601.234.578-90', email: 'thiago.alves@yahoo.com',          phone: '(11) 92177-8899', status: 'Ativo' },
  { id: 'cl-v3-08', name: 'Vanessa Oliveira Martins',     cpf: '712.345.689-01', email: 'vanessa.martins@gmail.com',       phone: '(11) 91088-9900', status: 'Ativo' },
  { id: 'cl-v3-09', name: 'Eduardo Costa Carvalho',       cpf: '823.456.790-12', email: 'eduardo.carvalho@outlook.com',   phone: '(21) 99977-0011', status: 'Ativo' },
  { id: 'cl-v3-10', name: 'Juliana Pereira Souza',        cpf: '934.567.801-23', email: 'juliana.souza@gmail.com',         phone: '(21) 98866-1122', status: 'Ativo' },
  { id: 'cl-v3-11', name: 'Escola Estadual Paulo Freire', cpf: '23.456.789/0001-01', email: 'secretaria@eepaulofreire.edu.br', phone: '(11) 3456-8901', status: 'Ativo' },
  { id: 'cl-v3-12', name: 'Escola Particular Futuro',     cpf: '34.567.890/0001-12', email: 'admin@escolafuturo.edu.br',   phone: '(11) 3567-9012', status: 'Ativo' },
  { id: 'cl-v3-13', name: 'Escritório Central LTDA',      cpf: '45.678.901/0001-23', email: 'compras@escritoriocentral.com', phone: '(11) 3678-0123', status: 'Ativo' },
  { id: 'cl-v3-14', name: 'Rafael Dantas Mendonça',       cpf: '045.891.203-34', email: 'rafael.mendonca@empresa.com.br', phone: '(31) 99543-2200', status: 'Ativo' },
  { id: 'cl-v3-15', name: 'Amanda Batista Cardoso',       cpf: '156.902.314-45', email: 'amanda.cardoso@gmail.com',        phone: '(41) 98432-1109', status: 'Ativo' },
  { id: 'cl-v3-16', name: 'Felipe Azevedo Correia',       cpf: '267.013.425-56', email: 'felipe.correia@hotmail.com',      phone: '(51) 97321-0098', status: 'Ativo' },
  { id: 'cl-v3-17', name: 'Renata Guimarães Pinto',       cpf: '378.124.536-67', email: 'renata.pinto@outlook.com',        phone: '(11) 96210-9987', status: 'Ativo' },
  { id: 'cl-v3-18', name: 'Bruno Cavalcante Ribeiro',     cpf: '489.235.647-78', email: 'bruno.ribeiro@gmail.com',         phone: '(11) 95109-8876', status: 'Ativo' },
  { id: 'cl-v3-19', name: 'Carolina Ramos Vieira',        cpf: '590.346.758-89', email: 'carolina.vieira@yahoo.com',       phone: '(11) 94098-7765', status: 'Ativo' },
  { id: 'cl-v3-20', name: 'Marcelo Fonseca Cruz',         cpf: '601.457.869-90', email: 'marcelo.cruz@empresa.com.br',     phone: '(11) 93987-6654', status: 'Ativo' },
  { id: 'cl-v3-21', name: 'Cristina Aragão Silva',        cpf: '712.568.970-01', email: 'cristina.silva@gmail.com',        phone: '(11) 92876-5543', status: 'Ativo' },
  { id: 'cl-v3-22', name: 'Guilherme Nunes Barros',       cpf: '823.679.081-12', email: 'guilherme.barros@hotmail.com',    phone: '(11) 91765-4432', status: 'Ativo' },
  { id: 'cl-v3-23', name: 'Tatiana Moura Andrade',        cpf: '934.780.192-23', email: 'tatiana.andrade@gmail.com',       phone: '(11) 90654-3321', status: 'Inativo' },
  { id: 'cl-v3-24', name: 'Leonardo Vasconcelos Luz',     cpf: '045.891.203-34', email: 'leonardo.luz@outlook.com',        phone: '(11) 99543-2210', status: 'Ativo' },
  { id: 'cl-v3-25', name: 'Patrícia Monteiro Leal',       cpf: '156.902.314-45', email: 'patricia.leal@gmail.com',         phone: '(11) 98432-1109', status: 'Ativo' },
  { id: 'cl-v3-26', name: 'Clínica São Lucas LTDA',       cpf: '56.789.012/0001-34', email: 'compras@clinicasaolucas.com.br', phone: '(11) 3789-1234', status: 'Ativo' },
  { id: 'cl-v3-27', name: 'Condomínio Residencial Arco',  cpf: '67.890.123/0001-45', email: 'sindico@condarco.com.br',     phone: '(11) 3890-2345', status: 'Ativo' },
  { id: 'cl-v3-28', name: 'Igor Santana Bezerra',         cpf: '278.013.425-56', email: 'igor.bezerra@gmail.com',          phone: '(71) 99988-7766', status: 'Ativo' },
  { id: 'cl-v3-29', name: 'Simone Cunha Madeira',         cpf: '389.124.536-67', email: 'simone.madeira@hotmail.com',      phone: '(85) 98877-6655', status: 'Ativo' },
  { id: 'cl-v3-30', name: 'Henrique Prado Villela',       cpf: '490.235.647-78', email: 'henrique.villela@empresa.com.br', phone: '(11) 97766-5544', status: 'Ativo' },
];

// New categories: Presentes e Variedades, Doces e Balcão
const V3_CATS: DBCategory[] = [
  { id: 'c-008', name: 'Presentes e Variedades', description: 'Itens de presente, utilidades e novidades', status: 'Ativa' },
  { id: 'c-009', name: 'Doces e Balcão',         description: 'Produtos de impulso próximos ao caixa', status: 'Ativa' },
];

const V3_PRODUCTS: DBProduct[] = [
  // Presentes e Variedades
  p('v3-232','P-232','Caneca Porcelana 300ml Personalizada','Presentes e Variedades',19.90,30,8),
  p('v3-233','P-233','Porta-Retratos 10x15 Plástico Cromado','Presentes e Variedades',14.90,20,5),
  p('v3-234','P-234','Kit Presente Escolar Tilibra Premium','Presentes e Variedades',49.90,15,4),
  p('v3-235','P-235','Caixinha de Música Personalizada','Presentes e Variedades',34.90,8,3),
  p('v3-236','P-236','Diário Ilustrado Capa Dura A5','Presentes e Variedades',29.90,18,5),
  p('v3-237','P-237','Porta-Foto Mdf 3D Decorativo','Presentes e Variedades',24.90,12,3),
  p('v3-238','P-238','Almofada de Mesa Personalizada','Presentes e Variedades',12.90,10,3),
  p('v3-239','P-239','Mini Buquê Artificial Decorativo','Presentes e Variedades',18.90,15,4),
  p('v3-240','P-240','Garrafa Squeeze 500ml c/ Canudinho','Presentes e Variedades',22.90,20,5),
  p('v3-241','P-241','Mochila Escolar Juvenil Estampada','Presentes e Variedades',89.90,12,3),
  p('v3-242','P-242','Estojo Escolar 3 Andares Com Alça','Presentes e Variedades',39.90,18,5),
  p('v3-243','P-243','Lancheira Térmica Escolar Infantil','Presentes e Variedades',44.90,10,3),
  p('v3-244','P-244','Kit Caneta + Lapiseira Faber-Castell','Presentes e Variedades',29.90,20,5),
  p('v3-245','P-245','Caixa Organizadora Kraft c/ Tampa','Presentes e Variedades',16.90,15,4),
  p('v3-246','P-246','Marca-Páginas Magnético Kit 8un','Presentes e Variedades',12.90,25,6),
  p('v3-247','P-247','Adesivos Decorativos Kit 50un','Presentes e Variedades',8.90,30,8),
  p('v3-248','P-248','Caderno de Receitas Capa Kraft','Presentes e Variedades',22.90,14,4),
  p('v3-249','P-249','Luminária LED Abajur De Mesa','Presentes e Variedades',59.90,6,2),
  p('v3-250','P-250','Porta-Lápis Cerâmico Pintado À Mão','Presentes e Variedades',28.90,8,2),
  // Doces e Balcão
  p('v3-251','P-251','Bala de Goma Sortida 7g Fini','Doces e Balcão',0.75,200,50),
  p('v3-252','P-252','Chiclete Trident Menta 8un','Doces e Balcão',2.50,120,30),
  p('v3-253','P-253','Pirulito Chupa Chups Sortido','Doces e Balcão',1.50,150,40),
  p('v3-254','P-254','Chocolate Bis Lacta 45g','Doces e Balcão',3.90,80,20),
  p('v3-255','P-255','Barra Chocolate Hersheys 40g','Doces e Balcão',4.90,60,15),
  p('v3-256','P-256','Bala Mentos Menta Tubo','Doces e Balcão',3.50,90,20),
  p('v3-257','P-257','Drops Halls Mentol c/12','Doces e Balcão',2.90,100,25),
  p('v3-258','P-258','Banana Chips Sachê 30g','Doces e Balcão',2.50,80,20),
  p('v3-259','P-259','Ioiô Profissional Colorido','Doces e Balcão',9.90,40,10),
  p('v3-260','P-260','Chaveiro Boneco Emborrachado','Doces e Balcão',5.90,50,12),
  p('v3-261','P-261','Borracha Divertida Formato 3D','Doces e Balcão',3.90,60,15),
  p('v3-262','P-262','Mini Adesivos Holográficos c/20','Doces e Balcão',4.90,70,18),
  p('v3-263','P-263','Bala Luminosa Piscante','Doces e Balcão',1.90,80,20),
  p('v3-264','P-264','Caneta Apagável Colorida Infantil','Doces e Balcão',5.90,50,12),
  p('v3-265','P-265','Mini Carimbo Divertido','Doces e Balcão',7.90,35,8),
  p('v3-266','P-266','Apontador Formato Animal','Doces e Balcão',3.50,60,15),
  p('v3-267','P-267','Estojo Mini Plástico Unicórnio','Doces e Balcão',8.90,30,8),
  p('v3-268','P-268','Régua Flexível Colorida 30cm','Doces e Balcão',4.90,45,10),
  p('v3-269','P-269','Confeito Colorido 50g Cake Design','Doces e Balcão',2.90,60,15),
  p('v3-270','P-270','Balas Sonho de Valsa Mini 30g','Doces e Balcão',3.90,70,18),
];

function ensureV3(): void {
  if (localStorage.getItem(V3_KEY)) return;
  try {
    // Add customers
    const rawC = localStorage.getItem(K.custs);
    const existingC: DBCustomer[] = rawC ? JSON.parse(rawC) : [];
    const custIds = new Set(existingC.map(x => x.id));
    const toAddC = V3_CUSTOMERS.filter(x => !custIds.has(x.id));
    if (toAddC.length > 0) persist(K.custs, [...existingC, ...toAddC]);

    // Add products
    const rawP = localStorage.getItem(K.prods);
    const existingP: DBProduct[] = rawP ? JSON.parse(rawP) : [...SEED_PRODS];
    const prodIds = new Set(existingP.map(x => x.id));
    const toAddP = V3_PRODUCTS.filter(x => !prodIds.has(x.id));
    if (toAddP.length > 0) persist(K.prods, [...existingP, ...toAddP]);

    // Add categories
    const rawCat = localStorage.getItem(K.cats);
    const existingCat: DBCategory[] = rawCat ? JSON.parse(rawCat) : [...SEED_CATS];
    const catIds = new Set(existingCat.map(x => x.id));
    const toAddCat = V3_CATS.filter(x => !catIds.has(x.id));
    if (toAddCat.length > 0) persist(K.cats, [...existingCat, ...toAddCat]);
  } catch {}
  localStorage.setItem(V3_KEY, '1');
}

ensureV3();

import { ensureV4 } from './v4Migration';
ensureV4();
