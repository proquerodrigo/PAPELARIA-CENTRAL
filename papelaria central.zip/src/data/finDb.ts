// ============================================================
// MÓDULO FINANCEIRO — Papelaria Central
// Camada de persistência em localStorage (pc_fin_v1_*)
// Espelha o padrão de src/data/db.ts
// ============================================================

import { newId } from './db';

export type PaymentMethod = 'Dinheiro' | 'Pix' | 'Cartão de débito' | 'Cartão de crédito' | 'Boleto' | 'Transferência';
export type RecStatus = 'Pago' | 'Pendente' | 'Cancelado';
export type ExpenseCat = 'Compra de estoque' | 'Salários' | 'VR' | 'VT' | 'Aluguel' | 'Energia' | 'Internet' | 'Fornecedores' | 'Outras despesas';
export type RevenueCat = 'Vendas' | 'Recebimentos' | 'Outros recebimentos';
export type OrderStatus = 'Pendente' | 'Em preparação' | 'Pronto para entrega' | 'Saiu para entrega' | 'Entregue' | 'Cancelado';
export type BillStatus = 'Pendente' | 'Pago' | 'Vencido';
export type ContractType = 'CLT' | 'Outro';

export interface FinRevenue {
  id: string;
  description: string;
  category: RevenueCat;
  value: number;
  date: string;
  paymentMethod: PaymentMethod;
  status: RecStatus;
  createdAt: string;
}

export interface FinExpense {
  id: string;
  description: string;
  category: ExpenseCat;
  value: number;
  date: string;
  paymentMethod: PaymentMethod;
  status: RecStatus;
  createdAt: string;
}

export interface FinOrder {
  id: string;
  orderNumber: string;
  client: string;
  products: string;
  qty: number;
  total: number;
  orderDate: string;
  deliveryDate: string;
  address: string;
  paymentMethod: PaymentMethod;
  status: OrderStatus;
  createdAt: string;
}

export interface FinBill {
  id: string;
  description: string;
  category: string;
  value: number;
  dueDate: string;
  status: BillStatus;
  createdAt: string;
}

export interface FinEmployee {
  id: string;
  userId: string;
  salary: number;
  vr: number;
  vt: number;
  contractType: ContractType;
  admissionDate: string;
}

export interface FinPayroll {
  id: string;
  employeeId: string;
  userId: string;
  name: string;
  jobTitle: string;
  month: string;
  salary: number;
  vr: number;
  vt: number;
  total: number;
  status: 'Pago' | 'Pendente';
  paymentDate?: string;
  paidBy?: string;
  createdAt: string;
}

export type SaleStatus = 'A receber' | 'Recebido' | 'Cancelado';

export interface FinSale {
  id: string;
  saleNumber: string;
  date: string;
  client: string;
  description: string;
  grossValue: number;
  feeRate: number;
  feeValue: number;
  netValue: number;
  paymentMethod: PaymentMethod;
  installments: number;
  expectedDate: string;
  receivedDate?: string;
  status: SaleStatus;
  createdAt: string;
}

export interface TaxConfig {
  pix: { rate: number; days: number };
  dinheiro: { rate: number; days: number };
  debito: { rate: number; days: number };
  creditoAvista: { rate: number; days: number };
  creditoParcelado2a6: { rate: number; days: number };
  creditoParcelado7a12: { rate: number; days: number };
  boleto: { rate: number; days: number };
  transferencia: { rate: number; days: number };
}

const K = {
  revenues: 'pc_fin_v1_revenues',
  expenses: 'pc_fin_v1_expenses',
  orders: 'pc_fin_v1_orders',
  bills: 'pc_fin_v1_bills',
  employees: 'pc_fin_v1_employees',
  payroll: 'pc_fin_v1_payroll',
  seeded: 'pc_fin_v1_seeded',
  sales: 'pc_fin_v1_sales',
  salesSeeded: 'pc_fin_v1_sales_seeded',
  taxConfig: 'pc_fin_v1_taxConfig',
};

function fload<T>(key: string): T[] {
  try { const r = localStorage.getItem(key); return r ? JSON.parse(r) : []; } catch { return []; }
}
function fpersist(key: string, data: unknown[]): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// ── seed helpers ──────────────────────────────────────────
function d(y: number, m: number, day: number) {
  return new Date(y, m - 1, day).toISOString().slice(0, 10);
}
function pm(): PaymentMethod {
  const opts: PaymentMethod[] = ['Pix', 'Cartão de crédito', 'Cartão de débito', 'Dinheiro', 'Boleto', 'Transferência'];
  return opts[Math.floor(Math.random() * opts.length)];
}
function fmtDate(iso: string) {
  const [y, m, day] = iso.split('-');
  return `${day}/${m}/${y}`;
}

// Seed de receitas — Julho, Agosto e Setembro 2026
const SEED_REVENUES: FinRevenue[] = [
  // Julho
  { id: 'r-001', description: 'Venda balcão — materiais escolares', category: 'Vendas', value: 1842.50, date: d(2026,7,2), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,2) },
  { id: 'r-002', description: 'Venda balcão — cadernos e canetas', category: 'Vendas', value: 934.00, date: d(2026,7,3), paymentMethod: 'Cartão de crédito', status: 'Pago', createdAt: d(2026,7,3) },
  { id: 'r-003', description: 'Pedido corporativo — Escola Municipal', category: 'Vendas', value: 3480.00, date: d(2026,7,7), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,7) },
  { id: 'r-004', description: 'Venda balcão — papelaria artística', category: 'Vendas', value: 720.00, date: d(2026,7,9), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,7,9) },
  { id: 'r-005', description: 'Venda balcão — material de escritório', category: 'Vendas', value: 1150.00, date: d(2026,7,11), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,11) },
  { id: 'r-006', description: 'Recebimento — pedido Papelaria do Bairro', category: 'Recebimentos', value: 2200.00, date: d(2026,7,14), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,14) },
  { id: 'r-007', description: 'Venda balcão — kits escolares', category: 'Vendas', value: 1640.00, date: d(2026,7,16), paymentMethod: 'Cartão de débito', status: 'Pago', createdAt: d(2026,7,16) },
  { id: 'r-008', description: 'Venda balcão — impressão e papéis', category: 'Vendas', value: 880.00, date: d(2026,7,18), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,18) },
  { id: 'r-009', description: 'Pedido corporativo — Escola Estadual Prof. Wanderley', category: 'Vendas', value: 5620.00, date: d(2026,7,21), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,21) },
  { id: 'r-010', description: 'Venda balcão — lápis e borrachas', category: 'Vendas', value: 540.00, date: d(2026,7,23), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,7,23) },
  { id: 'r-011', description: 'Venda balcão — organizadores', category: 'Vendas', value: 1230.00, date: d(2026,7,25), paymentMethod: 'Cartão de crédito', status: 'Pago', createdAt: d(2026,7,25) },
  { id: 'r-012', description: 'Recebimento adiantamento — cliente Gabriel', category: 'Recebimentos', value: 500.00, date: d(2026,7,28), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,28) },
  { id: 'r-013', description: 'Venda balcão — fim de mês', category: 'Vendas', value: 1990.00, date: d(2026,7,30), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,30) },
  // Agosto
  { id: 'r-014', description: 'Venda balcão — início de mês', category: 'Vendas', value: 2140.00, date: d(2026,8,4), paymentMethod: 'Cartão de crédito', status: 'Pago', createdAt: d(2026,8,4) },
  { id: 'r-015', description: 'Pedido corporativo — empresa Beatriz Lima', category: 'Vendas', value: 4200.00, date: d(2026,8,6), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,6) },
  { id: 'r-016', description: 'Venda balcão — cadernos universitários', category: 'Vendas', value: 1580.00, date: d(2026,8,8), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,8,8) },
  { id: 'r-017', description: 'Venda balcão — canetas e lapiseiras', category: 'Vendas', value: 920.00, date: d(2026,8,12), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,8,12) },
  { id: 'r-018', description: 'Recebimento — saldo devedor cliente Mariana', category: 'Recebimentos', value: 780.00, date: d(2026,8,14), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,8,14) },
  { id: 'r-019', description: 'Pedido corporativo — volta às aulas', category: 'Vendas', value: 6840.00, date: d(2026,8,15), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,8,15) },
  { id: 'r-020', description: 'Venda balcão — materiais artísticos', category: 'Vendas', value: 1340.00, date: d(2026,8,19), paymentMethod: 'Cartão de crédito', status: 'Pago', createdAt: d(2026,8,19) },
  { id: 'r-021', description: 'Venda balcão — pastas e organizadores', category: 'Vendas', value: 870.00, date: d(2026,8,21), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,8,21) },
  { id: 'r-022', description: 'Pedido Papelaria do Bairro — agosto', category: 'Vendas', value: 2950.00, date: d(2026,8,25), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,8,25) },
  { id: 'r-023', description: 'Venda balcão — papéis sulfite', category: 'Vendas', value: 1120.00, date: d(2026,8,27), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,8,27) },
  { id: 'r-024', description: 'Outros recebimentos — brindes devolvidos', category: 'Outros recebimentos', value: 240.00, date: d(2026,8,29), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,8,29) },
  // Setembro
  { id: 'r-025', description: 'Venda balcão — semana 1', category: 'Vendas', value: 1760.00, date: d(2026,9,2), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,9,2) },
  { id: 'r-026', description: 'Pedido corporativo — Lucas Almeida empresa', category: 'Vendas', value: 3100.00, date: d(2026,9,5), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,9,5) },
  { id: 'r-027', description: 'Venda balcão — cadernos e lápis', category: 'Vendas', value: 1020.00, date: d(2026,9,9), paymentMethod: 'Cartão de crédito', status: 'Pago', createdAt: d(2026,9,9) },
  { id: 'r-028', description: 'Venda balcão — kits artísticos', category: 'Vendas', value: 1450.00, date: d(2026,9,12), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,9,12) },
  { id: 'r-029', description: 'Recebimento — pedido anterior Escola Wanderley', category: 'Recebimentos', value: 2800.00, date: d(2026,9,15), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,9,15) },
  { id: 'r-030', description: 'Venda balcão — semana 3', category: 'Vendas', value: 1890.00, date: d(2026,9,18), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,9,18) },
  { id: 'r-031', description: 'Pedido corporativo — papéis e impressão', category: 'Vendas', value: 2340.00, date: d(2026,9,22), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,9,22) },
  { id: 'r-032', description: 'Venda balcão — semana 4', category: 'Vendas', value: 1540.00, date: d(2026,9,25), paymentMethod: 'Cartão de débito', status: 'Pago', createdAt: d(2026,9,25) },
  { id: 'r-033', description: 'Pedido pendente — cliente Beatriz Rodrigues', category: 'Recebimentos', value: 1800.00, date: d(2026,9,29), paymentMethod: 'Boleto', status: 'Pendente', createdAt: d(2026,9,29) },
];

// Seed de despesas
const SEED_EXPENSES: FinExpense[] = [
  // Julho
  { id: 'e-001', description: 'Aluguel — julho/2026', category: 'Aluguel', value: 3800.00, date: d(2026,7,5), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,5) },
  { id: 'e-002', description: 'Conta de energia elétrica', category: 'Energia', value: 480.00, date: d(2026,7,8), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,8) },
  { id: 'e-003', description: 'Internet — fibra 300mb', category: 'Internet', value: 149.90, date: d(2026,7,10), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,10) },
  { id: 'e-004', description: 'Compra de estoque — Faber-Castell e BIC', category: 'Compra de estoque', value: 4200.00, date: d(2026,7,12), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,12) },
  { id: 'e-005', description: 'Compra de estoque — Tilibra cadernos', category: 'Compra de estoque', value: 2800.00, date: d(2026,7,15), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,15) },
  { id: 'e-006', description: 'VR — funcionários julho', category: 'VR', value: 2574.00, date: d(2026,7,20), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,20) },
  { id: 'e-007', description: 'VT — funcionários julho', category: 'VT', value: 1287.00, date: d(2026,7,20), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,20) },
  { id: 'e-008', description: 'Compra de estoque — papéis Chamex', category: 'Compra de estoque', value: 1600.00, date: d(2026,7,22), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,7,22) },
  { id: 'e-009', description: 'Fornecedor Maped — novos produtos', category: 'Fornecedores', value: 3200.00, date: d(2026,7,25), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,7,25) },
  { id: 'e-010', description: 'Folha de pagamento — julho', category: 'Salários', value: 15800.00, date: d(2026,7,30), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,7,30) },
  // Agosto
  { id: 'e-011', description: 'Aluguel — agosto/2026', category: 'Aluguel', value: 3800.00, date: d(2026,8,5), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,5) },
  { id: 'e-012', description: 'Energia elétrica — agosto', category: 'Energia', value: 510.00, date: d(2026,8,8), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,8,8) },
  { id: 'e-013', description: 'Internet — agosto', category: 'Internet', value: 149.90, date: d(2026,8,10), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,10) },
  { id: 'e-014', description: 'Compra de estoque — Stabilo e Pilot', category: 'Compra de estoque', value: 3100.00, date: d(2026,8,11), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,8,11) },
  { id: 'e-015', description: 'Compra de estoque — Spiral cadernos', category: 'Compra de estoque', value: 2400.00, date: d(2026,8,13), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,8,13) },
  { id: 'e-016', description: 'VR — funcionários agosto', category: 'VR', value: 2574.00, date: d(2026,8,20), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,20) },
  { id: 'e-017', description: 'VT — funcionários agosto', category: 'VT', value: 1287.00, date: d(2026,8,20), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,20) },
  { id: 'e-018', description: 'Fornecedor DAC — pastas e organizadores', category: 'Fornecedores', value: 1800.00, date: d(2026,8,22), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,8,22) },
  { id: 'e-019', description: 'Outras despesas — material de limpeza', category: 'Outras despesas', value: 320.00, date: d(2026,8,24), paymentMethod: 'Dinheiro', status: 'Pago', createdAt: d(2026,8,24) },
  { id: 'e-020', description: 'Folha de pagamento — agosto', category: 'Salários', value: 15800.00, date: d(2026,8,30), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,8,30) },
  // Setembro
  { id: 'e-021', description: 'Aluguel — setembro/2026', category: 'Aluguel', value: 3800.00, date: d(2026,9,5), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,9,5) },
  { id: 'e-022', description: 'Energia elétrica — setembro', category: 'Energia', value: 492.00, date: d(2026,9,8), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,9,8) },
  { id: 'e-023', description: 'Internet — setembro', category: 'Internet', value: 149.90, date: d(2026,9,10), paymentMethod: 'Transferência', status: 'Pago', createdAt: d(2026,9,10) },
  { id: 'e-024', description: 'Compra de estoque — Pentel e Maped', category: 'Compra de estoque', value: 2700.00, date: d(2026,9,11), paymentMethod: 'Boleto', status: 'Pago', createdAt: d(2026,9,11) },
  { id: 'e-025', description: 'Compra de estoque — Acrilex tintas', category: 'Compra de estoque', value: 1400.00, date: d(2026,9,16), paymentMethod: 'Pix', status: 'Pago', createdAt: d(2026,9,16) },
  { id: 'e-026', description: 'VR — funcionários setembro', category: 'VR', value: 2574.00, date: d(2026,9,20), paymentMethod: 'Transferência', status: 'Pendente', createdAt: d(2026,9,20) },
  { id: 'e-027', description: 'VT — funcionários setembro', category: 'VT', value: 1287.00, date: d(2026,9,20), paymentMethod: 'Transferência', status: 'Pendente', createdAt: d(2026,9,20) },
  { id: 'e-028', description: 'Fornecedor Compactor — acessórios', category: 'Fornecedores', value: 2100.00, date: d(2026,9,23), paymentMethod: 'Boleto', status: 'Pendente', createdAt: d(2026,9,23) },
  { id: 'e-029', description: 'Folha de pagamento — setembro', category: 'Salários', value: 15800.00, date: d(2026,9,30), paymentMethod: 'Transferência', status: 'Pendente', createdAt: d(2026,9,30) },
];

// Seed de pedidos
const SEED_ORDERS: FinOrder[] = [
  { id: 'o-001', orderNumber: 'PED-001', client: 'Escola Estadual Prof. Wanderley', products: 'Cadernos Tilibra 10 Matérias x50, Canetas BIC Cristal x100', qty: 150, total: 1840.00, orderDate: d(2026,9,18), deliveryDate: d(2026,9,28), address: 'Rua das Escolas, 142 — Vila Educação, SP', paymentMethod: 'Boleto', status: 'Pronto para entrega', createdAt: d(2026,9,18) },
  { id: 'o-002', orderNumber: 'PED-002', client: 'Papelaria do Bairro LTDA', products: 'Lápis Faber-Castell HB x200, Borrachas Tilibra x150', qty: 350, total: 3200.00, orderDate: d(2026,9,20), deliveryDate: d(2026,10,2), address: 'Av. das Acácias, 88 — Centro, SP', paymentMethod: 'Pix', status: 'Em preparação', createdAt: d(2026,9,20) },
  { id: 'o-003', orderNumber: 'PED-003', client: 'Ana Beatriz Martins', products: 'Kit artístico Faber-Castell, Tinta Acrilex 12 cores', qty: 8, total: 420.00, orderDate: d(2026,9,22), deliveryDate: d(2026,9,30), address: 'Rua das Flores, 55 — Jardim São Paulo, SP', paymentMethod: 'Cartão de crédito', status: 'Saiu para entrega', createdAt: d(2026,9,22) },
  { id: 'o-004', orderNumber: 'PED-004', client: 'Lucas Henrique Almeida', products: 'Papel Chamex A4 500fl x10, Canetas Pilot G-2 x20', qty: 30, total: 680.00, orderDate: d(2026,9,24), deliveryDate: d(2026,10,5), address: 'Rua Ipiranga, 200 — Mooca, SP', paymentMethod: 'Pix', status: 'Pendente', createdAt: d(2026,9,24) },
  { id: 'o-005', orderNumber: 'PED-005', client: 'Gabriel Santos Ferreira', products: 'Cadernos universitários Spiral x30, Lápis Staedtler x60', qty: 90, total: 1120.00, orderDate: d(2026,9,25), deliveryDate: d(2026,10,8), address: 'Av. Paulista, 1000 — Bela Vista, SP', paymentMethod: 'Boleto', status: 'Pendente', createdAt: d(2026,9,25) },
  { id: 'o-006', orderNumber: 'PED-006', client: 'Beatriz Rodrigues Lima', products: 'Stabilo Boss Kit 6 cores x5, Caderno Foroni x10', qty: 15, total: 340.00, orderDate: d(2026,9,10), deliveryDate: d(2026,9,20), address: 'Rua Augusta, 400 — Consolação, SP', paymentMethod: 'Pix', status: 'Entregue', createdAt: d(2026,9,10) },
  { id: 'o-007', orderNumber: 'PED-007', client: 'Escola Estadual Prof. Wanderley', products: 'Resmas Chamex A4 x30, Cartolinas coloridas x200', qty: 230, total: 2460.00, orderDate: d(2026,8,28), deliveryDate: d(2026,9,8), address: 'Rua das Escolas, 142 — Vila Educação, SP', paymentMethod: 'Transferência', status: 'Entregue', createdAt: d(2026,8,28) },
  { id: 'o-008', orderNumber: 'PED-008', client: 'Mariana Oliveira Costa', products: 'Conjunto geometria Faber-Castell x10, Lapiseiras x20', qty: 30, total: 480.00, orderDate: d(2026,9,26), deliveryDate: d(2026,10,10), address: 'Rua dos Pinheiros, 77 — Pinheiros, SP', paymentMethod: 'Cartão de débito', status: 'Em preparação', createdAt: d(2026,9,26) },
  { id: 'o-009', orderNumber: 'PED-009', client: 'Papelaria do Bairro LTDA', products: 'Marca-textos Stabilo Boss x100, Corretivos BIC x50', qty: 150, total: 890.00, orderDate: d(2026,9,15), deliveryDate: d(2026,9,22), address: 'Av. das Acácias, 88 — Centro, SP', paymentMethod: 'Boleto', status: 'Cancelado', createdAt: d(2026,9,15) },
];

// Seed de contas pendentes
const SEED_BILLS: FinBill[] = [
  { id: 'b-001', description: 'Aluguel — outubro/2026', category: 'Aluguel', value: 3800.00, dueDate: d(2026,10,5), status: 'Pendente', createdAt: d(2026,9,15) },
  { id: 'b-002', description: 'Energia elétrica — outubro', category: 'Energia', value: 490.00, dueDate: d(2026,10,8), status: 'Pendente', createdAt: d(2026,9,20) },
  { id: 'b-003', description: 'Folha de pagamento — setembro', category: 'Salários', value: 15800.00, dueDate: d(2026,9,30), status: 'Pendente', createdAt: d(2026,9,1) },
  { id: 'b-004', description: 'Fornecedor Compactor — parcela 2', category: 'Fornecedores', value: 2100.00, dueDate: d(2026,9,28), status: 'Vencido', createdAt: d(2026,9,1) },
  { id: 'b-005', description: 'Internet — outubro', category: 'Internet', value: 149.90, dueDate: d(2026,10,10), status: 'Pendente', createdAt: d(2026,9,25) },
  { id: 'b-006', description: 'VR — setembro', category: 'Benefícios', value: 2574.00, dueDate: d(2026,9,20), status: 'Vencido', createdAt: d(2026,9,1) },
  { id: 'b-007', description: 'VT — setembro', category: 'Benefícios', value: 1287.00, dueDate: d(2026,9,20), status: 'Vencido', createdAt: d(2026,9,1) },
  { id: 'b-008', description: 'Compra de estoque — nota Pentel (parcela 2)', category: 'Estoque', value: 1350.00, dueDate: d(2026,10,15), status: 'Pendente', createdAt: d(2026,9,10) },
];

// Seed de dados financeiros dos funcionários
const SEED_FIN_EMPLOYEES: FinEmployee[] = [
  { id: 'fe-001', userId: 'u-002', salary: 4500.00, vr: 660.00, vt: 330.00, contractType: 'CLT', admissionDate: '2024-03-01' },
  { id: 'fe-002', userId: 'u-003', salary: 2800.00, vr: 528.00, vt: 264.00, contractType: 'CLT', admissionDate: '2024-06-15' },
  { id: 'fe-003', userId: 'u-004', salary: 2200.00, vr: 396.00, vt: 198.00, contractType: 'CLT', admissionDate: '2024-08-01' },
  { id: 'fe-004', userId: 'u-005', salary: 1900.00, vr: 352.00, vt: 176.00, contractType: 'CLT', admissionDate: '2024-09-01' },
  { id: 'fe-005', userId: 'u-006', salary: 2000.00, vr: 374.00, vt: 187.00, contractType: 'CLT', admissionDate: '2024-10-15' },
  { id: 'fe-006', userId: 'u-007', salary: 1900.00, vr: 352.00, vt: 176.00, contractType: 'CLT', admissionDate: '2025-01-10' },
  { id: 'fe-007', userId: 'u-008', salary: 2500.00, vr: 462.00, vt: 231.00, contractType: 'CLT', admissionDate: '2025-02-01' },
];

// Seed folha de pagamento — 3 meses
function makePayroll(month: string, pago: boolean): FinPayroll[] {
  const items = [
    { id: `pay-${month}-1`, employeeId: 'fe-001', userId: 'u-002', name: 'Ana Beatriz Martins', jobTitle: 'Gerente', salary: 4500, vr: 660, vt: 330 },
    { id: `pay-${month}-2`, employeeId: 'fe-002', userId: 'u-003', name: 'Lucas Henrique Almeida', jobTitle: 'Vendedor', salary: 2800, vr: 528, vt: 264 },
    { id: `pay-${month}-3`, employeeId: 'fe-003', userId: 'u-004', name: 'Camila Fernandes Rocha', jobTitle: 'Caixa', salary: 2200, vr: 396, vt: 198 },
    { id: `pay-${month}-4`, employeeId: 'fe-004', userId: 'u-005', name: 'Mariana Oliveira Costa', jobTitle: 'Atendente', salary: 1900, vr: 352, vt: 176 },
    { id: `pay-${month}-5`, employeeId: 'fe-005', userId: 'u-006', name: 'Rafael Mendes Souza', jobTitle: 'Estoquista', salary: 2000, vr: 374, vt: 187 },
    { id: `pay-${month}-6`, employeeId: 'fe-006', userId: 'u-007', name: 'Juliana Carvalho Mendes', jobTitle: 'Atendente', salary: 1900, vr: 352, vt: 176 },
    { id: `pay-${month}-7`, employeeId: 'fe-007', userId: 'u-008', name: 'Pedro Henrique Nascimento', jobTitle: 'Vendedor', salary: 2500, vr: 462, vt: 231 },
  ];
  return items.map(e => ({
    ...e,
    month,
    total: e.salary + e.vr + e.vt,
    status: pago ? 'Pago' as const : 'Pendente' as const,
    paymentDate: pago ? `${month}-30` : undefined,
    paidBy: pago ? 'Administrador' : undefined,
    createdAt: `${month}-01`,
  }));
}

const SEED_PAYROLL: FinPayroll[] = [
  ...makePayroll('2026-07', true),
  ...makePayroll('2026-08', true),
  ...makePayroll('2026-09', false),
];

// ── Configuração padrão de taxas ─────────────────────────
export const DEFAULT_TAX_CONFIG: TaxConfig = {
  pix:               { rate: 0,    days: 0  },
  dinheiro:          { rate: 0,    days: 0  },
  debito:            { rate: 1.49, days: 1  },
  creditoAvista:     { rate: 3.49, days: 30 },
  creditoParcelado2a6: { rate: 4.99, days: 30 },
  creditoParcelado7a12: { rate: 5.99, days: 30 },
  boleto:            { rate: 2.50, days: 2  },
  transferencia:     { rate: 0,    days: 0  },
};

// ── Helpers para seed de vendas ───────────────────────────
const SALE_TODAY = '2026-09-28';
function addDays(dateStr: string, days: number): string {
  const dt = new Date(dateStr + 'T12:00:00');
  dt.setDate(dt.getDate() + days);
  return dt.toISOString().slice(0, 10);
}
function r2(v: number): number { return Math.round(v * 100) / 100; }
function getTaxForMethod(method: PaymentMethod, installments: number): { rate: number; days: number } {
  const cfg = DEFAULT_TAX_CONFIG;
  if (method === 'Pix') return cfg.pix;
  if (method === 'Dinheiro') return cfg.dinheiro;
  if (method === 'Cartão de débito') return cfg.debito;
  if (method === 'Cartão de crédito') {
    if (installments <= 1) return cfg.creditoAvista;
    if (installments <= 6) return { rate: cfg.creditoParcelado2a6.rate, days: cfg.creditoParcelado2a6.days * installments };
    return { rate: cfg.creditoParcelado7a12.rate, days: cfg.creditoParcelado7a12.days * installments };
  }
  if (method === 'Boleto') return cfg.boleto;
  return cfg.transferencia;
}
let _sc = 0;
function mkSale(date: string, gross: number, method: PaymentMethod, client: string, desc: string, installments = 1): FinSale {
  _sc++;
  const { rate, days } = getTaxForMethod(method, installments);
  const feeValue = r2(gross * rate / 100);
  const netValue = r2(gross - feeValue);
  const expectedDate = addDays(date, days);
  const received = expectedDate <= SALE_TODAY;
  return {
    id: `s-${String(_sc).padStart(3, '0')}`,
    saleNumber: `V-${String(_sc).padStart(3, '0')}`,
    date, client, description: desc,
    grossValue: gross, feeRate: rate, feeValue, netValue,
    paymentMethod: method, installments, expectedDate,
    receivedDate: received ? expectedDate : undefined,
    status: received ? 'Recebido' : 'A receber',
    createdAt: date,
  };
}
const CC: PaymentMethod = 'Cartão de crédito';
const DB: PaymentMethod = 'Cartão de débito';
const PIX: PaymentMethod = 'Pix';
const DIN: PaymentMethod = 'Dinheiro';
const BOL: PaymentMethod = 'Boleto';
const TRF: PaymentMethod = 'Transferência';
const mk = mkSale;

const SEED_SALES: FinSale[] = [
  // ── Julho 2026 ────────────────────────────────────────────
  mk(d(2026,7,2),  285,  PIX, 'Cliente balcão',              'Venda balcão — material escolar'),
  mk(d(2026,7,2),  120,  DIN, 'Cliente balcão',              'Venda avulsa — canetas e borrachas'),
  mk(d(2026,7,3),  480,  CC,  'Ana Beatriz Martins',         'Cadernos universitários Tilibra', 1),
  mk(d(2026,7,4), 1200,  CC,  'Escola Municipal Jardim',     'Kit escolar completo — 40 alunos', 6),
  mk(d(2026,7,5),   95,  PIX, 'Cliente balcão',              'Lapiseiras e borrachas Tilibra'),
  mk(d(2026,7,7),  320,  DB,  'Gabriel Ferreira',            'Material de escritório — pastas DAC'),
  mk(d(2026,7,8),  540,  PIX, 'Mariana Costa',               'Papéis e impressão — Chamex A4'),
  mk(d(2026,7,9),   75,  DIN, 'Cliente balcão',              'Borrachas e lápis avulsos'),
  mk(d(2026,7,10), 890,  CC,  'Lucas Almeida',               'Material artístico Faber-Castell kit', 3),
  mk(d(2026,7,11),3480,  BOL, 'Escola Municipal Jardim',     'Pedido corporativo — 100 cadernos Tilibra'),
  mk(d(2026,7,12), 150,  PIX, 'Cliente balcão',              'Canetas BIC Cristal kit 50 unid.'),
  mk(d(2026,7,14), 680,  TRF, 'Papelaria do Bairro LTDA',    'Revenda — lápis Faber-Castell HB x200'),
  mk(d(2026,7,15), 410,  CC,  'Beatriz Lima',                'Kit escolar Stabilo + caderno Spiral', 1),
  mk(d(2026,7,16), 245,  DB,  'Cliente balcão',              'Cadernos e pastas organizadoras'),
  mk(d(2026,7,17),1840,  BOL, 'Empresa ABC Comércio',        'Materiais de escritório — pedido mensal'),
  mk(d(2026,7,19), 180,  PIX, 'Juliana Mendes',              'Organização — caixas e pastas'),
  mk(d(2026,7,21),5620,  TRF, 'Escola Est. Prof. Wanderley', 'Pedido corporativo — volta às aulas'),
  mk(d(2026,7,22), 320,  DIN, 'Cliente balcão',              'Vendas avulsas — cadernos e canetas'),
  mk(d(2026,7,23), 760,  CC,  'Rafael Souza',                'Material artístico — tinta Acrilex kit', 1),
  mk(d(2026,7,24), 415,  PIX, 'Pedro Nascimento',            'Cadernos universitários + canetas Pilot'),
  mk(d(2026,7,25),1230,  CC,  'Empresa XYZ Ltda',            'Kit completo escolar — 50 itens', 12),
  mk(d(2026,7,26), 285,  DB,  'Camila Rocha',                'Papéis sulfite e impressão'),
  mk(d(2026,7,28), 880,  PIX, 'Escola do Bairro',            'Compra volta às aulas — lápis e borrachas'),
  mk(d(2026,7,29), 340,  DIN, 'Cliente balcão',              'Vendas avulsas — material artístico'),
  mk(d(2026,7,30),1990,  BOL, 'Distribuidora Papéis SP',     'Pedido corporativo — fim de mês'),
  // ── Agosto 2026 ──────────────────────────────────────────
  mk(d(2026,8,1),  425,  PIX, 'Ana Costa',                   'Material escolar — início de mês'),
  mk(d(2026,8,2),  180,  DIN, 'Cliente balcão',              'Vendas avulsas diversas'),
  mk(d(2026,8,4), 2140,  CC,  'Empresa Beatriz Lima',        'Material escritório completo', 6),
  mk(d(2026,8,5), 4200,  TRF, 'Rede de Ensino SPBC',        'Pedido corporativo — agosto'),
  mk(d(2026,8,6),  310,  PIX, 'Cliente balcão',              'Canetas e marcadores Stabilo'),
  mk(d(2026,8,7),  780,  CC,  'Fernanda Alves',              'Cadernos Tilibra + lapiseiras Pentel', 1),
  mk(d(2026,8,8), 1580,  BOL, 'Supermercado Modelo',         'Material de escritório — boleto 30d'),
  mk(d(2026,8,9),  145,  DIN, 'Cliente balcão',              'Lápis e borrachas avulsos'),
  mk(d(2026,8,11), 460,  DB,  'Roberto Santana',             'Pastas e organizadores DAC'),
  mk(d(2026,8,12), 920,  PIX, 'Escola Municipal Centro',     'Material para sala de aula'),
  mk(d(2026,8,13), 280,  CC,  'Carla Mendes',                'Kit artístico aquarela Faber-Castell', 1),
  mk(d(2026,8,15),6840,  BOL, 'Escola Est. Prof. Wanderley', 'Volta às aulas — grande pedido agosto'),
  mk(d(2026,8,16), 520,  PIX, 'Thiago Rodrigues',            'Cadernos e canetas — kit universitário'),
  mk(d(2026,8,17), 390,  DIN, 'Cliente balcão',              'Material de escritório diverso'),
  mk(d(2026,8,18),1340,  CC,  'Empresa Central Papéis',      'Resmas Chamex + organizadores', 3),
  mk(d(2026,8,19), 680,  DB,  'Isabela Martins',             'Material artístico — tintas e pincéis'),
  mk(d(2026,8,20), 340,  PIX, 'Cliente balcão',              'Canetas coloridas Faber-Castell'),
  mk(d(2026,8,21), 870,  PIX, 'Jorge Oliveira',              'Pastas e cadernos universitários'),
  mk(d(2026,8,22),2950,  BOL, 'Papelaria do Bairro LTDA',    'Revenda mensal — lotes'),
  mk(d(2026,8,23), 175,  DIN, 'Cliente balcão',              'Vendas avulsas — material artístico'),
  mk(d(2026,8,25),1120,  CC,  'Editora Paulista',            'Papel sulfite resmas + clips', 1),
  mk(d(2026,8,26), 560,  DB,  'Amanda Souza',                'Caderno universitário + lapiseiras'),
  mk(d(2026,8,27), 890,  PIX, 'Escola Estadual Centro',      'Material de apoio — sala de recursos'),
  mk(d(2026,8,28), 430,  CC,  'Carlos Eduardo Lima',         'Kit completo material escolar', 1),
  mk(d(2026,8,29), 240,  DIN, 'Cliente balcão',              'Compra final de mês — material diverso'),
  // ── Setembro 2026 ────────────────────────────────────────
  mk(d(2026,9,1),  380,  PIX, 'Ana Ferreira',                'Material escolar — início setembro'),
  mk(d(2026,9,2), 1760,  PIX, 'Condomínio Jardins',          'Material de escritório — pedido mensal'),
  mk(d(2026,9,3),  420,  DB,  'Marcos Pereira',              'Pastas e cadernos — material escritório'),
  mk(d(2026,9,5), 3100,  BOL, 'Escola Municipal Norte',      'Pedido corporativo — material escolar'),
  mk(d(2026,9,6),  285,  DIN, 'Cliente balcão',              'Vendas diversas — canetas e lápis'),
  mk(d(2026,9,8),  740,  CC,  'Patricia Alves',              'Kit artístico completo Faber-Castell', 1),
  mk(d(2026,9,9), 1020,  CC,  'Empresa Beta LTDA',           'Material escritório — parcelado', 6),
  mk(d(2026,9,10), 195,  PIX, 'Cliente balcão',              'Borrachas e apontadores'),
  mk(d(2026,9,12),1450,  PIX, 'Escola Infantil Alegre',      'Material didático — papéis e lápis'),
  mk(d(2026,9,13), 380,  DB,  'Rodrigo Campos',              'Cadernos e organizadores'),
  mk(d(2026,9,15),2800,  TRF, 'Rede Aprender',               'Recebimento pedido anterior — escolas'),
  mk(d(2026,9,16), 680,  CC,  'Sonia Medeiros',              'Kit escolar universitário completo', 1),
  mk(d(2026,9,17), 245,  PIX, 'Cliente balcão',              'Material artístico — aquarela e pincéis'),
  mk(d(2026,9,18),1890,  DIN, 'Escola do Parque',            'Grande compra balcão — material didático'),
  mk(d(2026,9,19), 520,  DB,  'Gustavo Lima',                'Pastas, clipes e grampos — escritório'),
  mk(d(2026,9,20), 340,  PIX, 'Cliente balcão',              'Cadernos brochura e canetas'),
  mk(d(2026,9,22),2340,  BOL, 'Prefeitura Municipal',        'Material escolar — pedido institucional'),
  mk(d(2026,9,23), 880,  CC,  'Agência Criativa SP',         'Material para design — Faber-Castell', 3),
  mk(d(2026,9,24), 410,  PIX, 'Leticia Rodrigues',           'Cadernos e canetas universitárias'),
  mk(d(2026,9,25),1540,  DB,  'SENAI Unidade Central',       'Material técnico — réguas e compassos'),
  mk(d(2026,9,26), 290,  DIN, 'Cliente balcão',              'Vendas avulsas — material artístico'),
  mk(d(2026,9,27), 760,  PIX, 'Marina Carvalho',             'Cadernos e organizadores — kit'),
  mk(d(2026,9,28), 520,  CC,  'Daniel Fonseca',              'Material artístico kit completo', 1),
];

function seedSalesIfNeeded(): void {
  if (localStorage.getItem(K.salesSeeded)) return;
  fpersist(K.sales, SEED_SALES);
  localStorage.setItem(K.salesSeeded, '1');
}

// ── Função de seed inicial ────────────────────────────────
function seedIfNeeded(): void {
  if (localStorage.getItem(K.seeded)) return;
  fpersist(K.revenues, SEED_REVENUES);
  fpersist(K.expenses, SEED_EXPENSES);
  fpersist(K.orders, SEED_ORDERS);
  fpersist(K.bills, SEED_BILLS);
  fpersist(K.employees, SEED_FIN_EMPLOYEES);
  fpersist(K.payroll, SEED_PAYROLL);
  localStorage.setItem(K.seeded, '1');
}

// ── API pública ───────────────────────────────────────────
export const finDb = {
  revenues: {
    all(): FinRevenue[] { seedIfNeeded(); return fload<FinRevenue>(K.revenues).sort((a,b) => b.date.localeCompare(a.date)); },
    add(r: Omit<FinRevenue, 'id' | 'createdAt'>): FinRevenue {
      const item: FinRevenue = { ...r, id: newId(), createdAt: new Date().toISOString().slice(0,10) };
      const list = fload<FinRevenue>(K.revenues); list.unshift(item); fpersist(K.revenues, list); return item;
    },
    update(id: string, patch: Partial<FinRevenue>): void {
      const list = fload<FinRevenue>(K.revenues).map(x => x.id === id ? { ...x, ...patch } : x);
      fpersist(K.revenues, list);
    },
    remove(id: string): void { fpersist(K.revenues, fload<FinRevenue>(K.revenues).filter(x => x.id !== id)); },
  },
  expenses: {
    all(): FinExpense[] { seedIfNeeded(); return fload<FinExpense>(K.expenses).sort((a,b) => b.date.localeCompare(a.date)); },
    add(r: Omit<FinExpense, 'id' | 'createdAt'>): FinExpense {
      const item: FinExpense = { ...r, id: newId(), createdAt: new Date().toISOString().slice(0,10) };
      const list = fload<FinExpense>(K.expenses); list.unshift(item); fpersist(K.expenses, list); return item;
    },
    update(id: string, patch: Partial<FinExpense>): void {
      const list = fload<FinExpense>(K.expenses).map(x => x.id === id ? { ...x, ...patch } : x);
      fpersist(K.expenses, list);
    },
    remove(id: string): void { fpersist(K.expenses, fload<FinExpense>(K.expenses).filter(x => x.id !== id)); },
  },
  orders: {
    all(): FinOrder[] { seedIfNeeded(); return fload<FinOrder>(K.orders).sort((a,b) => b.orderDate.localeCompare(a.orderDate)); },
    add(r: Omit<FinOrder, 'id' | 'createdAt'>): FinOrder {
      const item: FinOrder = { ...r, id: newId(), createdAt: new Date().toISOString().slice(0,10) };
      const list = fload<FinOrder>(K.orders); list.unshift(item); fpersist(K.orders, list); return item;
    },
    update(id: string, patch: Partial<FinOrder>): void {
      const list = fload<FinOrder>(K.orders).map(x => x.id === id ? { ...x, ...patch } : x);
      fpersist(K.orders, list);
    },
    remove(id: string): void { fpersist(K.orders, fload<FinOrder>(K.orders).filter(x => x.id !== id)); },
  },
  bills: {
    all(): FinBill[] { seedIfNeeded(); return fload<FinBill>(K.bills).sort((a,b) => a.dueDate.localeCompare(b.dueDate)); },
    add(r: Omit<FinBill, 'id' | 'createdAt'>): FinBill {
      const item: FinBill = { ...r, id: newId(), createdAt: new Date().toISOString().slice(0,10) };
      const list = fload<FinBill>(K.bills); list.push(item); fpersist(K.bills, list); return item;
    },
    update(id: string, patch: Partial<FinBill>): void {
      const list = fload<FinBill>(K.bills).map(x => x.id === id ? { ...x, ...patch } : x);
      fpersist(K.bills, list);
    },
    remove(id: string): void { fpersist(K.bills, fload<FinBill>(K.bills).filter(x => x.id !== id)); },
  },
  finEmployees: {
    all(): FinEmployee[] { seedIfNeeded(); return fload<FinEmployee>(K.employees); },
    byUserId(userId: string): FinEmployee | undefined { return this.all().find(e => e.userId === userId); },
    upsert(emp: FinEmployee): void {
      const list = fload<FinEmployee>(K.employees);
      const idx = list.findIndex(e => e.id === emp.id);
      if (idx >= 0) list[idx] = emp; else list.push(emp);
      fpersist(K.employees, list);
    },
  },
  payroll: {
    all(): FinPayroll[] { seedIfNeeded(); return fload<FinPayroll>(K.payroll).sort((a,b) => b.month.localeCompare(a.month) || a.name.localeCompare(b.name)); },
    byMonth(month: string): FinPayroll[] { return this.all().filter(p => p.month === month); },
    markPaid(id: string, adminName: string): void {
      const list = fload<FinPayroll>(K.payroll).map(p =>
        p.id === id ? { ...p, status: 'Pago' as const, paymentDate: new Date().toISOString().slice(0,10), paidBy: adminName } : p
      );
      fpersist(K.payroll, list);
    },
    markPending(id: string): void {
      const list = fload<FinPayroll>(K.payroll).map(p =>
        p.id === id ? { ...p, status: 'Pendente' as const, paymentDate: undefined, paidBy: undefined } : p
      );
      fpersist(K.payroll, list);
    },
    generateMonth(month: string): void {
      const employees = fload<FinEmployee>(K.employees);
      const existing = fload<FinPayroll>(K.payroll).filter(p => p.month === month);
      if (existing.length) return;
      // Import users from db
      const usersRaw = localStorage.getItem('pc_v1_users');
      const users: Array<{ id: string; name: string; jobTitle: string; status: string }> = usersRaw ? JSON.parse(usersRaw) : [];
      const newEntries: FinPayroll[] = employees.map(emp => {
        const user = users.find(u => u.id === emp.userId);
        return {
          id: newId(),
          employeeId: emp.id,
          userId: emp.userId,
          name: user?.name ?? 'Funcionário',
          jobTitle: user?.jobTitle ?? '',
          month,
          salary: emp.salary,
          vr: emp.vr,
          vt: emp.vt,
          total: emp.salary + emp.vr + emp.vt,
          status: 'Pendente',
          createdAt: new Date().toISOString().slice(0,10),
        };
      });
      const list = fload<FinPayroll>(K.payroll);
      fpersist(K.payroll, [...list, ...newEntries]);
    },
  },
  sales: {
    all(): FinSale[] { seedSalesIfNeeded(); return fload<FinSale>(K.sales).sort((a,b) => b.date.localeCompare(a.date)); },
    add(r: Omit<FinSale, 'id' | 'createdAt'>): FinSale {
      const item: FinSale = { ...r, id: newId(), createdAt: new Date().toISOString().slice(0,10) };
      const list = fload<FinSale>(K.sales); list.unshift(item); fpersist(K.sales, list); return item;
    },
    update(id: string, patch: Partial<FinSale>): void {
      fpersist(K.sales, fload<FinSale>(K.sales).map(x => x.id === id ? { ...x, ...patch } : x));
    },
    remove(id: string): void { fpersist(K.sales, fload<FinSale>(K.sales).filter(x => x.id !== id)); },
    markReceived(id: string): void {
      const today = new Date().toISOString().slice(0,10);
      fpersist(K.sales, fload<FinSale>(K.sales).map(x => x.id === id ? { ...x, status: 'Recebido' as SaleStatus, receivedDate: today } : x));
    },
  },
  taxConfig: {
    get(): TaxConfig {
      try { const r = localStorage.getItem(K.taxConfig); return r ? JSON.parse(r) : DEFAULT_TAX_CONFIG; } catch { return DEFAULT_TAX_CONFIG; }
    },
    set(cfg: TaxConfig): void { localStorage.setItem(K.taxConfig, JSON.stringify(cfg)); },
    reset(): void { localStorage.removeItem(K.taxConfig); },
  },
  logo: {
    get(): string | null { return localStorage.getItem('pc_v1_logo_b64'); },
    set(b64: string): void { localStorage.setItem('pc_v1_logo_b64', b64); },
    remove(): void { localStorage.removeItem('pc_v1_logo_b64'); },
  },
};

// Utilitários de filtragem por período
export function filterByPeriod<T extends { date?: string; orderDate?: string; dueDate?: string }>(
  items: T[],
  from: string,
  to: string,
  dateField: keyof T = 'date' as keyof T
): T[] {
  return items.filter(item => {
    const val = item[dateField] as string | undefined;
    if (!val) return true;
    return val >= from && val <= to;
  });
}

export function periodRange(period: string, customFrom?: string, customTo?: string): { from: string; to: string } {
  const today = new Date();
  const y = today.getFullYear();
  const m = today.getMonth();
  const d = today.getDate();
  const toStr = (dt: Date) => dt.toISOString().slice(0, 10);
  switch (period) {
    case 'hoje':    return { from: toStr(today), to: toStr(today) };
    case 'ontem': { const yst = new Date(y, m, d - 1); return { from: toStr(yst), to: toStr(yst) }; }
    case '7d':     return { from: toStr(new Date(y, m, d - 6)), to: toStr(today) };
    case 'mes':    return { from: `${y}-${String(m+1).padStart(2,'0')}-01`, to: toStr(today) };
    case 'mes_ant': {
      const pm = m === 0 ? 11 : m - 1;
      const py = m === 0 ? y - 1 : y;
      const lastDay = new Date(py, pm + 1, 0).getDate();
      return { from: `${py}-${String(pm+1).padStart(2,'0')}-01`, to: `${py}-${String(pm+1).padStart(2,'0')}-${String(lastDay).padStart(2,'0')}` };
    }
    case '3m':  return { from: toStr(new Date(y, m - 3,  d)), to: toStr(today) };
    case '6m':  return { from: toStr(new Date(y, m - 6,  d)), to: toStr(today) };
    case '9m':  return { from: toStr(new Date(y, m - 9,  d)), to: toStr(today) };
    case '12m': return { from: toStr(new Date(y, m - 12, d)), to: toStr(today) };
    case 'ano': return { from: `${y}-01-01`, to: toStr(today) };
    case 'tudo': return { from: '2025-06-01', to: toStr(today) };
    case 'custom': return { from: customFrom ?? '2025-06-01', to: customTo ?? toStr(today) };
    default: return { from: toStr(new Date(y, m - 3, d)), to: toStr(today) };
  }
}

export function previousPeriodRange(period: string): { from: string; to: string } {
  const today = new Date();
  const y = today.getFullYear();
  const m = today.getMonth();
  const d = today.getDate();
  const toStr = (dt: Date) => dt.toISOString().slice(0, 10);
  switch (period) {
    case 'hoje':    { const yst = new Date(y, m, d - 1); return { from: toStr(yst), to: toStr(yst) }; }
    case 'ontem':   { const d2 = new Date(y, m, d - 2); return { from: toStr(d2), to: toStr(d2) }; }
    case '7d':      return { from: toStr(new Date(y, m, d - 13)), to: toStr(new Date(y, m, d - 7)) };
    case 'mes':     return { from: toStr(new Date(y, m - 1, 1)), to: toStr(new Date(y, m, 0)) };
    case 'mes_ant': return { from: toStr(new Date(y, m - 2, 1)), to: toStr(new Date(y, m - 1, 0)) };
    case '3m':  return { from: toStr(new Date(y, m - 6,  d)), to: toStr(new Date(y, m - 3,  d - 1)) };
    case '6m':  return { from: toStr(new Date(y, m - 12, d)), to: toStr(new Date(y, m - 6,  d - 1)) };
    case '9m':  return { from: toStr(new Date(y, m - 18, d)), to: toStr(new Date(y, m - 9,  d - 1)) };
    case '12m': return { from: toStr(new Date(y, m - 24, d)), to: toStr(new Date(y, m - 12, d - 1)) };
    case 'ano': return { from: `${y-1}-01-01`, to: `${y-1}-12-31` };
    default:    return { from: '2025-01-01', to: '2025-12-31' };
  }
}

export function fmtBRL(v: number) {
  return v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

export { fmtDate };
