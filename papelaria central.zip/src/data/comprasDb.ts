import { newId } from './db';

export interface NFItem {
  productId: string;
  productName: string;
  qty: number;
  unitCost: number;
  subtotal: number;
}

export interface NotaFiscal {
  id: string;
  numero: string;
  fornecedorId: string;
  fornecedorNome: string;
  data: string;        // DD/MM/YYYY
  valorTotal: number;
  itens: NFItem[];
  responsavelId: string;
  responsavelNome: string;
  observacoes?: string;
  createdAt: string;
}

const KEY = 'pc_v1_nfs';

const SEED: NotaFiscal[] = [
  {
    id: 'nf-001',
    numero: '000142',
    fornecedorId: 'f-001',
    fornecedorNome: 'SP Paper',
    data: '05/01/2026',
    valorTotal: 487.50,
    itens: [
      { productId: 'p-001', productName: 'Caderno Universitário 10 Matérias', qty: 25, unitCost: 10.50, subtotal: 262.50 },
      { productId: 'p-004', productName: 'Borracha Branca Escolar', qty: 50, unitCost: 0.75, subtotal: 37.50 },
      { productId: 'p-008', productName: 'Tesoura Escolar 13cm', qty: 20, unitCost: 4.75, subtotal: 95.00 },
      { productId: 'p-009', productName: 'Régua 30 cm', qty: 30, unitCost: 3.08, subtotal: 92.50 },
    ],
    responsavelId: 'u-002',
    responsavelNome: 'Ana Beatriz Martins',
    observacoes: 'Entrega OK. Mercadoria conferida.',
    createdAt: '2026-01-05T10:00:00.000Z',
  },
  {
    id: 'nf-002',
    numero: '003871',
    fornecedorId: 'f-002',
    fornecedorNome: 'Nacional Escolar',
    data: '12/02/2026',
    valorTotal: 620.00,
    itens: [
      { productId: 'v2-011', productName: 'Caderno Universitário Tilibra 10 Matérias 200fls', qty: 20, unitCost: 12.00, subtotal: 240.00 },
      { productId: 'v2-028', productName: 'Caderno Escolar Brochura 40fls Tilibra', qty: 60, unitCost: 3.00, subtotal: 180.00 },
      { productId: 'v2-038', productName: 'Caderno Brochura Pequeno 48fls Foroni', qty: 50, unitCost: 2.00, subtotal: 100.00 },
      { productId: 'p-010', productName: 'Bloco de Notas A5', qty: 20, unitCost: 5.00, subtotal: 100.00 },
    ],
    responsavelId: 'u-002',
    responsavelNome: 'Ana Beatriz Martins',
    createdAt: '2026-02-12T09:30:00.000Z',
  },
  {
    id: 'nf-003',
    numero: '000589',
    fornecedorId: 'f-007',
    fornecedorNome: 'Império Canetas',
    data: '03/03/2026',
    valorTotal: 345.80,
    itens: [
      { productId: 'v2-051', productName: 'Caneta Esferográfica BIC Cristal 0,8mm Azul', qty: 100, unitCost: 0.90, subtotal: 90.00 },
      { productId: 'v2-052', productName: 'Caneta Esferográfica BIC Cristal Ponta Média Preta', qty: 80, unitCost: 0.90, subtotal: 72.00 },
      { productId: 'v2-068', productName: 'Marca-texto Stabilo Boss Original Amarelo', qty: 30, unitCost: 3.00, subtotal: 90.00 },
      { productId: 'v2-063', productName: 'Caneta Pilot G2 0.7mm Preta Gel Retrátil', qty: 20, unitCost: 4.69, subtotal: 93.80 },
    ],
    responsavelId: 'u-006',
    responsavelNome: 'Rafael Mendes Souza',
    observacoes: 'Faltou 5 unidades da Pilot G2. Ajustado na nota.',
    createdAt: '2026-03-03T14:00:00.000Z',
  },
  {
    id: 'nf-004',
    numero: '002200',
    fornecedorId: 'f-003',
    fornecedorNome: 'RJ Papéis',
    data: '18/03/2026',
    valorTotal: 798.00,
    itens: [
      { productId: 'p-006', productName: 'Papel Sulfite A4 500 folhas', qty: 10, unitCost: 17.80, subtotal: 178.00 },
      { productId: 'v2-216', productName: 'Papel Sulfite Chamex A4 75g 500fls', qty: 10, unitCost: 19.50, subtotal: 195.00 },
      { productId: 'v2-217', productName: 'Papel Sulfite Chamex A4 90g 500fls', qty: 10, unitCost: 25.00, subtotal: 250.00 },
      { productId: 'v2-218', productName: 'Papel Fotográfico Glossy A4 180g c/50', qty: 5, unitCost: 15.00, subtotal: 75.00 },
      { productId: 'v2-219', productName: 'Papel Fotográfico Fosco A4 180g c/50', qty: 5, unitCost: 20.00, subtotal: 100.00 },
    ],
    responsavelId: 'u-002',
    responsavelNome: 'Ana Beatriz Martins',
    createdAt: '2026-03-18T11:00:00.000Z',
  },
  {
    id: 'nf-005',
    numero: '007654',
    fornecedorId: 'f-005',
    fornecedorNome: 'Sul Office',
    data: '10/04/2026',
    valorTotal: 512.40,
    itens: [
      { productId: 'v2-131', productName: 'Grampeador Maped Mini Plus 24/6', qty: 10, unitCost: 14.00, subtotal: 140.00 },
      { productId: 'v2-133', productName: 'Grampo Galvanizado 26/6 c/5000un Bacchi', qty: 20, unitCost: 5.00, subtotal: 100.00 },
      { productId: 'v2-136', productName: 'Perfurador de Papel Rocama 2 Furos', qty: 10, unitCost: 10.90, subtotal: 109.00 },
      { productId: 'v2-156', productName: 'Post-it 3M 76x76mm 4 Blocos Coloridos', qty: 15, unitCost: 10.96, subtotal: 164.40 },
    ],
    responsavelId: 'u-006',
    responsavelNome: 'Rafael Mendes Souza',
    createdAt: '2026-04-10T13:30:00.000Z',
  },
  {
    id: 'nf-006',
    numero: '001133',
    fornecedorId: 'f-012',
    fornecedorNome: 'Arte & Cor',
    data: '05/05/2026',
    valorTotal: 430.60,
    itens: [
      { productId: 'v2-191', productName: 'Tinta Guache Acrilex 12 cores 15ml', qty: 10, unitCost: 16.50, subtotal: 165.00 },
      { productId: 'v2-193', productName: 'Tinta Acrílica Acrilex 60ml Branca', qty: 15, unitCost: 5.50, subtotal: 82.50 },
      { productId: 'v2-198', productName: 'Pincéis Artísticos Tigre Set 7 peças', qty: 8, unitCost: 13.90, subtotal: 111.20 },
      { productId: 'v2-204', productName: 'Carvão Vegetal Natural Faber-Castell c/6', qty: 10, unitCost: 7.19, subtotal: 71.90 },
    ],
    responsavelId: 'u-002',
    responsavelNome: 'Ana Beatriz Martins',
    observacoes: 'Material artístico para reposição de estoque.',
    createdAt: '2026-05-05T09:00:00.000Z',
  },
  {
    id: 'nf-007',
    numero: '009910',
    fornecedorId: 'f-009',
    fornecedorNome: 'Escola Total',
    data: '20/06/2026',
    valorTotal: 615.00,
    itens: [
      { productId: 'v2-101', productName: 'Cola Escolar Branca BIC 40g', qty: 50, unitCost: 2.50, subtotal: 125.00 },
      { productId: 'v2-103', productName: 'Cola Bastão Pritt 10g', qty: 40, unitCost: 3.75, subtotal: 150.00 },
      { productId: 'v2-109', productName: 'Borracha Branca Escolar Faber-Castell 40x20mm', qty: 80, unitCost: 1.00, subtotal: 80.00 },
      { productId: 'v2-121', productName: 'Apontador Faber-Castell Simples Com Depósito', qty: 60, unitCost: 2.00, subtotal: 120.00 },
      { productId: 'v2-129', productName: 'Líquido Corretor BIC Wite-Out 20ml', qty: 40, unitCost: 3.50, subtotal: 140.00 },
    ],
    responsavelId: 'u-006',
    responsavelNome: 'Rafael Mendes Souza',
    createdAt: '2026-06-20T10:00:00.000Z',
  },
  {
    id: 'nf-008',
    numero: '004477',
    fornecedorId: 'f-016',
    fornecedorNome: 'CO Brindes',
    data: '14/08/2026',
    valorTotal: 743.20,
    itens: [
      { productId: 'v3-232', productName: 'Caneca Porcelana 300ml Personalizada', qty: 20, unitCost: 10.50, subtotal: 210.00 },
      { productId: 'v3-234', productName: 'Kit Presente Escolar Tilibra Premium', qty: 10, unitCost: 27.00, subtotal: 270.00 },
      { productId: 'v3-246', productName: 'Marca-Páginas Magnético Kit 8un', qty: 30, unitCost: 6.74, subtotal: 202.20 },
      { productId: 'v3-247', productName: 'Adesivos Decorativos Kit 50un', qty: 30, unitCost: 2.04, subtotal: 61.00 },
    ],
    responsavelId: 'u-002',
    responsavelNome: 'Ana Beatriz Martins',
    observacoes: 'Itens de presentes e variedades para o período de volta às aulas.',
    createdAt: '2026-08-14T15:00:00.000Z',
  },
];

function load(): NotaFiscal[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as NotaFiscal[];
  } catch {}
  localStorage.setItem(KEY, JSON.stringify(SEED));
  return [...SEED];
}

function save(data: NotaFiscal[]): void {
  localStorage.setItem(KEY, JSON.stringify(data));
}

export const comprasDb = {
  all(): NotaFiscal[] {
    return load();
  },
  findById(id: string): NotaFiscal | undefined {
    return load().find(nf => nf.id === id);
  },
  add(nf: Omit<NotaFiscal, 'id' | 'createdAt'>): NotaFiscal {
    const list = load();
    const full: NotaFiscal = { ...nf, id: newId(), createdAt: new Date().toISOString() };
    list.unshift(full);
    save(list);
    return full;
  },
  remove(id: string): void {
    save(load().filter(nf => nf.id !== id));
  },
};
