const EMPRESA_KEY = 'pc_v1_empresa';
const EMPRESA_SEEDED = 'pc_v1_empresa_seeded';

export interface DadosEmpresa {
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  inscricaoEstadual: string;
  telefone: string;
  whatsapp: string;
  email: string;
  cep: string;
  endereco: string;
  numero: string;
  bairro: string;
  cidade: string;
  estado: string;
  horarioFuncionamento?: string;
  redesSociais?: {
    instagram?: string;
    facebook?: string;
    website?: string;
  };
}

const DEFAULT: DadosEmpresa = {
  razaoSocial: 'Papelaria Central Comércio de Materiais Ltda.',
  nomeFantasia: 'Papelaria Central',
  cnpj: '12.345.678/0001-99',
  inscricaoEstadual: '111.222.333.444',
  telefone: '(11) 3421-8800',
  whatsapp: '(11) 98765-4321',
  email: 'contato@papelariacentral.com.br',
  cep: '01310-100',
  endereco: 'Av. Paulista',
  numero: '1578',
  bairro: 'Bela Vista',
  cidade: 'São Paulo',
  estado: 'SP',
  horarioFuncionamento: 'Segunda a Sexta: 8h–18h | Sábado: 8h–13h | Domingo: Fechado',
  redesSociais: {
    instagram: '@papelariacentral',
    facebook: 'papelariacentral',
    website: 'www.papelariacentral.com.br',
  },
};

function seed(): void {
  if (localStorage.getItem(EMPRESA_SEEDED)) return;
  localStorage.setItem(EMPRESA_KEY, JSON.stringify(DEFAULT));
  localStorage.setItem(EMPRESA_SEEDED, '1');
}

seed();

export const empresaDb = {
  get(): DadosEmpresa {
    try {
      const raw = localStorage.getItem(EMPRESA_KEY);
      if (raw) return JSON.parse(raw) as DadosEmpresa;
    } catch {
      // fall through
    }
    return { ...DEFAULT };
  },

  set(data: DadosEmpresa): void {
    localStorage.setItem(EMPRESA_KEY, JSON.stringify(data));
  },
};
