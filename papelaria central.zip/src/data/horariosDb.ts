export type DiaSemana = 'segunda' | 'terca' | 'quarta' | 'quinta' | 'sexta' | 'sabado' | 'domingo';

export interface HorarioDia {
  aberto: boolean;
  abertura: string;   // HH:MM
  fechamento: string; // HH:MM
}

export type HorarioFuncionamento = Record<DiaSemana, HorarioDia>;

const HORARIO_KEY = 'pc_v1_horarios';

export const HORARIO_DEFAULT: HorarioFuncionamento = {
  segunda: { aberto: true,  abertura: '08:00', fechamento: '18:00' },
  terca:   { aberto: true,  abertura: '08:00', fechamento: '18:00' },
  quarta:  { aberto: true,  abertura: '08:00', fechamento: '18:00' },
  quinta:  { aberto: true,  abertura: '08:00', fechamento: '18:00' },
  sexta:   { aberto: true,  abertura: '08:00', fechamento: '18:00' },
  sabado:  { aberto: true,  abertura: '08:00', fechamento: '13:00' },
  domingo: { aberto: false, abertura: '09:00', fechamento: '12:00' },
};

export const DIAS_LABELS: Record<DiaSemana, string> = {
  segunda: 'Segunda-feira',
  terca:   'Terça-feira',
  quarta:  'Quarta-feira',
  quinta:  'Quinta-feira',
  sexta:   'Sexta-feira',
  sabado:  'Sábado',
  domingo: 'Domingo',
};

export const DIAS_ORDER: DiaSemana[] = ['segunda', 'terca', 'quarta', 'quinta', 'sexta', 'sabado', 'domingo'];

// JS getDay() → DiaSemana
const JS_DOW: Record<number, DiaSemana> = {
  0: 'domingo', 1: 'segunda', 2: 'terca', 3: 'quarta', 4: 'quinta', 5: 'sexta', 6: 'sabado',
};

export const horariosDb = {
  get(): HorarioFuncionamento {
    try {
      const raw = localStorage.getItem(HORARIO_KEY);
      if (raw) return { ...HORARIO_DEFAULT, ...JSON.parse(raw) };
    } catch {}
    return { ...HORARIO_DEFAULT };
  },

  set(h: HorarioFuncionamento): void {
    localStorage.setItem(HORARIO_KEY, JSON.stringify(h));
  },

  isAberta(): { aberta: boolean; abertura: string; fechamento: string; dia: DiaSemana } {
    const now = new Date();
    const dia = JS_DOW[now.getDay()];
    const h = this.get()[dia];
    if (!h.aberto) return { aberta: false, abertura: h.abertura, fechamento: h.fechamento, dia };
    const nowMin = now.getHours() * 60 + now.getMinutes();
    const [ah, am] = h.abertura.split(':').map(Number);
    const [fh, fm] = h.fechamento.split(':').map(Number);
    return {
      aberta: nowMin >= ah * 60 + am && nowMin < fh * 60 + fm,
      abertura: h.abertura,
      fechamento: h.fechamento,
      dia,
    };
  },
};
