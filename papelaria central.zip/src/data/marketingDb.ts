import { newId } from './db';

export type MarketingCanal = 'Instagram' | 'Facebook/Meta Ads' | 'Google Ads' | 'WhatsApp' | 'Panfletagem' | 'Outros';

export interface MarketingGasto {
  id: string;
  canal: MarketingCanal;
  campanha: string;
  valor: number;
  date: string;
  responsavel: string;
  observacao?: string;
  createdAt: string;
}

export interface MarketingBudget {
  verbaMensal: number;
  verbaReservada: number;
  gastos: MarketingGasto[];
}

const KEY = 'pc_v1_marketing';

function seed(): MarketingBudget {
  return {
    verbaMensal: 2000,
    verbaReservada: 500,
    gastos: [
      { id: newId(), canal: 'Instagram', campanha: 'Volta às aulas — agosto/2025', valor: 350, date: '2025-08-01', responsavel: 'Administrador', observacao: 'Impulsionamento de posts', createdAt: '2025-08-01T09:00:00.000Z' },
      { id: newId(), canal: 'Facebook/Meta Ads', campanha: 'Promoção material escolar', valor: 280, date: '2025-08-15', responsavel: 'Administrador', createdAt: '2025-08-15T10:00:00.000Z' },
      { id: newId(), canal: 'Google Ads', campanha: 'Busca — papelaria SP', valor: 420, date: '2025-09-01', responsavel: 'Administrador', createdAt: '2025-09-01T09:00:00.000Z' },
      { id: newId(), canal: 'Instagram', campanha: 'Dia das Crianças', valor: 300, date: '2025-10-01', responsavel: 'Administrador', createdAt: '2025-10-01T09:00:00.000Z' },
      { id: newId(), canal: 'Facebook/Meta Ads', campanha: 'Black Friday papelaria', valor: 500, date: '2025-11-01', responsavel: 'Administrador', createdAt: '2025-11-01T09:00:00.000Z' },
      { id: newId(), canal: 'Instagram', campanha: 'Natal e Ano Novo', valor: 400, date: '2025-12-01', responsavel: 'Administrador', createdAt: '2025-12-01T09:00:00.000Z' },
      { id: newId(), canal: 'Google Ads', campanha: 'Volta às aulas — jan/2026', valor: 600, date: '2026-01-05', responsavel: 'Administrador', createdAt: '2026-01-05T09:00:00.000Z' },
      { id: newId(), canal: 'Instagram', campanha: 'Promoção canetas Faber-Castell', valor: 180, date: '2026-03-10', responsavel: 'Administrador', createdAt: '2026-03-10T10:00:00.000Z' },
      { id: newId(), canal: 'Facebook/Meta Ads', campanha: 'Pascoa criativa — artesanato', valor: 250, date: '2026-04-01', responsavel: 'Administrador', createdAt: '2026-04-01T09:00:00.000Z' },
      { id: newId(), canal: 'Google Ads', campanha: 'Dia dos professores', valor: 350, date: '2026-10-10', responsavel: 'Administrador', createdAt: '2026-10-10T09:00:00.000Z' },
    ],
  };
}

export const marketingDb = {
  get(): MarketingBudget {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) return JSON.parse(raw) as MarketingBudget;
    } catch {}
    const s = seed();
    localStorage.setItem(KEY, JSON.stringify(s));
    return s;
  },
  set(budget: MarketingBudget): void {
    localStorage.setItem(KEY, JSON.stringify(budget));
  },
  addGasto(g: Omit<MarketingGasto, 'id' | 'createdAt'>): MarketingBudget {
    const budget = this.get();
    const gasto: MarketingGasto = { ...g, id: newId(), createdAt: new Date().toISOString() };
    budget.gastos = [...budget.gastos, gasto];
    this.set(budget);
    return budget;
  },
  removeGasto(id: string): void {
    const budget = this.get();
    budget.gastos = budget.gastos.filter(g => g.id !== id);
    this.set(budget);
  },
  totalGastoCanal(canal: MarketingCanal): number {
    return this.get().gastos.filter(g => g.canal === canal).reduce((s, g) => s + g.valor, 0);
  },
};
