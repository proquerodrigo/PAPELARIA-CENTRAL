const AUDIT_KEY = 'pc_v1_audit';
const AUDIT_SEEDED = 'pc_v1_audit_seeded';

export type AuditModule =
  | 'Produtos'
  | 'Estoque'
  | 'Clientes'
  | 'Funcionários'
  | 'Financeiro'
  | 'Caixa'
  | 'Pedidos'
  | 'Fornecedores'
  | 'Sistema'
  | 'Usuários';

export interface AuditEntry {
  id: string;
  action: string;
  target: string;
  userId: string;
  userName: string;
  date: string;      // 'DD/MM/YYYY'
  time: string;      // 'HH:mm'
  createdAt: string; // ISO string
  module: AuditModule;
  details?: string;
}

function formatDate(d: Date): string {
  return `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
}

function formatTime(d: Date): string {
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function daysAgo(n: number, hour = 9, min = 0): Date {
  const d = new Date();
  d.setDate(d.getDate() - n);
  d.setHours(hour, min, 0, 0);
  return d;
}

const SEED_ENTRIES: Omit<AuditEntry, 'id' | 'date' | 'time'>[] = [
  // July 2026 (~60 days ago)
  { action: 'Produto adicionado', target: 'Caneta BIC Cristal Azul cx/50', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(61, 9, 12).toISOString(), module: 'Produtos', details: 'SKU: CAN-BIC-AZ50 | Preço: R$ 28,90' },
  { action: 'Estoque ajustado', target: 'Papel Sulfite A4 500fls', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(60, 10, 5).toISOString(), module: 'Estoque', details: 'Qtde anterior: 12 → Nova: 48 (reposição)' },
  { action: 'Cliente cadastrado', target: 'Escola Municipal Jardim das Flores', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(59, 11, 30).toISOString(), module: 'Clientes', details: 'CNPJ: 45.123.456/0001-22' },
  { action: 'Caixa aberto', target: 'Caixa Principal', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(58, 8, 0).toISOString(), module: 'Caixa', details: 'Troco inicial: R$ 200,00' },
  { action: 'Venda registrada', target: 'Pedido #0071', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(58, 14, 22).toISOString(), module: 'Pedidos', details: 'Total: R$ 154,70 | Cliente: Escritório Primavera' },
  { action: 'Caixa fechado', target: 'Caixa Principal', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(58, 18, 5).toISOString(), module: 'Caixa', details: 'Total do dia: R$ 1.234,50 | Sangria: R$ 500,00' },
  { action: 'Fornecedor cadastrado', target: 'Distribuidora Papelfix Ltda.', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(57, 9, 45).toISOString(), module: 'Fornecedores', details: 'CNPJ: 78.901.234/0001-55 | Tel: (11) 3456-7890' },
  { action: 'Produto editado', target: 'Lápis Faber-Castell 6B cx/12', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(56, 10, 20).toISOString(), module: 'Produtos', details: 'Preço atualizado: R$ 18,50 → R$ 21,00' },
  { action: 'Estoque ajustado', target: 'Borracha Branca Faber-Castell', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(55, 11, 0).toISOString(), module: 'Estoque', details: 'Perda por vencimento: -5 un' },
  { action: 'Despesa lançada', target: 'Conta de energia elétrica', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(54, 8, 50).toISOString(), module: 'Financeiro', details: 'Vencimento: 10/08/2026 | Valor: R$ 487,30' },
  // August 2026 (~30 days ago)
  { action: 'Funcionário cadastrado', target: 'Pedro A. Lima', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(50, 9, 0).toISOString(), module: 'Funcionários', details: 'Cargo: Atendente | Admissão: 01/08/2026' },
  { action: 'Usuário criado', target: 'pedro.lima@papelcentral.com.br', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(50, 9, 5).toISOString(), module: 'Usuários', details: 'Perfil: Funcionário' },
  { action: 'Pedido cancelado', target: 'Pedido #0083', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(48, 15, 10).toISOString(), module: 'Pedidos', details: 'Motivo: Cliente desistiu | Valor estornado: R$ 89,00' },
  { action: 'Caixa aberto', target: 'Caixa Principal', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(46, 8, 2).toISOString(), module: 'Caixa', details: 'Troco inicial: R$ 200,00' },
  { action: 'Venda registrada', target: 'Pedido #0091', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(46, 10, 55).toISOString(), module: 'Pedidos', details: 'Total: R$ 342,00 | Cliente: Colégio São Bento' },
  { action: 'Produto adicionado', target: 'Caderno Universitário 200fls 10 matérias', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(45, 11, 30).toISOString(), module: 'Produtos', details: 'SKU: CAD-UNIV-10M | Preço: R$ 39,90' },
  { action: 'Estoque recebido', target: 'Caneta Gel Pilot G2 0.7mm', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(44, 14, 0).toISOString(), module: 'Estoque', details: 'Nota fiscal NF-e 003421 | +120 un | Fornecedor: Papelfix' },
  { action: 'Receita lançada', target: 'Venda balcão – agosto', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(42, 9, 30).toISOString(), module: 'Financeiro', details: 'Valor: R$ 8.750,00' },
  { action: 'Cliente editado', target: 'Escritório Primavera EIRELI', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(40, 16, 45).toISOString(), module: 'Clientes', details: 'Telefone atualizado' },
  { action: 'Produto desativado', target: 'Tinta para impressora HP 664 preta', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(38, 10, 0).toISOString(), module: 'Produtos', details: 'Motivo: descontinuado pelo fornecedor' },
  // September 2026 (last ~28 days)
  { action: 'Caixa aberto', target: 'Caixa Principal', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(28, 8, 1).toISOString(), module: 'Caixa', details: 'Troco inicial: R$ 200,00' },
  { action: 'Venda registrada', target: 'Pedido #0112', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(28, 9, 14).toISOString(), module: 'Pedidos', details: 'Total: R$ 76,50 | Cliente: Pessoa física – CPF 123' },
  { action: 'Estoque ajustado', target: 'Papel Kraft 80g Rolo 50m', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(25, 11, 0).toISOString(), module: 'Estoque', details: 'Contagem manual: 8 → 6 (2 un danificadas)' },
  { action: 'Funcionário editado', target: 'Pedro A. Lima', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(22, 10, 15).toISOString(), module: 'Funcionários', details: 'Salário atualizado após período de experiência' },
  { action: 'Pedido gerado', target: 'Pedido #0120', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(20, 14, 40).toISOString(), module: 'Pedidos', details: 'Total: R$ 1.280,00 | Cliente: Prefeitura Municipal' },
  { action: 'Despesa lançada', target: 'Aluguel – Setembro/2026', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(18, 8, 30).toISOString(), module: 'Financeiro', details: 'Vencimento: 05/10/2026 | Valor: R$ 3.200,00' },
  { action: 'Produto adicionado', target: 'Fichário A4 4 argolas 50mm', userId: 'u2', userName: 'Lucas H. Almeida', createdAt: daysAgo(15, 11, 20).toISOString(), module: 'Produtos', details: 'SKU: FIC-A4-4AR50 | Preço: R$ 49,90' },
  { action: 'Backup exportado', target: 'Dados do sistema', userId: 'u1', userName: 'Ana B. Martins', createdAt: daysAgo(10, 8, 5).toISOString(), module: 'Sistema', details: 'Backup completo gerado manualmente' },
  { action: 'Estoque recebido', target: 'Caneta BIC Cristal Azul cx/50', userId: 'u3', userName: 'Camila F. Rocha', createdAt: daysAgo(7, 13, 30).toISOString(), module: 'Estoque', details: 'NF-e 003498 | +10 cx | Fornecedor: Papelfix' },
  { action: 'Venda registrada', target: 'Pedido #0135', userId: 'u4', userName: 'Rafael M. Souza', createdAt: daysAgo(2, 15, 50).toISOString(), module: 'Pedidos', details: 'Total: R$ 218,40 | Cliente: Escola Municipal Jardim das Flores' },
];

function makeid(): string {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

function load(): AuditEntry[] {
  try {
    return JSON.parse(localStorage.getItem(AUDIT_KEY) || '[]');
  } catch {
    return [];
  }
}

function save(entries: AuditEntry[]): void {
  localStorage.setItem(AUDIT_KEY, JSON.stringify(entries));
}

function seed(): void {
  if (localStorage.getItem(AUDIT_SEEDED)) return;
  const entries: AuditEntry[] = SEED_ENTRIES.map(e => {
    const d = new Date(e.createdAt);
    return {
      ...e,
      id: makeid(),
      date: formatDate(d),
      time: formatTime(d),
    };
  });
  entries.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  save(entries);
  localStorage.setItem(AUDIT_SEEDED, '1');
}

seed();

export const auditDb = {
  all(): AuditEntry[] {
    return load();
  },

  recent(n = 50): AuditEntry[] {
    const all = load();
    return all.slice(-n).reverse();
  },

  add(entry: Omit<AuditEntry, 'id' | 'date' | 'time' | 'createdAt'>): void {
    const all = load();
    const now = new Date();
    all.push({
      ...entry,
      id: makeid(),
      date: formatDate(now),
      time: formatTime(now),
      createdAt: now.toISOString(),
    });
    save(all);
  },

  byModule(module: string): AuditEntry[] {
    return load().filter(e => e.module === module);
  },

  clear(): void {
    save([]);
    localStorage.removeItem(AUDIT_SEEDED);
  },
};
