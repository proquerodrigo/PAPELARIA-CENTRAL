export type CaixaStatus = 'aberto' | 'fechado';
export type LancTipo = 'suprimento' | 'venda' | 'sangria' | 'retirada' | 'despesa';

export interface CaixaSessao {
  id: string;
  data: string;               // YYYY-MM-DD
  horaAbertura: string;       // HH:MM
  horaFechamento?: string;
  responsavelId: string;
  responsavelNome: string;
  valorInicial: number;
  // totais acumulados durante o dia
  totalDinheiro: number;
  totalPix: number;
  totalDebito: number;
  totalCredito: number;
  totalBoleto: number;
  totalTransferencia: number;
  totalEntradas: number;
  totalSangrias: number;
  // fechamento
  valorEsperado: number;
  valorInformado: number;
  diferenca: number;
  observacoesFechamento: string;
  status: CaixaStatus;
  createdAt: string;
}

export interface CaixaLancamento {
  id: string;
  sessaoId: string;
  tipo: LancTipo;
  descricao: string;
  valor: number;
  formaPagamento: string;
  responsavelId: string;
  responsavelNome: string;
  hora: string; // HH:MM
  createdAt: string;
}

const K = {
  sessoes: 'pc_v1_caixa_sessoes',
  lancamentos: 'pc_v1_caixa_lanc',
  seeded: 'pc_v1_caixa_seeded',
};

let _ctr = 1;
function newId(): string { return `cx-${Date.now()}-${(_ctr++).toString(36)}`; }
function load<T>(key: string, def: T[]): T[] {
  try { const r = localStorage.getItem(key); if (r !== null) return JSON.parse(r) as T[]; } catch {}
  localStorage.setItem(key, JSON.stringify(def));
  return [...def];
}
function persist(key: string, data: unknown[]): void { localStorage.setItem(key, JSON.stringify(data)); }
function padT(n: number): string { return String(n).padStart(2, '0'); }

// ── Deterministic seed ────────────────────────────────────────────────────────

function buildSeed(): { sessoes: CaixaSessao[]; lancamentos: CaixaLancamento[] } {
  const sessoes: CaixaSessao[] = [];
  const lancamentos: CaixaLancamento[] = [];

  function addMonth(year: number, month: number, days: number) {
    for (let d = 1; d <= days; d++) {
      const dt = `${year}-${padT(month)}-${padT(d)}`;
      const dow = new Date(dt).getDay();
      if (dow === 0) continue; // closed Sunday

      const isWeekend = dow === 6;
      // Deterministic amounts based on day index
      const x = d * 7 + month * 3;
      const din = isWeekend ? 180 + (x % 120) : 280 + (x % 400);
      const pix = isWeekend ? 230 + (x % 150) : 540 + (x % 550);
      const deb = isWeekend ? 110 + (x % 100) : 220 + (x % 320);
      const cre = isWeekend ? 80  + (x % 120) : 190 + (x % 380);
      const totalEntradas = din + pix + deb + cre;
      const sangria = Math.floor(totalEntradas * 0.35);
      const valorInicial = 200;
      const valorEsperado = valorInicial + totalEntradas - sangria;
      // Small difference for some days to make it realistic
      const diff = (x % 17 === 0) ? -2 : (x % 23 === 0) ? 3 : 0;

      const sessId = `cx-${dt}`;
      sessoes.push({
        id: sessId, data: dt,
        horaAbertura: '08:05',
        horaFechamento: isWeekend ? '13:20' : '18:15',
        responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
        valorInicial,
        totalDinheiro: din, totalPix: pix, totalDebito: deb,
        totalCredito: cre, totalBoleto: 0, totalTransferencia: 0,
        totalEntradas, totalSangrias: sangria,
        valorEsperado, valorInformado: valorEsperado + diff, diferenca: diff,
        observacoesFechamento: diff !== 0 ? 'Pequena diferença – conferir troco.' : '',
        status: 'fechado', createdAt: `${dt}T08:05:00.000Z`,
      });

      lancamentos.push({
        id: `lc-${dt}-sup`, sessaoId: sessId, tipo: 'suprimento',
        descricao: 'Abertura de caixa – fundo de troco',
        valor: valorInicial, formaPagamento: 'Dinheiro',
        responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
        hora: '08:05', createdAt: `${dt}T08:05:00.000Z`,
      });

      if (sangria > 0) {
        lancamentos.push({
          id: `lc-${dt}-san`, sessaoId: sessId, tipo: 'sangria',
          descricao: 'Sangria para cofre – meio do dia',
          valor: sangria, formaPagamento: 'Dinheiro',
          responsavelId: 'u-002', responsavelNome: 'Ana Beatriz Martins',
          hora: '12:30', createdAt: `${dt}T12:30:00.000Z`,
        });
      }
    }
  }

  addMonth(2026, 7, 31); // July
  addMonth(2026, 8, 31); // August
  addMonth(2026, 9, 27); // Sep 1-27 (today=28 not yet opened)

  return { sessoes, lancamentos };
}

export function newCaixaId(): string { return newId(); }

export const caixaDb = {
  sessoes: {
    all(): CaixaSessao[] {
      if (!localStorage.getItem(K.seeded)) {
        const { sessoes, lancamentos } = buildSeed();
        localStorage.setItem(K.sessoes, JSON.stringify(sessoes));
        localStorage.setItem(K.lancamentos, JSON.stringify(lancamentos));
        localStorage.setItem(K.seeded, '1');
        return sessoes;
      }
      return load<CaixaSessao>(K.sessoes, []);
    },
    byDate(date: string): CaixaSessao | undefined { return this.all().find(s => s.data === date); },
    aberta(): CaixaSessao | undefined { return this.all().find(s => s.status === 'aberto'); },
    add(s: CaixaSessao): void { const l = this.all(); l.push(s); persist(K.sessoes, l); },
    update(id: string, patch: Partial<CaixaSessao>): void {
      persist(K.sessoes, this.all().map(s => s.id === id ? { ...s, ...patch } : s));
    },
  },

  lancamentos: {
    all(): CaixaLancamento[] {
      // Ensure sessoes are seeded first (which also seeds lancamentos)
      caixaDb.sessoes.all();
      return load<CaixaLancamento>(K.lancamentos, []);
    },
    bySessao(sessaoId: string): CaixaLancamento[] {
      return this.all().filter(l => l.sessaoId === sessaoId);
    },
    add(l: CaixaLancamento): void { const list = this.all(); list.push(l); persist(K.lancamentos, list); },
  },
};
