export type OcorrenciaTipo =
  | 'falta' | 'falta_justificada' | 'atraso' | 'saida_antecipada'
  | 'folga' | 'ferias' | 'atestado';

export type PontoStatus = 'presente' | 'ausente' | 'folga' | 'ferias' | 'atestado';
export type DecimoStatus = 'pendente' | 'parcial' | 'pago';

export interface PontoRegistro {
  id: string;
  userId: string;
  userName: string;
  date: string;            // YYYY-MM-DD
  entrada?: string;        // HH:MM
  saidaAlmoco?: string;
  retornoAlmoco?: string;
  saida?: string;
  horasPrevistas: number;
  horasTrabalhadas: number;
  horasExtras: number;
  atrasoMin: number;
  saidaAntecMin: number;
  status: PontoStatus;
  observacoes: string;
  editadoPor?: string;
  createdAt: string;
}

export interface Ocorrencia {
  id: string;
  userId: string;
  userName: string;
  date: string;
  tipo: OcorrenciaTipo;
  horas: number;
  observacao: string;
  registradoPor: string;
  statusOc: 'pendente' | 'aprovado' | 'rejeitado';
  createdAt: string;
}

export interface DecimoTerceiro {
  id: string;
  userId: string;
  userName: string;
  ano: number;
  salarioBase: number;
  avos: number;
  valorTotal: number;
  parcela1: number;
  dataParcela1: string;
  parcela1Paga: boolean;
  parcela2: number;
  dataParcela2: string;
  parcela2Paga: boolean;
  status: DecimoStatus;
  observacoes: string;
  createdAt: string;
}

const K = {
  ponto: 'pc_v1_ponto',
  pontoSeeded: 'pc_v1_ponto_seeded',
  ocorrencias: 'pc_v1_ocorrencias',
  ocSeeded: 'pc_v1_oc_seeded',
  decimo: 'pc_v1_decimo',
  decimoSeeded: 'pc_v1_decimo_seeded',
};

let _ctr = 1;
function newId(): string { return `pt-${Date.now()}-${(_ctr++).toString(36)}`; }
function load<T>(key: string, def: T[]): T[] {
  try { const r = localStorage.getItem(key); if (r !== null) return JSON.parse(r) as T[]; } catch {}
  localStorage.setItem(key, JSON.stringify(def));
  return [...def];
}
function persist(key: string, data: unknown[]): void { localStorage.setItem(key, JSON.stringify(data)); }

// ── Seed helpers ─────────────────────────────────────────────────────────────

const PONTO_USERS = [
  { id: 'u-002', name: 'Ana Beatriz Martins',      salary: 3500, sat: true  },
  { id: 'u-003', name: 'Lucas Henrique Almeida',   salary: 2200, sat: false },
  { id: 'u-004', name: 'Camila Fernandes Rocha',   salary: 2000, sat: true  },
  { id: 'u-007', name: 'Juliana Carvalho Mendes',  salary: 1980, sat: false },
  { id: 'u-008', name: 'Pedro Henrique Nascimento',salary: 2100, sat: false },
];

function padT(n: number): string { return String(n).padStart(2, '0'); }
function toMin(t: string): number { const [h, m] = t.split(':').map(Number); return h * 60 + m; }
function fromMin(m: number): string { return `${padT(Math.floor(m / 60))}:${padT(m % 60)}`; }

function mkPonto(
  uid: string, uname: string, date: string,
  ent: string, salmoc: string, ret: string, sai: string,
  obs = '',
): PontoRegistro {
  const trabMin = Math.max(0, (toMin(sai) - toMin(ent)) - (toMin(ret) - toMin(salmoc)));
  const extMin  = Math.max(0, trabMin - 8 * 60);
  const atrMin  = toMin(ent) > toMin('08:15') ? toMin(ent) - toMin('08:00') : 0;
  const antMin  = toMin(sai) < toMin('17:45') ? toMin('18:00') - toMin(sai) : 0;
  return {
    id: newId(), userId: uid, userName: uname, date,
    entrada: ent, saidaAlmoco: salmoc, retornoAlmoco: ret, saida: sai,
    horasPrevistas: 8,
    horasTrabalhadas: Math.round((trabMin / 60) * 100) / 100,
    horasExtras: Math.round((extMin / 60) * 100) / 100,
    atrasoMin: atrMin, saidaAntecMin: antMin,
    status: 'presente', observacoes: obs, createdAt: `${date}T${ent}:00.000Z`,
  };
}

function mkFolga(uid: string, uname: string, date: string): PontoRegistro {
  return {
    id: newId(), userId: uid, userName: uname, date,
    horasPrevistas: 0, horasTrabalhadas: 0, horasExtras: 0,
    atrasoMin: 0, saidaAntecMin: 0,
    status: 'folga', observacoes: 'Folga compensatória', createdAt: `${date}T12:00:00.000Z`,
  };
}

function mkAusente(uid: string, uname: string, date: string, obs = 'Ausência não justificada'): PontoRegistro {
  return {
    id: newId(), userId: uid, userName: uname, date,
    horasPrevistas: 8, horasTrabalhadas: 0, horasExtras: 0,
    atrasoMin: 0, saidaAntecMin: 0,
    status: 'ausente', observacoes: obs, createdAt: `${date}T08:00:00.000Z`,
  };
}

// Entry variations (deterministic by userId index + day)
const ENT_VARS = ['08:00','08:03','08:07','08:12','08:00','08:05','08:18','08:02','08:00','08:08'];
const SAI_VARS = ['18:05','18:10','18:02','18:20','17:50','18:08','18:00','18:15','18:30','18:05'];

function buildSeedPonto(): PontoRegistro[] {
  const records: PontoRegistro[] = [];

  function addDays(year: number, month: number, days: number) {
    for (let d = 1; d <= days; d++) {
      const dt = `${year}-${padT(month)}-${padT(d)}`;
      const dow = new Date(dt).getDay(); // 0=Sun,6=Sat
      const isWeekday = dow >= 1 && dow <= 5;
      const isSat = dow === 6;
      if (!isWeekday && !isSat) continue;

      PONTO_USERS.forEach((u, ui) => {
        const hash = (ui + d) % 10;
        if (isSat) {
          if (!u.sat) return; // only Ana/Camila work Saturdays
          records.push(mkPonto(u.id, u.name, dt, '08:05', '12:00', '13:00', '13:10'));
          return;
        }
        // Weekday
        if (hash === 2 && ui === 2) { records.push(mkFolga(u.id, u.name, dt)); return; }
        if (hash === 7 && ui === 3) { records.push(mkAusente(u.id, u.name, dt)); return; }
        const ent = ENT_VARS[hash];
        const sai = SAI_VARS[hash];
        records.push(mkPonto(u.id, u.name, dt, ent, '12:00', '13:00', sai));
      });
    }
  }

  addDays(2026, 7, 31);  // July
  addDays(2026, 8, 31);  // August
  addDays(2026, 9, 27);  // Sep 1-27 (today=28 not seeded—punched live)
  return records;
}

// ── Seed Décimo Terceiro 2026 ─────────────────────────────────────────────────

const SEED_DECIMO: DecimoTerceiro[] = PONTO_USERS.map((u, i) => {
  const avos = 9; // Jan–Sep 2026
  const valorTotal = Math.round(u.salary * avos / 12 * 100) / 100;
  const p1 = Math.round(valorTotal / 2 * 100) / 100;
  return {
    id: `dec-${u.id}`,
    userId: u.id, userName: u.name,
    ano: 2026, salarioBase: u.salary, avos, valorTotal,
    parcela1: p1, dataParcela1: '2026-11-30', parcela1Paga: false,
    parcela2: valorTotal - p1, dataParcela2: '2026-12-20', parcela2Paga: false,
    status: 'pendente', observacoes: '',
    createdAt: '2026-01-01T00:00:00.000Z',
  };
});

const SEED_OCORRENCIAS: Ocorrencia[] = [
  {
    id: 'oc-001', userId: 'u-003', userName: 'Lucas Henrique Almeida',
    date: '2026-09-10', tipo: 'atestado', horas: 8,
    observacao: 'Consulta médica – CID J00 (resfriado)', registradoPor: 'Ana Beatriz Martins',
    statusOc: 'aprovado', createdAt: '2026-09-10T08:00:00.000Z',
  },
  {
    id: 'oc-002', userId: 'u-007', userName: 'Juliana Carvalho Mendes',
    date: '2026-08-20', tipo: 'saida_antecipada', horas: 4,
    observacao: 'Saída antecipada – consulta odontológica', registradoPor: 'Ana Beatriz Martins',
    statusOc: 'aprovado', createdAt: '2026-08-20T14:00:00.000Z',
  },
  {
    id: 'oc-003', userId: 'u-008', userName: 'Pedro Henrique Nascimento',
    date: '2026-09-05', tipo: 'atraso', horas: 1,
    observacao: 'Atraso – falha no transporte coletivo', registradoPor: 'Ana Beatriz Martins',
    statusOc: 'aprovado', createdAt: '2026-09-05T09:00:00.000Z',
  },
  {
    id: 'oc-004', userId: 'u-004', userName: 'Camila Fernandes Rocha',
    date: '2026-08-14', tipo: 'falta_justificada', horas: 8,
    observacao: 'Falta justificada – acompanhamento familiar ao médico', registradoPor: 'Ana Beatriz Martins',
    statusOc: 'aprovado', createdAt: '2026-08-14T08:00:00.000Z',
  },
  {
    id: 'oc-005', userId: 'u-002', userName: 'Ana Beatriz Martins',
    date: '2026-09-22', tipo: 'folga', horas: 8,
    observacao: 'Folga compensatória acumulada', registradoPor: 'Administrador',
    statusOc: 'aprovado', createdAt: '2026-09-22T08:00:00.000Z',
  },
];

// ── DB interface ─────────────────────────────────────────────────────────────

export function newPontoId(): string { return newId(); }

export const pontoDb = {
  registros: {
    all(): PontoRegistro[] {
      if (!localStorage.getItem(K.pontoSeeded)) {
        const seed = buildSeedPonto();
        localStorage.setItem(K.ponto, JSON.stringify(seed));
        localStorage.setItem(K.pontoSeeded, '1');
        return seed;
      }
      return load<PontoRegistro>(K.ponto, []);
    },
    byUser(userId: string): PontoRegistro[] { return this.all().filter(r => r.userId === userId); },
    byDate(date: string): PontoRegistro[] { return this.all().filter(r => r.date === date); },
    byUserDate(userId: string, date: string): PontoRegistro | undefined {
      return this.all().find(r => r.userId === userId && r.date === date);
    },
    add(r: PontoRegistro): void { const l = this.all(); l.push(r); persist(K.ponto, l); },
    update(id: string, patch: Partial<PontoRegistro>): void {
      persist(K.ponto, this.all().map(r => r.id === id ? { ...r, ...patch } : r));
    },
    remove(id: string): void { persist(K.ponto, this.all().filter(r => r.id !== id)); },
  },

  ocorrencias: {
    all(): Ocorrencia[] {
      if (!localStorage.getItem(K.ocSeeded)) {
        localStorage.setItem(K.ocorrencias, JSON.stringify(SEED_OCORRENCIAS));
        localStorage.setItem(K.ocSeeded, '1');
        return SEED_OCORRENCIAS;
      }
      return load<Ocorrencia>(K.ocorrencias, []);
    },
    add(o: Ocorrencia): void { const l = this.all(); l.push(o); persist(K.ocorrencias, l); },
    update(id: string, patch: Partial<Ocorrencia>): void {
      persist(K.ocorrencias, this.all().map(o => o.id === id ? { ...o, ...patch } : o));
    },
    remove(id: string): void { persist(K.ocorrencias, this.all().filter(o => o.id !== id)); },
  },

  decimo: {
    all(): DecimoTerceiro[] {
      if (!localStorage.getItem(K.decimoSeeded)) {
        localStorage.setItem(K.decimo, JSON.stringify(SEED_DECIMO));
        localStorage.setItem(K.decimoSeeded, '1');
        return SEED_DECIMO;
      }
      return load<DecimoTerceiro>(K.decimo, []);
    },
    update(id: string, patch: Partial<DecimoTerceiro>): void {
      const l = this.all().map(d => {
        if (d.id !== id) return d;
        const updated = { ...d, ...patch };
        // Auto-compute status
        if (updated.parcela1Paga && updated.parcela2Paga) updated.status = 'pago';
        else if (updated.parcela1Paga || updated.parcela2Paga) updated.status = 'parcial';
        else updated.status = 'pendente';
        return updated;
      });
      persist(K.decimo, l);
    },
  },

  // helper: for a date, returns all PONTO_USERS with their record (or undefined)
  todayMap(date: string): Array<{ user: typeof PONTO_USERS[0]; registro: PontoRegistro | undefined }> {
    const records = this.registros.byDate(date);
    return PONTO_USERS.map(u => ({ user: u, registro: records.find(r => r.userId === u.id) }));
  },

  users: PONTO_USERS,
  fromMin,
};
