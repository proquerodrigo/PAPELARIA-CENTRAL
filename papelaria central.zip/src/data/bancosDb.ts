import { newId } from './db';

export type TipoConta = 'Conta corrente' | 'Conta poupança' | 'Conta digital' | 'Conta pagamento';

export interface BancoMovimento {
  id: string;
  contaId: string;
  type: 'entrada' | 'saida' | 'transferencia';
  value: number;
  description: string;
  date: string;
  contaDestinoId?: string;
  createdAt: string;
}

export interface ContaBancaria {
  id: string;
  apelido: string;
  banco: string;
  agencia: string;
  conta: string;
  tipo: TipoConta;
  saldoInicial: number;
  saldoAtual: number;
  ativa: boolean;
  createdAt: string;
}

const KEY_CONTAS = 'pc_v1_bancos_contas';
const KEY_MOVS = 'pc_v1_bancos_movs';

const SEED_CONTAS: ContaBancaria[] = [
  {
    id: 'banco-001', apelido: 'Conta principal — Itaú', banco: 'Itaú Unibanco',
    agencia: '0874', conta: '12345-6', tipo: 'Conta corrente',
    saldoInicial: 15000, saldoAtual: 23480.50, ativa: true,
    createdAt: '2025-06-01T10:00:00.000Z',
  },
  {
    id: 'banco-002', apelido: 'Conta digital — Nubank', banco: 'Nubank',
    agencia: '0001', conta: '987654-3', tipo: 'Conta digital',
    saldoInicial: 5000, saldoAtual: 8750.20, ativa: true,
    createdAt: '2025-06-01T10:00:00.000Z',
  },
  {
    id: 'banco-003', apelido: 'Poupança — Bradesco', banco: 'Bradesco',
    agencia: '1234', conta: '54321-0', tipo: 'Conta poupança',
    saldoInicial: 10000, saldoAtual: 11200.00, ativa: true,
    createdAt: '2025-07-01T10:00:00.000Z',
  },
];

const SEED_MOVS: BancoMovimento[] = [
  { id: newId(), contaId: 'banco-001', type: 'entrada', value: 12500, description: 'Vendas — julho/2025', date: '2025-07-31', createdAt: '2025-07-31T18:00:00.000Z' },
  { id: newId(), contaId: 'banco-001', type: 'saida', value: 3200, description: 'Pagamento fornecedor BIC', date: '2025-08-05', createdAt: '2025-08-05T10:00:00.000Z' },
  { id: newId(), contaId: 'banco-001', type: 'transferencia', value: 2000, description: 'Transferência para poupança', date: '2025-08-10', contaDestinoId: 'banco-003', createdAt: '2025-08-10T09:00:00.000Z' },
  { id: newId(), contaId: 'banco-002', type: 'entrada', value: 5800, description: 'Recebimento Pix — vendas', date: '2025-09-15', createdAt: '2025-09-15T16:00:00.000Z' },
  { id: newId(), contaId: 'banco-001', type: 'saida', value: 1450, description: 'Aluguel — setembro/2025', date: '2025-09-05', createdAt: '2025-09-05T09:00:00.000Z' },
  { id: newId(), contaId: 'banco-003', type: 'entrada', value: 200, description: 'Rendimento poupança', date: '2025-10-01', createdAt: '2025-10-01T08:00:00.000Z' },
];

export const bancosDb = {
  contas: {
    all(): ContaBancaria[] {
      try {
        const raw = localStorage.getItem(KEY_CONTAS);
        if (raw) return JSON.parse(raw) as ContaBancaria[];
      } catch {}
      localStorage.setItem(KEY_CONTAS, JSON.stringify(SEED_CONTAS));
      return [...SEED_CONTAS];
    },
    findById(id: string): ContaBancaria | undefined {
      return this.all().find(c => c.id === id);
    },
    add(c: ContaBancaria): void {
      const all = this.all();
      localStorage.setItem(KEY_CONTAS, JSON.stringify([...all, c]));
    },
    update(id: string, patch: Partial<ContaBancaria>): void {
      const all = this.all().map(c => c.id === id ? { ...c, ...patch } : c);
      localStorage.setItem(KEY_CONTAS, JSON.stringify(all));
    },
    remove(id: string): void {
      localStorage.setItem(KEY_CONTAS, JSON.stringify(this.all().filter(c => c.id !== id)));
    },
  },
  movimentos: {
    all(): BancoMovimento[] {
      try {
        const raw = localStorage.getItem(KEY_MOVS);
        if (raw) return JSON.parse(raw) as BancoMovimento[];
      } catch {}
      localStorage.setItem(KEY_MOVS, JSON.stringify(SEED_MOVS));
      return [...SEED_MOVS];
    },
    byConta(contaId: string): BancoMovimento[] {
      return this.all().filter(m => m.contaId === contaId || m.contaDestinoId === contaId);
    },
    add(m: BancoMovimento): void {
      const all = this.all();
      localStorage.setItem(KEY_MOVS, JSON.stringify([...all, m]));
    },
  },
  saldoTotal(): number {
    return this.contas.all().filter(c => c.ativa).reduce((s, c) => s + c.saldoAtual, 0);
  },
};
