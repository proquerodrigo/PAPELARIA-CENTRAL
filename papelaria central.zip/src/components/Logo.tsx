import { C } from '../theme';

// ==========================================
// LOGO DA PAPELARIA CENTRAL
// SUBSTITUA O ARQUIVO /public/logo-papelaria.png PELO PNG REAL DA SUA EMPRESA
// Tamanho recomendado: 400x120px, fundo transparente
// ==========================================

interface LogoProps {
  variant?: 'dark' | 'light';
}

export default function Logo({ variant = 'light' }: LogoProps) {
  const isDark = variant === 'dark';

  return (
    <img
      src="/logo-papelaria.png"
      alt="Papelaria Central"
      style={{ height: 36, maxWidth: '100%', objectFit: 'contain', display: 'block' }}
      onError={e => {
        // Fallback: substitui pela placa de texto caso o PNG não exista
        const img = e.currentTarget;
        img.style.display = 'none';
        const fallback = img.nextElementSibling as HTMLElement | null;
        if (fallback) fallback.style.display = 'flex';
      }}
    />
  );
}

// Componente de fallback embutido para usar junto com Logo
export function LogoWithFallback({ variant = 'light' }: LogoProps) {
  const isDark = variant === 'dark';
  // Check localStorage override first (set via Identidade Visual page)
  const b64Override = localStorage.getItem('pc_v1_logo_b64');
  const imgSrc = b64Override || '/logo-papelaria.png';

  return (
    <div style={{ position: 'relative' }}>
      <img
        src={imgSrc}
        alt="Papelaria Central"
        style={{ height: isDark ? 48 : 52, maxWidth: '100%', objectFit: 'contain', display: 'block' }}
        onError={e => {
          const img = e.currentTarget;
          img.style.display = 'none';
          const fallback = img.nextElementSibling as HTMLElement | null;
          if (fallback) fallback.style.removeProperty('display');
        }}
      />
      {/* Placeholder exibido enquanto o PNG real não existe */}
      <div style={{
        display: 'none',
        height: isDark ? 48 : 52,
        border: isDark ? '1px dashed rgba(255,255,255,0.2)' : `1px dashed ${C.border}`,
        borderRadius: 4,
        alignItems: 'center',
        justifyContent: 'center',
        padding: '0 12px',
        background: isDark ? 'rgba(255,255,255,0.04)' : C.white,
      }}>
        <span style={{
          fontSize: 10,
          color: isDark ? 'rgba(255,255,255,0.25)' : '#B0BEC5',
          letterSpacing: '0.06em',
          textTransform: 'uppercase' as const,
          fontFamily: 'Inter, sans-serif',
        }}>
          Espaço reservado para logotipo
        </span>
      </div>
    </div>
  );
}
