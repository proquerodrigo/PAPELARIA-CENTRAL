import { useState } from 'react';

interface AppLogoProps {
  height?: number;
  variant?: 'dark' | 'light';
}

export function AppLogo({ height = 36, variant = 'dark' }: AppLogoProps) {
  const [failed, setFailed] = useState(false);

  if (!failed) {
    return (
      <img
        src="/logo-papelaria.png"
        alt="Papelaria Central"
        height={height}
        style={{ display: 'block', maxHeight: height, objectFit: 'contain' }}
        onError={() => setFailed(true)}
      />
    );
  }

  const isDark = variant === 'dark';
  return (
    <div style={{
      height,
      border: `1px dashed ${isDark ? 'rgba(255,255,255,0.15)' : '#C5CDD6'}`,
      borderRadius: 3,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      minWidth: 120,
    }}>
      <span style={{
        fontSize: 10,
        color: isDark ? 'rgba(255,255,255,0.25)' : '#9BA8B5',
        letterSpacing: '0.05em',
        textTransform: 'uppercase',
        fontFamily: 'Inter, sans-serif',
      }}>
        Logotipo
      </span>
    </div>
  );
}
