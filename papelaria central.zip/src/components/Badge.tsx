export function Badge({ style, children }: { style: React.CSSProperties; children: React.ReactNode }) {
  return (
    <span style={{
      ...style,
      display: 'inline-block',
      padding: '1px 7px',
      borderRadius: 3,
      fontSize: 11,
      fontWeight: 500,
      lineHeight: '18px',
    }}>
      {children}
    </span>
  );
}
