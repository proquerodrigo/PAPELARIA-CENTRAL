import { useState } from 'react';
import { NavLink, Outlet, useNavigate, useLocation, Navigate } from 'react-router';
import { useApp } from '../context/AppContext';
import { LogoWithFallback } from '../components/Logo';

/* ── Sidebar graphite palette ────────────────────── */
const SB_BG      = '#1D2129';    /* dark graphite / charcoal steel */
const SB_ACTIVE  = 'rgba(255,255,255,0.10)';
const SB_ACCENT  = '#6DBA8C';    /* muted green — active indicator only */
const SB_TEXT    = 'rgba(255,255,255,0.58)';
const SB_ACT_TXT = '#FFFFFF';
const SB_DIV     = 'rgba(255,255,255,0.08)';

const navItems = [
  { to: '/dashboard',             label: 'Dashboard',           adminOnly: false },
  { to: '/produtos',              label: 'Produtos',            adminOnly: false },
  { to: '/categorias',            label: 'Categorias',          adminOnly: false },
  { to: '/clientes',              label: 'Clientes',            adminOnly: false },
  { to: '/funcionarios',          label: 'Funcionários',        adminOnly: false },
  { to: '/estoque',               label: 'Estoque',             adminOnly: false },
  { to: '/estoque/movimentacoes', label: 'Movimentações',       adminOnly: false },
  { to: '/ponto',                 label: 'Folha de Ponto',      adminOnly: false },
  { to: '/caixa',                 label: 'Caixa',               adminOnly: false },
  { to: '/vendas',                label: 'Vendas (PDV)',         adminOnly: false },
  { to: '/whatsapp-pedidos',      label: 'WhatsApp Pedidos',    adminOnly: false },
  { to: '/fornecedores',          label: 'Fornecedores',        adminOnly: true  },
  { to: '/compras',               label: 'Compras / NF',        adminOnly: true  },
  { to: '/usuarios',              label: 'Usuários',            adminOnly: false },
  { to: '/auditoria',             label: 'Auditoria',           adminOnly: true  },
  { to: '/financeiro',            label: 'Financeiro',          adminOnly: true  },
];

const pageTitles: Record<string, string> = {
  '/dashboard':                'Dashboard',
  '/produtos':                 'Produtos',
  '/produtos/novo':            'Novo Produto',
  '/categorias':               'Categorias',
  '/clientes':                 'Clientes',
  '/funcionarios':             'Funcionários',
  '/estoque':                  'Estoque',
  '/estoque/movimentacoes':    'Movimentações',
  '/usuarios':                 'Usuários',
  '/configuracoes':            'Configurações',
  '/ponto':                    'Folha de Ponto',
  '/caixa':                    'Caixa',
  '/whatsapp-pedidos':         'WhatsApp — Pedidos para Retirada',
  '/fornecedores':             'Fornecedores',
  '/auditoria':                'Auditoria — Histórico de Ações',
  '/compras':                  'Compras / Entrada de NF',
  '/financeiro':               'Financeiro',
  '/financeiro/fluxo':         'Financeiro — Fluxo de caixa',
  '/financeiro/receitas':      'Financeiro — Receitas',
  '/financeiro/despesas':      'Financeiro — Despesas',
  '/financeiro/folha':         'Financeiro — Folha de pagamento',
  '/financeiro/pedidos':       'Financeiro — Pedidos',
  '/financeiro/contas':        'Financeiro — Contas pendentes',
  '/financeiro/custos':        'Financeiro — Custos e margens',
  '/financeiro/receber':       'Financeiro — Contas a Receber',
  '/financeiro/relatorios':    'Financeiro — Relatórios',
  '/financeiro/config':        'Financeiro — Configurações financeiras',
  '/financeiro/identidade':    'Financeiro — Identidade Visual',
};

function SidebarContent({ onClose }: { onClose?: () => void }) {
  const { user, logout } = useApp();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
    onClose?.();
  };

  const navStyle = ({ isActive }: { isActive: boolean }): React.CSSProperties => ({
    display: 'block',
    padding: '8px 16px',
    fontSize: 13,
    color: isActive ? SB_ACT_TXT : SB_TEXT,
    background: isActive ? SB_ACTIVE : 'transparent',
    borderLeft: isActive ? `2px solid ${SB_ACCENT}` : '2px solid transparent',
    fontWeight: isActive ? 500 : 400,
    cursor: 'pointer',
    transition: 'color 0.1s, background 0.1s',
    lineHeight: 1.45,
  });

  return (
    <>
      {/* Brand / logo */}
      <div style={{ padding: '16px 16px 12px', borderBottom: `1px solid ${SB_DIV}` }}>
        <LogoWithFallback variant="dark" />
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
        {navItems.filter(item => !item.adminOnly || user?.role === 'admin').map(({ to, label, adminOnly }) => (
          <div key={to}>
            {adminOnly && label === 'Fornecedores' && (
              <>
                <div style={{ margin: '6px 16px', borderTop: `1px solid ${SB_DIV}` }} />
                <div style={{ padding: '4px 16px 2px', fontSize: 10, color: 'rgba(255,255,255,0.28)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                  Admin
                </div>
              </>
            )}
            <NavLink
              to={to}
              end={to === '/estoque'}
              onClick={() => onClose?.()}
              style={navStyle}
            >
              {label}
            </NavLink>
          </div>
        ))}

        <div style={{ margin: '8px 16px', borderTop: `1px solid ${SB_DIV}` }} />
        <NavLink to="/configuracoes" onClick={() => onClose?.()} style={navStyle}>
          Configurações
        </NavLink>
      </nav>

      {/* User footer */}
      <div style={{ borderTop: `1px solid ${SB_DIV}`, padding: '10px 16px' }}>
        <div style={{ fontSize: 12, fontWeight: 500, color: '#CBD5E1', marginBottom: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {user?.name}
        </div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.32)', marginBottom: 8 }}>
          {user?.role === 'admin' ? 'Administrador' : 'Funcionário'}
        </div>
        <button
          onClick={handleLogout}
          style={{ fontSize: 12, color: 'rgba(255,255,255,0.4)', background: 'none', border: 'none', cursor: 'pointer', padding: 0, fontFamily: 'Inter, sans-serif' }}
        >
          Sair
        </button>
      </div>
    </>
  );
}

export default function AppLayout() {
  const { user } = useApp();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const title = pageTitles[location.pathname]
    ?? (location.pathname.includes('/editar') ? 'Editar Produto' : 'Sistema');

  if (!user) return <Navigate to="/" replace />;

  const SIDEBAR_W = 206;

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>

      {/* ── Mobile overlay ── */}
      {mobileOpen && (
        <div
          className="sidebar-overlay open"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* ── Sidebar ── */}
      <aside
        className="sidebar-drawer"
        style={{
          width: SIDEBAR_W,
          flexShrink: 0,
          background: SB_BG,
          display: 'flex',
          flexDirection: 'column',
          height: '100vh',
          overflow: 'hidden',
          /* subtle metallic sheen — very thin lighter left edge */
          borderRight: '1px solid rgba(255,255,255,0.04)',
        }}
      >
        <SidebarContent onClose={() => setMobileOpen(false)} />
      </aside>

      {/* ── Main ── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', minWidth: 0 }}>
        {/* Header */}
        <header style={{
          height: 48,
          background: '#fff',
          borderBottom: '1px solid #E5E7EB',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 20px',
          flexShrink: 0,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {/* Hamburger for mobile */}
            <button
              className="mobile-menu-btn"
              onClick={() => setMobileOpen(v => !v)}
              style={{
                display: 'none',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                padding: 4,
                color: '#374151',
                alignItems: 'center',
              }}
              aria-label="Abrir menu"
            >
              <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
            <span style={{ fontSize: 14, fontWeight: 600, color: '#101828' }}>{title}</span>
          </div>
          <div style={{ fontSize: 12, color: '#6B7280', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', maxWidth: 200 }}>
            {user?.name} &nbsp;·&nbsp; {user?.role === 'admin' ? 'Adm.' : 'Func.'}
          </div>
        </header>

        {/* Content */}
        <main
          className="page-content-inner"
          style={{ flex: 1, overflowY: 'auto', padding: 22, background: '#F1F3F5' }}
        >
          <Outlet />
        </main>

        {/* Footer */}
        <footer style={{
          height: 32,
          background: '#fff',
          borderTop: '1px solid #E5E7EB',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          flexShrink: 0,
          fontSize: 11,
          color: '#9CA3AF',
          letterSpacing: '0.02em',
        }}>
          Papelaria Central © 2026 &nbsp;·&nbsp; Sistema de Gestão — v1.0.0
        </footer>
      </div>
    </div>
  );
}
